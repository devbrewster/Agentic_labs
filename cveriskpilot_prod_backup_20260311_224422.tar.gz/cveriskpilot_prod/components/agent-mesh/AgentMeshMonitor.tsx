"use client";

import { useEffect, useRef, useState } from "react";

import { SurfaceCard } from "@/components/dashboard/SurfaceCard";
import { StatusPill } from "@/components/dashboard/StatusPill";
import type { AgentMeshMonitorSnapshot, AgentMeshStatus } from "@/types/agent-mesh";

type AgentMeshResponse = {
  ok: boolean;
  data?: AgentMeshMonitorSnapshot;
  error?: {
    message?: string;
  };
};

type ActivityFeedEntry = {
  id: string;
  timestamp: string;
  agent: string;
  message: string;
};

function statusTone(status: AgentMeshStatus["status"] | "pending") {
  if (status === "running") {
    return "accent";
  }

  if (status === "failed") {
    return "danger";
  }

  if (status === "completed" || status === "dry_run_complete") {
    return "success";
  }

  if (status === "pending") {
    return "warning";
  }

  return "default";
}

function formatTimestamp(value?: string | null) {
  if (!value) {
    return "n/a";
  }

  return value.replace("T", " ").replace("Z", " UTC");
}

function formatBytes(value: number) {
  if (!value) {
    return "0 B";
  }

  if (value < 1024) {
    return `${value} B`;
  }

  if (value < 1024 * 1024) {
    return `${(value / 1024).toFixed(1)} KB`;
  }

  return `${(value / (1024 * 1024)).toFixed(1)} MB`;
}

export function AgentMeshMonitor() {
  const [snapshot, setSnapshot] = useState<AgentMeshMonitorSnapshot | null>(null);
  const [activityFeed, setActivityFeed] = useState<ActivityFeedEntry[]>([]);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(true);
  const seenLogVersions = useRef<Record<string, string>>({});

  function updateActivityFeed(data: AgentMeshMonitorSnapshot) {
    setActivityFeed((previous) => {
      const next = [...previous];

      for (const log of data.logs) {
        const versionToken = `${log.updatedAt ?? "none"}|${log.tail.length}|${log.tail.at(-1) ?? ""}`;
        const priorToken = seenLogVersions.current[log.fileName];

        if (priorToken === versionToken) {
          continue;
        }

        seenLogVersions.current[log.fileName] = versionToken;
        const recentLines = log.tail.slice(-4).filter(Boolean);
        const agent = log.fileName.split("-")[0] ?? "agent";

        for (const [index, line] of recentLines.entries()) {
          next.push({
            id: `${log.fileName}:${log.updatedAt ?? "none"}:${index}:${line.slice(0, 24)}`,
            timestamp: log.updatedAt ?? data.generatedAt,
            agent,
            message: line,
          });
        }
      }

      return next.slice(-240);
    });
  }

  useEffect(() => {
    let cancelled = false;

    async function loadSnapshot() {
      try {
        const response = await fetch("/api/agent-mesh", {
          cache: "no-store",
        });
        const json = (await response.json()) as AgentMeshResponse;

        if (cancelled) {
          return;
        }

        if (!response.ok || !json.ok || !json.data) {
          throw new Error(json.error?.message ?? "Unable to load agent mesh monitor.");
        }

        setSnapshot(json.data);
        updateActivityFeed(json.data);
        setError(null);
      } catch (loadError) {
        if (cancelled) {
          return;
        }

        setError(
          loadError instanceof Error
            ? loadError.message
            : "Unable to load agent mesh monitor.",
        );
      } finally {
        if (!cancelled) {
          setLoading(false);
        }
      }
    }

    void loadSnapshot();
    const intervalId = window.setInterval(() => {
      void loadSnapshot();
    }, 4000);

    return () => {
      cancelled = true;
      window.clearInterval(intervalId);
    };
  }, []);

  return (
    <div className="space-y-6">
      <SurfaceCard
        eyebrow="// Local Agent Mesh"
        title="Codex Mesh Monitor"
        description="Local-only monitor for the autonomous multi-agent run. Refreshes automatically every 4 seconds."
        meta={
          snapshot ? (
            <div className="text-right">
              <div className="font-mono text-[0.62rem] uppercase tracking-[0.12em] text-[var(--accent)]">
                Current phase
              </div>
              <div className="mt-1 text-[0.92rem] font-semibold text-white">
                {snapshot.currentPhase}
              </div>
            </div>
          ) : null
        }
      >
        {loading && !snapshot ? (
          <div className="font-mono text-[0.72rem] uppercase tracking-[0.12em] text-[#5a7080]">
            Loading monitor state...
          </div>
        ) : null}

        {error ? (
          <div className="rounded border border-[rgba(255,69,96,0.24)] bg-[rgba(255,69,96,0.08)] px-4 py-3 text-[0.82rem] text-[var(--danger)]">
            {error}
          </div>
        ) : null}

        {snapshot ? (
          <div className="grid gap-3 md:grid-cols-4">
            <div className="rounded border border-[rgba(0,200,180,0.08)] bg-[#040810] p-4">
              <div className="font-mono text-[0.6rem] uppercase tracking-[0.12em] text-[#5a7080]">
                Generated
              </div>
              <div className="mt-2 text-[0.82rem] text-white">
                {formatTimestamp(snapshot.generatedAt)}
              </div>
            </div>
            <div className="rounded border border-[rgba(0,200,180,0.08)] bg-[#040810] p-4">
              <div className="font-mono text-[0.6rem] uppercase tracking-[0.12em] text-[#5a7080]">
                Running
              </div>
              <div className="mt-2 text-[1.1rem] font-black text-[var(--accent)]">
                {snapshot.runningCount}
              </div>
            </div>
            <div className="rounded border border-[rgba(0,200,180,0.08)] bg-[#040810] p-4">
              <div className="font-mono text-[0.6rem] uppercase tracking-[0.12em] text-[#5a7080]">
                Completed
              </div>
              <div className="mt-2 text-[1.1rem] font-black text-white">
                {snapshot.completedCount}
              </div>
            </div>
            <div className="rounded border border-[rgba(0,200,180,0.08)] bg-[#040810] p-4">
              <div className="font-mono text-[0.6rem] uppercase tracking-[0.12em] text-[#5a7080]">
                Failed
              </div>
              <div className="mt-2 text-[1.1rem] font-black text-[var(--danger)]">
                {snapshot.failedCount}
              </div>
            </div>
          </div>
        ) : null}
      </SurfaceCard>

      <SurfaceCard
        eyebrow="// Mesh Phases"
        title="Execution Timeline"
        description="Tracks each mesh phase in order and current task completion."
      >
        <div className="grid gap-3 lg:grid-cols-4">
          {snapshot?.phaseStates.map((phaseState) => (
            <div
              key={phaseState.phase}
              className="rounded border border-[rgba(0,200,180,0.08)] bg-[#040810] p-4"
            >
              <div className="flex items-center justify-between gap-2">
                <div className="font-mono text-[0.64rem] uppercase tracking-[0.12em] text-[var(--accent)]">
                  {phaseState.label}
                </div>
                <StatusPill tone={statusTone(phaseState.status)}>
                  {phaseState.status}
                </StatusPill>
              </div>
              <div className="mt-3 flex flex-wrap items-center gap-2 text-[0.72rem] text-[var(--text-dim)]">
                <span>{phaseState.completedTasks}/{phaseState.totalTasks} complete</span>
                <span>run: {phaseState.runningTasks}</span>
                <span>fail: {phaseState.failedTasks}</span>
              </div>
            </div>
          ))}
        </div>
      </SurfaceCard>

      <SurfaceCard
        eyebrow="// Agent Status"
        title="Phase Status Files"
        description="Direct view of the current `.codex/state/*.status` files driving the mesh."
      >
        <div className="grid gap-3 lg:grid-cols-2">
          {snapshot?.statuses.map((status) => (
            <div
              key={status.fileName}
              className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4"
            >
              <div className="flex flex-wrap items-center gap-2">
                <div className="font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[var(--accent)]">
                  {status.agent}
                </div>
                <StatusPill tone={statusTone(status.status)}>
                  {status.status}
                </StatusPill>
                <StatusPill>{status.phase}</StatusPill>
              </div>
              <div className="mt-3 space-y-1 text-[0.76rem] leading-6 text-[var(--text-dim)]">
                <div>Started: {formatTimestamp(status.startedAt)}</div>
                <div>Completed: {formatTimestamp(status.completedAt)}</div>
                <div>Failed: {formatTimestamp(status.failedAt)}</div>
                <div className="truncate">Output: {status.output ?? "n/a"}</div>
                <div className="truncate">Log: {status.log ?? "n/a"}</div>
              </div>
            </div>
          ))}
        </div>
      </SurfaceCard>

      <SurfaceCard
        eyebrow="// Live Feed"
        title="Runtime Activity Stream"
        description="Rolling feed of log activity while the mesh is running."
      >
        <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#02050c] p-3">
          <div className="max-h-[26rem] overflow-auto">
            <div className="space-y-2 font-mono text-[0.68rem] leading-6 text-[#9cb9c7]">
              {activityFeed.length === 0 ? (
                <div className="text-[var(--text-dim)]">No runtime activity captured yet.</div>
              ) : (
                activityFeed.map((entry) => (
                  <div
                    key={entry.id}
                    className="rounded border border-[rgba(0,200,180,0.05)] bg-[#040810] px-3 py-2"
                  >
                    <div className="mb-1 flex items-center gap-2 text-[0.62rem] uppercase tracking-[0.12em] text-[var(--accent)]">
                      <span>{entry.agent}</span>
                      <span className="text-[#5a7080]">{formatTimestamp(entry.timestamp)}</span>
                    </div>
                    <div className="whitespace-pre-wrap break-words text-[#9cb9c7]">{entry.message}</div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>
      </SurfaceCard>

      <SurfaceCard
        eyebrow="// Output Files"
        title="Report Artifacts"
        description="Tracks whether the mesh is writing markdown outputs into the expected locations."
      >
        <div className="grid gap-4 xl:grid-cols-3">
          {(
            [
              ["Individual", snapshot?.reports.individual ?? []],
              ["Cross Review", snapshot?.reports.crossReview ?? []],
              ["Final", snapshot?.reports.final ?? []],
            ] as Array<[string, AgentMeshMonitorSnapshot["reports"]["individual"]]>
          ).map(([label, reports]) => (
            <div
              key={label}
              className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4"
            >
              <div className="font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[var(--accent)]">
                {label}
              </div>
              <div className="mt-3 space-y-3">
                {reports.map((report) => (
                  <div
                    key={report.path}
                    className="border-b border-[rgba(0,200,180,0.04)] pb-3 last:border-b-0 last:pb-0"
                  >
                    <div className="truncate text-[0.76rem] text-white">{report.path}</div>
                    <div className="mt-1 flex flex-wrap items-center gap-2 text-[0.72rem] text-[var(--text-dim)]">
                      <StatusPill tone={report.exists ? "success" : "default"}>
                        {report.exists ? "exists" : "missing"}
                      </StatusPill>
                      <span>{formatBytes(report.sizeBytes)}</span>
                      <span>{formatTimestamp(report.updatedAt)}</span>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
      </SurfaceCard>

      <SurfaceCard
        eyebrow="// Log Tails"
        title="Per-Agent Logs"
        description="Last 16 lines from each `.codex/state/logs/*.log` file."
      >
        <div className="grid gap-4 xl:grid-cols-2">
          {snapshot?.logs.map((log) => (
            <div
              key={log.fileName}
              className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="truncate font-mono text-[0.66rem] uppercase tracking-[0.12em] text-[var(--accent)]">
                  {log.fileName}
                </div>
                <div className="shrink-0 text-[0.68rem] text-[var(--text-dim)]">
                  {formatTimestamp(log.updatedAt)}
                </div>
              </div>
              <pre className="mt-3 max-h-80 overflow-auto whitespace-pre-wrap break-words rounded border border-[rgba(0,200,180,0.04)] bg-[rgba(0,0,0,0.18)] p-3 font-mono text-[0.68rem] leading-6 text-[#b7d1de]">
                {log.tail.length ? log.tail.join("\n") : "No log output yet."}
              </pre>
            </div>
          ))}
        </div>
      </SurfaceCard>
    </div>
  );
}
