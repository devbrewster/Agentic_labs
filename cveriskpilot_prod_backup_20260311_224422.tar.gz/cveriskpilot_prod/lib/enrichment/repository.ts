import {
  EnrichmentRunSchema,
  EnrichmentRunWithSnapshotsSchema,
  FindingEnrichmentSnapshotSchema,
  type EnrichmentRun,
  type EnrichmentRunWithSnapshots,
  type FindingEnrichmentSnapshot,
} from "@/types/enrichment";

export type EnrichmentRepository = {
  createRun(run: EnrichmentRun): Promise<void>;
  updateRun(run: EnrichmentRun): Promise<void>;
  findRunById(runId: string): Promise<EnrichmentRunWithSnapshots | null>;
  findLatestRunByUploadJobId(uploadJobId: string): Promise<EnrichmentRunWithSnapshots | null>;
  listSnapshotsByFindingId(findingId: string): Promise<FindingEnrichmentSnapshot[]>;
  replaceSnapshotsForRun(
    runId: string,
    snapshots: FindingEnrichmentSnapshot[],
  ): Promise<void>;
};

export class InMemoryEnrichmentRepository implements EnrichmentRepository {
  private readonly runs = new Map<string, EnrichmentRun>();
  private readonly snapshotsByRunId = new Map<string, FindingEnrichmentSnapshot[]>();

  async createRun(run: EnrichmentRun) {
    this.runs.set(run.id, EnrichmentRunSchema.parse(run));
    this.snapshotsByRunId.set(run.id, []);
  }

  async updateRun(run: EnrichmentRun) {
    this.runs.set(run.id, EnrichmentRunSchema.parse(run));
  }

  async findRunById(runId: string) {
    const run = this.runs.get(runId);

    if (!run) {
      return null;
    }

    return EnrichmentRunWithSnapshotsSchema.parse({
      run,
      snapshots: this.snapshotsByRunId.get(runId) ?? [],
    });
  }

  async findLatestRunByUploadJobId(uploadJobId: string) {
    const candidates = Array.from(this.runs.values())
      .filter((run) => run.uploadJobId === uploadJobId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

    const latest = candidates[0];

    if (!latest) {
      return null;
    }

    return EnrichmentRunWithSnapshotsSchema.parse({
      run: latest,
      snapshots: this.snapshotsByRunId.get(latest.id) ?? [],
    });
  }

  async replaceSnapshotsForRun(runId: string, snapshots: FindingEnrichmentSnapshot[]) {
    this.snapshotsByRunId.set(
      runId,
      snapshots.map((snapshot) => FindingEnrichmentSnapshotSchema.parse(snapshot)),
    );
  }

  async listSnapshotsByFindingId(findingId: string) {
    const allSnapshots = Array.from(this.snapshotsByRunId.values()).flat();
    return allSnapshots
      .filter((snapshot) => snapshot.findingId === findingId)
      .sort((a, b) => b.createdAt.localeCompare(a.createdAt))
      .map((snapshot) => FindingEnrichmentSnapshotSchema.parse(snapshot));
  }
}
