import { describe, expect, it } from "vitest";

import { PostgresUploadRepository } from "@/lib/ingestion/postgres-repository";
import type { PostgresQueryClient } from "@/lib/platform/database";

describe("PostgresUploadRepository", () => {
  it("maps upload records through the shared SQL repository implementation", async () => {
    const tenantId = crypto.randomUUID();
    const uploadJobId = crypto.randomUUID();
    const rawArtifactId = crypto.randomUUID();
    const findingId = crypto.randomUUID();

    const client: PostgresQueryClient = {
      async query<T>(sql: string, params?: readonly unknown[]) {
        if (sql.includes("FROM upload_jobs uj") && sql.includes("WHERE uj.id = $1 AND uj.tenant_id = $2")) {
          expect(params).toEqual([uploadJobId, tenantId]);

          return {
            rows: [
              {
                id: uploadJobId,
                tenant_id: tenantId,
                raw_artifact_id: rawArtifactId,
                selected_source_type: "generic_csv",
                detected_source_type: "generic_csv",
                status: "parsed",
                error_summary: null,
                warning_count: 0,
                finding_count: 1,
                checksum_sha256: "a".repeat(64),
                created_at: "2026-03-11T12:00:00.000Z",
                updated_at: "2026-03-11T12:05:00.000Z",
                parsed_at: "2026-03-11T12:05:00.000Z",
                storage_key: "uploads/example.csv",
                original_filename: "example.csv",
                mime_type: "text/csv",
                file_type: "csv",
                size_bytes: 123,
                uploaded_at: "2026-03-11T12:00:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        if (sql.includes("FROM parse_outcomes")) {
          expect(params).toEqual([uploadJobId]);

          return {
            rows: [
              {
                upload_job_id: uploadJobId,
                metadata_json: JSON.stringify({
                  scannerName: "Generic CSV",
                  scannerVersion: null,
                  sourceType: "generic_csv",
                  fileType: "csv",
                  hostCount: 1,
                  findingCount: 1,
                  parsedAt: "2026-03-11T12:05:00.000Z",
                  checksumSha256: "a".repeat(64),
                }),
                warnings_json: "[]",
                errors_json: "[]",
                updated_at: "2026-03-11T12:05:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        if (sql.includes("FROM normalized_findings") && sql.includes("WHERE upload_job_id = $1")) {
          expect(params).toEqual([uploadJobId]);

          return {
            rows: [
              {
                id: findingId,
                upload_job_id: uploadJobId,
                raw_record_ref_json: JSON.stringify({
                  recordId: "row-1",
                  recordIndex: 0,
                  locationHint: "line 2",
                  sourceChecksumSha256: "a".repeat(64),
                }),
                asset_identifier: "server-1",
                hostname: "server-1",
                fqdn: "server-1.example.com",
                ip_address: "10.0.0.5",
                port: 443,
                protocol: "tcp",
                vulnerability_id: "vuln-1",
                plugin_id: null,
                cve_ids_json: JSON.stringify(["CVE-2026-0001"]),
                title: "Example finding",
                description: "Example description",
                severity: "high",
                normalized_severity: "high",
                cvss_score: 8.1,
                cvss_vector: null,
                remediation: "Patch it",
                evidence: null,
                status: "open",
                privilege_required: "low",
                detected_at: "2026-03-11T12:00:00.000Z",
                first_observed_at: null,
                last_observed_at: null,
                source_type: "generic_csv",
                source_scanner: "Generic CSV",
                tags_json: JSON.stringify(["internet"]),
                created_at: "2026-03-11T12:05:00.000Z",
                updated_at: "2026-03-11T12:05:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        if (sql.includes("FROM normalized_findings nf") && sql.includes("WHERE nf.id = $1 AND uj.tenant_id = $2")) {
          expect(params).toEqual([findingId, tenantId]);

          return {
            rows: [
              {
                id: findingId,
                upload_job_id: uploadJobId,
                raw_record_ref_json: JSON.stringify({
                  recordId: "row-1",
                  recordIndex: 0,
                  locationHint: "line 2",
                  sourceChecksumSha256: "a".repeat(64),
                }),
                asset_identifier: "server-1",
                hostname: "server-1",
                fqdn: "server-1.example.com",
                ip_address: "10.0.0.5",
                port: 443,
                protocol: "tcp",
                vulnerability_id: "vuln-1",
                plugin_id: null,
                cve_ids_json: JSON.stringify(["CVE-2026-0001"]),
                title: "Example finding",
                description: "Example description",
                severity: "high",
                normalized_severity: "high",
                cvss_score: 8.1,
                cvss_vector: null,
                remediation: "Patch it",
                evidence: null,
                status: "open",
                privilege_required: "low",
                detected_at: "2026-03-11T12:00:00.000Z",
                first_observed_at: null,
                last_observed_at: null,
                source_type: "generic_csv",
                source_scanner: "Generic CSV",
                tags_json: JSON.stringify(["internet"]),
                created_at: "2026-03-11T12:05:00.000Z",
                updated_at: "2026-03-11T12:05:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        throw new Error(`Unexpected SQL in test client: ${sql}`);
      },
    };

    const repository = new PostgresUploadRepository(client);
    const record = await repository.findByIdForTenant(uploadJobId, tenantId);
    const finding = await repository.findFindingByIdForTenant(findingId, tenantId);

    expect(record?.uploadJob.id).toBe(uploadJobId);
    expect(record?.rawArtifact.id).toBe(rawArtifactId);
    expect(record?.outcome?.findings).toHaveLength(1);
    expect(finding?.id).toBe(findingId);
  });
});
