import Link from "next/link";

import { getDashboardHref } from "@/lib/app-routes";
import { DataSourceBadge } from "@/components/DataSourceBadge";
import { NvdNotice } from "@/components/NvdNotice";

const sources = [
  {
    title: "NVD",
    detail:
      "Canonical CVE metadata including descriptions, CVSS vectors, publication timestamps, weaknesses, and references.",
    badge: "Source: NVD",
    tone: "nvd" as const,
  },
  {
    title: "CVERiskPilot Analysis",
    detail:
      "Generated narratives and prioritization from CVERiskPilot logic and AI workflows. This is separate from original NVD content.",
    badge: "Source: CVERiskPilot AI Analysis",
    tone: "analysis" as const,
  },
  {
    title: "Other Enrichment Sources",
    detail:
      "KEV, EPSS, vendor advisories, scanner context, and enterprise architecture context are merged as independent enrichment layers.",
    badge: "Source: KEV / Vendor / EPSS",
    tone: "enrichment" as const,
  },
];

export default function AboutPage() {
  return (
    <main className="min-h-screen bg-[#040810] px-6 py-10 text-[#c8d8e8]">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8 flex items-center justify-between gap-3">
          <h1 className="text-3xl font-black tracking-[-0.02em] text-white">
            About / Data Sources
          </h1>
          <Link
            href={getDashboardHref("overview")}
            className="rounded border border-[rgba(0,200,180,0.22)] px-3 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[#89b7c2] transition hover:border-[#00c8b4] hover:text-[#00f5dd]"
          >
            Back to Dashboard
          </Link>
        </div>

        <NvdNotice className="mb-6" />

        <div className="rounded border border-[rgba(0,200,180,0.08)] bg-[#070e1a] p-5">
          <p className="text-sm leading-7 text-[#c8d8e8]">
            CVERiskPilot combines public vulnerability intelligence with platform-generated
            risk analysis. Original source data and generated analysis are intentionally
            separated to avoid confusion between authoritative records and derived guidance.
          </p>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {sources.map((source) => (
            <section
              key={source.title}
              className="rounded border border-[rgba(0,200,180,0.08)] bg-[#070e1a] p-4"
            >
              <div className="mb-2">
                <DataSourceBadge label={source.badge} tone={source.tone} />
              </div>
              <h2 className="text-lg font-semibold text-white">{source.title}</h2>
              <p className="mt-2 text-sm leading-7 text-[#95aaba]">{source.detail}</p>
            </section>
          ))}
        </div>

        <div className="mt-6 rounded border border-[rgba(0,200,180,0.08)] bg-[#070e1a] p-5">
          <h3 className="font-mono text-[0.74rem] uppercase tracking-[0.11em] text-[#9ddad3]">
            Compliance Summary
          </h3>
          <ul className="mt-3 list-disc space-y-2 pl-5 text-sm text-[#b8cdd9]">
            <li>NVD attribution notice is displayed in the app footer and CVE context surfaces.</li>
            <li>No UI language may imply endorsement, certification, or approval by NVD.</li>
            <li>Generated AI content is rendered in separate sections from original source data.</li>
          </ul>
        </div>
      </div>
    </main>
  );
}
