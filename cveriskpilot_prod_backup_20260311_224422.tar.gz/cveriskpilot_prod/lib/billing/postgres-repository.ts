import type { PostgresQueryClient } from "@/lib/platform/database";
import { PostgresAppDatabase } from "@/lib/platform/database";
import { SqlBillingRepository } from "@/lib/billing/sql-repository";

export class PostgresBillingRepository extends SqlBillingRepository {
  constructor(client: PostgresQueryClient) {
    super(new PostgresAppDatabase(client));
  }
}
