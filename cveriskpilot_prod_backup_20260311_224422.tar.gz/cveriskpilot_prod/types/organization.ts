import { z } from "zod";

export const OrganizationIdSchema = z.string().uuid();
export type OrganizationId = z.infer<typeof OrganizationIdSchema>;

export const OrganizationSlugSchema = z
  .string()
  .min(3)
  .max(64)
  .regex(/^[a-z0-9-]+$/, "Organization slug must use lowercase letters, numbers, and dashes.");
export type OrganizationSlug = z.infer<typeof OrganizationSlugSchema>;

export const OrganizationRoleSchema = z.enum([
  "owner",
  "admin",
  "analyst",
  "viewer",
]);
export type OrganizationRole = z.infer<typeof OrganizationRoleSchema>;

export const OrganizationStatusSchema = z.enum(["active", "suspended"]);
export type OrganizationStatus = z.infer<typeof OrganizationStatusSchema>;

export const OrganizationSchema = z.object({
  id: OrganizationIdSchema,
  name: z.string().min(1).max(160),
  slug: OrganizationSlugSchema,
  status: OrganizationStatusSchema,
  createdAt: z.iso.datetime(),
  updatedAt: z.iso.datetime(),
});
export type Organization = z.infer<typeof OrganizationSchema>;

export const OrganizationMemberSchema = z.object({
  id: z.string().uuid(),
  organizationId: OrganizationIdSchema,
  userId: z.string().uuid(),
  role: OrganizationRoleSchema,
  joinedAt: z.iso.datetime(),
  invitedByUserId: z.string().uuid().nullable(),
});
export type OrganizationMember = z.infer<typeof OrganizationMemberSchema>;

export const OrganizationMembershipSummarySchema = z.object({
  organization: OrganizationSchema,
  member: OrganizationMemberSchema,
});
export type OrganizationMembershipSummary = z.infer<typeof OrganizationMembershipSummarySchema>;

export const CurrentOrganizationContextSchema = z.object({
  organizationId: OrganizationIdSchema.nullable(),
  memberships: z.array(OrganizationMembershipSummarySchema),
});
export type CurrentOrganizationContext = z.infer<typeof CurrentOrganizationContextSchema>;
