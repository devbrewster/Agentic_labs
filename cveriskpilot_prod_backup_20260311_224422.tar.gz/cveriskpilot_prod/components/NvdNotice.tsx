import { NVD_ATTRIBUTION_NOTICE } from "@/lib/nvd/constants";

type NvdNoticeProps = {
  className?: string;
};

export function NvdNotice({ className }: NvdNoticeProps) {
  return (
    <div
      className={`rounded border border-[rgba(0,200,180,0.18)] bg-[rgba(0,200,180,0.06)] px-3 py-2 text-[0.72rem] text-[#9dc8d0] ${className ?? ""}`}
      role="note"
      aria-label="NVD attribution notice"
    >
      {NVD_ATTRIBUTION_NOTICE}
    </div>
  );
}
