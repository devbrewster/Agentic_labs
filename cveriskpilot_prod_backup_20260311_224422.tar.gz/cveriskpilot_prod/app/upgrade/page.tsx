import Link from "next/link";

export default function UpgradePage() {
  return (
    <main className="min-h-screen bg-[#040810] px-6 py-12 text-[#c8d8e8]">
      <div className="mx-auto max-w-3xl rounded-md border border-[rgba(0,200,180,0.08)] bg-[#070e1a] p-8">
        <div className="mb-3 font-mono text-[0.7rem] uppercase tracking-[0.16em] text-[#00c8b4]">
          // UPGRADE
        </div>
        <h1 className="text-3xl font-bold text-white">Upgrade to Pro</h1>
        <p className="mt-4 max-w-2xl text-sm leading-7 text-[#8ca2b4]">
          Your workspace already tracks organization-level billing and usage. Pro will unlock higher limits, advanced reporting, and premium integrations as billing becomes available.
        </p>

        <div className="mt-8 grid gap-4 sm:grid-cols-2">
          <div className="rounded border border-[rgba(0,200,180,0.08)] bg-[#0a1525] p-5">
            <div className="font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#00c8b4]">
              Free
            </div>
            <ul className="mt-3 space-y-2 text-sm text-[#8ca2b4]">
              <li>3 uploads per month</li>
              <li>10 AI analyses per month</li>
              <li>1 export per month</li>
            </ul>
          </div>

          <div className="rounded border border-[rgba(0,200,180,0.14)] bg-[rgba(0,200,180,0.05)] p-5">
            <div className="font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#00c8b4]">
              Pro
            </div>
            <ul className="mt-3 space-y-2 text-sm text-[#c8d8e8]">
              <li>Higher upload and analysis quotas</li>
              <li>Advanced reports and premium integrations</li>
              <li>Shared workspace and org-level administration</li>
            </ul>
          </div>
        </div>

        <div className="mt-8 flex gap-3">
          <Link
            href="/account"
            className="rounded border border-[rgba(0,200,180,0.14)] px-4 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[#00c8b4] transition hover:border-[#00c8b4]"
          >
            Back to Account
          </Link>
          <Link
            href="/about"
            className="rounded border border-[rgba(255,255,255,0.08)] px-4 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[#8ca2b4] transition hover:border-[rgba(0,200,180,0.14)] hover:text-[#c8d8e8]"
          >
            Review Platform Status
          </Link>
        </div>
      </div>
    </main>
  );
}
