# Multi-Agent Runbook

## Phase 1 - Independent Reviews
Each agent reviews the codebase and writes its own assessment to:
- .codex/reports/individual/orchestrator-assessment.md
- .codex/reports/individual/pm-agent-assessment.md
- .codex/reports/individual/product-ux-assessment.md
- .codex/reports/individual/security-platform-assessment.md

## Phase 2 - Cross-Review
Each agent reads the other reports and writes feedback into:
- .codex/reports/cross-review/

## Phase 3 - Unified Final
The Orchestrator merges:
- the 4 individual reports
- all cross-reviews
- unresolved conflicts
into:
- .codex/reports/final/unified-production-saas-assessment.md

## Required Final Output
The final report must clearly answer:
1. What exists today
2. What is missing
3. What is critically blocking production SaaS
4. What should be built first
5. What can wait