import { NextResponse } from "next/server";

import { dbFirst, dbRun, DbSchemaNotInitializedError } from "@/lib/db";
import { getResolvedOrganizationContext } from "@/lib/organizations/service";
import type {
  AuthApiSuccess,
  AuthErrorCode,
  SafeUser,
  UserRecord,
} from "@/types/auth";

const FIFTEEN_MINUTES_MS = 15 * 60 * 1000;

export async function readJsonBody<T>(request: Request): Promise<T | null> {
  try {
    return (await request.json()) as T;
  } catch {
    return null;
  }
}

export function apiSuccess<T>(data: T, status = 200) {
  return NextResponse.json<AuthApiSuccess<T>>({ ok: true, data }, { status });
}

export function apiError(
  code: AuthErrorCode,
  message: string,
  status = 400,
  details?: Record<string, string>,
) {
  return NextResponse.json(
    {
      ok: false,
      reason: code,
      error: {
        code,
        message,
        details,
      },
    },
    { status },
  );
}

export function withAuthRoute(
  handler: (request: Request) => Promise<Response>,
) {
  return async function wrappedHandler(request: Request) {
    try {
      return await handler(request);
    } catch (error) {
      if (error instanceof DbSchemaNotInitializedError) {
        return apiError("server_error", error.message, 500, {
          action: "Run `npm run db:migrate:local` before testing auth locally.",
        });
      }

      console.error("Auth route failed:", error);
      return apiError("server_error", "Unexpected server error.", 500);
    }
  };
}

export function sanitizeUser(user: UserRecord): SafeUser {
  return {
    id: user.id,
    email: user.email,
    display_name: user.display_name,
    email_verified: Boolean(user.email_verified),
    created_at: user.created_at,
  };
}

export async function hydrateUserOrganizationContext(user: SafeUser): Promise<SafeUser> {
  const { context, activeOrganizationId } = await getResolvedOrganizationContext(user.id);

  return {
    ...user,
    current_organization_id: activeOrganizationId,
    organization_context: context,
  };
}

export function getAppBaseUrl(request?: Request) {
  const envBaseUrl = process.env.APP_BASE_URL?.trim();

  if (envBaseUrl) {
    return envBaseUrl.replace(/\/+$/, "");
  }

  if (request) {
    return new URL(request.url).origin;
  }

  return "http://localhost:3000";
}

export function getNow() {
  return new Date();
}

export function toIso(date: Date) {
  return date.toISOString();
}

export function addMinutes(date: Date, minutes: number) {
  return new Date(date.getTime() + minutes * 60 * 1000);
}

export function isExpired(isoTimestamp: string) {
  return new Date(isoTimestamp).getTime() <= Date.now();
}

export function createOpaqueToken(bytes = 32) {
  const buffer = new Uint8Array(bytes);
  crypto.getRandomValues(buffer);
  return Array.from(buffer, (value) => value.toString(16).padStart(2, "0")).join("");
}

export async function sha256Hex(value: string) {
  const data = new TextEncoder().encode(value);
  const digest = await crypto.subtle.digest("SHA-256", data);
  const bytes = new Uint8Array(digest);
  return Array.from(bytes, (value) => value.toString(16).padStart(2, "0")).join("");
}

export async function getUserByEmail(email: string) {
  return dbFirst<UserRecord>(
    `SELECT id, email, password_hash, display_name, email_verified, created_at
     FROM users
     WHERE email = ?
     LIMIT 1`,
    email,
  );
}

export async function getUserById(userId: string) {
  return dbFirst<UserRecord>(
    `SELECT id, email, password_hash, display_name, email_verified, created_at
     FROM users
     WHERE id = ?
     LIMIT 1`,
    userId,
  );
}

export async function createEmailVerificationToken(userId: string, email: string) {
  const token = createOpaqueToken(32);
  const tokenHash = await sha256Hex(token);
  const now = getNow();
  const expiresAt = addMinutes(now, 15);
  const tokenId = crypto.randomUUID();

  await dbRun(
    `INSERT INTO email_verification_tokens (
      id,
      user_id,
      email,
      token_hash,
      expires_at,
      created_at,
      used_at
    ) VALUES (?, ?, ?, ?, ?, ?, NULL)`,
    tokenId,
    userId,
    email,
    tokenHash,
    toIso(expiresAt),
    toIso(now),
  );

  return {
    id: tokenId,
    token,
    expiresAt: toIso(expiresAt),
  };
}

export async function createPasswordResetToken(userId: string, email: string) {
  const token = createOpaqueToken(32);
  const tokenHash = await sha256Hex(token);
  const now = getNow();
  const expiresAt = addMinutes(now, 15);
  const tokenId = crypto.randomUUID();

  await dbRun("DELETE FROM password_reset_tokens WHERE user_id = ?", userId);

  await dbRun(
    `INSERT INTO password_reset_tokens (
      id,
      user_id,
      email,
      token_hash,
      expires_at,
      created_at,
      used_at
    ) VALUES (?, ?, ?, ?, ?, ?, NULL)`,
    tokenId,
    userId,
    email,
    tokenHash,
    toIso(expiresAt),
    toIso(now),
  );

  return {
    id: tokenId,
    token,
    expiresAt: toIso(expiresAt),
  };
}

export async function consumeEmailVerificationToken(rawToken: string) {
  const tokenHash = await sha256Hex(rawToken);
  const record = await dbFirst<
    UserRecord & {
      token_id: string;
      token_expires_at: string;
      token_used_at: string | null;
    }
  >(
    `SELECT
       u.id,
       u.email,
       u.password_hash,
       u.display_name,
       u.email_verified,
       u.created_at,
       evt.id AS token_id,
       evt.expires_at AS token_expires_at,
       evt.used_at AS token_used_at
     FROM email_verification_tokens evt
     INNER JOIN users u ON u.id = evt.user_id
     WHERE evt.token_hash = ?
     LIMIT 1`,
    tokenHash,
  );

  if (!record || record.token_used_at) {
    return { ok: false as const, reason: "invalid_token" as const };
  }

  if (isExpired(record.token_expires_at)) {
    return { ok: false as const, reason: "token_expired" as const };
  }

  await dbRun("UPDATE users SET email_verified = 1 WHERE id = ?", record.id);
  await dbRun(
    "UPDATE email_verification_tokens SET used_at = ? WHERE id = ?",
    toIso(getNow()),
    record.token_id,
  );

  return {
    ok: true as const,
    user: await hydrateUserOrganizationContext(
      sanitizeUser({
      id: record.id,
      email: record.email,
      password_hash: record.password_hash,
      display_name: record.display_name,
      email_verified: 1,
      created_at: record.created_at,
      }),
    ),
  };
}

export async function validatePasswordResetToken(rawToken: string) {
  const tokenHash = await sha256Hex(rawToken);
  const record = await dbFirst<
    UserRecord & {
      token_id: string;
      token_expires_at: string;
      token_used_at: string | null;
    }
  >(
    `SELECT
       u.id,
       u.email,
       u.password_hash,
       u.display_name,
       u.email_verified,
       u.created_at,
       prt.id AS token_id,
       prt.expires_at AS token_expires_at,
       prt.used_at AS token_used_at
     FROM password_reset_tokens prt
     INNER JOIN users u ON u.id = prt.user_id
     WHERE prt.token_hash = ?
     LIMIT 1`,
    tokenHash,
  );

  if (!record || record.token_used_at) {
    return { ok: false as const, reason: "invalid_token" as const };
  }

  if (isExpired(record.token_expires_at)) {
    return { ok: false as const, reason: "token_expired" as const };
  }

  return {
    ok: true as const,
    user: record,
    tokenId: record.token_id,
    expiresAt: record.token_expires_at,
  };
}

export async function consumePasswordResetToken(rawToken: string, newPasswordHash: string) {
  const tokenCheck = await validatePasswordResetToken(rawToken);

  if (!tokenCheck.ok) {
    return tokenCheck;
  }

  await dbRun(
    `UPDATE users
     SET password_hash = ?
     WHERE id = ?`,
    newPasswordHash,
    tokenCheck.user.id,
  );

  await dbRun(
    `UPDATE password_reset_tokens
     SET used_at = ?
     WHERE id = ?`,
    toIso(getNow()),
    tokenCheck.tokenId,
  );

  return {
    ok: true as const,
    user: sanitizeUser(tokenCheck.user),
  };
}

export async function deleteUserAccount(userId: string) {
  await dbRun("DELETE FROM email_verification_tokens WHERE user_id = ?", userId);
  await dbRun("DELETE FROM password_reset_tokens WHERE user_id = ?", userId);
  await dbRun("DELETE FROM sessions WHERE user_id = ?", userId);
  await dbRun("DELETE FROM organization_members WHERE user_id = ?", userId);
  await dbRun("DELETE FROM users WHERE id = ?", userId);
  await dbRun(
    `DELETE FROM organizations
     WHERE id NOT IN (
       SELECT DISTINCT organization_id
       FROM organization_members
     )`,
  );
}

export function buildVerificationUrl(request: Request, token: string) {
  const url = new URL("/api/auth/verify", getAppBaseUrl(request));
  url.searchParams.set("token", token);
  return url.toString();
}

export function buildPasswordResetUrl(request: Request, token: string) {
  const url = new URL("/reset-password", getAppBaseUrl(request));
  url.searchParams.set("token", token);
  return url.toString();
}

export function verificationWindowMinutes() {
  return FIFTEEN_MINUTES_MS / (60 * 1000);
}
