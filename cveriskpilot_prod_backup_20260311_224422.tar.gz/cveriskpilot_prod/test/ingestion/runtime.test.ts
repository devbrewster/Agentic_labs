import { afterEach, describe, expect, it } from "vitest";

import type { PostgresQueryClient } from "@/lib/platform/database";
import { clearPostgresQueryClient, configurePostgresQueryClient } from "@/lib/platform/postgres";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";

describe("ingestion runtime", () => {
  afterEach(() => {
    clearPostgresQueryClient();
    delete process.env.DATABASE_URL;
    delete process.env.UPLOAD_STORAGE_DRIVER;
  });

  it("selects the Postgres ingestion repository when a Postgres client is configured", async () => {
    process.env.DATABASE_URL = "postgres://example";
    process.env.UPLOAD_STORAGE_DRIVER = "local_fs";

    const client: PostgresQueryClient = {
      async query() {
        return {
          rows: [],
          rowCount: 0,
        };
      },
    };

    configurePostgresQueryClient(client);

    const runtime = await getIngestionRuntime();

    expect(runtime.uploadRepository.constructor.name).toBe("PostgresUploadRepository");
  });
});
