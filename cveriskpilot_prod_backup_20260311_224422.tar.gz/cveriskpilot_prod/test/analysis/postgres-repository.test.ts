import { describe, expect, it } from "vitest";

import { PostgresAnalysisTraceRepository } from "@/lib/analysis/postgres-repository";
import type { PostgresQueryClient } from "@/lib/platform/database";

describe("PostgresAnalysisTraceRepository", () => {
  it("maps analysis traces through the shared SQL repository implementation", async () => {
    const findingId = crypto.randomUUID();

    const client: PostgresQueryClient = {
      async query<T>(sql: string, params?: readonly unknown[]) {
        if (sql.includes("FROM analysis_runs")) {
          expect(sql).toContain("WHERE finding_id = $1");
          expect(params).toEqual([findingId]);

          return {
            rows: [
              {
                id: crypto.randomUUID(),
                finding_id: findingId,
                source: "ingestion",
                requested_mode: "live",
                provider: "claude",
                model: "claude-sonnet-4-6",
                template_version: "p3-7.v1",
                trace_status: "completed",
                fallback_reason: null,
                warning_count: 1,
                generated_at: "2026-03-11T12:00:00.000Z",
                created_at: "2026-03-11T12:00:01.000Z",
                prompt_context_json: JSON.stringify({ findingId }),
                prompt_envelope_json: JSON.stringify({
                  templateVersion: "p3-7.v1",
                  userPrompt: "prompt",
                }),
                output_json: JSON.stringify({
                  businessImpact: "impact",
                  exploitabilityAssessment: "exploitability",
                  falsePositiveAssessment: "false positive",
                  recommendedAction: "action",
                  confidence: 0.92,
                }),
                warnings_json: JSON.stringify(["warning"]),
              },
            ] as T[],
            rowCount: 1,
          };
        }

        throw new Error(`Unexpected SQL in test client: ${sql}`);
      },
    };

    const repository = new PostgresAnalysisTraceRepository(client);
    const records = await repository.listByFindingId(findingId);

    expect(records).toHaveLength(1);
    expect(records[0]?.findingId).toBe(findingId);
    expect(records[0]?.provider).toBe("claude");
    expect(records[0]?.warningsJson).toEqual(["warning"]);
  });
});
