# AWS SaaS Migration Plan

Last updated: 2026-03-11  
Status: in progress

## Purpose

This plan tracks the controlled migration path from the current Cloudflare-first application to an AWS-hosted SaaS deployment under:

- `cveriskpilot.com` for marketing
- `app.cveriskpilot.com` for the application

The end-state must support:

- AWS deployment
- organization-scoped isolation
- future SaaS licensing
- separate landing page and application lifecycle

## Current blockers

The application is not yet AWS-portable because these assumptions still exist:

- Cloudflare D1-specific repository implementations
- OpenNext Cloudflare runtime bootstrap in local/runtime flows
- Wrangler deployment and Workers routing assumptions
- data model not yet scoped by organization

## Chunk Sequence

| Chunk | Title | Status |
|---|---|---|
| AWS-1 | Portability audit + shared platform abstraction scaffolding | completed |
| AWS-2 | Organization and membership domain model | completed |
| AWS-3 | Postgres repository interfaces + first implementation slice | completed |
| AWS-4 | S3 artifact storage implementation | completed |
| AWS-5 | App subdomain deployment split (`app.cveriskpilot.com`) | completed |
| AWS-6 | Org-aware auth/session scoping | completed |
| AWS-7 | SaaS licensing readiness gate | completed |
| AWS-8 | Organization-scoped workload isolation enforcement | completed |
| AWS-9 | Postgres-ready billing persistence slice | completed |
| AWS-10 | Postgres-ready analyst and analysis persistence slices | completed |
| AWS-11 | Postgres-ready ingestion persistence slice | completed |
| AWS-12 | Postgres-ready enrichment persistence slice + portability closeout | completed |
| AWS-13 | Real Postgres client bootstrap + PostgreSQL schema track | completed |
| AWS-14 | Containerization + ECS deploy handoff | completed |
| AWS-15 | Staging cutover runbook + ECR push helper | completed |

## AWS-1 Deliverables

- initial AWS infrastructure bootstrap in `infra/aws`
- shared platform profile types
- runtime environment detection
- database adapter seam for future Postgres support
- migration plan and handoff logging

## Exit rule for AWS-1

AWS-1 is complete only when:

1. AWS bootstrap files exist
2. portability scaffolding is committed in app code
3. the migration plan is documented
4. the progress log records the chunk

## AWS-2 Deliverables

- organization and organization membership schema tables
- shared organization domain types
- D1-backed organization read repository
- authenticated user context hydration path for future org scoping
- progress logging for handoff continuity

## AWS-3 Deliverables

- shared SQL repository implementation for organizations
- Postgres-capable database adapter and placeholder rewriting
- Postgres organization repository implementation
- regression coverage for SQL placeholder rewriting and org reads
- progress logging for handoff continuity

## AWS-4 Deliverables

- real S3-backed artifact storage provider
- env-driven storage provider selection in ingestion runtime
- regression coverage for S3 artifact save/read/missing-object behavior
- documentation for AWS storage env configuration

## AWS-5 Deliverables

- host-aware root deployment mode for `app.cveriskpilot.com`
- middleware rewrite layer for root app routes to current dashboard pages
- shared dashboard route helper for path-mode vs subdomain-mode links
- documentation for subdomain deployment env configuration

## AWS-6 Deliverables

- default organization + owner membership created during signup
- sessions persist active organization context
- authenticated session hydration resolves and normalizes active organization
- org-switching API route scaffold for multi-org users
- regression coverage for org selection helper behavior

## AWS-7 Deliverables

- org-scoped billing schema tables for customers, subscriptions, and usage counters
- shared billing domain types and repository/runtime scaffolding
- billing summary service that derives current plan and workspace entitlements
- authenticated `GET /api/billing` route for frontend-safe billing snapshot access
- account workspace page wired to real billing state instead of static plan placeholders
- Stripe env contracts added without wiring checkout/webhooks yet

## AWS-8 Deliverables

- upload, findings, enrichment, dashboard overview, and executive summary APIs now require an active organization context
- ingestion deduplication is scoped per organization instead of globally by checksum
- organization-filtered repository methods added for uploads and findings
- finding-level analysis, enrichment, and analyst disposition routes validate org ownership before returning data
- integration coverage now includes cross-organization isolation assertions

## AWS-9 Deliverables

- shared SQL billing repository implementation aligned with the existing organization repository pattern
- Postgres billing repository implementation for customer, subscription, and usage-counter reads/writes
- runtime selection for billing repositories based on configured database driver and registered Postgres client
- regression coverage for Postgres SQL placeholder rewriting and runtime repository selection

## AWS-10 Deliverables

- shared SQL analysis trace repository implementation
- shared SQL analyst disposition repository implementation
- Postgres repositories for analysis traces and analyst dispositions
- runtime selection for analysis and analyst persistence based on configured database driver and registered Postgres client
- regression coverage for Postgres repository reads and runtime repository selection

## AWS-11 Deliverables

- shared SQL ingestion repositories for upload jobs, raw artifacts, parse outcomes, and normalized findings
- Postgres ingestion repository implementations and runtime selection
- D1 ingestion repositories reduced to thin adapters over shared SQL
- regression coverage for Postgres upload/finding reads and ingestion runtime repository selection

## AWS-12 Deliverables

- shared SQL enrichment repository implementation
- Postgres enrichment repository implementation and runtime selection
- D1 enrichment repository reduced to a thin adapter over shared SQL
- regression coverage for Postgres enrichment reads and enrichment runtime repository selection
- AWS portability closeout for the current repository/runtime seams

## AWS-13 Deliverables

- real Node/Postgres client bootstrap from `DATABASE_URL`
- pooled Postgres runtime configuration via env
- PostgreSQL-specific schema file for AWS/RDS deployments
- regression coverage for Postgres client bootstrap and organization runtime selection
- AWS runtime docs updated with concrete migration/env commands

## AWS-14 Deliverables

- Dockerfile for AWS/Next standalone runtime
- `.dockerignore` for clean image builds
- health endpoint for ALB/ECS target group checks
- Terraform defaults/examples updated for the real app container on port `3000`
- AWS docs updated with image build/push handoff

## AWS-15 Deliverables

- staging cutover runbook for `app.cveriskpilot.com`
- step-by-step ECR, Terraform, migration, smoke-test, and rollback instructions
- reusable ECR build/push helper script
- npm wrapper command for the helper script

## Notes

- Billing remains blocked until organization isolation exists.
- The main repository/runtime seams now have Postgres/S3 replacements.
- Remaining AWS work is execution-focused:
  - deploy a real container image
  - run PostgreSQL schema migration
  - inject Secrets Manager / env config
  - validate staging on `app.cveriskpilot.com`
