import { beforeEach, describe, expect, it, vi } from "vitest";

const authMocks = vi.hoisted(() => ({
  apiSuccess: vi.fn((data: unknown, status = 200) => Response.json({ ok: true, data }, { status })),
  apiError: vi.fn(
    (code: string, message: string, status = 400, details?: Record<string, string>) =>
      Response.json(
        {
          ok: false,
          reason: code,
          error: { code, message, details },
        },
        { status },
      ),
  ),
  buildPasswordResetUrl: vi.fn((_request: Request, token: string) => `http://localhost/reset-password?token=${token}`),
  createPasswordResetToken: vi.fn(),
  consumePasswordResetToken: vi.fn(),
  getUserByEmail: vi.fn(),
  readJsonBody: vi.fn(async (request: Request) => request.json()),
  validatePasswordResetToken: vi.fn(),
  withAuthRoute: vi.fn((handler: (request: Request) => Promise<Response>) => handler),
}));

const mailerMocks = vi.hoisted(() => ({
  sendPasswordResetEmail: vi.fn(),
}));

const passwordMocks = vi.hoisted(() => ({
  hashPassword: vi.fn(),
}));

const sessionMocks = vi.hoisted(() => ({
  revokeAllSessions: vi.fn(),
}));

const validatorMocks = vi.hoisted(() => ({
  validatePasswordResetPayload: vi.fn(),
  validatePasswordResetRequestPayload: vi.fn(),
}));

vi.mock("@/lib/auth", () => authMocks);
vi.mock("@/lib/mailer", () => mailerMocks);
vi.mock("@/lib/passwords", () => passwordMocks);
vi.mock("@/lib/session", () => sessionMocks);
vi.mock("@/lib/validators", () => validatorMocks);

const forgotRoute = await import("@/app/api/auth/forgot/route");
const resetRoute = await import("@/app/api/auth/reset/route");

describe("password reset routes", () => {
  beforeEach(() => {
    vi.clearAllMocks();
  });

  it("returns a generic success response when the email is unknown", async () => {
    validatorMocks.validatePasswordResetRequestPayload.mockReturnValue({
      success: true,
      data: { email: "missing@example.com" },
    });
    authMocks.getUserByEmail.mockResolvedValue(null);

    const response = await forgotRoute.POST(
      new Request("http://localhost/api/auth/forgot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: "missing@example.com" }),
      }),
    );
    const json = await response.json();

    expect(response.status).toBe(200);
    expect(json.ok).toBe(true);
    expect(json.data.message).toContain("If that email exists");
    expect(authMocks.createPasswordResetToken).not.toHaveBeenCalled();
    expect(mailerMocks.sendPasswordResetEmail).not.toHaveBeenCalled();
  });

  it("creates a reset token and sends a reset email for a known user", async () => {
    validatorMocks.validatePasswordResetRequestPayload.mockReturnValue({
      success: true,
      data: { email: "known@example.com" },
    });
    authMocks.getUserByEmail.mockResolvedValue({
      id: "user-1",
      email: "known@example.com",
      display_name: "Known User",
    });
    authMocks.createPasswordResetToken.mockResolvedValue({
      id: "token-row-1",
      token: "reset-token-123",
      expiresAt: "2026-03-11T18:00:00.000Z",
    });
    mailerMocks.sendPasswordResetEmail.mockResolvedValue({
      previewUrl: "https://preview.test/reset",
    });

    const response = await forgotRoute.POST(
      new Request("http://localhost/api/auth/forgot", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: "known@example.com" }),
      }),
    );
    const json = await response.json();

    expect(response.status).toBe(200);
    expect(authMocks.createPasswordResetToken).toHaveBeenCalledWith("user-1", "known@example.com");
    expect(mailerMocks.sendPasswordResetEmail).toHaveBeenCalledWith({
      to: "known@example.com",
      displayName: "Known User",
      resetUrl: "http://localhost/reset-password?token=reset-token-123",
    });
    expect(json.data.email_preview_url).toBe("https://preview.test/reset");
  });

  it("validates a reset token through the GET route", async () => {
    authMocks.validatePasswordResetToken.mockResolvedValue({
      ok: true,
      user: {
        email: "known@example.com",
      },
      expiresAt: "2026-03-11T18:00:00.000Z",
    });

    const response = await resetRoute.GET(
      new Request("http://localhost/api/auth/reset?token=reset-token-123"),
    );
    const json = await response.json();

    expect(response.status).toBe(200);
    expect(json.data.email).toBe("known@example.com");
    expect(json.data.expires_at).toBe("2026-03-11T18:00:00.000Z");
  });

  it("resets the password and revokes sessions through the POST route", async () => {
    validatorMocks.validatePasswordResetPayload.mockReturnValue({
      success: true,
      data: {
        token: "reset-token-123",
        new_password: "NewStrongPass456!",
      },
    });
    passwordMocks.hashPassword.mockResolvedValue("hashed-password");
    authMocks.consumePasswordResetToken.mockResolvedValue({
      ok: true,
      user: {
        id: "user-1",
      },
    });

    const response = await resetRoute.POST(
      new Request("http://localhost/api/auth/reset", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          token: "reset-token-123",
          new_password: "NewStrongPass456!",
        }),
      }),
    );
    const json = await response.json();

    expect(response.status).toBe(200);
    expect(passwordMocks.hashPassword).toHaveBeenCalledWith("NewStrongPass456!");
    expect(authMocks.consumePasswordResetToken).toHaveBeenCalledWith(
      "reset-token-123",
      "hashed-password",
    );
    expect(sessionMocks.revokeAllSessions).toHaveBeenCalledWith("user-1");
    expect(json.data.message).toContain("Password reset successful");
  });
});
