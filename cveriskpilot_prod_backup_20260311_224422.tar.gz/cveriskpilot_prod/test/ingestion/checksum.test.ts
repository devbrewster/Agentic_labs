import { describe, expect, it } from "vitest";

import { sha256Hex } from "@/lib/ingestion/checksum";

describe("sha256Hex", () => {
  it("produces a deterministic sha256 checksum", () => {
    const checksum = sha256Hex(Buffer.from("cveriskpilot"));

    expect(checksum).toHaveLength(64);
    expect(checksum).toBe(sha256Hex(Buffer.from("cveriskpilot")));
  });
});
