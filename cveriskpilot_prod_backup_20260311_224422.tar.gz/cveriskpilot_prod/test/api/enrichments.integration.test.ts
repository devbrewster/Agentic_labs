import { describe, expect, it } from "vitest";

import { GET as getEnrichmentRun } from "@/app/api/enrichments/[id]/route";
import { POST as triggerEnrichment } from "@/app/api/enrichments/route";
import { GET as getFindingEnrichment } from "@/app/api/findings/[id]/enrichment/route";
import { POST as reparseUpload } from "@/app/api/uploads/[id]/reparse/route";
import { POST as createUpload } from "@/app/api/uploads/route";
import { createAuthenticatedTestContext, withAuthHeaders } from "@/test/helpers/auth";
import { successfulCsvFixture } from "@/test/fixtures/generic-csv";

async function createParsedUploadThroughRoute(authHeaders: HeadersInit) {
  const formData = new FormData();
  formData.set(
    "file",
    new File([successfulCsvFixture], `enrichment-${crypto.randomUUID()}.csv`, {
      type: "text/csv",
    }),
  );
  formData.set("selectedSourceType", "generic_csv");

  const uploadResponse = await createUpload(
    new Request("http://localhost/api/uploads", {
      method: "POST",
      headers: withAuthHeaders(authHeaders),
      body: formData,
    }),
  );
  const uploadJson = await uploadResponse.json();
  const uploadJobId = uploadJson.data.uploadJob.id as string;

  const parseResponse = await reparseUpload(
    new Request(`http://localhost/api/uploads/${uploadJobId}/reparse`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(authHeaders).entries()),
        },
        body: JSON.stringify({ force: true }),
    }),
    {
      params: Promise.resolve({ id: uploadJobId }),
    },
  );
  const parseJson = await parseResponse.json();
  expect(parseJson.data.uploadJob.status).toBe("enrichment_pending");

  return {
    uploadJobId,
    firstFindingId: parseJson.data.outcome.findings[0].id as string,
  };
}

describe("enrichment routes", () => {
  it("triggers an enrichment run and returns run details", async () => {
    const auth = await createAuthenticatedTestContext("enrichment-complete");
    const { uploadJobId, firstFindingId } = await createParsedUploadThroughRoute(
      auth.headers,
    );

    const triggerResponse = await triggerEnrichment(
      new Request("http://localhost/api/enrichments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({
          uploadJobId,
          providers: ["nvd", "cisa_kev"],
          triggeredBy: "integration-test",
        }),
      }),
    );
    const triggerJson = await triggerResponse.json();

    expect(triggerResponse.status).toBe(200);
    expect(triggerJson.ok).toBe(true);
    expect(triggerJson.data.run.status).toBe("completed");
    expect(triggerJson.data.snapshots.length).toBeGreaterThan(0);

    const runId = triggerJson.data.run.id as string;
    const runDetailResponse = await getEnrichmentRun(
      new Request(`http://localhost/api/enrichments/${runId}`, {
        headers: withAuthHeaders(auth.headers),
      }),
      {
        params: Promise.resolve({ id: runId }),
      },
    );
    const runDetailJson = await runDetailResponse.json();

    expect(runDetailResponse.status).toBe(200);
    expect(runDetailJson.data.run.id).toBe(runId);
    expect(runDetailJson.data.snapshots.length).toBe(triggerJson.data.snapshots.length);

    const findingSnapshotsResponse = await getFindingEnrichment(
      new Request(`http://localhost/api/findings/${firstFindingId}/enrichment`, {
        headers: withAuthHeaders(auth.headers),
      }),
      {
        params: Promise.resolve({ id: firstFindingId }),
      },
    );
    const findingSnapshotsJson = await findingSnapshotsResponse.json();

    expect(findingSnapshotsResponse.status).toBe(200);
    expect(findingSnapshotsJson.data.findingId).toBe(firstFindingId);
    expect(findingSnapshotsJson.data.snapshotCount).toBeGreaterThan(0);
  });

  it("returns a partial run when some providers fail", async () => {
    const auth = await createAuthenticatedTestContext("enrichment-partial");
    const { uploadJobId } = await createParsedUploadThroughRoute(auth.headers);

    const triggerResponse = await triggerEnrichment(
      new Request("http://localhost/api/enrichments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({
          uploadJobId,
          providers: ["nvd", "wiz"],
          triggeredBy: "integration-test",
          force: true,
        }),
      }),
    );
    const triggerJson = await triggerResponse.json();

    expect(triggerResponse.status).toBe(200);
    expect(triggerJson.ok).toBe(true);
    expect(triggerJson.data.run.status).toBe("partial");
    expect(triggerJson.data.run.errorCount).toBeGreaterThan(0);
  });

  it("returns a failed run when all providers fail", async () => {
    const auth = await createAuthenticatedTestContext("enrichment-failed");
    const { uploadJobId } = await createParsedUploadThroughRoute(auth.headers);

    const triggerResponse = await triggerEnrichment(
      new Request("http://localhost/api/enrichments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({
          uploadJobId,
          providers: ["wiz", "snyk"],
          triggeredBy: "integration-test",
          force: true,
        }),
      }),
    );
    const triggerJson = await triggerResponse.json();

    expect(triggerResponse.status).toBe(200);
    expect(triggerJson.ok).toBe(true);
    expect(triggerJson.data.run.status).toBe("failed");
    expect(triggerJson.data.run.errorCount).toBeGreaterThan(0);
  });

  it("returns a validation error when uploadJobId is missing", async () => {
    const auth = await createAuthenticatedTestContext("enrichment-invalid");
    const response = await triggerEnrichment(
      new Request("http://localhost/api/enrichments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({
          providers: ["nvd"],
          triggeredBy: "integration-test",
        }),
      }),
    );
    const json = await response.json();

    expect(response.status).toBe(400);
    expect(json.ok).toBe(false);
    expect(json.error.code).toBe("invalid_request");
  });

  it("does not expose enrichment runs across organizations", async () => {
    const authA = await createAuthenticatedTestContext("enrichment-org-a");
    const authB = await createAuthenticatedTestContext("enrichment-org-b");
    const { uploadJobId } = await createParsedUploadThroughRoute(authA.headers);

    const triggerResponse = await triggerEnrichment(
      new Request("http://localhost/api/enrichments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(authA.headers).entries()),
        },
        body: JSON.stringify({
          uploadJobId,
          providers: ["nvd"],
          triggeredBy: "integration-test",
        }),
      }),
    );
    const triggerJson = await triggerResponse.json();
    const runId = triggerJson.data.run.id as string;

    const response = await getEnrichmentRun(
      new Request(`http://localhost/api/enrichments/${runId}`, {
        headers: withAuthHeaders(authB.headers),
      }),
      {
        params: Promise.resolve({ id: runId }),
      },
    );
    const json = await response.json();

    expect(response.status).toBe(404);
    expect(json.error.code).toBe("enrichment_run_not_found");
  });
});
