import type { NextConfig } from "next";
import { initOpenNextCloudflareForDev } from "@opennextjs/cloudflare";

const isAwsBuild = process.env.DEPLOY_TARGET === "aws";

const nextConfig: NextConfig = {
  output: isAwsBuild ? "standalone" : undefined,
  serverExternalPackages: isAwsBuild ? ["pg"] : undefined,
};

void initOpenNextCloudflareForDev();

export default nextConfig;
