**CVERiskPilot Pending Issues Status**



Using the current structured internal issue list.



**ISSUE-001 · P0 Now · in progress**
Complete dashboard auth and tenant scoping
Track: Dashboard Access
Impact: This is the primary barrier to trusting dashboard and report isolation across organizations.
Next: Audit all dashboard child routes and add redirect coverage for unauthenticated access.

**ISSUE-002 · P0 Now · blocked**
Fix selected-finding enrichment signals after completed provider runs
Track: Enrichment
Impact: Users can see stale pending signals even when enrichment has already completed, which undermines confidence in the source data.
Next: Trace the source-of-truth path between findings list, enrichment detail API, and the detail rail, then add a large-list regression test.

**ISSUE-003 · P1 Next · queued**
Harden upload validation and ingestion orchestration
Track: Ingestion
Impact: Upload reliability and enterprise trust remain limited until ingestion is safer and more deterministic.
Next: Add stricter upload validation, audit events, and continue moving parse/enrichment work off fragile request-path assumptions.

**ISSUE-004 · P1 Next · queued**
Implement Stripe checkout, webhook ingestion, and server-side entitlements
Track: Billing
Impact: The product cannot move from beta workflow validation to monetized SaaS operation without this layer.
Next: Build checkout + webhook routes, then wire org-scoped usage enforcement before exposing paid plans.

**ISSUE-005 · P1 Next · queued**
Add compliance-grade upload audit events and retrieval surfaces
Track: Audit
Impact: Support, compliance, and incident-review workflows are weaker without append-only audit history.
Next: Implement upload audit event persistence, retrieval APIs, and an internal operator view.

**ISSUE-006 · P2 Later · monitoring**
Clean up remaining UI polish and placeholder copy drift
Track: UI
Impact: This does not block core behavior, but it still affects perceived quality.
Next: Address only after access control, enrichment truthfulness, ingestion hardening, and billing are stable.

