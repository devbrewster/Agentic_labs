# Orchestrator Review – PM Agent Assessment

## Agreements
- Auth lifecycle is implemented with verification + reset flows while magic links remain unimplemented, matching the PM narrative (`app/api/auth/signup/route.ts:1-122`, `app/api/auth/reset/route.ts:1-78`, `app/api/auth/magic/route.ts:1-17`).
- Billing is snapshot-only with no checkout, portal, or entitlement enforcement; the GET route merely returns plan metadata derived from `getOrganizationBillingSnapshot`, aligning with the PM callout (`app/api/billing/route.ts:1-41`, `lib/billing/service.ts:12-133`).
- Settings, integrations, and action plans are UI scaffolding backed entirely by mock services, so labeling those areas as placeholders is accurate (`app/dashboard/settings/page.tsx:5-30`, `lib/services/action-plans.ts:1-16`, `lib/mock/platform.ts:34-73`).
- Upload stabilization is still scoped to Generic CSV and operations rely on manual D1 cleanup runbooks, as the PM summary noted (`docs/upload-stabilization-plan.md:1-62`, `docs/admin-runbook.md:1-115`).

## Blind Spots
- `/api/uploads` still mixes mock payloads into real responses: the handler returns `jobs: listUploadJobs()` which is just an array of hard-coded fixtures and even the supported format list is mocked, so the UI can display fictional ingestion activity (`app/api/uploads/route.ts:18-27`, `lib/services/uploads.ts:1-11`, `lib/mock/uploads.ts:1-43`). The PM report treated the uploads area as production-backed without flagging this discrepancy.
- There is no server-side file security: uploads accept any file size or type, immediately buffer the entire body, compute a checksum, and persist it with no malware scanning, file-type validation, or rate limiting (`app/api/uploads/route.ts:37-85`, `lib/ingestion/upload-service.ts:12-105`). This is a notable SaaS readiness gap (product and security) that went unmentioned.
- Misconfiguration silently drops tenant data because `getIngestionRuntime` falls back to an in-memory repository whenever Postgres/D1 bindings are missing, meaning a staging/production deploy without the right env vars would “succeed” but lose every upload on restart (`lib/ingestion/runtime.ts:29-135`). The PM assessment didn’t surface this architectural risk.

## Conflicts / Corrections
- Labeling the ingestion experience as “beyond MVP” ignores the mocked job list and supported-format banner noted above; until `/api/uploads` only emits real persistence-backed entities, customer dashboards can still lie about queue state. The readiness classification for uploads should be downgraded to PARTIAL to reflect this evidence.
- The PM section on “product completeness” cites action plans and integrations as mock-only, but it does not explain that billing/usage banners also rely on mocked limits, which materially affects monetization readiness messaging in the dashboard. Highlighting this would keep go-to-market stakeholders from assuming any plan gating is live (`app/upgrade/page.tsx:1-48`, `lib/billing/service.ts:12-133`).

## Recommended Changes to PM Report
1. Add an explicit Current State note that `/api/uploads` still injects `mockUploadJobs` and mocked format metadata so operators cannot rely on the dashboard to reflect live queued jobs; classify ingestion UI as PARTIAL until those mocks are removed.
2. Expand the Security Review section with the lack of upload sanitization/AV scanning and absence of size/type enforcement as a CRITICAL gap, referencing the upload route + service.
3. Document the in-memory fallback path in Architecture Gaps so deployment engineers understand that missing D1/Postgres bindings cause silent data loss rather than a hard failure.
