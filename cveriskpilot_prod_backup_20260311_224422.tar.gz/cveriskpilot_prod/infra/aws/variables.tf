variable "project" {
  description = "Project slug used in resource names."
  type        = string
  default     = "cveriskpilot"
}

variable "environment" {
  description = "Deployment environment name."
  type        = string
  default     = "prod"
}

variable "aws_region" {
  description = "AWS region for the stack."
  type        = string
  default     = "us-east-1"
}

variable "root_domain" {
  description = "Primary apex domain for the business."
  type        = string
  default     = "cveriskpilot.com"
}

variable "app_subdomain" {
  description = "Subdomain prefix for the app."
  type        = string
  default     = "app"
}

variable "manage_route53_records" {
  description = "Set true only if the domain is managed in Route53. Leave false if DNS stays in Cloudflare."
  type        = bool
  default     = false
}

variable "enable_https" {
  description = "Create ACM certificate resources. If Route53 is not managed here, certificate validation must be completed manually."
  type        = bool
  default     = true
}

variable "vpc_cidr" {
  description = "CIDR block for the AWS VPC."
  type        = string
  default     = "10.20.0.0/16"
}

variable "public_subnet_cidrs" {
  description = "Two public subnet CIDR ranges."
  type        = list(string)
  default     = ["10.20.0.0/24", "10.20.1.0/24"]
}

variable "private_app_subnet_cidrs" {
  description = "Two private application subnet CIDR ranges."
  type        = list(string)
  default     = ["10.20.10.0/24", "10.20.11.0/24"]
}

variable "private_db_subnet_cidrs" {
  description = "Two private database subnet CIDR ranges."
  type        = list(string)
  default     = ["10.20.20.0/24", "10.20.21.0/24"]
}

variable "container_image" {
  description = "Container image for the ECS service. Point this at the built CVERiskPilot app image in ECR."
  type        = string
  default     = "REPLACE_WITH_ECR_IMAGE_URI"
}

variable "container_port" {
  description = "Application container port."
  type        = number
  default     = 3000
}

variable "health_check_path" {
  description = "ALB health check path for the app container."
  type        = string
  default     = "/api/health"
}

variable "task_cpu" {
  description = "Fargate task CPU units."
  type        = number
  default     = 512
}

variable "task_memory" {
  description = "Fargate task memory in MiB."
  type        = number
  default     = 1024
}

variable "desired_count" {
  description = "Desired ECS task count."
  type        = number
  default     = 1
}

variable "db_name" {
  description = "Initial Postgres database name."
  type        = string
  default     = "cveriskpilot"
}

variable "db_username" {
  description = "Master username for Postgres."
  type        = string
  default     = "cveriskpilot"
}

variable "db_instance_class" {
  description = "RDS instance class."
  type        = string
  default     = "db.t4g.micro"
}

variable "db_allocated_storage" {
  description = "Allocated storage for Postgres in GiB."
  type        = number
  default     = 30
}

variable "db_multi_az" {
  description = "Whether to create the database in Multi-AZ mode."
  type        = bool
  default     = false
}

variable "db_backup_retention_period" {
  description = "Number of days to retain automated backups."
  type        = number
  default     = 7
}

variable "tags" {
  description = "Additional tags applied to all supported resources."
  type        = map(string)
  default     = {}
}
