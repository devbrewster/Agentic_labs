import type {
  BillingCustomer,
  BillingSubscription,
  UsageCounter,
} from "@/types/billing";
import type { OrganizationId } from "@/types/organization";

export interface BillingRepository {
  findCustomerByOrganizationId(organizationId: OrganizationId): Promise<BillingCustomer | null>;
  findSubscriptionByOrganizationId(
    organizationId: OrganizationId,
  ): Promise<BillingSubscription | null>;
  findUsageCounter(
    organizationId: OrganizationId,
    periodStart: string,
    periodEnd: string,
  ): Promise<UsageCounter | null>;
  upsertUsageCounter(counter: UsageCounter): Promise<void>;
}

export class InMemoryBillingRepository implements BillingRepository {
  async findCustomerByOrganizationId() {
    return null;
  }

  async findSubscriptionByOrganizationId() {
    return null;
  }

  async findUsageCounter() {
    return null;
  }

  async upsertUsageCounter() {}
}
