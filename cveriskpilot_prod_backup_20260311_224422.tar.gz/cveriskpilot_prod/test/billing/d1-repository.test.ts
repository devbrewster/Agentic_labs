import { describe, expect, it } from "vitest";

import { D1BillingRepository } from "@/lib/billing/d1-repository";

class FakeD1PreparedStatement {
  private params: unknown[] = [];

  constructor(private readonly sql: string) {}

  bind(...params: unknown[]) {
    this.params = params;
    return this;
  }

  async first<T>() {
    const [organizationId] = this.params as [string];

    if (this.sql.includes("FROM billing_customers")) {
      return {
        organization_id: organizationId,
        stripe_customer_id: "cus_test_123",
        created_at: "2026-03-01T00:00:00.000Z",
        updated_at: "2026-03-01T00:00:00.000Z",
      } as T;
    }

    if (this.sql.includes("FROM subscriptions")) {
      return {
        organization_id: organizationId,
        stripe_subscription_id: "sub_test_123",
        status: "active",
        price_id: "price_test_pro",
        current_period_start: "2026-03-01T00:00:00.000Z",
        current_period_end: "2026-04-01T00:00:00.000Z",
        cancel_at_period_end: 0,
        created_at: "2026-03-01T00:00:00.000Z",
        updated_at: "2026-03-01T00:00:00.000Z",
      } as T;
    }

    if (this.sql.includes("FROM usage_counters")) {
      return {
        organization_id: organizationId,
        period_start: "2026-03-01T00:00:00.000Z",
        period_end: "2026-04-01T00:00:00.000Z",
        uploads_used: 2,
        analyses_used: 4,
        cve_lookups_used: 7,
        exports_used: 1,
        updated_at: "2026-03-11T10:00:00.000Z",
      } as T;
    }

    throw new Error(`Unsupported SQL in fake D1 first: ${this.sql}`);
  }

  async run() {
    return {
      meta: {
        changes: 1,
      },
    };
  }
}

class FakeD1Database {
  prepare(sql: string) {
    return new FakeD1PreparedStatement(sql);
  }
}

describe("D1BillingRepository", () => {
  it("reads org-scoped customer, subscription, and usage rows", async () => {
    const repository = new D1BillingRepository(new FakeD1Database() as never);
    const organizationId = crypto.randomUUID();

    const customer = await repository.findCustomerByOrganizationId(organizationId);
    const subscription = await repository.findSubscriptionByOrganizationId(organizationId);
    const usage = await repository.findUsageCounter(
      organizationId,
      "2026-03-01T00:00:00.000Z",
      "2026-04-01T00:00:00.000Z",
    );

    expect(customer?.stripeCustomerId).toBe("cus_test_123");
    expect(subscription?.status).toBe("active");
    expect(usage?.uploadsUsed).toBe(2);
    expect(usage?.analysesUsed).toBe(4);
  });
});
