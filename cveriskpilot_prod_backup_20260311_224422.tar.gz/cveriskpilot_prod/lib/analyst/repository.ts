import {
  AnalystDispositionEventSchema,
  AnalystDispositionRecordSchema,
  AnalystDispositionResponseSchema,
  type AnalystDispositionEvent,
  type AnalystDispositionRecord,
  type AnalystDispositionResponse,
  type UpsertAnalystDispositionInput,
} from "@/types/analyst";

export type AnalystDispositionRepository = {
  findByFindingId(findingId: string): Promise<AnalystDispositionRecord | null>;
  listHistoryByFindingId(findingId: string): Promise<AnalystDispositionEvent[]>;
  upsertByFindingId(
    findingId: string,
    input: UpsertAnalystDispositionInput,
  ): Promise<AnalystDispositionResponse>;
};

export class InMemoryAnalystDispositionRepository implements AnalystDispositionRepository {
  private readonly records = new Map<string, AnalystDispositionRecord>();
  private readonly history = new Map<string, AnalystDispositionEvent[]>();

  async findByFindingId(findingId: string): Promise<AnalystDispositionRecord | null> {
    const record = this.records.get(findingId);
    return record ? AnalystDispositionRecordSchema.parse(record) : null;
  }

  async listHistoryByFindingId(findingId: string): Promise<AnalystDispositionEvent[]> {
    return (this.history.get(findingId) ?? []).map((event) =>
      AnalystDispositionEventSchema.parse(event),
    );
  }

  async upsertByFindingId(
    findingId: string,
    input: UpsertAnalystDispositionInput,
  ): Promise<AnalystDispositionResponse> {
    const now = new Date().toISOString();
    const current = this.records.get(findingId);
    const createdAt = current?.createdAt ?? now;

    const nextRecord = AnalystDispositionRecordSchema.parse({
      findingId,
      decision: input.decision,
      rationale: input.rationale,
      notes: input.notes,
      factors: input.factors,
      updatedBy: input.updatedBy,
      updatedAt: now,
      createdAt,
    });

    this.records.set(findingId, nextRecord);

    const nextEvent = AnalystDispositionEventSchema.parse({
      id: crypto.randomUUID(),
      findingId,
      decision: input.decision,
      rationale: input.rationale,
      notes: input.notes,
      factors: input.factors,
      updatedBy: input.updatedBy,
      createdAt: now,
    });

    const previous = this.history.get(findingId) ?? [];
    this.history.set(findingId, [nextEvent, ...previous]);

    return AnalystDispositionResponseSchema.parse({
      disposition: nextRecord,
      history: this.history.get(findingId) ?? [],
    });
  }
}
