#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-.}"
REPO_ROOT="$(cd "$REPO_ROOT" && pwd)"

code "$REPO_ROOT" --new-window
sleep 1
code "$REPO_ROOT" --new-window
sleep 1
code "$REPO_ROOT" --new-window
sleep 1
code "$REPO_ROOT" --new-window

echo "Opened 4 VS Code windows."
echo "Assign roles:"
echo "1. Orchestrator Agent"
echo "2. Program Manager Agent"
echo "3. SaaS Product & UX Audit Agent"
echo "4. Security / Architecture / Platform Audit Agent"