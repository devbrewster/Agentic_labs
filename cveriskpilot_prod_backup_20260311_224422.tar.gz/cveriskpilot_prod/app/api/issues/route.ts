import { NextResponse } from "next/server";

import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";
import {
  buildDiscordPendingIssuesReport,
  buildInternalPendingIssuesReport,
  getPendingIssueSummary,
  listPendingIssues,
} from "@/lib/services/issues";

export async function GET(request: Request) {
  const auth = await requireCurrentOrganizationAccess(request);

  if (!auth.ok) {
    return auth.response;
  }

  const url = new URL(request.url);
  const format = url.searchParams.get("format");

  if (format === "discord") {
    return new NextResponse(buildDiscordPendingIssuesReport(), {
      headers: {
        "Content-Type": "text/markdown; charset=utf-8",
      },
    });
  }

  if (format === "internal") {
    return new NextResponse(buildInternalPendingIssuesReport(), {
      headers: {
        "Content-Type": "text/markdown; charset=utf-8",
      },
    });
  }

  return NextResponse.json({
    ok: true,
    data: {
      summary: getPendingIssueSummary(),
      issues: listPendingIssues(),
    },
  });
}
