"use client";

import { useMemo, useState } from "react";

import { StatusPill } from "@/components/dashboard/StatusPill";
import { listActionPlanColumns, listActionPlans } from "@/lib/services/action-plans";

const statusTone = {
  open: "danger",
  in_progress: "warning",
  completed: "accent",
} as const;

export function ActionPlansBoard() {
  const actionPlanColumns = listActionPlanColumns();
  const actionPlans = listActionPlans();
  const [selectedPlanId, setSelectedPlanId] = useState<string>(actionPlans[0]?.id ?? "");

  const groupedPlans = useMemo(
    () =>
      actionPlanColumns.map((column) => ({
        ...column,
        plans: actionPlans.filter((plan) => plan.status === column.key),
      })),
    [actionPlanColumns, actionPlans],
  );

  const selectedPlan =
    actionPlans.find((plan) => plan.id === selectedPlanId) ?? actionPlans[0] ?? null;

  return (
    <section className="grid gap-5 2xl:grid-cols-[minmax(0,1.8fr)_360px]">
      <div className="space-y-5">
        <div className="grid gap-3 md:grid-cols-3">
          {groupedPlans.map((column) => (
            <div
              key={column.key}
              className="rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] px-4 py-4 shadow-[0_12px_26px_rgba(0,0,0,0.18)]"
            >
              <div className="flex items-center justify-between gap-3">
                <div className="font-mono text-[0.62rem] uppercase tracking-[0.14em] text-[#5a7080]">
                  {column.label}
                </div>
                <StatusPill tone={statusTone[column.key]}>{column.plans.length}</StatusPill>
              </div>
            </div>
          ))}
        </div>

        <div className="grid gap-4 xl:grid-cols-3">
          {groupedPlans.map((column) => (
            <section
              key={column.key}
              className="flex min-h-[420px] flex-col overflow-hidden rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] shadow-[0_18px_48px_rgba(0,0,0,0.22)]"
            >
              <div className="flex items-center gap-3 border-b border-[rgba(0,200,180,0.06)] px-4 py-3">
                <div className="font-mono text-[0.7rem] uppercase tracking-[0.12em] text-[var(--accent)]">
                  // {column.label}
                </div>
                <div className="ml-auto font-mono text-[0.62rem] uppercase tracking-[0.12em] text-[#5a7080]">
                  {column.plans.length} plans
                </div>
              </div>

              <div className="min-h-0 space-y-3 overflow-y-auto px-4 py-4">
                {column.plans.map((plan) => {
                  const isSelected = plan.id === selectedPlan?.id;

                  return (
                    <button
                      key={plan.id}
                      type="button"
                      onClick={() => setSelectedPlanId(plan.id)}
                      className={`w-full rounded border px-4 py-4 text-left transition ${
                        isSelected
                          ? "border-[rgba(0,200,180,0.18)] bg-[rgba(0,200,180,0.08)]"
                          : "border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] hover:bg-[rgba(0,200,180,0.03)]"
                      }`}
                    >
                      <div className="flex flex-wrap items-center gap-2">
                        <StatusPill tone={statusTone[plan.status]}>{plan.priority}</StatusPill>
                        <StatusPill>{plan.relatedCve}</StatusPill>
                      </div>

                      <h3 className="mt-3 text-[0.9rem] font-semibold leading-7 text-white">
                        {plan.title}
                      </h3>

                      <div className="mt-3 space-y-1 font-mono text-[0.66rem] uppercase tracking-[0.08em] text-[#5a7080]">
                        <div>Assignee: {plan.assignee}</div>
                        <div>Component: {plan.component}</div>
                        <div>ETA: {plan.eta}</div>
                      </div>

                      <div className="mt-3 flex flex-wrap gap-2">
                        {plan.labels.map((label) => (
                          <StatusPill key={label}>{label}</StatusPill>
                        ))}
                      </div>
                    </button>
                  );
                })}
              </div>
            </section>
          ))}
        </div>
      </div>

      <aside className="flex min-h-[520px] flex-col overflow-hidden rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] shadow-[0_18px_48px_rgba(0,0,0,0.22)]">
        <div className="flex items-center gap-3 border-b border-[rgba(0,200,180,0.06)] px-4 py-3">
          <div className="font-mono text-[0.75rem] uppercase tracking-[0.12em] text-[var(--accent)]">
            // Plan Details
          </div>
        </div>

        <div className="space-y-4 px-4 py-4">
          {selectedPlan ? (
            <>
              <div>
                <div className="flex flex-wrap gap-2">
                  <StatusPill tone={statusTone[selectedPlan.status]}>
                    {selectedPlan.status.replaceAll("_", " ")}
                  </StatusPill>
                  <StatusPill>{selectedPlan.relatedCve}</StatusPill>
                </div>
                <h3 className="mt-3 text-[1rem] font-semibold leading-tight text-white">
                  {selectedPlan.title}
                </h3>
              </div>

              <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4 font-mono text-[0.7rem] leading-7 text-[var(--text)]">
                <div>
                  <span className="text-[var(--accent)]">PRIORITY:</span> {selectedPlan.priority}
                </div>
                <div>
                  <span className="text-[var(--accent)]">ASSIGNEE:</span> {selectedPlan.assignee}
                </div>
                <div>
                  <span className="text-[var(--accent)]">COMPONENT:</span> {selectedPlan.component}
                </div>
                <div>
                  <span className="text-[var(--accent)]">ETA:</span> {selectedPlan.eta}
                </div>
                <div>
                  <span className="text-[var(--accent)]">INTEGRATIONS:</span>{" "}
                  {selectedPlan.integrationTargets?.join(", ") ?? "pending"}
                </div>
              </div>

              <div>
                <div className="mb-2 font-mono text-[0.62rem] uppercase tracking-[0.15em] text-[#5a7080]">
                  Plan Summary
                </div>
                <p className="text-[0.82rem] leading-8 text-[var(--text)] opacity-90">
                  {selectedPlan.summary}
                </p>
              </div>

              <div>
                <div className="mb-2 font-mono text-[0.62rem] uppercase tracking-[0.15em] text-[#5a7080]">
                  Labels
                </div>
                <div className="flex flex-wrap gap-2">
                  {selectedPlan.labels.map((label) => (
                    <StatusPill key={label}>{label}</StatusPill>
                  ))}
                </div>
              </div>

              <div>
                <div className="mb-2 font-mono text-[0.62rem] uppercase tracking-[0.15em] text-[#5a7080]">
                  Tracking Notes
                </div>
                <p className="text-[0.82rem] leading-8 text-[var(--text-dim)]">
                  {selectedPlan.notes ??
                    "Execution notes will be captured here once ticket synchronization and persistence are connected."}
                </p>
              </div>
            </>
          ) : null}
        </div>
      </aside>
    </section>
  );
}
