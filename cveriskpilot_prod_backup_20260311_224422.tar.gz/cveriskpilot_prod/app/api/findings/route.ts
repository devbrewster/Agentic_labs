import { NextResponse } from "next/server";

import { getAnalystRuntime } from "@/lib/analyst/runtime";
import { getCachedFindings } from "@/lib/cache/workload-cache";
import { getEnrichmentRuntime } from "@/lib/enrichment/runtime";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";
import { buildEnrichmentSummary } from "@/lib/services/enrichment-summary";
import { listFindings } from "@/lib/services/findings";
import { mapNormalizedFindingToDashboardFinding } from "@/lib/services/findings";
import { applyPrioritizationInfluence, sortFindingsByPriority } from "@/lib/services/findings";
import type { AnalystDispositionRecord } from "@/types/analyst";
import { toArchitectureSummary } from "@/types/analyst";
import type { Finding } from "@/types/dashboard";

const FINDINGS_LIST_HYDRATION_LIMIT = 20;

export async function GET(request: Request) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const data = await getCachedFindings(auth.organizationId, async () => {
      const { uploadRepository } = await getIngestionRuntime();
      const normalizedFindings = await uploadRepository.listFindingsByTenant(auth.organizationId);

      if (normalizedFindings.length === 0) {
        return {
          findings: [],
          source: "ingestion" as const,
          total: 0,
        };
      }

      const uploadRecords = await uploadRepository.listByTenant(auth.organizationId);
      const parseOutcomes = await uploadRepository.parseOutcomes.listByUploadJobIds(
        uploadRecords.map((record) => record.uploadJob.id),
      );
      const parseOutcomeByUploadJobId = new Map(
        parseOutcomes.map((outcome) => [outcome.uploadJobId, outcome] as const),
      );
      const uploadContextByJobId = new Map(
        uploadRecords.map((record) => [
          record.uploadJob.id,
          {
            artifactFilename: record.rawArtifact.originalFilename,
            checksumSha256: record.rawArtifact.checksumSha256,
            warningCount: record.uploadJob.warningCount,
            errorCount:
              parseOutcomeByUploadJobId.get(record.uploadJob.id)?.parserErrors.length ?? 0,
          },
        ] as const),
      );

      const shouldHydrateRelatedState =
        normalizedFindings.length <= FINDINGS_LIST_HYDRATION_LIMIT;

      let enrichmentSummaryByFindingId = new Map<
        string,
        NonNullable<Finding["enrichmentSummary"]>
      >();
      let dispositionByFindingId = new Map<string, AnalystDispositionRecord | null>();

      if (shouldHydrateRelatedState) {
        const [{ enrichmentRepository }, { analystDispositionRepository }] = await Promise.all([
          getEnrichmentRuntime(),
          getAnalystRuntime(),
        ]);

        const enrichmentSummaryEntries = await Promise.all(
          normalizedFindings.map(async (finding) => {
            const snapshots = await enrichmentRepository.listSnapshotsByFindingId(finding.id);
            return [finding.id, buildEnrichmentSummary(snapshots)] as const;
          }),
        );
        enrichmentSummaryByFindingId = new Map(enrichmentSummaryEntries);

        const dispositionEntries = await Promise.all(
          normalizedFindings.map(async (finding) => {
            try {
              const disposition = await analystDispositionRepository.findByFindingId(finding.id);
              return [finding.id, disposition] as const;
            } catch {
              return [finding.id, null] as const;
            }
          }),
        );
        dispositionByFindingId = new Map(dispositionEntries);
      }

      return {
        findings: sortFindingsByPriority(normalizedFindings.map((finding) => {
          const disposition = dispositionByFindingId.get(finding.id) ?? null;
          const mappedFinding = mapNormalizedFindingToDashboardFinding(
            finding,
            uploadContextByJobId.get(finding.uploadJobId) ?? undefined,
          );
          const enrichedFinding = {
            ...mappedFinding,
            enrichmentSummary: enrichmentSummaryByFindingId.get(finding.id),
            analystDisposition: disposition?.decision ?? mappedFinding.analystDisposition,
            analystRationale: disposition?.rationale ?? mappedFinding.analystRationale,
            analystNotes: disposition?.notes ?? mappedFinding.analystNotes,
            decisionRationale: disposition?.rationale ?? mappedFinding.decisionRationale,
            architectureContextSummary: disposition
              ? toArchitectureSummary(disposition.factors)
              : mappedFinding.architectureContextSummary,
          };
          return applyPrioritizationInfluence(enrichedFinding, disposition ?? null);
        })),
        source: "ingestion" as const,
        total: normalizedFindings.length,
      };
    });

    return NextResponse.json({
      ok: true,
      data,
    });
  } catch (error) {
    console.error("Falling back to mock findings:", error);
    return NextResponse.json({
      ok: true,
      data: {
        findings: listFindings(),
        source: "mock",
        total: listFindings().length,
      },
    });
  }
}
