# Core Readiness Execution Plan

Last updated: 2026-03-11
Status: completed

## Purpose

This plan breaks `docs/core-readiness-checklist.md` into executable chunks.

Billing remains blocked until all chunks required for core readiness are complete.

## Chunk Sequence

| Chunk | Title | Status |
|---|---|---|
| CR-1 | Nessus parser implementation + fixtures/tests | completed |
| CR-2 | Qualys parser implementation + fixtures/tests | completed |
| CR-3 | Rapid7 parser implementation + fixtures/tests | completed |
| CR-4 | Parser parity validation in `dev` and `preview` | completed |
| CR-5 | Enrichment reliability hardening (NVD + KEV) | completed |
| CR-6 | AI analysis safety + audit trace hardening | completed |
| CR-7 | Analyst feedback influence on prioritization | completed |
| CR-8 | Stakeholder insight readiness + executive summary validation | completed |
| CR-9 | Operational hardening closeout | completed |

## CR-1 Scope

Implement a real Nessus parser for `.nessus` / Nessus XML exports.

Deliverables:

- real `NessusParser` finding extraction
- normalization for host and vulnerability fields
- warnings for partial field quality
- Nessus XML fixture with realistic `ReportHost` + `ReportItem`
- parser unit tests

Acceptance:

- Nessus findings are extracted into normalized findings
- metadata host count and finding count are correct
- parser does not return fatal `not implemented` errors for valid Nessus XML

## Exit Rule

CR-1 is complete only after:

1. Tests pass
2. Progress log is updated
3. This file is updated to mark CR-1 `completed`
