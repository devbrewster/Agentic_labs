import { describe, expect, it } from "vitest";

import { PostgresAnalystDispositionRepository } from "@/lib/analyst/postgres-repository";
import type { PostgresQueryClient } from "@/lib/platform/database";

describe("PostgresAnalystDispositionRepository", () => {
  it("maps analyst disposition records through the shared SQL repository implementation", async () => {
    const findingId = crypto.randomUUID();

    const client: PostgresQueryClient = {
      async query<T>(sql: string, params?: readonly unknown[]) {
        if (sql.includes("FROM analyst_dispositions")) {
          expect(sql).toContain("WHERE finding_id = $1");
          expect(params).toEqual([findingId]);

          return {
            rows: [
              {
                finding_id: findingId,
                decision: "true_risk",
                rationale: "validated by analyst",
                notes: "monitor closely",
                factors_json: JSON.stringify({
                  internetExposed: true,
                  internalOnly: false,
                  segmentedNetwork: false,
                  compensatingControlPresent: false,
                  assetCriticality: "critical",
                  authRequired: false,
                  reachableFromAttackerPath: true,
                }),
                updated_by: "sec-analyst",
                updated_at: "2026-03-11T12:00:00.000Z",
                created_at: "2026-03-11T11:00:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        if (sql.includes("FROM analyst_disposition_events")) {
          expect(sql).toContain("WHERE finding_id = $1");
          expect(params).toEqual([findingId]);

          return {
            rows: [
              {
                id: crypto.randomUUID(),
                finding_id: findingId,
                decision: "true_risk",
                rationale: "validated by analyst",
                notes: "monitor closely",
                factors_json: JSON.stringify({
                  internetExposed: true,
                  internalOnly: false,
                  segmentedNetwork: false,
                  compensatingControlPresent: false,
                  assetCriticality: "critical",
                  authRequired: false,
                  reachableFromAttackerPath: true,
                }),
                updated_by: "sec-analyst",
                created_at: "2026-03-11T12:00:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        throw new Error(`Unexpected SQL in test client: ${sql}`);
      },
    };

    const repository = new PostgresAnalystDispositionRepository(client);
    const [disposition, history] = await Promise.all([
      repository.findByFindingId(findingId),
      repository.listHistoryByFindingId(findingId),
    ]);

    expect(disposition?.findingId).toBe(findingId);
    expect(disposition?.decision).toBe("true_risk");
    expect(history).toHaveLength(1);
    expect(history[0]?.updatedBy).toBe("sec-analyst");
  });
});
