import {
  createUnknownSourceError,
  createUnsupportedSelectedSourceError,
  detectSourceType,
} from "@/lib/ingestion/detection";
import {
  ParserSelectionInputSchema,
  type ParserDetectionHint,
  type ParserRegistry,
  type ScannerParser,
  type ScannerSourceType,
} from "@/types/ingestion";

export class DefaultParserRegistry implements ParserRegistry {
  private readonly parsers = new Map<ScannerSourceType, ScannerParser>();

  register(parser: ScannerParser) {
    if (this.parsers.has(parser.sourceType)) {
      throw new Error(`Parser already registered for source type '${parser.sourceType}'.`);
    }

    this.parsers.set(parser.sourceType, parser);
  }

  getBySourceType(sourceType: ScannerSourceType) {
    return this.parsers.get(sourceType) ?? null;
  }

  async detectParser(input: ParserDetectionHint) {
    const detectedSourceType = detectSourceType(input);

    if (!detectedSourceType) {
      return null;
    }

    const parser = this.getBySourceType(detectedSourceType);

    if (!parser) {
      return null;
    }

    const canParse = await parser.canParse(input);
    return canParse ? parser : null;
  }

  listParsers() {
    return Array.from(this.parsers.values());
  }

  async resolve(input: Parameters<ParserRegistry["resolve"]>[0]) {
    const validatedInput = ParserSelectionInputSchema.parse(input);
    const { selectedSourceType, detectionHint } = validatedInput;

    if (selectedSourceType) {
      const explicitParser = this.getBySourceType(selectedSourceType);

      if (!explicitParser) {
        return {
          parser: null,
          error: createUnsupportedSelectedSourceError({
            selectedSourceType,
            fileType: detectionHint.fileType,
          }),
        };
      }

      const supportsFileType = explicitParser.supportedFileTypes.includes(detectionHint.fileType);
      const canParse = await explicitParser.canParse(detectionHint);

      if (!supportsFileType || !canParse) {
        return {
          parser: null,
          error: {
            code: "selected_source_mismatch",
            message: `Selected source '${selectedSourceType}' does not match the uploaded file.`,
            details: {
              selectedSourceType,
              fileType: detectionHint.fileType,
              filename: detectionHint.filename,
            },
            fatal: true,
          },
        };
      }

      return {
        parser: explicitParser,
        error: null,
      };
    }

    const detectedParser = await this.detectParser(detectionHint);

    if (!detectedParser) {
      return {
        parser: null,
        error: createUnknownSourceError(detectionHint),
      };
    }

    return {
      parser: detectedParser,
      error: null,
    };
  }
}
