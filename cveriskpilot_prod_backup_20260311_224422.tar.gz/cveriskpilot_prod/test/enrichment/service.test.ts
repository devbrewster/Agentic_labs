import { describe, expect, it } from "vitest";

import { createDefaultEnrichmentService } from "@/lib/enrichment";

describe("EnrichmentService", () => {
  it("returns completed status for registered providers", async () => {
    const service = createDefaultEnrichmentService();

    const result = await service.enrichFinding({
      triggeredBy: "test",
      providers: ["nvd", "cisa_kev"],
      finding: {
        findingId: "65cc6cb4-1fca-496b-9b31-61f64f6d56f4",
        cveIds: ["CVE-2024-21413"],
        title: "Outlook RCE",
        description: "test finding",
        normalizedSeverity: "critical",
        cvssScore: 9.8,
        sourceUpdatedAt: null,
      },
    });

    expect(result.runStatus).toBe("completed");
    expect(result.completedProviders).toHaveLength(2);
    expect(result.errorCount).toBe(0);
  });

  it("returns partial status when a provider is not registered", async () => {
    const service = createDefaultEnrichmentService();

    const result = await service.enrichFinding({
      triggeredBy: "test",
      providers: ["nvd", "wiz"],
      finding: {
        findingId: "d4284ff1-fe00-460c-9e0f-43d80559c085",
        cveIds: ["CVE-2026-9999"],
        title: "Provider registration test",
        description: null,
        normalizedSeverity: "medium",
        cvssScore: null,
        sourceUpdatedAt: null,
      },
    });

    expect(result.runStatus).toBe("partial");
    expect(result.errorCount).toBe(1);
    expect(result.completedProviders.some((item) => item.errorCode === "provider_not_registered")).toBe(true);
  });

  it("returns failed status when every requested provider errors", async () => {
    const service = createDefaultEnrichmentService();

    const result = await service.enrichFinding({
      triggeredBy: "test",
      providers: ["wiz", "snyk"],
      finding: {
        findingId: "9d84f2f1-f4a9-4b38-b01e-f2b57564fc77",
        cveIds: ["CVE-2026-9998"],
        title: "Failure path test",
        description: null,
        normalizedSeverity: "high",
        cvssScore: null,
        sourceUpdatedAt: null,
      },
    });

    expect(result.runStatus).toBe("failed");
    expect(result.errorCount).toBe(2);
    expect(result.completedProviders.every((item) => item.status === "error")).toBe(true);
  });
});
