import {
  NormalizedFindingSchema,
  ParseResultSchema,
  type ArtifactFileType,
  type NormalizedFinding,
  type NormalizedSeverity,
  type ParseContext,
  type ParseMetadata,
  type ParseResult,
  type ParserDetectionHint,
  type ParserWarning,
  type RawArtifact,
  type ScannerParser,
} from "@/types/ingestion";

const NESSUS_SCANNER_NAME = "Tenable Nessus";

function extractXmlRootTag(sampleText: string | null) {
  if (!sampleText) {
    return null;
  }

  const match = sampleText.match(/<([A-Za-z_][\w:.-]*)[^>]*>/);
  return match?.[1] ?? null;
}

function extractScannerVersion(sampleText: string | null) {
  if (!sampleText) {
    return null;
  }

  const match = sampleText.match(/<NessusClientData_v2[^>]*version="([^"]+)"/i);
  return match?.[1] ?? null;
}

function decodeXmlText(value: string | null) {
  if (!value) {
    return null;
  }

  return value
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim();
}

function extractAttributeValue(tag: string, attributeName: string) {
  const match = tag.match(new RegExp(`${attributeName}="([^"]*)"`, "i"));
  return decodeXmlText(match?.[1] ?? null);
}

function extractTagValue(block: string, tagName: string) {
  const match = block.match(new RegExp(`<${tagName}>([\\s\\S]*?)</${tagName}>`, "i"));
  return decodeXmlText(match?.[1] ?? null);
}

function extractTagValues(block: string, tagName: string) {
  return Array.from(block.matchAll(new RegExp(`<${tagName}>([\\s\\S]*?)</${tagName}>`, "gi")))
    .map((match) => decodeXmlText(match[1] ?? null))
    .filter((value): value is string => Boolean(value));
}

function normalizeSeverity(value: string | null): NormalizedSeverity {
  switch ((value ?? "").trim().toLowerCase()) {
    case "4":
    case "critical":
      return "critical";
    case "3":
    case "high":
      return "high";
    case "2":
    case "medium":
    case "moderate":
      return "medium";
    case "1":
    case "low":
      return "low";
    case "0":
    case "info":
    case "informational":
      return "informational";
    default:
      return "unknown";
  }
}

function extractCvssScore(itemBlock: string) {
  const raw = extractTagValue(itemBlock, "cvss3_base_score") ?? extractTagValue(itemBlock, "cvss_base_score");
  if (!raw) {
    return null;
  }

  const parsed = Number(raw);
  return Number.isFinite(parsed) ? parsed : null;
}

function extractCvssVector(itemBlock: string) {
  return extractTagValue(itemBlock, "cvss3_vector") ?? extractTagValue(itemBlock, "cvss_vector");
}

function extractHostProperties(hostBlock: string) {
  const propertiesBlock = hostBlock.match(/<HostProperties>([\s\S]*?)<\/HostProperties>/i)?.[1] ?? "";
  const tags = Array.from(
    propertiesBlock.matchAll(/<tag[^>]*name="([^"]+)"[^>]*>([\s\S]*?)<\/tag>/gi),
  );

  const properties = new Map<string, string>();

  for (const [, rawName, rawValue] of tags) {
    properties.set(rawName.toLowerCase(), decodeXmlText(rawValue)?.trim() ?? "");
  }

  return {
    hostIp: properties.get("host-ip") || null,
    fqdn: properties.get("host-fqdn") || null,
    operatingSystem: properties.get("operating-system") || null,
  };
}

function extractCveIds(itemBlock: string) {
  return extractTagValues(itemBlock, "cve")
    .flatMap((value) => value.split(/[\s,;|]+/))
    .map((value) => value.trim().toUpperCase())
    .filter((value, index, values) => /^CVE-\d{4}-\d{4,}$/i.test(value) && values.indexOf(value) === index);
}

function buildRecordId(hostName: string | null, pluginId: string | null, index: number) {
  return `${hostName ?? "unknown-host"}:${pluginId ?? "unknown-plugin"}:${index}`;
}

function buildMetadata(input: {
  artifact: RawArtifact;
  parsedAt: string;
  sampleText: string;
  hostCount: number;
  findingCount: number;
}): ParseMetadata {
  return {
    scannerName: NESSUS_SCANNER_NAME,
    scannerVersion: extractScannerVersion(input.sampleText),
    sourceType: "nessus",
    fileType: input.artifact.fileType,
    hostCount: input.hostCount,
    findingCount: input.findingCount,
    parsedAt: input.parsedAt,
    checksumSha256: input.artifact.checksumSha256,
  };
}

export class NessusParser implements ScannerParser {
  readonly sourceType = "nessus" as const;
  readonly displayName = NESSUS_SCANNER_NAME;
  readonly supportedFileTypes: readonly ArtifactFileType[] = ["xml"];

  async canParse(input: ParserDetectionHint) {
    if (!this.supportedFileTypes.includes(input.fileType)) {
      return false;
    }

    const rootTag = extractXmlRootTag(input.sampleText);

    return (
      /nessus/i.test(input.filename) ||
      /\.nessus$/i.test(input.filename) ||
      rootTag?.toLowerCase() === "nessusclientdata_v2"
    );
  }

  async parse(input: {
    artifact: RawArtifact;
    content: string;
    context: ParseContext;
  }): Promise<ParseResult> {
    const parsedAt = input.context.now;
    const parserWarnings: ParserWarning[] = [];
    const findings: NormalizedFinding[] = [];
    const hostBlocks = Array.from(
      input.content.matchAll(/<ReportHost\b([^>]*)>([\s\S]*?)<\/ReportHost>/gi),
    );

    if (hostBlocks.length === 0) {
      return ParseResultSchema.parse({
        findings: [],
        parserWarnings: [],
        parserErrors: [
          {
            code: "nessus_missing_report_hosts",
            message: "Nessus XML did not contain any ReportHost entries.",
            details: null,
            fatal: true,
          },
        ],
        metadata: buildMetadata({
          artifact: input.artifact,
          parsedAt,
          sampleText: input.content.slice(0, 8192),
          hostCount: 0,
          findingCount: 0,
        }),
      });
    }

    hostBlocks.forEach((hostMatch, hostIndex) => {
      const hostAttributes = hostMatch[1] ?? "";
      const hostBlock = hostMatch[2] ?? "";
      const hostname = extractAttributeValue(hostAttributes, "name");
      const hostProperties = extractHostProperties(hostBlock);
      const itemBlocks = Array.from(
        hostBlock.matchAll(/<ReportItem\b([^>]*)>([\s\S]*?)<\/ReportItem>/gi),
      );

      if (itemBlocks.length === 0) {
        parserWarnings.push({
          code: "nessus_host_without_items",
          message: `Host '${hostname ?? `index-${hostIndex}`}' did not contain any ReportItem entries.`,
          field: "ReportHost",
          row: hostIndex + 1,
          level: "warning",
        });
      }

      itemBlocks.forEach((itemMatch, itemIndex) => {
        const itemAttributes = itemMatch[1] ?? "";
        const itemBlock = itemMatch[2] ?? "";
        const pluginId = extractAttributeValue(itemAttributes, "pluginID");
        const pluginName = extractAttributeValue(itemAttributes, "pluginName");
        const severityValue = extractAttributeValue(itemAttributes, "severity");
        const portValue = extractAttributeValue(itemAttributes, "port");
        const protocol = extractAttributeValue(itemAttributes, "protocol");
        const serviceName = extractAttributeValue(itemAttributes, "svc_name");
        const cveIds = extractCveIds(itemBlock);

        if (!pluginId) {
          parserWarnings.push({
            code: "nessus_missing_plugin_id",
            message: `Nessus finding on host '${hostname ?? hostProperties.hostIp ?? "unknown"}' is missing pluginID.`,
            field: "pluginID",
            row: itemIndex + 1,
            level: "warning",
          });
        }

        findings.push(
          NormalizedFindingSchema.parse({
            id: crypto.randomUUID(),
            uploadJobId: input.context.uploadJob.id,
            rawRecordRef: {
              recordId: buildRecordId(hostname, pluginId, itemIndex),
              recordIndex: itemIndex,
              locationHint: hostname ?? hostProperties.hostIp,
              sourceChecksumSha256: input.artifact.checksumSha256,
            },
            assetIdentifier: hostname ?? hostProperties.hostIp,
            hostname,
            fqdn: hostProperties.fqdn,
            ipAddress: hostProperties.hostIp,
            port: portValue ? Number(portValue) : null,
            protocol: protocol ?? serviceName,
            vulnerabilityId: pluginId,
            pluginId,
            cveIds,
            title:
              pluginName ??
              extractTagValue(itemBlock, "synopsis") ??
              "Unnamed Nessus finding",
            description: extractTagValue(itemBlock, "description"),
            severity: severityValue,
            normalizedSeverity: normalizeSeverity(severityValue),
            cvssScore: extractCvssScore(itemBlock),
            cvssVector: extractCvssVector(itemBlock),
            remediation: extractTagValue(itemBlock, "solution"),
            evidence: extractTagValue(itemBlock, "plugin_output"),
            status: "open",
            privilegeRequired: "unknown",
            detectedAt: parsedAt,
            firstObservedAt: parsedAt,
            lastObservedAt: parsedAt,
            sourceType: "nessus",
            sourceScanner: NESSUS_SCANNER_NAME,
            tags: [
              "nessus",
              ...(hostProperties.operatingSystem ? [hostProperties.operatingSystem] : []),
            ],
            createdAt: parsedAt,
            updatedAt: parsedAt,
          }),
        );
      });
    });

    if (findings.some((finding) => finding.cveIds.length === 0)) {
      parserWarnings.push({
        code: "nessus_missing_cve",
        message: "One or more Nessus findings did not include CVE identifiers.",
        field: "cve",
        row: null,
        level: "warning",
      });
    }

    return ParseResultSchema.parse({
      findings,
      parserWarnings,
      parserErrors:
        findings.length === 0
          ? [
              {
                code: "nessus_no_findings_extracted",
                message: "Nessus XML was detected but no findings could be normalized.",
                details: null,
                fatal: true,
              },
            ]
          : [],
      metadata: buildMetadata({
        artifact: input.artifact,
        parsedAt,
        sampleText: input.content.slice(0, 8192),
        hostCount: hostBlocks.length,
        findingCount: findings.length,
      }),
    });
  }
}
