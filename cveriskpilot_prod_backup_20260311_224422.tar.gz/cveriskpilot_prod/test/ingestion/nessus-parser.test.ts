import { describe, expect, it } from "vitest";

import { NessusParser } from "@/lib/ingestion/parsers/nessus-parser";
import { nessusXmlFixture } from "@/test/fixtures/generic-csv";
import type { ParseContext, RawArtifact } from "@/types/ingestion";

function createArtifact(): RawArtifact {
  return {
    id: crypto.randomUUID(),
    storageKey: "test/fixture.nessus",
    originalFilename: "fixture.nessus",
    mimeType: "application/xml",
    fileType: "xml",
    sizeBytes: 1024,
    checksumSha256: "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    uploadedAt: "2026-03-10T00:00:00.000Z",
  };
}

function createContext(uploadJobId = crypto.randomUUID()): ParseContext {
  return {
    uploadJob: {
      id: uploadJobId,
      tenantId: null,
      rawArtifactId: crypto.randomUUID(),
      selectedSourceType: "nessus",
      detectedSourceType: "nessus",
      status: "parsing",
      errorSummary: null,
      warningCount: 0,
      findingCount: 0,
      checksumSha256: "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
      createdAt: "2026-03-10T00:00:00.000Z",
      updatedAt: "2026-03-10T00:00:00.000Z",
      parsedAt: null,
    },
    rawArtifact: createArtifact(),
    selectedSourceType: "nessus",
    detectedSourceType: "nessus",
    checksumSha256: "bbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbbb",
    now: "2026-03-10T00:00:00.000Z",
  };
}

describe("NessusParser", () => {
  it("detects and parses Nessus XML into normalized findings", async () => {
    const parser = new NessusParser();
    const canParse = await parser.canParse({
      filename: "example.nessus",
      mimeType: "application/xml",
      fileType: "xml",
      leadingBytes: nessusXmlFixture.slice(0, 32),
      sampleText: nessusXmlFixture.slice(0, 2048),
    });

    expect(canParse).toBe(true);

    const result = await parser.parse({
      artifact: createArtifact(),
      content: nessusXmlFixture,
      context: createContext(),
    });

    expect(result.parserErrors).toHaveLength(0);
    expect(result.findings).toHaveLength(2);
    expect(result.findings[0]?.hostname).toBe("mail-prod-01");
    expect(result.findings[0]?.cveIds).toContain("CVE-2024-21413");
    expect(result.findings[0]?.normalizedSeverity).toBe("critical");
    expect(result.findings[0]?.cvssScore).toBe(9.8);
    expect(result.metadata.hostCount).toBe(1);
    expect(result.metadata.findingCount).toBe(2);
  });

  it("preserves warnings when Nessus findings omit CVE identifiers", async () => {
    const parser = new NessusParser();
    const result = await parser.parse({
      artifact: createArtifact(),
      content: nessusXmlFixture,
      context: createContext(),
    });

    expect(
      result.parserWarnings.some((warning) => warning.code === "nessus_missing_cve"),
    ).toBe(true);
  });
});
