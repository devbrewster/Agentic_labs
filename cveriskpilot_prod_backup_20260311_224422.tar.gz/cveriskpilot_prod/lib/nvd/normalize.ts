import type { NvdApiResponse, VulnerabilityRecord } from "@/lib/nvd/types";
import { VulnerabilityRecordSchema } from "@/lib/nvd/types";

function toIsoOrUndefined(value: string | undefined) {
  if (!value) {
    return undefined;
  }

  const date = new Date(value);
  if (Number.isNaN(date.getTime())) {
    return undefined;
  }

  return date.toISOString();
}

export function normalizeNvdCve(response: NvdApiResponse): VulnerabilityRecord | null {
  const vulnerability = response.vulnerabilities?.[0]?.cve;

  if (!vulnerability?.id) {
    return null;
  }

  const englishDescription =
    vulnerability.descriptions?.find((description) => description.lang === "en")?.value;

  const weaknesses =
    vulnerability.weaknesses?.flatMap((item) =>
      (item.description ?? [])
        .filter((description) => description.lang === "en" && description.value)
        .map((description) => description.value as string),
    ) ?? [];

  const references =
    vulnerability.references
      ?.filter((reference) => reference.url)
      .map((reference) => ({
        url: reference.url as string,
        source: reference.source,
        tags: reference.tags,
      })) ?? [];

  return VulnerabilityRecordSchema.parse({
    cveId: vulnerability.id.toUpperCase(),
    nvd: {
      source: "NVD",
      rawDescription: englishDescription,
      published: toIsoOrUndefined(vulnerability.published),
      lastModified: toIsoOrUndefined(vulnerability.lastModified),
      cvssV31: vulnerability.metrics?.cvssMetricV31?.[0],
      cvssV30: vulnerability.metrics?.cvssMetricV30?.[0],
      cvssV2: vulnerability.metrics?.cvssMetricV2?.[0],
      weaknesses,
      references,
      configurations: vulnerability.configurations,
      rawPayload: response,
    },
    analysis: {
      source: "CVERiskPilot",
    },
    enrichments: {},
    compliance: {
      attributionRequired: true,
      endorsementProhibited: true,
      modifiedContentSeparated: true,
    },
  });
}
