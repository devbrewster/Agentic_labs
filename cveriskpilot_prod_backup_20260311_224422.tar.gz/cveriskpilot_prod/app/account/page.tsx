"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { useEffect, useState } from "react";

type UsageItem = {
  label: string;
  used: number;
  limit: number;
};

type BillingPlan = "free" | "pro";

type MeResponse = {
  ok: boolean;
  data?: {
    user: {
      id: string;
      email: string;
      display_name: string;
      email_verified: boolean;
      created_at: string;
    };
  };
  reason?: string;
};

type BillingResponse = {
  ok: boolean;
  data?: {
    organization: {
      id: string;
      name: string;
      role: string;
    };
    snapshot: {
      plan: BillingPlan;
      upgradeReady: boolean;
      usage: {
        uploadsUsed: number;
        analysesUsed: number;
        cveLookupsUsed: number;
        exportsUsed: number;
      };
      entitlements: {
        uploadsPerMonth: number;
        analysesPerMonth: number;
        cveLookupsPerDay: number;
        exportsPerMonth: number;
      };
      subscription: {
        status: string;
        currentPeriodEnd: string | null;
      } | null;
    };
  };
};

const defaultUsage: UsageItem[] = [
  { label: "Scans This Month", used: 2, limit: 3 },
  { label: "AI Analyses This Month", used: 7, limit: 10 },
  { label: "CVE Lookups Today", used: 3, limit: 10 },
  { label: "Exports This Month", used: 0, limit: 1 },
];

function getUsagePercent(used: number, limit: number) {
  if (!limit) return 0;
  return Math.min((used / limit) * 100, 100);
}

function getUsageColor(percent: number) {
  if (percent >= 85) return "bg-[#ff4560]";
  if (percent >= 60) return "bg-[#ffd060]";
  return "bg-[#00c8b4]";
}

function formatPlanLabel(plan: BillingPlan) {
  return plan === "pro" ? "PRO" : "FREE";
}

function getUsageItems(data: BillingResponse["data"] | undefined): UsageItem[] {
  if (!data) {
    return defaultUsage;
  }

  return [
    {
      label: "Scans This Month",
      used: data.snapshot.usage.uploadsUsed,
      limit: data.snapshot.entitlements.uploadsPerMonth,
    },
    {
      label: "AI Analyses This Month",
      used: data.snapshot.usage.analysesUsed,
      limit: data.snapshot.entitlements.analysesPerMonth,
    },
    {
      label: "CVE Lookups Today",
      used: data.snapshot.usage.cveLookupsUsed,
      limit: data.snapshot.entitlements.cveLookupsPerDay,
    },
    {
      label: "Exports This Month",
      used: data.snapshot.usage.exportsUsed,
      limit: data.snapshot.entitlements.exportsPerMonth,
    },
  ];
}

export default function AccountPage() {
  const router = useRouter();

  const [loadingAccount, setLoadingAccount] = useState(true);
  const [displayName, setDisplayName] = useState("");
  const [email, setEmail] = useState("");
  const [emailVerified, setEmailVerified] = useState(false);

  const [currentPassword, setCurrentPassword] = useState("");
  const [newPassword, setNewPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [organizationName, setOrganizationName] = useState("Workspace");
  const [organizationRole, setOrganizationRole] = useState("viewer");
  const [plan, setPlan] = useState<BillingPlan>("free");
  const [upgradeReady, setUpgradeReady] = useState(false);
  const [usage, setUsage] = useState<UsageItem[]>(defaultUsage);
  const [subscriptionStatus, setSubscriptionStatus] = useState<string | null>(null);
  const [subscriptionRenewal, setSubscriptionRenewal] = useState<string | null>(null);

  const [profileSuccess, setProfileSuccess] = useState("");
  const [profileError, setProfileError] = useState("");
  const [passwordSuccess, setPasswordSuccess] = useState("");
  const [passwordError, setPasswordError] = useState("");

  const [savingProfile, setSavingProfile] = useState(false);
  const [savingPassword, setSavingPassword] = useState(false);
  const [loggingOut, setLoggingOut] = useState(false);
  const [loggingOutAll, setLoggingOutAll] = useState(false);
  const [deletingAccount, setDeletingAccount] = useState(false);

  useEffect(() => {
    let cancelled = false;

    async function loadAccount() {
      try {
        const [accountRes, billingRes] = await Promise.all([
          fetch("/api/auth/me", { cache: "no-store" }),
          fetch("/api/billing", { cache: "no-store" }),
        ]);
        const data = (await accountRes.json().catch(() => ({}))) as MeResponse;
        const billing = (await billingRes.json().catch(() => ({}))) as BillingResponse;

        if (!accountRes.ok || !data.data?.user) {
          router.push("/login");
          return;
        }

        if (cancelled) {
          return;
        }

        setDisplayName(data.data.user.display_name);
        setEmail(data.data.user.email);
        setEmailVerified(data.data.user.email_verified);

        if (billingRes.ok && billing.data) {
          setOrganizationName(billing.data.organization.name);
          setOrganizationRole(billing.data.organization.role);
          setPlan(billing.data.snapshot.plan);
          setUpgradeReady(billing.data.snapshot.upgradeReady);
          setUsage(getUsageItems(billing.data));
          setSubscriptionStatus(billing.data.snapshot.subscription?.status ?? null);
          setSubscriptionRenewal(
            billing.data.snapshot.subscription?.currentPeriodEnd ?? null,
          );
        }
      } catch {
        router.push("/login");
      } finally {
        if (!cancelled) {
          setLoadingAccount(false);
        }
      }
    }

    void loadAccount();

    return () => {
      cancelled = true;
    };
  }, [router]);

  function clearProfileAlerts() {
    setProfileSuccess("");
    setProfileError("");
  }

  function clearPasswordAlerts() {
    setPasswordSuccess("");
    setPasswordError("");
  }

  async function saveProfile() {
    clearProfileAlerts();
    const trimmedName = displayName.trim();

    if (!trimmedName) {
      setProfileError("✗ Display name is required.");
      return;
    }

    setSavingProfile(true);

    try {
      const res = await fetch("/api/auth/me", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ display_name: trimmedName }),
      });

      const data = await res.json().catch(() => ({}));

      if (res.ok) {
        setDisplayName(data.data?.user?.display_name || trimmedName);
        setProfileSuccess("✓ Profile updated successfully.");
      } else {
        setProfileError("✗ Failed to update profile.");
      }
    } catch {
      setProfileError("✗ Network error.");
    } finally {
      setSavingProfile(false);
    }
  }

  async function changePassword() {
    clearPasswordAlerts();

    if (!currentPassword || !newPassword || newPassword.length < 8) {
      setPasswordError("✗ New password must be at least 8 characters.");
      return;
    }

    if (newPassword !== confirmPassword) {
      setPasswordError("✗ Passwords do not match.");
      return;
    }

    setSavingPassword(true);

    try {
      const res = await fetch("/api/auth/password", {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          current_password: currentPassword,
          new_password: newPassword,
        }),
      });

      const data = await res.json().catch(() => ({}));

      if (res.ok) {
        setPasswordSuccess(
          "✓ Password updated. All sessions have been invalidated.",
        );
        setCurrentPassword("");
        setNewPassword("");
        setConfirmPassword("");
        setTimeout(() => {
          router.push("/login");
        }, 1200);
      } else if (data.reason === "invalid_current") {
        setPasswordError("✗ Current password is incorrect.");
      } else {
        setPasswordError("✗ Failed to update password.");
      }
    } catch {
      setPasswordError("✗ Network error.");
    } finally {
      setSavingPassword(false);
    }
  }

  async function handleLogout() {
    setLoggingOut(true);
    try {
      await fetch("/api/auth/logout", { method: "POST" });
      router.push("/login");
    } catch {
      router.push("/login");
    } finally {
      setLoggingOut(false);
    }
  }

  async function logoutAll() {
    const confirmed = window.confirm("Log out of all devices?");
    if (!confirmed) return;

    setLoggingOutAll(true);
    try {
      await fetch("/api/auth/logout-all", { method: "POST" });
      router.push("/login");
    } catch {
      router.push("/login");
    } finally {
      setLoggingOutAll(false);
    }
  }

  async function confirmDelete() {
    const confirmed = window.prompt(
      "Type DELETE to permanently remove your account:",
    );

    if (confirmed !== "DELETE") return;

    setDeletingAccount(true);
    try {
      await fetch("/api/auth/account", { method: "DELETE" });
      router.push("/");
    } catch {
      router.push("/");
    } finally {
      setDeletingAccount(false);
    }
  }

  if (loadingAccount) {
    return (
      <main className="flex min-h-screen items-center justify-center bg-[#040810] text-[#c8d8e8]">
        <div className="font-mono text-[0.75rem] uppercase tracking-[0.1em] text-[#00c8b4]">
          Loading account...
        </div>
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-[#040810] text-[#c8d8e8]">
      <div className="pointer-events-none fixed inset-0 z-0 bg-[linear-gradient(rgba(0,200,180,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(0,200,180,0.02)_1px,transparent_1px)] bg-[size:40px_40px]" />

      <header className="sticky top-0 z-50 border-b border-[rgba(0,200,180,0.06)] bg-[rgba(4,8,16,0.85)] px-4 py-3 backdrop-blur md:px-8">
        <div className="mx-auto flex max-w-6xl items-center gap-4">
          <div className="text-base font-extrabold text-white">
            CVE<span className="text-[#00c8b4]">Risk</span>Pilot
          </div>

          <Link
            href={getDashboardHref("overview")}
            className="font-mono text-[0.72rem] tracking-[0.06em] text-[#4a6070] transition hover:text-[#00c8b4]"
          >
            ← Dashboard
          </Link>

          <div className="ml-auto">
            <button
              type="button"
              onClick={handleLogout}
              disabled={loggingOut}
              className="rounded border border-[rgba(255,69,96,0.3)] px-4 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[rgba(255,69,96,0.6)] transition hover:border-[#ff4560] hover:text-[#ff4560] disabled:opacity-50"
            >
              {loggingOut ? "Logging out..." : "⎋ Log Out"}
            </button>
          </div>
        </div>
      </header>

      <div className="relative z-10 mx-auto max-w-[860px] px-6 py-10">
        <h1 className="text-[1.4rem] font-bold text-white">Account Settings</h1>
        <div className="mb-2 font-mono text-[0.68rem] tracking-[0.1em] text-[#4a6070]">
          {`// ${organizationName.toUpperCase()} · ${formatPlanLabel(plan)} TIER · ${organizationRole.toUpperCase()}`}
        </div>
        <div className="mb-9 inline-flex items-center gap-2 rounded border border-[rgba(0,200,180,0.12)] bg-[#0a1525] px-3 py-2 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[#00c8b4]">
          {emailVerified ? "Verified Email" : "Unverified Email"}
        </div>

        <section className="mb-5 overflow-hidden rounded-md border border-[rgba(0,200,180,0.06)] bg-[#070e1a]">
          <div className="flex items-center justify-between border-b border-[rgba(0,200,180,0.06)] px-6 py-4">
            <div className="font-mono text-[0.72rem] uppercase tracking-[0.12em] text-[#00c8b4]">
              // Current Plan
            </div>
            <Link
              href="/upgrade"
              className="rounded border border-[#00c8b4] bg-[#00c8b4] px-4 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[#040810] transition hover:bg-[#00ffe8]"
            >
              {upgradeReady ? "⬆ Upgrade to Pro" : "Billing Setup Pending"}
            </Link>
          </div>

          <div className="p-6">
            <div className="mb-5 flex items-center gap-5 rounded border border-[rgba(0,200,180,0.12)] bg-[#0a1525] p-5">
              <div className="text-[1.6rem] font-extrabold text-white">{formatPlanLabel(plan)}</div>
              <div className="flex-1">
                <div className="mb-1 font-mono text-[0.68rem] uppercase tracking-[0.15em] text-[#00c8b4]">
                  {plan === "pro" ? "Pro Workspace" : "Free Workspace"}
                </div>
                <div className="text-[0.82rem] leading-6 text-[#4a6070]">
                  {plan === "pro"
                    ? "Your workspace has an active Pro plan with organization-level billing and usage tracking."
                    : "Your workspace is on the Free plan. Upgrading will unlock higher quotas, premium integrations, and advanced reporting."}
                </div>
                {subscriptionStatus ? (
                  <div className="mt-3 font-mono text-[0.64rem] uppercase tracking-[0.12em] text-[#8ca2b4]">
                    {`Subscription: ${subscriptionStatus}${
                      subscriptionRenewal ? ` · renews ${subscriptionRenewal.slice(0, 10)}` : ""
                    }`}
                  </div>
                ) : null}
              </div>
            </div>

            <div className="grid gap-4 sm:grid-cols-2 xl:grid-cols-4">
              {usage.map((item) => {
                const percent = getUsagePercent(item.used, item.limit);
                return (
                  <div
                    key={item.label}
                    className="rounded border border-[rgba(0,200,180,0.06)] bg-[#0a1525] p-4"
                  >
                    <div className="mb-1 font-mono text-[0.62rem] uppercase tracking-[0.12em] text-[#4a6070]">
                      {item.label}
                    </div>
                    <div className="mb-2 text-[1.3rem] font-bold text-white">
                      {item.used}{" "}
                      <span className="text-[0.85rem] font-normal text-[#4a6070]">
                        / {item.limit}
                      </span>
                    </div>
                    <div className="h-1 overflow-hidden rounded bg-[rgba(255,255,255,0.05)]">
                      <div
                        className={`h-full rounded ${getUsageColor(percent)}`}
                        style={{ width: `${percent}%` }}
                      />
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        <section className="mb-5 overflow-hidden rounded-md border border-[rgba(0,200,180,0.06)] bg-[#070e1a]">
          <div className="border-b border-[rgba(0,200,180,0.06)] px-6 py-4">
            <div className="font-mono text-[0.72rem] uppercase tracking-[0.12em] text-[#00c8b4]">
              // Profile
            </div>
          </div>

          <div className="p-6">
            {profileSuccess ? (
              <div className="mb-4 rounded border border-[#00c8b4] bg-[rgba(0,200,180,0.08)] px-4 py-3 font-mono text-[0.72rem] tracking-[0.05em] text-[#00c8b4]">
                {profileSuccess}
              </div>
            ) : null}

            {profileError ? (
              <div className="mb-4 rounded border border-[#ff4560] bg-[rgba(255,69,96,0.08)] px-4 py-3 font-mono text-[0.72rem] tracking-[0.05em] text-[#ff4560]">
                {profileError}
              </div>
            ) : null}

            <div className="mb-5 grid gap-4 sm:grid-cols-2">
              <div className="flex flex-col gap-2">
                <label className="font-mono text-[0.65rem] uppercase tracking-[0.12em] text-[#4a6070]">
                  Display Name
                </label>
                <input
                  type="text"
                  value={displayName}
                  onChange={(e) => setDisplayName(e.target.value)}
                  placeholder="Your name"
                  className="w-full rounded border border-[rgba(0,200,180,0.12)] bg-[#040810] px-4 py-3 font-mono text-[0.85rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] focus:border-[#00c8b4]"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="font-mono text-[0.65rem] uppercase tracking-[0.12em] text-[#4a6070]">
                  Email Address
                </label>
                <input
                  type="email"
                  value={email}
                  disabled
                  className="w-full cursor-not-allowed rounded border border-[rgba(0,200,180,0.12)] bg-[#040810] px-4 py-3 font-mono text-[0.85rem] text-[#c8d8e8] opacity-40 outline-none"
                />
              </div>
            </div>

            <div className="flex justify-end">
              <button
                type="button"
                onClick={saveProfile}
                disabled={savingProfile}
                className="rounded border border-[#00c8b4] bg-[#00c8b4] px-4 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[#040810] transition hover:bg-[#00ffe8] disabled:opacity-50"
              >
                {savingProfile ? "Saving..." : "Save Profile"}
              </button>
            </div>
          </div>
        </section>

        <section className="mb-5 overflow-hidden rounded-md border border-[rgba(0,200,180,0.06)] bg-[#070e1a]">
          <div className="border-b border-[rgba(0,200,180,0.06)] px-6 py-4">
            <div className="font-mono text-[0.72rem] uppercase tracking-[0.12em] text-[#00c8b4]">
              // Change Password
            </div>
          </div>

          <div className="p-6">
            {passwordSuccess ? (
              <div className="mb-4 rounded border border-[#00c8b4] bg-[rgba(0,200,180,0.08)] px-4 py-3 font-mono text-[0.72rem] tracking-[0.05em] text-[#00c8b4]">
                {passwordSuccess}
              </div>
            ) : null}

            {passwordError ? (
              <div className="mb-4 rounded border border-[#ff4560] bg-[rgba(255,69,96,0.08)] px-4 py-3 font-mono text-[0.72rem] tracking-[0.05em] text-[#ff4560]">
                {passwordError}
              </div>
            ) : null}

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="sm:col-span-2 flex flex-col gap-2">
                <label className="font-mono text-[0.65rem] uppercase tracking-[0.12em] text-[#4a6070]">
                  Current Password
                </label>
                <input
                  type="password"
                  value={currentPassword}
                  onChange={(e) => setCurrentPassword(e.target.value)}
                  placeholder="Your current password"
                  className="w-full rounded border border-[rgba(0,200,180,0.12)] bg-[#040810] px-4 py-3 font-mono text-[0.85rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] focus:border-[#00c8b4]"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="font-mono text-[0.65rem] uppercase tracking-[0.12em] text-[#4a6070]">
                  New Password
                </label>
                <input
                  type="password"
                  value={newPassword}
                  onChange={(e) => setNewPassword(e.target.value)}
                  placeholder="Min 8 characters"
                  className="w-full rounded border border-[rgba(0,200,180,0.12)] bg-[#040810] px-4 py-3 font-mono text-[0.85rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] focus:border-[#00c8b4]"
                />
              </div>

              <div className="flex flex-col gap-2">
                <label className="font-mono text-[0.65rem] uppercase tracking-[0.12em] text-[#4a6070]">
                  Confirm New Password
                </label>
                <input
                  type="password"
                  value={confirmPassword}
                  onChange={(e) => setConfirmPassword(e.target.value)}
                  placeholder="Repeat new password"
                  className="w-full rounded border border-[rgba(0,200,180,0.12)] bg-[#040810] px-4 py-3 font-mono text-[0.85rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] focus:border-[#00c8b4]"
                />
              </div>
            </div>

            <div className="mt-4 flex justify-end">
              <button
                type="button"
                onClick={changePassword}
                disabled={savingPassword}
                className="rounded border border-[#00c8b4] bg-[#00c8b4] px-4 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[#040810] transition hover:bg-[#00ffe8] disabled:opacity-50"
              >
                {savingPassword ? "Updating..." : "Update Password"}
              </button>
            </div>
          </div>
        </section>

        <section className="overflow-hidden rounded-md border border-[rgba(0,200,180,0.06)] bg-[#070e1a]">
          <div className="border-b border-[rgba(0,200,180,0.06)] px-6 py-4">
            <div className="font-mono text-[0.72rem] uppercase tracking-[0.12em] text-[#ff4560]">
              // Danger Zone
            </div>
          </div>

          <div className="p-6">
            <div className="flex flex-col gap-3">
              <div className="flex flex-col justify-between gap-4 border-b border-[rgba(0,200,180,0.06)] py-4 sm:flex-row sm:items-center">
                <div>
                  <div className="mb-1 text-[0.88rem] text-[#c8d8e8]">
                    Log out of all sessions
                  </div>
                  <div className="text-[0.78rem] text-[#4a6070]">
                    Invalidates all active sessions across all devices.
                  </div>
                </div>

                <button
                  type="button"
                  onClick={logoutAll}
                  disabled={loggingOutAll}
                  className="rounded border border-[rgba(255,69,96,0.3)] px-4 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[rgba(255,69,96,0.6)] transition hover:border-[#ff4560] hover:text-[#ff4560] disabled:opacity-50"
                >
                  {loggingOutAll ? "Logging out..." : "Log Out All"}
                </button>
              </div>

              <div className="flex flex-col justify-between gap-4 py-4 sm:flex-row sm:items-center">
                <div>
                  <div className="mb-1 text-[0.88rem] text-[#c8d8e8]">
                    Delete account
                  </div>
                  <div className="text-[0.78rem] text-[#4a6070]">
                    Permanently deletes your account and all associated data.
                    This cannot be undone.
                  </div>
                </div>

                <button
                  type="button"
                  onClick={confirmDelete}
                  disabled={deletingAccount}
                  className="rounded border border-[rgba(255,69,96,0.3)] px-4 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[rgba(255,69,96,0.6)] transition hover:border-[#ff4560] hover:text-[#ff4560] disabled:opacity-50"
                >
                  {deletingAccount ? "Deleting..." : "Delete Account"}
                </button>
              </div>
            </div>
          </div>
        </section>
      </div>
    </main>
  );
}
import { getDashboardHref } from "@/lib/app-routes";
