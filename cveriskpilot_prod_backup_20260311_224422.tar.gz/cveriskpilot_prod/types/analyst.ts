import { z } from "zod";

import { type AnalystDecision, type ArchitectureInfluenceFactors } from "@/types/dashboard";

export const analystDecisionValues = [
  "true_risk",
  "accepted_risk",
  "mitigated",
  "false_positive",
  "not_applicable",
] as const;

export const AnalystDecisionSchema = z.enum(analystDecisionValues);
export type AnalystDecisionValue = z.infer<typeof AnalystDecisionSchema>;

export const ArchitectureInfluenceFactorsSchema = z.object({
  internetExposed: z.boolean(),
  internalOnly: z.boolean(),
  segmentedNetwork: z.boolean(),
  compensatingControlPresent: z.boolean(),
  assetCriticality: z.enum(["critical", "high", "medium", "low"]),
  authRequired: z.boolean(),
  reachableFromAttackerPath: z.boolean(),
});

export type ArchitectureInfluenceFactorsValue = z.infer<
  typeof ArchitectureInfluenceFactorsSchema
>;

export const AnalystDispositionRecordSchema = z.object({
  findingId: z.string().min(1),
  decision: AnalystDecisionSchema,
  rationale: z.string().max(4000),
  notes: z.string().max(4000).nullable(),
  factors: ArchitectureInfluenceFactorsSchema,
  updatedBy: z.string().min(1).max(128),
  updatedAt: z.iso.datetime(),
  createdAt: z.iso.datetime(),
});

export type AnalystDispositionRecord = z.infer<typeof AnalystDispositionRecordSchema>;

export const AnalystDispositionEventSchema = z.object({
  id: z.string().uuid(),
  findingId: z.string().min(1),
  decision: AnalystDecisionSchema,
  rationale: z.string().max(4000),
  notes: z.string().max(4000).nullable(),
  factors: ArchitectureInfluenceFactorsSchema,
  updatedBy: z.string().min(1).max(128),
  createdAt: z.iso.datetime(),
});

export type AnalystDispositionEvent = z.infer<typeof AnalystDispositionEventSchema>;

export const UpsertAnalystDispositionInputSchema = z.object({
  decision: AnalystDecisionSchema,
  rationale: z.string().max(4000).default(""),
  notes: z.string().max(4000).nullable().default(null),
  factors: ArchitectureInfluenceFactorsSchema,
  updatedBy: z.string().min(1).max(128).default("dashboard-analyst"),
});

export type UpsertAnalystDispositionInput = z.infer<
  typeof UpsertAnalystDispositionInputSchema
>;

export const AnalystDispositionResponseSchema = z.object({
  disposition: AnalystDispositionRecordSchema.nullable(),
  history: z.array(AnalystDispositionEventSchema),
});

export type AnalystDispositionResponse = z.infer<
  typeof AnalystDispositionResponseSchema
>;

export function toArchitectureSummary(factors: ArchitectureInfluenceFactors): string {
  const tags: string[] = [];

  if (factors.internetExposed) tags.push("internet-exposed");
  if (factors.internalOnly) tags.push("internal-only");
  if (factors.segmentedNetwork) tags.push("segmented-network");
  if (factors.compensatingControlPresent) tags.push("compensating-control");
  if (factors.authRequired) tags.push("auth-required");
  if (factors.reachableFromAttackerPath) tags.push("attacker-path-reachable");

  return `${factors.assetCriticality} criticality${tags.length ? ` · ${tags.join(", ")}` : ""}`;
}

export const defaultArchitectureFactors: ArchitectureInfluenceFactorsValue = {
  internetExposed: false,
  internalOnly: true,
  segmentedNetwork: true,
  compensatingControlPresent: false,
  assetCriticality: "medium",
  authRequired: true,
  reachableFromAttackerPath: false,
};

export const defaultAnalystDecision: AnalystDecision = "true_risk";
