project               = "cveriskpilot"
environment           = "app"
aws_region            = "us-east-1"
root_domain           = "cveriskpilot.com"
app_subdomain         = "app"

# Leave false if your DNS is still hosted in Cloudflare.
manage_route53_records = false

enable_https           = true
container_image        = "123456789012.dkr.ecr.us-east-1.amazonaws.com/cveriskpilot-prod-app:latest"
container_port         = 3000
health_check_path      = "/api/health"
desired_count          = 1

db_instance_class      = "db.t4g.micro"
db_allocated_storage   = 30
db_multi_az            = false
db_backup_retention_period = 7

tags = {
  Owner = "CVERiskPilot"
}
