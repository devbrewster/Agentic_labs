import { apiError, readJsonBody, withAuthRoute } from "@/lib/auth";
import { validateMagicLinkPayload } from "@/lib/validators";

export const POST = withAuthRoute(async function POST(request: Request) {
  const payload = await readJsonBody(request);
  const validation = validateMagicLinkPayload(payload);

  if (!validation.success) {
    return apiError("invalid_input", validation.message, 400, validation.fieldErrors);
  }

  return apiError(
    "todo_not_implemented",
    "Magic link auth is not implemented yet.",
    501,
  );
});
