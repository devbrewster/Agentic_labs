# AWS Bootstrap for CVERiskPilot

This Terraform stack brings up the **initial AWS application environment** for the future move to:

- `cveriskpilot.com` for marketing / landing
- `app.cveriskpilot.com` for the SaaS application

It creates:

- VPC with public and private subnets
- Internet gateway + single NAT gateway
- Application Load Balancer
- ECS Fargate cluster/service
- ECR repository for the app image
- S3 bucket for upload artifacts
- RDS PostgreSQL
- Secrets Manager bootstrap secret
- Optional ACM + Route53 records for `app.cveriskpilot.com`

## Important limitation

This does **not** mean the current app is already AWS-portable.

The codebase is still Cloudflare-coupled in several areas:

- D1-backed repositories
- OpenNext Cloudflare dev/runtime assumptions
- Wrangler deployment scripts

This stack is the **infrastructure starting point** so the port can happen cleanly.

## Recommended first use

1. Copy the example vars:

```bash
cp infra/aws/terraform.tfvars.example infra/aws/terraform.tfvars
```

2. Review these values:

- `root_domain`
- `app_subdomain`
- `manage_route53_records`
- `container_image`

3. Initialize and plan:

```bash
cd infra/aws
terraform init
terraform plan
```

4. Apply:

```bash
terraform apply
```

## DNS note

If your DNS is still managed in Cloudflare, keep:

```hcl
manage_route53_records = false
```

Then after `terraform apply`, read the `manual_acm_validation_records` output and add those CNAME records in your DNS provider so the ACM certificate can validate.

You can also point `app.cveriskpilot.com` at the ALB manually instead of letting Route53 manage it.

## Container build and push

This repo now includes:

- [Dockerfile](/home/gonti/cveriskpilot_prod/Dockerfile)
- [.dockerignore](/home/gonti/cveriskpilot_prod/.dockerignore)
- health endpoint at [route.ts](/home/gonti/cveriskpilot_prod/app/api/health/route.ts)

The container is built for the AWS target using Next.js standalone output and exposes port `3000`.

Build locally:

```bash
npm run docker:build:aws
```

Or with a custom app domain:

```bash
docker build \
  --build-arg DEPLOY_TARGET=aws \
  --build-arg NEXT_PUBLIC_APP_DEPLOYMENT_MODE=subdomain_root \
  --build-arg NEXT_PUBLIC_APP_DOMAIN_HOST=app.cveriskpilot.com \
  -t cveriskpilot-app:aws .
```

Push to ECR:

```bash
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <account>.dkr.ecr.us-east-1.amazonaws.com
docker tag cveriskpilot-app:aws <account>.dkr.ecr.us-east-1.amazonaws.com/cveriskpilot-prod-app:latest
docker push <account>.dkr.ecr.us-east-1.amazonaws.com/cveriskpilot-prod-app:latest
```

Then set `container_image` in `terraform.tfvars`.

## Next engineering steps after infra bootstrap

1. Add platform abstractions for DB/storage/runtime
2. Replace D1 with PostgreSQL repositories
3. Replace local/D1 artifact handling with S3-backed artifact storage
4. Add organization-scoped tenancy before licensing
5. Deploy the app under `app.cveriskpilot.com`

## Current app support added

The app now includes an `S3ArtifactStorage` provider and can select S3 artifact storage when these env vars are set:

```env
UPLOAD_STORAGE_DRIVER=s3
UPLOAD_S3_BUCKET=your-upload-bucket-name
AWS_REGION=us-east-1
```

This only covers artifact body storage. The app still needs broader Postgres/runtime migration work before AWS becomes the primary production target.

## App subdomain deployment mode

The app now supports a host-aware root deployment mode for `app.cveriskpilot.com`.

Use these env vars in the app deployment:

```env
APP_DEPLOYMENT_MODE=subdomain_root
NEXT_PUBLIC_APP_DEPLOYMENT_MODE=subdomain_root
APP_DOMAIN_HOST=app.cveriskpilot.com
NEXT_PUBLIC_APP_DOMAIN_HOST=app.cveriskpilot.com
```

Behavior in this mode:

- `https://app.cveriskpilot.com/` rewrites to the dashboard overview
- `https://app.cveriskpilot.com/findings` rewrites to the findings workspace
- `https://app.cveriskpilot.com/uploads` rewrites to the uploads workspace
- dashboard navigation generates root-based app links instead of `/dashboard/*`

The legacy `/dashboard/*` paths still remain available during transition.

## AWS-13 runtime handoff

The app now supports self-bootstrapping a real Postgres client from environment configuration instead of requiring manual client registration in code.

Required runtime env for AWS:

```env
DATABASE_URL=postgres://...
POSTGRES_SSL_MODE=require
POSTGRES_POOL_MAX=10
POSTGRES_IDLE_TIMEOUT_MS=30000
POSTGRES_CONNECTION_TIMEOUT_MS=10000
UPLOAD_STORAGE_DRIVER=s3
UPLOAD_S3_BUCKET=your-upload-bucket-name
AWS_REGION=us-east-1
```

The PostgreSQL schema is tracked separately from the D1 schema:

```text
database/postgres/schema.sql
```

Recommended first migration command in AWS or a connected admin environment:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f database/postgres/schema.sql
```

## ECS app defaults

The Terraform examples now assume the real app container:

- `container_port = 3000`
- `health_check_path = "/api/health"`

Before `terraform apply`, replace the example `container_image` with your actual ECR image URI.

## AWS-15 staging runbook

Use the full staging cutover checklist in:

- [aws-staging-cutover-runbook.md](/home/gonti/cveriskpilot_prod/docs/aws-staging-cutover-runbook.md)

Helper commands added:

```bash
npm run aws:push:ecr -- <ecr_repository_url> latest
```

This wraps build, ECR login, and push for the app image.
