import type { AppDatabase } from "@/lib/platform/database";
import type { EnrichmentRepository } from "@/lib/enrichment/repository";
import {
  EnrichmentRunSchema,
  EnrichmentRunWithSnapshotsSchema,
  FindingEnrichmentSnapshotSchema,
  type EnrichmentRun,
  type EnrichmentRunWithSnapshots,
  type FindingEnrichmentSnapshot,
} from "@/types/enrichment";

type EnrichmentRunRow = {
  id: string;
  upload_job_id: string | null;
  triggered_by: string;
  status: string;
  provider_count: number;
  success_count: number;
  error_count: number;
  error_summary: string | null;
  started_at: string | null;
  completed_at: string | null;
  created_at: string;
  updated_at: string;
};

type FindingEnrichmentSnapshotRow = {
  id: string;
  enrichment_run_id: string;
  finding_id: string;
  provider: string;
  status: string;
  source_url: string | null;
  source_version: string | null;
  observed_at: string | null;
  error_code: string | null;
  error_message: string | null;
  summary_json: string | null;
  raw_payload_json: string | null;
  created_at: string;
  updated_at: string;
};

function parseJsonObject(value: string | null) {
  if (!value) {
    return null;
  }

  return JSON.parse(value) as Record<string, unknown>;
}

function mapRunRow(row: EnrichmentRunRow): EnrichmentRun {
  return EnrichmentRunSchema.parse({
    id: row.id,
    uploadJobId: row.upload_job_id,
    triggeredBy: row.triggered_by,
    status: row.status,
    providerCount: row.provider_count,
    successCount: row.success_count,
    errorCount: row.error_count,
    errorSummary: row.error_summary,
    startedAt: row.started_at,
    completedAt: row.completed_at,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  });
}

function mapSnapshotRow(row: FindingEnrichmentSnapshotRow): FindingEnrichmentSnapshot {
  return FindingEnrichmentSnapshotSchema.parse({
    id: row.id,
    enrichmentRunId: row.enrichment_run_id,
    findingId: row.finding_id,
    provider: row.provider,
    status: row.status,
    sourceUrl: row.source_url,
    sourceVersion: row.source_version,
    observedAt: row.observed_at,
    errorCode: row.error_code,
    errorMessage: row.error_message,
    summaryJson: parseJsonObject(row.summary_json),
    rawPayloadJson: parseJsonObject(row.raw_payload_json),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  });
}

export class SqlEnrichmentRepository implements EnrichmentRepository {
  constructor(private readonly db: AppDatabase) {}

  async createRun(runModel: EnrichmentRun) {
    await this.db
      .prepare(
        `INSERT INTO enrichment_runs (
           id,
           upload_job_id,
           triggered_by,
           status,
           provider_count,
           success_count,
           error_count,
           error_summary,
           started_at,
           completed_at,
           created_at,
           updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        runModel.id,
        runModel.uploadJobId,
        runModel.triggeredBy,
        runModel.status,
        runModel.providerCount,
        runModel.successCount,
        runModel.errorCount,
        runModel.errorSummary,
        runModel.startedAt,
        runModel.completedAt,
        runModel.createdAt,
        runModel.updatedAt,
      )
      .run();
  }

  async updateRun(runModel: EnrichmentRun) {
    await this.db
      .prepare(
        `UPDATE enrichment_runs
         SET
           upload_job_id = ?,
           triggered_by = ?,
           status = ?,
           provider_count = ?,
           success_count = ?,
           error_count = ?,
           error_summary = ?,
           started_at = ?,
           completed_at = ?,
           created_at = ?,
           updated_at = ?
         WHERE id = ?`,
      )
      .bind(
        runModel.uploadJobId,
        runModel.triggeredBy,
        runModel.status,
        runModel.providerCount,
        runModel.successCount,
        runModel.errorCount,
        runModel.errorSummary,
        runModel.startedAt,
        runModel.completedAt,
        runModel.createdAt,
        runModel.updatedAt,
        runModel.id,
      )
      .run();
  }

  async findRunById(runId: string): Promise<EnrichmentRunWithSnapshots | null> {
    const runRow = await this.db
      .prepare(
        `SELECT
           id,
           upload_job_id,
           triggered_by,
           status,
           provider_count,
           success_count,
           error_count,
           error_summary,
           started_at,
           completed_at,
           created_at,
           updated_at
         FROM enrichment_runs
         WHERE id = ?
         LIMIT 1`,
      )
      .bind(runId)
      .first<EnrichmentRunRow>();

    if (!runRow) {
      return null;
    }

    const snapshotRows = await this.db
      .prepare(
        `SELECT
           id,
           enrichment_run_id,
           finding_id,
           provider,
           status,
           source_url,
           source_version,
           observed_at,
           error_code,
           error_message,
           summary_json,
           raw_payload_json,
           created_at,
           updated_at
         FROM finding_enrichment_snapshots
         WHERE enrichment_run_id = ?
         ORDER BY created_at ASC`,
      )
      .bind(runId)
      .all<FindingEnrichmentSnapshotRow>();

    return EnrichmentRunWithSnapshotsSchema.parse({
      run: mapRunRow(runRow),
      snapshots: snapshotRows.map(mapSnapshotRow),
    });
  }

  async findLatestRunByUploadJobId(uploadJobId: string): Promise<EnrichmentRunWithSnapshots | null> {
    const runRow = await this.db
      .prepare(
        `SELECT
           id,
           upload_job_id,
           triggered_by,
           status,
           provider_count,
           success_count,
           error_count,
           error_summary,
           started_at,
           completed_at,
           created_at,
           updated_at
         FROM enrichment_runs
         WHERE upload_job_id = ?
         ORDER BY created_at DESC
         LIMIT 1`,
      )
      .bind(uploadJobId)
      .first<EnrichmentRunRow>();

    if (!runRow) {
      return null;
    }

    return this.findRunById(runRow.id);
  }

  async listSnapshotsByFindingId(findingId: string): Promise<FindingEnrichmentSnapshot[]> {
    const rows = await this.db
      .prepare(
        `SELECT
           id,
           enrichment_run_id,
           finding_id,
           provider,
           status,
           source_url,
           source_version,
           observed_at,
           error_code,
           error_message,
           summary_json,
           raw_payload_json,
           created_at,
           updated_at
         FROM finding_enrichment_snapshots
         WHERE finding_id = ?
         ORDER BY created_at DESC`,
      )
      .bind(findingId)
      .all<FindingEnrichmentSnapshotRow>();

    return rows.map(mapSnapshotRow);
  }

  async replaceSnapshotsForRun(
    runId: string,
    snapshots: FindingEnrichmentSnapshot[],
  ) {
    await this.db
      .prepare(
        `DELETE FROM finding_enrichment_snapshots
         WHERE enrichment_run_id = ?`,
      )
      .bind(runId)
      .run();

    for (const snapshot of snapshots) {
      await this.db
        .prepare(
          `INSERT INTO finding_enrichment_snapshots (
             id,
             enrichment_run_id,
             finding_id,
             provider,
             status,
             source_url,
             source_version,
             observed_at,
             error_code,
             error_message,
             summary_json,
             raw_payload_json,
             created_at,
             updated_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .bind(
          snapshot.id,
          snapshot.enrichmentRunId,
          snapshot.findingId,
          snapshot.provider,
          snapshot.status,
          snapshot.sourceUrl,
          snapshot.sourceVersion,
          snapshot.observedAt,
          snapshot.errorCode,
          snapshot.errorMessage,
          snapshot.summaryJson ? JSON.stringify(snapshot.summaryJson) : null,
          snapshot.rawPayloadJson ? JSON.stringify(snapshot.rawPayloadJson) : null,
          snapshot.createdAt,
          snapshot.updatedAt,
        )
        .run();
    }
  }
}
