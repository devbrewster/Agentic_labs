import { NextResponse } from "next/server";

import { listActionPlanColumns, listActionPlans } from "@/lib/services/action-plans";

export async function GET() {
  return NextResponse.json({
    ok: true,
    data: {
      plans: listActionPlans(),
      columns: listActionPlanColumns(),
    },
  });
}
