export type KevCatalogVulnerability = {
  cveID: string;
  vendorProject?: string;
  product?: string;
  vulnerabilityName?: string;
  shortDescription?: string;
  dateAdded?: string;
  dueDate?: string;
  requiredAction?: string;
  knownRansomwareCampaignUse?: string;
  notes?: string;
  [key: string]: unknown;
};

export type KevCatalogResponse = {
  title?: string;
  catalogVersion?: string;
  dateReleased?: string;
  count?: string | number;
  vulnerabilities?: KevCatalogVulnerability[];
  [key: string]: unknown;
};

export type KevMatchRecord = {
  cveId: string;
  vendorProject: string | null;
  product: string | null;
  vulnerabilityName: string | null;
  shortDescription: string | null;
  dateAdded: string | null;
  dueDate: string | null;
  requiredAction: string | null;
  knownRansomwareCampaignUse: string | null;
  notes: string | null;
};

export type KevCatalogIndex = {
  sourceVersion: string | null;
  fetchedAt: string;
  entriesByCve: Record<string, KevMatchRecord>;
};

export type KevClientError = {
  code: "invalid_cve_id" | "request_timeout" | "upstream_error" | "bad_response";
  message: string;
  retriable: boolean;
  status?: number;
  fromCache: boolean;
};

export type KevClientMeta = {
  source: "kev_live" | "kev_cache_fresh" | "kev_cache_stale" | "none";
  fetchedAt: string | null;
  cacheHit: boolean;
  stale: boolean;
};

export type KevClientResult =
  | {
      ok: true;
      data: KevMatchRecord | null;
      meta: KevClientMeta;
      sourceVersion: string | null;
    }
  | {
      ok: false;
      error: KevClientError;
      meta: KevClientMeta;
      sourceVersion: string | null;
    };
