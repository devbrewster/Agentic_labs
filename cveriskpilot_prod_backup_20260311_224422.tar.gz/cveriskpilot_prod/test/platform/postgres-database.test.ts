import { describe, expect, it } from "vitest";

import {
  PostgresAppDatabase,
  rewriteSqlPlaceholdersForPostgres,
  type PostgresQueryClient,
} from "@/lib/platform/database";

describe("rewriteSqlPlaceholdersForPostgres", () => {
  it("rewrites question-mark placeholders to postgres indexes", () => {
    expect(
      rewriteSqlPlaceholdersForPostgres(
        "SELECT id FROM organizations WHERE id = ? AND slug = ? LIMIT 1",
      ),
    ).toBe("SELECT id FROM organizations WHERE id = $1 AND slug = $2 LIMIT 1");
  });
});

describe("PostgresAppDatabase", () => {
  it("passes rewritten SQL and params into the query client", async () => {
    let executedSql = "";
    let executedParams: readonly unknown[] = [];

    const client: PostgresQueryClient = {
      async query<T>(sql: string, params?: readonly unknown[]) {
        executedSql = sql;
        executedParams = params ?? [];

        return {
          rows: [{ id: "org-1" }] as T[],
          rowCount: 1,
        };
      },
    };

    const db = new PostgresAppDatabase(client);
    const row = await db
      .prepare("SELECT id FROM organizations WHERE id = ?")
      .bind("org-1")
      .first<{ id: string }>();

    expect(executedSql).toBe("SELECT id FROM organizations WHERE id = $1");
    expect(executedParams).toEqual(["org-1"]);
    expect(row).toEqual({ id: "org-1" });
  });
});
