import { NextResponse } from "next/server";

import {
  apiError,
  apiSuccess,
  consumePasswordResetToken,
  readJsonBody,
  validatePasswordResetToken,
  withAuthRoute,
} from "@/lib/auth";
import { hashPassword } from "@/lib/passwords";
import { revokeAllSessions } from "@/lib/session";
import { validatePasswordResetPayload } from "@/lib/validators";

export const GET = withAuthRoute(async function GET(request: Request) {
  const token = new URL(request.url).searchParams.get("token")?.trim() ?? "";

  if (!token) {
    return apiError("invalid_token", "Reset link is invalid.", 400);
  }

  const result = await validatePasswordResetToken(token);

  if (!result.ok) {
    return apiError(
      result.reason,
      result.reason === "token_expired"
        ? "Reset link has expired."
        : "Reset link is invalid.",
      400,
    );
  }

  return apiSuccess({
    email: result.user.email,
    expires_at: result.expiresAt,
  });
});

export const POST = withAuthRoute(async function POST(request: Request) {
  const payload = await readJsonBody(request);
  const validation = validatePasswordResetPayload(payload);

  if (!validation.success) {
    return apiError("invalid_input", validation.message, 400, validation.fieldErrors);
  }

  const passwordHash = await hashPassword(validation.data.new_password);
  const result = await consumePasswordResetToken(validation.data.token, passwordHash);

  if (!result.ok) {
    return apiError(
      result.reason,
      result.reason === "token_expired"
        ? "Reset link has expired."
        : "Reset link is invalid.",
      400,
    );
  }

  await revokeAllSessions(result.user.id);

  return NextResponse.json(
    {
      ok: true,
      data: {
        message: "Password reset successful. You can log in with your new password.",
      },
    },
    { status: 200 },
  );
});
