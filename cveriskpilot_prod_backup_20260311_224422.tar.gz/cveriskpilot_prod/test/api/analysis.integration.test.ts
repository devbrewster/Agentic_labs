import { describe, expect, it } from "vitest";

import { GET as getAnalysisPrompt, POST as postAnalysis } from "@/app/api/findings/[id]/analysis/route";
import { GET as getFindings } from "@/app/api/findings/route";
import { POST as reparseUpload } from "@/app/api/uploads/[id]/reparse/route";
import { POST as createUpload } from "@/app/api/uploads/route";
import { createAuthenticatedTestContext, withAuthHeaders } from "@/test/helpers/auth";
import { successfulCsvFixture } from "@/test/fixtures/generic-csv";

async function createParsedUploadAndGetFindingId(authHeaders: HeadersInit) {
  const formData = new FormData();
  formData.set(
    "file",
    new File([successfulCsvFixture], `analysis-${crypto.randomUUID()}.csv`, {
      type: "text/csv",
    }),
  );
  formData.set("selectedSourceType", "generic_csv");

  const uploadResponse = await createUpload(
    new Request("http://localhost/api/uploads", {
      method: "POST",
      headers: withAuthHeaders(authHeaders),
      body: formData,
    }),
  );
  const uploadJson = await uploadResponse.json();
  const uploadJobId = uploadJson.data.uploadJob.id as string;

  await reparseUpload(
    new Request(`http://localhost/api/uploads/${uploadJobId}/reparse`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(authHeaders).entries()),
        },
        body: JSON.stringify({ force: true }),
    }),
    {
      params: Promise.resolve({ id: uploadJobId }),
    },
  );

  const findingsResponse = await getFindings(
    new Request("http://localhost/api/findings", {
      headers: withAuthHeaders(authHeaders),
    }),
  );
  const findingsJson = await findingsResponse.json();
  const findingId = (findingsJson.data.findings as Array<{ id: string }>)[0]?.id;

  if (!findingId) {
    throw new Error("Expected ingested findings for analysis tests.");
  }

  return findingId;
}

describe("finding analysis route", () => {
  it("returns prompt scaffolding for a finding", async () => {
    const auth = await createAuthenticatedTestContext("analysis-prompt");
    const findingId = await createParsedUploadAndGetFindingId(auth.headers);

    const response = await getAnalysisPrompt(
      new Request(`http://localhost/api/findings/${findingId}/analysis`, {
        headers: withAuthHeaders(auth.headers),
      }),
      {
        params: Promise.resolve({ id: findingId }),
      },
    );
    const json = await response.json();

    expect(response.status).toBe(200);
    expect(json.data.prompt.templateVersion).toBe("p3-7.v1");
    expect(json.data.prompt.systemPrompt).toContain("strict JSON only");
    expect(json.data.prompt.userPrompt).toContain(findingId);
    expect(json.data.traces).toEqual([]);
  });

  it("returns stub output and no secret leakage in live mode without key", async () => {
    const auth = await createAuthenticatedTestContext("analysis-live");
    const findingId = await createParsedUploadAndGetFindingId(auth.headers);

    const response = await postAnalysis(
      new Request(`http://localhost/api/findings/${findingId}/analysis`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({ mode: "live" }),
      }),
      {
        params: Promise.resolve({ id: findingId }),
      },
    );
    const json = await response.json();

    expect(response.status).toBe(200);
    expect(json.data.generated.mode).toBe("live");
    expect(json.data.generated.provider).toBe("stub");
    expect(json.data.generated.traceStatus).toBe("fallback");
    expect(json.data.generated.fallbackReason).toBe("anthropic_api_key_missing");
    expect(json.data.generated.warnings[0]).toContain("ANTHROPIC_API_KEY");
    expect(json.data.trace.findingId).toBe(findingId);
    expect(json.data.traces).toHaveLength(1);
    expect(json.data.traces[0].promptEnvelopeJson.templateVersion).toBe("p3-7.v1");
    expect(JSON.stringify(json)).not.toContain("sk-ant");
    expect(JSON.stringify(json)).not.toContain(process.env.ANTHROPIC_API_KEY ?? "__unset__");
  });
});
