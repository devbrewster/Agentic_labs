"use client";

import { useEffect, useRef, useState } from "react";

import type { AnalystDecision, ArchitectureInfluenceFactors, Finding } from "@/types/dashboard";
import type { VulnerabilityRecord } from "@/lib/nvd/types";
import type { AnalystDispositionResponse } from "@/types/analyst";

import { AnalysisSectionCard } from "@/components/dashboard/AnalysisSectionCard";
import { AnalystDispositionSection } from "@/components/dashboard/AnalystDispositionSection";
import { DecisionRationaleSection } from "@/components/dashboard/DecisionRationaleSection";
import { EnterpriseContextSection } from "@/components/dashboard/EnterpriseContextSection";
import { StatusPill } from "@/components/dashboard/StatusPill";
import { CveSourceSections } from "@/components/CveSourceSections";
import { EnrichmentErrorBanner } from "@/components/EnrichmentErrorBanner";
import { NvdNotice } from "@/components/NvdNotice";
import {
  AI_TRIAGE_RUN_EVENT,
  dispatchAiTriageStatus,
  type AiTriageRunDetail,
} from "@/lib/dashboard/ai-triage-events";
import { buildEnrichmentSummary } from "@/lib/services/enrichment-summary";
import type { AnalysisTraceRecord, GeneratedFindingAnalysis } from "@/types/analysis";
import type { FindingEnrichmentSnapshot } from "@/types/enrichment";

type FindingDetailsPanelProps = {
  finding: Finding | null;
};

type CachedDispositionState = {
  disposition: AnalystDecision;
  rationale: string;
  factors: ArchitectureInfluenceFactors;
  historyCount: number;
  updatedAt: string | null;
};

type CachedNvdState = {
  record: VulnerabilityRecord;
  warning: string | null;
  staleCache: boolean;
};

type CachedEnrichmentState = {
  summary: NonNullable<Finding["enrichmentSummary"]>;
};

const severityPillTone = {
  critical: "danger",
  high: "warning",
  medium: "accent",
  low: "default",
} as const;

const showInternalAnalysisControls =
  process.env.NODE_ENV !== "production" ||
  process.env.NEXT_PUBLIC_ENABLE_INTERNAL_ANALYSIS_CONTROLS === "true";

function deriveInitialFactors(finding: Finding): ArchitectureInfluenceFactors {
  return {
    internetExposed: finding.internetExposed,
    internalOnly: !finding.internetExposed,
    segmentedNetwork: finding.environment !== "development",
    compensatingControlPresent: finding.status === "mitigated",
    assetCriticality:
      finding.riskScore >= 95
        ? "critical"
        : finding.riskScore >= 85
          ? "high"
          : finding.riskScore >= 70
            ? "medium"
            : "low",
    authRequired: finding.privilegeRequired !== "none",
    reachableFromAttackerPath:
      finding.internetExposed || finding.exploitAvailable || finding.kevListed,
  };
}

export function FindingDetailsPanel({
  finding,
}: FindingDetailsPanelProps) {
  const dispositionCacheRef = useRef(new Map<string, CachedDispositionState>());
  const nvdCacheRef = useRef(new Map<string, CachedNvdState>());
  const enrichmentCacheRef = useRef(new Map<string, CachedEnrichmentState>());
  const [disposition, setDisposition] = useState<AnalystDecision>("true_risk");
  const [rationale, setRationale] = useState("");
  const [factors, setFactors] = useState<ArchitectureInfluenceFactors | null>(null);
  const [record, setRecord] = useState<VulnerabilityRecord | null>(null);
  const [resolvedEnrichmentSummary, setResolvedEnrichmentSummary] = useState<
    Finding["enrichmentSummary"] | undefined
  >(finding?.enrichmentSummary);
  const [enrichmentWarning, setEnrichmentWarning] = useState<string | null>(null);
  const [isStaleCache, setIsStaleCache] = useState(false);
  const [dispositionHistoryCount, setDispositionHistoryCount] = useState(0);
  const [dispositionUpdatedAt, setDispositionUpdatedAt] = useState<string | null>(null);
  const [dispositionSaveState, setDispositionSaveState] = useState<
    "idle" | "loading" | "saving" | "saved" | "error"
  >("idle");
  const [dispositionError, setDispositionError] = useState<string | null>(null);
  const [analysisState, setAnalysisState] = useState<{
    status: "idle" | "running" | "done" | "error";
    result: GeneratedFindingAnalysis | null;
    trace: AnalysisTraceRecord | null;
    traceCount: number;
    error: string | null;
  }>({
    status: "idle",
    result: null,
    trace: null,
    traceCount: 0,
    error: null,
  });

  const enrichment = resolvedEnrichmentSummary ?? finding?.enrichmentSummary;
  const effectiveKevListed = enrichment?.kevListed ?? finding?.kevListed ?? false;
  const effectiveExploitAvailable =
    enrichment?.exploitAvailable ?? finding?.exploitAvailable ?? false;
  const effectiveCvssScore = enrichment?.cvssScore ?? finding?.cvssScore ?? 0;

  useEffect(() => {
    if (!finding) {
      setRecord(null);
      setResolvedEnrichmentSummary(undefined);
      setEnrichmentWarning(null);
      setIsStaleCache(false);
      setDispositionHistoryCount(0);
      setDispositionUpdatedAt(null);
      setDispositionSaveState("idle");
      setDispositionError(null);
      return;
    }

    setDisposition(finding.analystDisposition ?? "true_risk");
    setRationale(finding.analystRationale ?? finding.decisionRationale ?? "");
    setFactors(deriveInitialFactors(finding));
    setResolvedEnrichmentSummary(finding.enrichmentSummary);
    setAnalysisState({
      status: "idle",
      result: null,
      trace: null,
      traceCount: 0,
      error: null,
    });
  }, [finding]);

  useEffect(() => {
    if (!finding) {
      return;
    }

    let isCancelled = false;
    const activeFinding = finding;

    async function loadEnrichmentSummary() {
      const cached = enrichmentCacheRef.current.get(activeFinding.id);
      if (cached) {
        setResolvedEnrichmentSummary(cached.summary);
        return;
      }

      try {
        const response = await fetch(
          `/api/findings/${encodeURIComponent(activeFinding.id)}/enrichment`,
          {
            method: "GET",
            cache: "no-store",
          },
        );
        const json = (await response.json()) as {
          ok: boolean;
          data?: {
            snapshots?: FindingEnrichmentSnapshot[];
          };
        };

        if (isCancelled || !response.ok || !json.ok) {
          return;
        }

        const snapshots = json.data?.snapshots ?? [];
        const summary = buildEnrichmentSummary(snapshots);
        enrichmentCacheRef.current.set(activeFinding.id, { summary });
        setResolvedEnrichmentSummary(summary);
      } catch {
        // Keep the list payload summary if the detail refresh fails.
      }
    }

    void loadEnrichmentSummary();

    return () => {
      isCancelled = true;
    };
  }, [finding]);

  useEffect(() => {
    if (!finding) {
      return;
    }

    let isCancelled = false;
    const activeFinding = finding;

    async function loadDisposition() {
      setDispositionSaveState("loading");
      setDispositionError(null);

      const cached = dispositionCacheRef.current.get(activeFinding.id);
      if (cached) {
        setDisposition(cached.disposition);
        setRationale(cached.rationale);
        setFactors(cached.factors);
        setDispositionHistoryCount(cached.historyCount);
        setDispositionUpdatedAt(cached.updatedAt);
        setDispositionSaveState("idle");
        return;
      }

      try {
        const response = await fetch(`/api/findings/${encodeURIComponent(activeFinding.id)}/disposition`, {
          method: "GET",
          cache: "no-store",
        });
        const json = (await response.json()) as {
          ok: boolean;
          data?: AnalystDispositionResponse;
          error?: {
            message?: string;
          };
        };

        if (isCancelled) {
          return;
        }

        if (!response.ok || !json.ok || !json.data) {
          throw new Error(json.error?.message ?? "Unable to load analyst disposition.");
        }

        setDispositionHistoryCount(json.data.history.length);
        setDispositionUpdatedAt(json.data.disposition?.updatedAt ?? null);

        if (json.data.disposition) {
          setDisposition(json.data.disposition.decision);
          setRationale(json.data.disposition.rationale);
          setFactors(json.data.disposition.factors);
          dispositionCacheRef.current.set(activeFinding.id, {
            disposition: json.data.disposition.decision,
            rationale: json.data.disposition.rationale,
            factors: json.data.disposition.factors,
            historyCount: json.data.history.length,
            updatedAt: json.data.disposition.updatedAt,
          });
        } else {
          dispositionCacheRef.current.set(activeFinding.id, {
            disposition: activeFinding.analystDisposition ?? "true_risk",
            rationale: activeFinding.analystRationale ?? activeFinding.decisionRationale ?? "",
            factors: deriveInitialFactors(activeFinding),
            historyCount: json.data.history.length,
            updatedAt: null,
          });
        }

        setDispositionSaveState("idle");
      } catch (error) {
        if (isCancelled) {
          return;
        }
        setDispositionSaveState("error");
        setDispositionError(
          error instanceof Error
            ? error.message
            : "Unable to load analyst disposition.",
        );
      }
    }

    void loadDisposition();

    return () => {
      isCancelled = true;
    };
  }, [finding]);

  useEffect(() => {
    if (!finding) {
      return;
    }

    let isCancelled = false;
    const activeFinding = finding;

    async function loadNvdRecord() {
      setEnrichmentWarning(null);
      setIsStaleCache(false);

      const cached = nvdCacheRef.current.get(activeFinding.cveId);
      if (cached) {
        setRecord(cached.record);
        setEnrichmentWarning(cached.warning);
        setIsStaleCache(cached.staleCache);
        return;
      }

      try {
        const response = await fetch(`/api/nvd?cve=${encodeURIComponent(activeFinding.cveId)}`, {
          method: "GET",
        });
        const json = await response.json();

        if (isCancelled) {
          return;
        }

        if (!response.ok || !json?.ok) {
          const message =
            json?.error?.message ??
            "NVD enrichment unavailable. Rendering scanner and analysis context only.";
          setEnrichmentWarning(message);
          const fallbackRecord = {
            cveId: activeFinding.cveId,
            nvd: {
              source: "NVD" as const,
              rawDescription: undefined,
            },
            analysis: {
              source: "CVERiskPilot" as const,
              businessImpact: activeFinding.businessImpact,
              exploitabilityAssessment: activeFinding.technicalImpact,
              falsePositiveAssessment: activeFinding.analystNotes,
              recommendedAction: activeFinding.remediationSummary,
              confidence:
                typeof activeFinding.aiConfidence === "number"
                  ? activeFinding.aiConfidence / 100
                  : undefined,
            },
            enrichments: {
              kev: activeFinding.kevListed,
              scannerContext: activeFinding.source,
              enterpriseArchitecture: activeFinding.architectureContextSummary,
            },
            compliance: {
              attributionRequired: true as const,
              endorsementProhibited: true as const,
              modifiedContentSeparated: true as const,
            },
          };
          nvdCacheRef.current.set(activeFinding.cveId, {
            record: fallbackRecord,
            warning: message,
            staleCache: false,
          });
          setRecord(fallbackRecord);
          return;
        }

        const cachedRecord = {
          ...(json.data as VulnerabilityRecord),
          analysis: {
            ...(json.data?.analysis ?? { source: "CVERiskPilot" }),
            source: "CVERiskPilot",
            businessImpact: activeFinding.businessImpact,
            exploitabilityAssessment: activeFinding.technicalImpact,
            falsePositiveAssessment: activeFinding.analystNotes,
            recommendedAction: activeFinding.remediationSummary,
            confidence:
              typeof activeFinding.aiConfidence === "number"
                ? activeFinding.aiConfidence / 100
                : undefined,
          },
          enrichments: {
            ...(json.data?.enrichments ?? {}),
            kev: activeFinding.kevListed,
            scannerContext: activeFinding.source,
            enterpriseArchitecture: activeFinding.architectureContextSummary,
          },
        };
        const warningMessage = typeof json?.warnings?.[0]?.message === "string"
          ? (json.warnings[0].message as string)
          : null;
        const stale = Boolean(json?.meta?.stale);

        nvdCacheRef.current.set(activeFinding.cveId, {
          record: cachedRecord,
          warning: warningMessage,
          staleCache: stale,
        });
        setIsStaleCache(stale);
        setEnrichmentWarning(warningMessage);
        setRecord(cachedRecord);
      } catch {
        if (isCancelled) {
          return;
        }
        setEnrichmentWarning(
          "NVD lookup failed. Rendering without live NVD data for this finding.",
        );
      }
    }

    void loadNvdRecord();

    return () => {
      isCancelled = true;
    };
  }, [finding]);

  useEffect(() => {
    function handleRunEvent(event: Event) {
      const customEvent = event as CustomEvent<AiTriageRunDetail>;

      if (customEvent.detail.mode !== "live") {
        return;
      }

      void handleGenerateNarrative("live");
    }

    window.addEventListener(AI_TRIAGE_RUN_EVENT, handleRunEvent as EventListener);

    return () => {
      window.removeEventListener(AI_TRIAGE_RUN_EVENT, handleRunEvent as EventListener);
    };
  }, []);

  if (!finding || !factors) {
    return (
      <aside className="flex min-h-[420px] flex-col overflow-hidden rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] shadow-[0_18px_48px_rgba(0,0,0,0.22)]">
        <div className="flex items-center gap-3 border-b border-[rgba(0,200,180,0.06)] px-4 py-3">
          <div className="font-mono text-[0.75rem] uppercase tracking-[0.12em] text-[var(--accent)]">
            // AI Analysis
          </div>
        </div>
        <div className="px-4 py-4">
          <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4">
            <div className="font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#5a7080]">
              No finding selected
            </div>
          </div>
        </div>
      </aside>
    );
  }

  async function handleSaveDisposition() {
    if (!finding) {
      return;
    }

    setDispositionSaveState("saving");
    setDispositionError(null);

    try {
      const response = await fetch(`/api/findings/${encodeURIComponent(finding.id)}/disposition`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          decision: disposition,
          rationale,
          notes: null,
          factors,
          updatedBy: "dashboard-analyst",
        }),
      });
      const json = (await response.json()) as {
        ok: boolean;
        data?: AnalystDispositionResponse;
        error?: {
          message?: string;
        };
      };

      if (!response.ok || !json.ok || !json.data) {
        throw new Error(json.error?.message ?? "Unable to save analyst disposition.");
      }

      setDispositionHistoryCount(json.data.history.length);
      setDispositionUpdatedAt(json.data.disposition?.updatedAt ?? null);
      if (json.data.disposition) {
        dispositionCacheRef.current.set(finding.id, {
          disposition: json.data.disposition.decision,
          rationale: json.data.disposition.rationale,
          factors: json.data.disposition.factors,
          historyCount: json.data.history.length,
          updatedAt: json.data.disposition.updatedAt,
        });
      }
      setDispositionSaveState("saved");
    } catch (error) {
      setDispositionSaveState("error");
      setDispositionError(
        error instanceof Error
          ? error.message
          : "Unable to save analyst disposition.",
      );
    }
  }

  async function handleGenerateNarrative(mode: "stub" | "live") {
    if (!finding) {
      dispatchAiTriageStatus({
        status: "error",
        message: "Select a finding before running AI triage.",
      });
      return;
    }

    dispatchAiTriageStatus({
      status: "running",
      message: `Generating AI triage for ${finding.cveId}.`,
    });

    setAnalysisState({
      status: "running",
      result: null,
      trace: null,
      traceCount: 0,
      error: null,
    });

    try {
      const response = await fetch(`/api/findings/${encodeURIComponent(finding.id)}/analysis`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ mode }),
      });
      const json = (await response.json()) as {
        ok: boolean;
        data?: {
          generated: GeneratedFindingAnalysis;
          trace: AnalysisTraceRecord;
          traces: AnalysisTraceRecord[];
        };
        error?: {
          message?: string;
        };
      };

      if (!response.ok || !json.ok || !json.data?.generated) {
        throw new Error(json.error?.message ?? "Unable to generate analysis narrative.");
      }

      setAnalysisState({
        status: "done",
        result: json.data.generated,
        trace: json.data.trace,
        traceCount: json.data.traces.length,
        error: null,
      });
      dispatchAiTriageStatus({
        status: "success",
        message: `AI triage completed for ${finding.cveId}.`,
      });
    } catch (error) {
      setAnalysisState({
        status: "error",
        result: null,
        trace: null,
        traceCount: 0,
        error:
          error instanceof Error
            ? error.message
            : "Unable to generate analysis narrative.",
      });
      dispatchAiTriageStatus({
        status: "error",
        message:
          error instanceof Error
            ? error.message
            : "Unable to generate analysis narrative.",
      });
    }
  }

  return (
    <aside className="flex min-h-[420px] flex-col overflow-hidden rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] shadow-[0_18px_48px_rgba(0,0,0,0.22)]">
      <div className="flex items-center gap-3 border-b border-[rgba(0,200,180,0.06)] px-4 py-3">
        <div className="font-mono text-[0.75rem] uppercase tracking-[0.12em] text-[var(--accent)]">
          // AI Analysis
        </div>
      </div>

      <div className="min-h-0 overflow-y-auto px-4 py-4">
        <div>
          <div className="font-mono text-[0.76rem] tracking-[0.05em] text-[var(--accent)]">
            {finding.cveId} · {finding.product} {finding.version}
          </div>
          <h3 className="mt-2 text-[1rem] font-semibold leading-tight text-white">
            {finding.title}
          </h3>
        </div>

        <div className="mt-4 flex items-end gap-4">
          <div>
          <div className="text-[2rem] font-black leading-none tracking-[-0.04em] text-[var(--danger)]">
              {effectiveCvssScore}
          </div>
            <div className="mt-1 font-mono text-[0.58rem] uppercase tracking-[0.12em] text-[#5a7080]">
              CVSS
            </div>
          </div>

          <div className="flex-1 px-2">
            <div className="mb-1 font-mono text-[0.58rem] uppercase tracking-[0.12em] text-[#5a7080]">
              Risk Meter
            </div>
            <div className="h-1 rounded bg-[#0a1525]">
              <div
                className="h-full rounded bg-[linear-gradient(90deg,#ff4560,#ff6b80)]"
                style={{ width: `${Math.min(finding.riskScore, 100)}%` }}
              />
            </div>
          </div>

          <div className="text-right">
            <div className="text-[1.8rem] font-black leading-none tracking-[-0.04em] text-[var(--danger)]">
              {finding.riskScore}
            </div>
            <div className="mt-1 font-mono text-[0.58rem] uppercase tracking-[0.12em] text-[#5a7080]">
              Risk Score
            </div>
          </div>
        </div>

        <div className="mt-4 flex flex-wrap gap-2">
          <StatusPill tone={severityPillTone[finding.severity]}>
            {finding.severity}
          </StatusPill>
          {effectiveExploitAvailable ? (
            <StatusPill tone="danger">Exploit Available</StatusPill>
          ) : null}
          {effectiveKevListed ? <StatusPill tone="warning">KEV Listed</StatusPill> : null}
          <StatusPill>{finding.assetName}</StatusPill>
        </div>

        <AnalysisSectionCard title="Enrichment Signals" badge="Sources">
          <div className="grid gap-2 text-[0.74rem] text-[var(--text)]">
            <div>
              <span className="font-mono text-[0.62rem] uppercase tracking-[0.1em] text-[#5a7080]">
                Status:
              </span>{" "}
              {(enrichment?.status ?? "pending").replaceAll("_", " ")}
            </div>
            <div>
              <span className="font-mono text-[0.62rem] uppercase tracking-[0.1em] text-[#5a7080]">
                Providers:
              </span>{" "}
              {enrichment?.providers.length
                ? enrichment.providers.join(", ")
                : "n/a"}
            </div>
            <div>
              <span className="font-mono text-[0.62rem] uppercase tracking-[0.1em] text-[#5a7080]">
                CVSS Vector:
              </span>{" "}
              {enrichment?.cvssVector ?? "n/a"}
            </div>
            <div>
              <span className="font-mono text-[0.62rem] uppercase tracking-[0.1em] text-[#5a7080]">
                Source Timestamp:
              </span>{" "}
              {enrichment?.lastObservedAt
                ? enrichment.lastObservedAt
                : "pending"}
            </div>
          </div>
        </AnalysisSectionCard>

        <AnalysisSectionCard title="Prioritization Influence" badge="Deterministic">
          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-3">
              <div className="font-mono text-[0.58rem] uppercase tracking-[0.12em] text-[#5a7080]">
                Base Risk
              </div>
              <div className="mt-2 text-[1.1rem] font-black text-white">
                {finding.prioritization?.baseRiskScore ?? finding.riskScore}
              </div>
            </div>
            <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-3">
              <div className="font-mono text-[0.58rem] uppercase tracking-[0.12em] text-[#5a7080]">
                Adjustment
              </div>
              <div className="mt-2 text-[1.1rem] font-black text-[var(--accent)]">
                {finding.prioritization?.totalAdjustment
                  ? `${finding.prioritization.totalAdjustment > 0 ? "+" : ""}${finding.prioritization.totalAdjustment}`
                  : "0"}
              </div>
            </div>
            <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-3">
              <div className="font-mono text-[0.58rem] uppercase tracking-[0.12em] text-[#5a7080]">
                Effective Risk
              </div>
              <div className="mt-2 text-[1.1rem] font-black text-white">
                {finding.riskScore}
              </div>
            </div>
          </div>
          <div className="mt-3 space-y-2 text-[0.78rem] leading-6 text-[var(--text-dim)]">
            {finding.prioritization?.reasons?.length ? (
              finding.prioritization.reasons.map((reason) => (
                <div key={reason}>- {reason}</div>
              ))
            ) : (
              <div>No analyst-driven priority adjustments recorded yet.</div>
            )}
          </div>
        </AnalysisSectionCard>

        <AnalysisSectionCard title="Business Impact" badge={finding.businessImpactSource ?? "AI"}>
          <div className="flex items-center justify-between gap-3">
            <div className="font-mono text-[0.58rem] uppercase tracking-[0.12em] text-[#5a7080]">
              Confidence {finding.aiConfidence ?? "n/a"}%
            </div>
            <div className="font-mono text-[0.58rem] uppercase tracking-[0.12em] text-[#5a7080]">
              Enriched {finding.lastEnrichedAt?.slice(0, 10) ?? "pending"}
            </div>
          </div>
          <p className="mt-3 text-[0.82rem] leading-8 text-[var(--text)] opacity-90">
            {finding.businessImpact ??
              "Business impact analysis will appear here after enrichment and AI triage complete."}
          </p>
        </AnalysisSectionCard>

        <AnalysisSectionCard title="Remediation Guidance" badge="AI">
          <p className="text-[0.82rem] leading-8 text-[var(--text)] opacity-90">
            {finding.remediationSummary ??
              "Remediation guidance will appear here after enrichment and analysis complete."}
          </p>
        </AnalysisSectionCard>

        <AnalysisSectionCard title="Ticket-ready Action Plan" badge="AI">
          <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-3 font-mono text-[0.7rem] leading-7 text-[var(--text)]">
            <div>
              <span className="text-[var(--accent)]">PRIORITY:</span>{" "}
              {finding.ticketReadyActionPlan?.priority ?? "Pending"}
            </div>
            <div>
              <span className="text-[var(--accent)]">ASSIGNEE:</span>{" "}
              {finding.ticketReadyActionPlan?.assignee ?? "To be assigned"}
            </div>
            <div>
              <span className="text-[var(--accent)]">ETA:</span>{" "}
              {finding.ticketReadyActionPlan?.eta ?? "TBD"}
            </div>
            <div>
              <span className="text-[var(--accent)]">COMPONENT:</span>{" "}
              {finding.ticketReadyActionPlan?.component ?? finding.product}
            </div>
            <div>
              <span className="text-[var(--accent)]">LABELS:</span>{" "}
              {finding.ticketReadyActionPlan?.labels.join(", ") ?? "pending"}
            </div>
          </div>
        </AnalysisSectionCard>

        {finding.ingestionProvenance ? (
          <AnalysisSectionCard title="Upload Provenance" badge="Ingested">
            <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-3 font-mono text-[0.68rem] leading-7 text-[var(--text)]">
              <div>
                <span className="text-[var(--accent)]">UPLOAD JOB:</span>{" "}
                {finding.ingestionProvenance.uploadJobId}
              </div>
              <div>
                <span className="text-[var(--accent)]">ARTIFACT:</span>{" "}
                {finding.ingestionProvenance.artifactFilename}
              </div>
              <div>
                <span className="text-[var(--accent)]">SCANNER:</span>{" "}
                {finding.ingestionProvenance.sourceScanner}
              </div>
              <div>
                <span className="text-[var(--accent)]">CHECKSUM:</span>{" "}
                {finding.ingestionProvenance.checksumSha256.slice(0, 12)}...
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <StatusPill
                tone={finding.ingestionProvenance.warningCount > 0 ? "warning" : "default"}
              >
                Warnings {finding.ingestionProvenance.warningCount}
              </StatusPill>
              <StatusPill
                tone={finding.ingestionProvenance.errorCount > 0 ? "danger" : "default"}
              >
                Errors {finding.ingestionProvenance.errorCount}
              </StatusPill>
            </div>
          </AnalysisSectionCard>
        ) : null}

        <NvdNotice className="mt-4" />
        {enrichmentWarning ? (
          <EnrichmentErrorBanner message={enrichmentWarning} staleCache={isStaleCache} />
        ) : null}
        <CveSourceSections record={record} enrichmentSummary={enrichment} />

        <EnterpriseContextSection
          factors={factors}
          onChange={setFactors}
          summary={
            finding.architectureContextSummary ??
            "Enterprise context will appear here as analyst and architecture inputs are added."
          }
        />

        <AnalystDispositionSection
          value={disposition}
          onChange={setDisposition}
          badge={
            dispositionSaveState === "loading"
              ? "Loading"
              : dispositionSaveState === "saving"
                ? "Saving"
                : dispositionSaveState === "saved"
                  ? "Saved"
                  : "Persisted"
          }
          disabled={dispositionSaveState === "loading" || dispositionSaveState === "saving"}
        />

        <DecisionRationaleSection value={rationale} onChange={setRationale} />

        <AnalysisSectionCard title="AI Analysis" badge="Live">
          <div className="flex flex-wrap gap-2">
            {showInternalAnalysisControls ? (
              <button
                type="button"
                onClick={() => handleGenerateNarrative("stub")}
                disabled={analysisState.status === "running"}
                className="rounded border border-[rgba(0,200,180,0.16)] bg-[rgba(0,200,180,0.12)] px-3 py-1.5 font-mono text-[0.62rem] uppercase tracking-[0.08em] text-[var(--accent)] transition hover:border-[rgba(0,200,180,0.24)] disabled:cursor-not-allowed disabled:opacity-50"
              >
                {analysisState.status === "running" ? "Generating..." : "Generate Baseline Draft"}
              </button>
            ) : null}
            <button
              type="button"
              onClick={() => handleGenerateNarrative("live")}
              disabled={analysisState.status === "running"}
              className="rounded border border-[rgba(255,208,96,0.18)] bg-[rgba(255,208,96,0.12)] px-3 py-1.5 font-mono text-[0.62rem] uppercase tracking-[0.08em] text-[var(--warning)] transition hover:border-[rgba(255,208,96,0.28)] disabled:cursor-not-allowed disabled:opacity-50"
            >
              Run AI Triage
            </button>
          </div>
          {analysisState.error ? (
            <p className="mt-3 text-[0.78rem] leading-7 text-[var(--danger)]">{analysisState.error}</p>
          ) : null}
          {analysisState.result ? (
            <div className="mt-3 rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-3 text-[0.8rem] leading-7 text-[var(--text)]">
              <div className="mt-2 flex flex-wrap gap-2">
                <StatusPill>
                  {analysisState.result.traceStatus}
                </StatusPill>
                {analysisState.trace?.generatedAt ? (
                  <StatusPill>
                    Generated {analysisState.trace.generatedAt.slice(0, 16).replace("T", " ")}
                  </StatusPill>
                ) : null}
                {showInternalAnalysisControls ? (
                  <StatusPill>
                    Trace {analysisState.traceCount}
                  </StatusPill>
                ) : null}
              </div>
              {showInternalAnalysisControls ? (
                <div className="mt-2">
                  <span className="font-mono text-[0.62rem] uppercase tracking-[0.1em] text-[var(--accent)]">
                    Provider:
                  </span>{" "}
                  {analysisState.result.provider} · {analysisState.result.model}
                </div>
              ) : null}
              {analysisState.result.fallbackReason ? (
                <div className="mt-2 text-[0.76rem] leading-6 text-[var(--warning)]">
                  Fallback reason: {analysisState.result.fallbackReason}
                </div>
              ) : null}
              {analysisState.result.warnings.length > 0 ? (
                <div className="mt-2 text-[0.76rem] leading-6 text-[var(--text-dim)]">
                  {analysisState.result.warnings.join(" ")}
                </div>
              ) : null}
              <div className="mt-2">
                <span className="font-mono text-[0.62rem] uppercase tracking-[0.1em] text-[var(--accent)]">
                  Business Impact:
                </span>{" "}
                {analysisState.result.output.businessImpact}
              </div>
              <div className="mt-2">
                <span className="font-mono text-[0.62rem] uppercase tracking-[0.1em] text-[var(--accent)]">
                  Exploitability:
                </span>{" "}
                {analysisState.result.output.exploitabilityAssessment}
              </div>
              <div className="mt-2">
                <span className="font-mono text-[0.62rem] uppercase tracking-[0.1em] text-[var(--accent)]">
                  Recommended Action:
                </span>{" "}
                {analysisState.result.output.recommendedAction}
              </div>
            </div>
          ) : (
            <p className="mt-3 text-[0.78rem] leading-7 text-[var(--text-dim)]">
              Stub mode is deterministic for safe local validation. Live mode uses Claude only when `ANTHROPIC_API_KEY` is configured server-side, and every generation now records an audit trace.
            </p>
          )}
        </AnalysisSectionCard>

        <AnalysisSectionCard title="Disposition Persistence" badge="API">
          <div className="flex flex-wrap items-center gap-2">
            <button
              type="button"
              onClick={handleSaveDisposition}
              disabled={dispositionSaveState === "loading" || dispositionSaveState === "saving"}
              className="rounded border border-[rgba(0,200,180,0.16)] bg-[rgba(0,200,180,0.12)] px-3 py-1.5 font-mono text-[0.62rem] uppercase tracking-[0.08em] text-[var(--accent)] transition hover:border-[rgba(0,200,180,0.24)] disabled:cursor-not-allowed disabled:opacity-50"
            >
              {dispositionSaveState === "saving" ? "Saving..." : "Save Disposition"}
            </button>
            <StatusPill>
              History {dispositionHistoryCount}
            </StatusPill>
            {dispositionUpdatedAt ? (
              <StatusPill>
                Updated {dispositionUpdatedAt.slice(0, 16).replace("T", " ")}
              </StatusPill>
            ) : null}
          </div>
          {dispositionError ? (
            <p className="mt-3 text-[0.78rem] leading-7 text-[var(--danger)]">{dispositionError}</p>
          ) : (
            <p className="mt-3 text-[0.78rem] leading-7 text-[var(--text-dim)]">
              Persisted analyst decisions feed the future Claude feedback loop and historical triage explainability.
            </p>
          )}
        </AnalysisSectionCard>
      </div>
    </aside>
  );
}
