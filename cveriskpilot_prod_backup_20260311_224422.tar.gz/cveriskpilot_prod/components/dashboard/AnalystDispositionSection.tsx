"use client";

import type { AnalystDecision } from "@/types/dashboard";

import { AnalysisSectionCard } from "@/components/dashboard/AnalysisSectionCard";
import { StatusPill } from "@/components/dashboard/StatusPill";

type AnalystDispositionSectionProps = {
  value: AnalystDecision;
  onChange: (value: AnalystDecision) => void;
  badge?: string;
  disabled?: boolean;
};

const options: AnalystDecision[] = [
  "true_risk",
  "false_positive",
  "mitigated",
  "accepted_risk",
  "not_applicable",
];

function formatLabel(value: AnalystDecision) {
  return value.replaceAll("_", " ");
}

export function AnalystDispositionSection({
  value,
  onChange,
  badge = "Persisted",
  disabled = false,
}: AnalystDispositionSectionProps) {
  return (
    <AnalysisSectionCard title="Analyst Disposition" badge={badge}>
      <div className="flex flex-wrap gap-2">
        {options.map((option) => (
          <button
            key={option}
            type="button"
            onClick={() => onChange(option)}
            disabled={disabled}
            className={`rounded border px-3 py-1.5 font-mono text-[0.62rem] uppercase tracking-[0.08em] transition ${
              value === option
                ? "border-[rgba(0,200,180,0.16)] bg-[rgba(0,200,180,0.12)] text-[var(--accent)]"
                : "border-[rgba(0,200,180,0.06)] text-[#5a7080] hover:border-[rgba(0,200,180,0.12)] hover:text-[var(--text)]"
            } disabled:cursor-not-allowed disabled:opacity-50`}
          >
            {formatLabel(option)}
          </button>
        ))}
      </div>

      <div className="mt-3">
        <StatusPill tone="accent">{formatLabel(value)}</StatusPill>
      </div>
    </AnalysisSectionCard>
  );
}
