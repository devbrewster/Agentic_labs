"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { getDashboardRouteKeyFromPathname } from "@/lib/app-routes";
import { listDashboardNavItems } from "@/lib/services/dashboard";

export function DashboardMobileNav() {
  const pathname = usePathname();
  const dashboardNavItems = listDashboardNavItems();
  const activeRouteKey = getDashboardRouteKeyFromPathname(pathname);

  return (
    <div className="border-b border-[rgba(0,200,180,0.06)] bg-[rgba(4,8,16,0.9)] px-4 py-3 xl:hidden">
      <div className="mb-2 font-mono text-[0.58rem] uppercase tracking-[0.16em] text-[#3a5060]">
        Workspace Navigation
      </div>
      <div className="flex gap-2 overflow-x-auto pb-1">
        {dashboardNavItems.map((item) => {
          const isActive = activeRouteKey === item.routeKey;

          return (
            <Link
              key={item.routeKey}
              href={item.href}
              prefetch={false}
              className={`whitespace-nowrap rounded border px-3 py-2 font-mono text-[0.64rem] uppercase tracking-[0.08em] ${
                isActive
                  ? "border-[rgba(0,200,180,0.12)] bg-[rgba(0,200,180,0.12)] text-[var(--accent)]"
                  : "border-[rgba(0,200,180,0.06)] text-[#5a7080]"
              }`}
            >
              {item.label}
            </Link>
          );
        })}
      </div>
    </div>
  );
}
