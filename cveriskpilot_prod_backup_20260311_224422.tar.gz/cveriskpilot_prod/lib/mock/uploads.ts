import type { UploadJob } from "@/types/dashboard";

export const supportedUploadFormats = [
  {
    label: "JSON",
    description: "Structured exports from scanner APIs and platform-native report bundles.",
  },
  {
    label: "CSV",
    description: "Tabular findings exports from vulnerability management and asset tooling.",
  },
  {
    label: "XML",
    description: "Legacy scan output and enterprise scanner report formats.",
  },
  {
    label: "SARIF",
    description: "Future placeholder for code scanning and static analysis interchange.",
  },
] as const;

export const mockUploadJobs: UploadJob[] = [
  {
    id: "upload-001",
    filename: "wiz-prod-export-2026-03-10.json",
    sourceType: "Wiz Export",
    status: "completed",
    uploadedAt: "2026-03-10T08:15:00.000Z",
    findingsDetected: 847,
    uploadedBy: "sec-analyst",
    notes: "Primary production snapshot used for morning triage.",
  },
  {
    id: "upload-002",
    filename: "snyk-app-services.csv",
    sourceType: "Snyk CSV",
    status: "processing",
    uploadedAt: "2026-03-10T09:05:00.000Z",
    findingsDetected: 214,
    uploadedBy: "platform-security",
    notes: "Application service package vulnerabilities queued for normalization.",
  },
  {
    id: "upload-003",
    filename: "qualys-edge-xml.xml",
    sourceType: "Qualys XML",
    status: "queued",
    uploadedAt: "2026-03-10T09:42:00.000Z",
    uploadedBy: "sec-analyst",
    notes: "Pending parser handoff to enrichment pipeline.",
  },
  {
    id: "upload-004",
    filename: "legacy-scan-batch.xml",
    sourceType: "Legacy XML",
    status: "failed",
    uploadedAt: "2026-03-09T16:28:00.000Z",
    findingsDetected: 0,
    uploadedBy: "ops-admin",
    notes: "Schema validation failed during ingestion pre-check.",
  },
];
