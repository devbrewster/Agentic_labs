import "server-only";

import { promises as fs } from "node:fs";
import path from "node:path";

import type {
  AgentMeshLogSummary,
  AgentMeshMonitorSnapshot,
  AgentMeshPhase,
  AgentMeshPhaseState,
  AgentMeshReportSummary,
  AgentMeshStatus,
} from "@/types/agent-mesh";

const STATUS_DIR = path.join(process.cwd(), ".codex", "state");
const LOG_DIR = path.join(STATUS_DIR, "logs");
const REPORTS_DIR = path.join(process.cwd(), ".codex", "reports");

function parseStatusContent(fileName: string, content: string): AgentMeshStatus {
  const entries = Object.fromEntries(
    content
      .split("\n")
      .map((line) => line.trim())
      .filter(Boolean)
      .map((line) => {
        const separatorIndex = line.indexOf("=");
        if (separatorIndex === -1) {
          return [line, ""];
        }

        return [
          line.slice(0, separatorIndex),
          line.slice(separatorIndex + 1),
        ];
      }),
  );

  return {
    fileName,
    agent: entries.agent ?? "unknown",
    phase: entries.phase ?? "unknown",
    status: entries.status ?? "unknown",
    startedAt: entries.started_at,
    completedAt: entries.completed_at,
    failedAt: entries.failed_at,
    output: entries.output,
    log: entries.log,
  };
}

async function safeReadDir(dirPath: string) {
  try {
    return await fs.readdir(dirPath, { withFileTypes: true });
  } catch {
    return [];
  }
}

async function readStatuses(): Promise<AgentMeshStatus[]> {
  const entries = await safeReadDir(STATUS_DIR);
  const statusFiles = entries
    .filter((entry) => entry.isFile() && entry.name.endsWith(".status"))
    .map((entry) => entry.name)
    .sort();

  const statuses = await Promise.all(
    statusFiles.map(async (fileName) => {
      const content = await fs.readFile(path.join(STATUS_DIR, fileName), "utf8");
      return parseStatusContent(fileName, content);
    }),
  );

  return statuses.sort((left, right) => {
    const leftTime = left.startedAt ?? left.completedAt ?? left.failedAt ?? "";
    const rightTime = right.startedAt ?? right.completedAt ?? right.failedAt ?? "";
    return rightTime.localeCompare(leftTime) || left.fileName.localeCompare(right.fileName);
  });
}

async function readLogs(): Promise<AgentMeshLogSummary[]> {
  const entries = await safeReadDir(LOG_DIR);
  const logFiles = entries
    .filter((entry) => entry.isFile() && entry.name.endsWith(".log"))
    .map((entry) => entry.name)
    .sort();

  return Promise.all(
    logFiles.map(async (fileName) => {
      const fullPath = path.join(LOG_DIR, fileName);
      const [content, stats] = await Promise.all([
        fs.readFile(fullPath, "utf8").catch(() => ""),
        fs.stat(fullPath).catch(() => null),
      ]);

      return {
        fileName,
        path: fullPath,
        tail: content.split("\n").filter(Boolean).slice(-16),
        updatedAt: stats?.mtime.toISOString() ?? null,
      };
    }),
  );
}

async function summarizeReportPaths(reportPaths: string[]): Promise<AgentMeshReportSummary[]> {
  return Promise.all(
    reportPaths.map(async (reportPath) => {
      try {
        const stats = await fs.stat(reportPath);
        return {
          path: reportPath,
          exists: true,
          sizeBytes: stats.size,
          updatedAt: stats.mtime.toISOString(),
        };
      } catch {
        return {
          path: reportPath,
          exists: false,
          sizeBytes: 0,
          updatedAt: null,
        };
      }
    }),
  );
}

function deriveCurrentPhase(statuses: AgentMeshStatus[]): AgentMeshPhase | "completed" {
  if (statuses.some((status) => status.status === "running" && status.phase === "independent")) {
    return "independent";
  }

  if (
    statuses.some(
      (status) =>
        status.status === "running" &&
        typeof status.phase === "string" &&
        status.phase.startsWith("cross-review-of-"),
    )
  ) {
    return "cross-review";
  }

  if (
    statuses.some(
      (status) => status.status === "running" && status.phase === "cross-review-matrix",
    )
  ) {
    return "cross-review-matrix";
  }

  if (statuses.some((status) => status.status === "running" && status.phase === "final")) {
    return "final";
  }

  return "completed";
}

function isCompletedStatus(status: string) {
  return status === "completed" || status === "dry_run_complete";
}

function buildPhaseState(
  phase: AgentMeshPhase,
  label: string,
  statuses: AgentMeshStatus[],
): AgentMeshPhaseState {
  let phaseStatuses: AgentMeshStatus[] = [];

  if (phase === "cross-review") {
    phaseStatuses = statuses.filter(
      (status) =>
        typeof status.phase === "string" && status.phase.startsWith("cross-review-of-"),
    );
  } else {
    phaseStatuses = statuses.filter((status) => status.phase === phase);
  }

  const totalTasks = phaseStatuses.length;
  const completedTasks = phaseStatuses.filter((status) => isCompletedStatus(status.status)).length;
  const runningTasks = phaseStatuses.filter((status) => status.status === "running").length;
  const failedTasks = phaseStatuses.filter((status) => status.status === "failed").length;

  let phaseStatus: AgentMeshPhaseState["status"] = "pending";

  if (failedTasks > 0) {
    phaseStatus = "failed";
  } else if (runningTasks > 0) {
    phaseStatus = "running";
  } else if (totalTasks > 0 && completedTasks === totalTasks) {
    phaseStatus = "completed";
  }

  return {
    phase,
    label,
    status: phaseStatus,
    totalTasks,
    completedTasks,
    runningTasks,
    failedTasks,
  };
}

function buildPhaseStates(statuses: AgentMeshStatus[]): AgentMeshPhaseState[] {
  return [
    buildPhaseState("independent", "Independent Reviews", statuses),
    buildPhaseState("cross-review", "Cross-Reviews", statuses),
    buildPhaseState("cross-review-matrix", "Cross-Review Matrix", statuses),
    buildPhaseState("final", "Final Synthesis", statuses),
  ];
}

export async function getAgentMeshMonitorSnapshot(): Promise<AgentMeshMonitorSnapshot> {
  const [statuses, logs, individual, crossReview, final] = await Promise.all([
    readStatuses(),
    readLogs(),
    summarizeReportPaths([
      path.join(REPORTS_DIR, "individual", "orchestrator-assessment.md"),
      path.join(REPORTS_DIR, "individual", "pm-agent-assessment.md"),
      path.join(REPORTS_DIR, "individual", "product-ux-assessment.md"),
      path.join(REPORTS_DIR, "individual", "security-platform-assessment.md"),
    ]),
    summarizeReportPaths([
      path.join(REPORTS_DIR, "cross-review", "orchestrator-review-of-pm.md"),
      path.join(REPORTS_DIR, "cross-review", "orchestrator-review-of-product.md"),
      path.join(REPORTS_DIR, "cross-review", "orchestrator-review-of-security.md"),
      path.join(REPORTS_DIR, "cross-review", "pm-review-of-orchestrator.md"),
      path.join(REPORTS_DIR, "cross-review", "pm-review-of-product.md"),
      path.join(REPORTS_DIR, "cross-review", "pm-review-of-security.md"),
      path.join(REPORTS_DIR, "cross-review", "product-review-of-orchestrator.md"),
      path.join(REPORTS_DIR, "cross-review", "product-review-of-pm.md"),
      path.join(REPORTS_DIR, "cross-review", "product-review-of-security.md"),
      path.join(REPORTS_DIR, "cross-review", "security-review-of-orchestrator.md"),
      path.join(REPORTS_DIR, "cross-review", "security-review-of-pm.md"),
      path.join(REPORTS_DIR, "cross-review", "security-review-of-product.md"),
      path.join(REPORTS_DIR, "cross-review", "cross-review-matrix.md"),
    ]),
    summarizeReportPaths([
      path.join(REPORTS_DIR, "final", "unified-source-bundle.md"),
      path.join(REPORTS_DIR, "final", "unified-production-saas-assessment.md"),
    ]),
  ]);

  return {
    generatedAt: new Date().toISOString(),
    currentPhase: deriveCurrentPhase(statuses),
    runningCount: statuses.filter((status) => status.status === "running").length,
    failedCount: statuses.filter((status) => status.status === "failed").length,
    completedCount: statuses.filter((status) =>
      status.status === "completed" || status.status === "dry_run_complete"
    ).length,
    phaseStates: buildPhaseStates(statuses),
    statuses,
    logs,
    reports: {
      individual,
      crossReview,
      final,
    },
  };
}
