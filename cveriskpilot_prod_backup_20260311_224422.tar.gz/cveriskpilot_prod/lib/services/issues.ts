import issuesData from "@/data/pending-issues.json";
import type { PendingIssue, IssuePriority, IssueStatus, IssueTrack } from "@/types/issues";

const issuePriorityOrder: Record<IssuePriority, number> = {
  "P0 Now": 0,
  "P1 Next": 1,
  "P2 Later": 2,
};

const issueStatusOrder: Record<IssueStatus, number> = {
  in_progress: 0,
  blocked: 1,
  queued: 2,
  monitoring: 3,
  completed: 4,
};

const issueTrackLabels: Record<IssueTrack, string> = {
  dashboard_access: "Dashboard Access",
  ingestion: "Ingestion",
  enrichment: "Enrichment",
  billing: "Billing",
  audit: "Audit",
  ui: "UI",
};

const issues = issuesData as PendingIssue[];

export function listPendingIssues() {
  return [...issues].sort((left, right) => {
    const priorityDifference =
      issuePriorityOrder[left.priority] - issuePriorityOrder[right.priority];

    if (priorityDifference !== 0) {
      return priorityDifference;
    }

    const statusDifference =
      issueStatusOrder[left.status] - issueStatusOrder[right.status];

    if (statusDifference !== 0) {
      return statusDifference;
    }

    return left.id.localeCompare(right.id);
  });
}

export function getPendingIssueSummary() {
  const allIssues = listPendingIssues();

  return {
    total: allIssues.length,
    byPriority: {
      p0: allIssues.filter((issue) => issue.priority === "P0 Now").length,
      p1: allIssues.filter((issue) => issue.priority === "P1 Next").length,
      p2: allIssues.filter((issue) => issue.priority === "P2 Later").length,
    },
    byStatus: {
      inProgress: allIssues.filter((issue) => issue.status === "in_progress").length,
      blocked: allIssues.filter((issue) => issue.status === "blocked").length,
      queued: allIssues.filter((issue) => issue.status === "queued").length,
      monitoring: allIssues.filter((issue) => issue.status === "monitoring").length,
    },
  };
}

export function formatIssueStatus(status: IssueStatus) {
  return status.replaceAll("_", " ");
}

export function formatIssueTrack(track: IssueTrack) {
  return issueTrackLabels[track];
}

export function buildDiscordPendingIssuesReport() {
  const allIssues = listPendingIssues();

  return [
    "**CVERiskPilot Pending Issues Status**",
    "",
    "Using the current structured internal issue list.",
    "",
    ...allIssues.map((issue) =>
      [
        `**${issue.id} · ${issue.priority} · ${formatIssueStatus(issue.status)}**`,
        `${issue.title}`,
        `Track: ${formatIssueTrack(issue.track)}`,
        `Impact: ${issue.impact}`,
        `Next: ${issue.nextAction}`,
      ].join("\n"),
    ),
  ].join("\n\n");
}

export function buildInternalPendingIssuesReport() {
  const summary = getPendingIssueSummary();
  const allIssues = listPendingIssues();

  return [
    "# CVERiskPilot Pending Issues Status Report",
    "",
    `Last updated: ${new Date().toISOString().slice(0, 10)}`,
    "",
    "## Summary",
    "",
    `- Total open issues: ${summary.total}`,
    `- P0 Now: ${summary.byPriority.p0}`,
    `- P1 Next: ${summary.byPriority.p1}`,
    `- P2 Later: ${summary.byPriority.p2}`,
    `- In progress: ${summary.byStatus.inProgress}`,
    `- Blocked: ${summary.byStatus.blocked}`,
    `- Queued: ${summary.byStatus.queued}`,
    `- Monitoring: ${summary.byStatus.monitoring}`,
    "",
    "## Structured issue list",
    "",
    ...allIssues.flatMap((issue) => [
      `### ${issue.id} - ${issue.title}`,
      "",
      `- Priority: ${issue.priority}`,
      `- Status: ${formatIssueStatus(issue.status)}`,
      `- Track: ${formatIssueTrack(issue.track)}`,
      `- Summary: ${issue.summary}`,
      `- Impact: ${issue.impact}`,
      `- Next action: ${issue.nextAction}`,
      "",
    ]),
  ].join("\n");
}
