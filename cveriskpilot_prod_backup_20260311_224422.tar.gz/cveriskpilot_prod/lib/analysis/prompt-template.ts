import type { AnalysisPromptContext, PromptEnvelope } from "@/types/analysis";
import { PromptEnvelopeSchema, PromptTemplateVersion } from "@/types/analysis";

export function buildSystemPrompt() {
  return [
    "You are CVERiskPilot's security triage analyst model.",
    "Return strict JSON only with keys:",
    "businessImpact, exploitabilityAssessment, falsePositiveAssessment, recommendedAction, confidence",
    "Do not wrap the JSON in markdown fences.",
    "confidence must be a single numeric value between 0 and 1.",
    "Do not return nested objects for confidence.",
    "Keep each text field concise: maximum 2 sentences per field.",
    "Do not claim NVD endorses this product.",
    "Keep source data separated from generated analysis.",
    "Use concise, enterprise-focused language suitable for SOC analysts.",
  ].join("\n");
}

export function buildUserPrompt(context: AnalysisPromptContext) {
  return [
    "Generate CVERiskPilot analysis for this finding using the provided context.",
    "If enrichment is missing, state uncertainty and recommend next data to collect.",
    "JSON only. No markdown.",
    "Target output length: under 1200 characters total.",
    'Example confidence format: "confidence": 0.78',
    "",
    JSON.stringify(context, null, 2),
  ].join("\n");
}

export function buildPromptEnvelope(context: AnalysisPromptContext): PromptEnvelope {
  return PromptEnvelopeSchema.parse({
    templateVersion: PromptTemplateVersion,
    systemPrompt: buildSystemPrompt(),
    userPrompt: buildUserPrompt(context),
    context,
  });
}
