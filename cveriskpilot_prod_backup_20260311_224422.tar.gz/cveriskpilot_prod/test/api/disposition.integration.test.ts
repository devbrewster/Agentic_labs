import { describe, expect, it } from "vitest";

import { GET as getDisposition, PATCH as patchDisposition } from "@/app/api/findings/[id]/disposition/route";
import { GET as getFindings } from "@/app/api/findings/route";
import { POST as reparseUpload } from "@/app/api/uploads/[id]/reparse/route";
import { POST as createUpload } from "@/app/api/uploads/route";
import { createAuthenticatedTestContext, withAuthHeaders } from "@/test/helpers/auth";
import { successfulCsvFixture } from "@/test/fixtures/generic-csv";

async function createParsedUploadAndGetFindingId(authHeaders: HeadersInit) {
  const formData = new FormData();
  formData.set(
    "file",
    new File([successfulCsvFixture], `disposition-${crypto.randomUUID()}.csv`, {
      type: "text/csv",
    }),
  );
  formData.set("selectedSourceType", "generic_csv");

  const uploadResponse = await createUpload(
    new Request("http://localhost/api/uploads", {
      method: "POST",
      headers: withAuthHeaders(authHeaders),
      body: formData,
    }),
  );
  const uploadJson = await uploadResponse.json();
  const uploadJobId = uploadJson.data.uploadJob.id as string;

  await reparseUpload(
    new Request(`http://localhost/api/uploads/${uploadJobId}/reparse`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(authHeaders).entries()),
        },
        body: JSON.stringify({ force: true }),
    }),
    {
      params: Promise.resolve({ id: uploadJobId }),
    },
  );

  const findingsResponse = await getFindings(
    new Request("http://localhost/api/findings", {
      headers: withAuthHeaders(authHeaders),
    }),
  );
  const findingsJson = await findingsResponse.json();
  const findingId = (findingsJson.data.findings as Array<{ id: string }>)[0]?.id;

  if (!findingId) {
    throw new Error("Expected ingested findings for disposition tests.");
  }

  return findingId;
}

describe("analyst disposition routes", () => {
  it("persists and returns disposition history for a finding", async () => {
    const auth = await createAuthenticatedTestContext("disposition-history");
    const findingId = await createParsedUploadAndGetFindingId(auth.headers);

    const patchResponse = await patchDisposition(
      new Request(`http://localhost/api/findings/${findingId}/disposition`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({
          decision: "accepted_risk",
          rationale: "Validated compensating controls in production edge path.",
          notes: "Business owner approved temporary exception.",
          factors: {
            internetExposed: true,
            internalOnly: false,
            segmentedNetwork: true,
            compensatingControlPresent: true,
            assetCriticality: "high",
            authRequired: true,
            reachableFromAttackerPath: true,
          },
          updatedBy: "integration-test",
        }),
      }),
      {
        params: Promise.resolve({ id: findingId }),
      },
    );
    const patchJson = await patchResponse.json();

    expect(patchResponse.status).toBe(200);
    expect(patchJson.data.disposition.decision).toBe("accepted_risk");
    expect(patchJson.data.history.length).toBe(1);

    const getResponse = await getDisposition(
      new Request(`http://localhost/api/findings/${findingId}/disposition`, {
        method: "GET",
        headers: withAuthHeaders(auth.headers),
      }),
      {
        params: Promise.resolve({ id: findingId }),
      },
    );
    const getJson = await getResponse.json();

    expect(getResponse.status).toBe(200);
    expect(getJson.data.disposition.findingId).toBe(findingId);
    expect(getJson.data.disposition.updatedBy).toBe("integration-test");
    expect(getJson.data.history.length).toBe(1);
  });

  it("includes persisted disposition fields in /api/findings payload", async () => {
    const auth = await createAuthenticatedTestContext("disposition-payload");
    const findingId = await createParsedUploadAndGetFindingId(auth.headers);

    await patchDisposition(
      new Request(`http://localhost/api/findings/${findingId}/disposition`, {
        method: "PATCH",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({
          decision: "mitigated",
          rationale: "Hotfix applied and validated through rescans.",
          notes: null,
          factors: {
            internetExposed: false,
            internalOnly: true,
            segmentedNetwork: true,
            compensatingControlPresent: true,
            assetCriticality: "medium",
            authRequired: true,
            reachableFromAttackerPath: false,
          },
          updatedBy: "integration-test",
        }),
      }),
      {
        params: Promise.resolve({ id: findingId }),
      },
    );

    const findingsResponse = await getFindings(
      new Request("http://localhost/api/findings", {
        headers: withAuthHeaders(auth.headers),
      }),
    );
    const findingsJson = await findingsResponse.json();
    const updatedFinding = (
      findingsJson.data.findings as Array<{
        id: string;
        analystDisposition?: string;
        analystRationale?: string;
        decisionRationale?: string;
        riskScore?: number;
        status?: string;
        prioritization?: {
          baseRiskScore: number;
          adjustedRiskScore: number;
          totalAdjustment: number;
          reasons: string[];
        };
      }>
    ).find((finding) => finding.id === findingId);

    expect(updatedFinding).toBeTruthy();
    expect(updatedFinding?.analystDisposition).toBe("mitigated");
    expect(updatedFinding?.analystRationale).toBe(
      "Hotfix applied and validated through rescans.",
    );
    expect(updatedFinding?.decisionRationale).toBe(
      "Hotfix applied and validated through rescans.",
    );
    expect(updatedFinding?.status).toBe("mitigated");
    expect(updatedFinding?.prioritization?.adjustedRiskScore).toBe(updatedFinding?.riskScore);
    expect(updatedFinding?.prioritization?.adjustedRiskScore).toBeLessThan(
      updatedFinding?.prioritization?.baseRiskScore ?? 101,
    );
    expect(updatedFinding?.prioritization?.reasons.length).toBeGreaterThan(0);
  });
});
