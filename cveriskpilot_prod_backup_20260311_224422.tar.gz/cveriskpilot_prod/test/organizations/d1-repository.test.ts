import { describe, expect, it } from "vitest";

import { D1OrganizationRepository } from "@/lib/organizations/d1-repository";

type MembershipRow = {
  organization_id: string;
  organization_name: string;
  organization_slug: string;
  organization_status: string;
  organization_created_at: string;
  organization_updated_at: string;
  member_id: string;
  user_id: string;
  role: string;
  joined_at: string;
  invited_by_user_id: string | null;
};

class FakeD1PreparedStatement {
  private params: unknown[] = [];

  constructor(
    private readonly sql: string,
    private readonly memberships: MembershipRow[],
  ) {}

  bind(...params: unknown[]) {
    this.params = params;
    return this;
  }

  async first<T>() {
    if (!this.sql.includes("FROM organizations")) {
      throw new Error(`Unsupported SQL in fake D1 first: ${this.sql}`);
    }

    const [organizationId] = this.params as [string];
    const membership = this.memberships.find((row) => row.organization_id === organizationId);

    if (!membership) {
      return null;
    }

    return {
      id: membership.organization_id,
      name: membership.organization_name,
      slug: membership.organization_slug,
      status: membership.organization_status,
      created_at: membership.organization_created_at,
      updated_at: membership.organization_updated_at,
    } as T;
  }

  async all<T>() {
    if (!this.sql.includes("FROM organization_members")) {
      throw new Error(`Unsupported SQL in fake D1 all: ${this.sql}`);
    }

    const [userId] = this.params as [string];

    return {
      results: this.memberships.filter((row) => row.user_id === userId) as T[],
    };
  }
}

class FakeD1Database {
  constructor(private readonly memberships: MembershipRow[]) {}

  prepare(sql: string) {
    return new FakeD1PreparedStatement(sql, this.memberships);
  }
}

describe("D1OrganizationRepository", () => {
  it("returns memberships for a user with organization context", async () => {
    const organizationId = crypto.randomUUID();
    const userId = crypto.randomUUID();
    const now = new Date().toISOString();

    const repository = new D1OrganizationRepository(
      new FakeD1Database([
        {
          organization_id: organizationId,
          organization_name: "Acme Security",
          organization_slug: "acme-security",
          organization_status: "active",
          organization_created_at: now,
          organization_updated_at: now,
          member_id: crypto.randomUUID(),
          user_id: userId,
          role: "owner",
          joined_at: now,
          invited_by_user_id: null,
        },
      ]) as never,
    );

    const context = await repository.getCurrentContextForUser(userId);

    expect(context.organizationId).toBe(organizationId);
    expect(context.memberships).toHaveLength(1);
    expect(context.memberships[0]?.organization.name).toBe("Acme Security");
    expect(context.memberships[0]?.member.role).toBe("owner");
  });
});
