import bcrypt from "bcryptjs";

const PASSWORD_MIN_LENGTH = 8;
const PASSWORD_SALT_ROUNDS = 12;

export function isStrongEnoughPassword(password: string) {
  return password.length >= PASSWORD_MIN_LENGTH;
}

export function getPasswordMinLength() {
  return PASSWORD_MIN_LENGTH;
}

export async function hashPassword(password: string) {
  return bcrypt.hash(password, PASSWORD_SALT_ROUNDS);
}

export async function verifyPassword(password: string, hash: string) {
  return bcrypt.compare(password, hash);
}
