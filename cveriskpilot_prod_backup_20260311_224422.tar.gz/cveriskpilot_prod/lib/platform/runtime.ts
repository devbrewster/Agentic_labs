import type { AppPlatformProfile, ArtifactStorageDriver, DatabaseDriver, RuntimePlatform } from "@/types/platform";

function detectRuntimePlatform(): RuntimePlatform {
  if (process.env.AWS_EXECUTION_ENV || process.env.ECS_CONTAINER_METADATA_URI_V4) {
    return "aws";
  }

  if (process.env.CF_PAGES || process.env.WORKERS_CI || process.env.CLOUDFLARE_ACCOUNT_ID) {
    return "cloudflare";
  }

  return "local";
}

function detectDatabaseDriver(runtimePlatform: RuntimePlatform): DatabaseDriver {
  if (process.env.DATABASE_URL) {
    return "postgres";
  }

  if (runtimePlatform === "cloudflare") {
    return "cloudflare_d1";
  }

  return "in_memory";
}

function detectArtifactStorageDriver(runtimePlatform: RuntimePlatform): ArtifactStorageDriver {
  const configured = process.env.UPLOAD_STORAGE_DRIVER;

  if (configured === "s3" || configured === "d1" || configured === "local_fs") {
    return configured;
  }

  if (process.env.UPLOAD_S3_BUCKET) {
    return "s3";
  }

  if (runtimePlatform === "cloudflare") {
    return "d1";
  }

  return "local_fs";
}

export function getPlatformProfile(): AppPlatformProfile {
  const runtimePlatform = detectRuntimePlatform();

  return {
    runtimePlatform,
    databaseDriver: detectDatabaseDriver(runtimePlatform),
    artifactStorageDriver: detectArtifactStorageDriver(runtimePlatform),
    appBaseUrl: process.env.APP_BASE_URL ?? null,
    organizationIsolationRequired: true,
  };
}
