CREATE TABLE IF NOT EXISTS organizations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  email_verified BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS organization_members (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role TEXT NOT NULL,
  joined_at TIMESTAMPTZ NOT NULL,
  invited_by_user_id TEXT
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  user_agent TEXT,
  ip_address TEXT,
  revoked_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS session_organization_context (
  session_id TEXT PRIMARY KEY REFERENCES sessions(id) ON DELETE CASCADE,
  active_organization_id TEXT REFERENCES organizations(id) ON DELETE SET NULL,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS email_verification_tokens (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  email TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  used_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS billing_customers (
  organization_id TEXT PRIMARY KEY REFERENCES organizations(id) ON DELETE CASCADE,
  stripe_customer_id TEXT NOT NULL UNIQUE,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS subscriptions (
  organization_id TEXT PRIMARY KEY REFERENCES organizations(id) ON DELETE CASCADE,
  stripe_subscription_id TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL,
  price_id TEXT NOT NULL,
  current_period_start TIMESTAMPTZ,
  current_period_end TIMESTAMPTZ,
  cancel_at_period_end BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS usage_counters (
  organization_id TEXT NOT NULL REFERENCES organizations(id) ON DELETE CASCADE,
  period_start TIMESTAMPTZ NOT NULL,
  period_end TIMESTAMPTZ NOT NULL,
  uploads_used INTEGER NOT NULL DEFAULT 0,
  analyses_used INTEGER NOT NULL DEFAULT 0,
  cve_lookups_used INTEGER NOT NULL DEFAULT 0,
  exports_used INTEGER NOT NULL DEFAULT 0,
  updated_at TIMESTAMPTZ NOT NULL,
  PRIMARY KEY (organization_id, period_start, period_end)
);

CREATE TABLE IF NOT EXISTS raw_artifacts (
  id TEXT PRIMARY KEY,
  tenant_id TEXT,
  storage_key TEXT NOT NULL UNIQUE,
  original_filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  file_type TEXT NOT NULL,
  size_bytes BIGINT NOT NULL,
  checksum_sha256 TEXT NOT NULL,
  uploaded_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS raw_artifact_contents (
  storage_key TEXT PRIMARY KEY,
  checksum_sha256 TEXT NOT NULL,
  body_text TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS upload_jobs (
  id TEXT PRIMARY KEY,
  tenant_id TEXT,
  raw_artifact_id TEXT NOT NULL REFERENCES raw_artifacts(id) ON DELETE CASCADE,
  selected_source_type TEXT,
  detected_source_type TEXT,
  status TEXT NOT NULL,
  error_summary TEXT,
  warning_count INTEGER NOT NULL DEFAULT 0,
  finding_count INTEGER NOT NULL DEFAULT 0,
  checksum_sha256 TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  parsed_at TIMESTAMPTZ
);

CREATE TABLE IF NOT EXISTS parse_outcomes (
  upload_job_id TEXT PRIMARY KEY REFERENCES upload_jobs(id) ON DELETE CASCADE,
  metadata_json JSONB,
  warnings_json JSONB NOT NULL,
  errors_json JSONB NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS normalized_findings (
  id TEXT PRIMARY KEY,
  upload_job_id TEXT NOT NULL REFERENCES upload_jobs(id) ON DELETE CASCADE,
  raw_record_ref_json JSONB NOT NULL,
  asset_identifier TEXT,
  hostname TEXT,
  fqdn TEXT,
  ip_address TEXT,
  port INTEGER,
  protocol TEXT,
  vulnerability_id TEXT,
  plugin_id TEXT,
  cve_ids_json JSONB NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  severity TEXT,
  normalized_severity TEXT NOT NULL,
  cvss_score DOUBLE PRECISION,
  cvss_vector TEXT,
  remediation TEXT,
  evidence TEXT,
  status TEXT,
  privilege_required TEXT,
  detected_at TIMESTAMPTZ,
  first_observed_at TIMESTAMPTZ,
  last_observed_at TIMESTAMPTZ,
  source_type TEXT NOT NULL,
  source_scanner TEXT NOT NULL,
  tags_json JSONB NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS enrichment_runs (
  id TEXT PRIMARY KEY,
  upload_job_id TEXT REFERENCES upload_jobs(id) ON DELETE SET NULL,
  triggered_by TEXT NOT NULL,
  status TEXT NOT NULL,
  provider_count INTEGER NOT NULL DEFAULT 0,
  success_count INTEGER NOT NULL DEFAULT 0,
  error_count INTEGER NOT NULL DEFAULT 0,
  error_summary TEXT,
  started_at TIMESTAMPTZ,
  completed_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS finding_enrichment_snapshots (
  id TEXT PRIMARY KEY,
  enrichment_run_id TEXT NOT NULL REFERENCES enrichment_runs(id) ON DELETE CASCADE,
  finding_id TEXT NOT NULL REFERENCES normalized_findings(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  status TEXT NOT NULL,
  source_url TEXT,
  source_version TEXT,
  observed_at TIMESTAMPTZ,
  error_code TEXT,
  error_message TEXT,
  summary_json JSONB,
  raw_payload_json JSONB,
  created_at TIMESTAMPTZ NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS analyst_dispositions (
  finding_id TEXT PRIMARY KEY REFERENCES normalized_findings(id) ON DELETE CASCADE,
  decision TEXT NOT NULL,
  rationale TEXT NOT NULL,
  notes TEXT,
  factors_json JSONB NOT NULL,
  updated_by TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS analyst_disposition_events (
  id TEXT PRIMARY KEY,
  finding_id TEXT NOT NULL REFERENCES normalized_findings(id) ON DELETE CASCADE,
  decision TEXT NOT NULL,
  rationale TEXT NOT NULL,
  notes TEXT,
  factors_json JSONB NOT NULL,
  updated_by TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL
);

CREATE TABLE IF NOT EXISTS analysis_runs (
  id TEXT PRIMARY KEY,
  finding_id TEXT NOT NULL REFERENCES normalized_findings(id) ON DELETE CASCADE,
  source TEXT NOT NULL,
  requested_mode TEXT NOT NULL,
  provider TEXT NOT NULL,
  model TEXT NOT NULL,
  template_version TEXT NOT NULL,
  trace_status TEXT NOT NULL,
  fallback_reason TEXT,
  warning_count INTEGER NOT NULL DEFAULT 0,
  generated_at TIMESTAMPTZ NOT NULL,
  created_at TIMESTAMPTZ NOT NULL,
  prompt_context_json JSONB NOT NULL,
  prompt_envelope_json JSONB NOT NULL,
  output_json JSONB NOT NULL,
  warnings_json JSONB NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_organizations_slug ON organizations(slug);
CREATE INDEX IF NOT EXISTS idx_organizations_status ON organizations(status);
CREATE INDEX IF NOT EXISTS idx_organization_members_user_id ON organization_members(user_id);
CREATE INDEX IF NOT EXISTS idx_organization_members_organization_id ON organization_members(organization_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_organization_members_org_user
  ON organization_members(organization_id, user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_sessions_revoked_at ON sessions(revoked_at);
CREATE INDEX IF NOT EXISTS idx_session_organization_context_active_org
  ON session_organization_context(active_organization_id);
CREATE INDEX IF NOT EXISTS idx_email_verification_tokens_user_id
  ON email_verification_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_email_verification_tokens_expires_at
  ON email_verification_tokens(expires_at);
CREATE INDEX IF NOT EXISTS idx_billing_customers_stripe_customer_id
  ON billing_customers(stripe_customer_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status
  ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_subscriptions_current_period_end
  ON subscriptions(current_period_end);
CREATE INDEX IF NOT EXISTS idx_usage_counters_period_start
  ON usage_counters(period_start);
CREATE INDEX IF NOT EXISTS idx_raw_artifacts_checksum_sha256
  ON raw_artifacts(checksum_sha256);
CREATE INDEX IF NOT EXISTS idx_raw_artifacts_uploaded_at
  ON raw_artifacts(uploaded_at);
CREATE INDEX IF NOT EXISTS idx_raw_artifact_contents_checksum_sha256
  ON raw_artifact_contents(checksum_sha256);
CREATE INDEX IF NOT EXISTS idx_upload_jobs_checksum_sha256
  ON upload_jobs(checksum_sha256);
CREATE INDEX IF NOT EXISTS idx_upload_jobs_status
  ON upload_jobs(status);
CREATE INDEX IF NOT EXISTS idx_upload_jobs_raw_artifact_id
  ON upload_jobs(raw_artifact_id);
CREATE INDEX IF NOT EXISTS idx_upload_jobs_created_at
  ON upload_jobs(created_at);
CREATE INDEX IF NOT EXISTS idx_normalized_findings_upload_job_id
  ON normalized_findings(upload_job_id);
CREATE INDEX IF NOT EXISTS idx_normalized_findings_normalized_severity
  ON normalized_findings(normalized_severity);
CREATE INDEX IF NOT EXISTS idx_normalized_findings_title
  ON normalized_findings(title);
CREATE INDEX IF NOT EXISTS idx_normalized_findings_hostname
  ON normalized_findings(hostname);
CREATE INDEX IF NOT EXISTS idx_enrichment_runs_upload_job_id
  ON enrichment_runs(upload_job_id);
CREATE INDEX IF NOT EXISTS idx_finding_enrichment_snapshots_run_id
  ON finding_enrichment_snapshots(enrichment_run_id);
CREATE INDEX IF NOT EXISTS idx_finding_enrichment_snapshots_finding_id
  ON finding_enrichment_snapshots(finding_id);
CREATE INDEX IF NOT EXISTS idx_analyst_disposition_events_finding_id
  ON analyst_disposition_events(finding_id);
CREATE INDEX IF NOT EXISTS idx_analysis_runs_finding_id
  ON analysis_runs(finding_id);
