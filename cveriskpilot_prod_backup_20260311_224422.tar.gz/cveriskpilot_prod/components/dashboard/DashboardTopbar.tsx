"use client";

import { usePathname } from "next/navigation";

import { getDashboardRouteKeyFromPathname } from "@/lib/app-routes";

type DashboardTopbarProps = {
  title: string;
  subtitle: string;
};

export function DashboardTopbar({
  title,
  subtitle,
}: DashboardTopbarProps) {
  const pathname = usePathname();
  const routeKey = pathname ? getDashboardRouteKeyFromPathname(pathname) : null;

  return (
    <header className="border-b border-[rgba(0,200,180,0.12)] bg-[rgba(4,8,16,0.8)] px-6 backdrop-blur">
      <div className="flex min-h-[52px] items-center gap-4">
        <div>
          <div className="text-[1rem] font-bold tracking-tight text-white">
            {title}
          </div>
          <div className="font-mono text-[0.7rem] leading-5 text-[#5a7080]">
            {subtitle}
          </div>
        </div>

        {routeKey ? <div className="ml-auto" /> : null}
      </div>
    </header>
  );
}
