"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";

import { getDashboardRouteAliases, getDashboardRouteKeyFromPathname } from "@/lib/app-routes";
import { listDashboardNavItems } from "@/lib/services/dashboard";

const sectionLabels = {
  workspace: "Workspace",
  reporting: "Reporting",
  platform: "Platform",
} as const;

export function DashboardSidebar() {
  const pathname = usePathname();
  const dashboardNavItems = listDashboardNavItems();
  const activeRouteKey = getDashboardRouteKeyFromPathname(pathname);

  return (
    <aside className="dashboard-sidebar hidden border-r border-[rgba(0,200,180,0.12)] bg-[var(--bg-elevated)] xl:flex xl:w-[220px] xl:flex-col">
      <div className="border-b border-[rgba(0,200,180,0.06)] px-5 py-5">
        <Link href="/" className="block text-base font-extrabold tracking-tight text-white">
          CVE<span className="text-[var(--accent)]">Risk</span>Pilot
        </Link>
        <p className="mt-1 font-mono text-[0.58rem] uppercase tracking-[0.18em] text-[#5a7080]">
          // Triage Console v1.0
        </p>
      </div>

      <div className="flex-1 overflow-y-auto px-3 py-4">
        {(["workspace", "reporting", "platform"] as const).map((section) => (
          <div key={section} className="mb-6">
            <div className="mb-2 px-2 font-mono text-[0.58rem] uppercase tracking-[0.2em] text-[#3a5060]">
              {sectionLabels[section]}
            </div>

            <nav className="space-y-0.5">
              {dashboardNavItems
                .filter((item) => item.section === section)
                .map((item) => {
                  const aliases = getDashboardRouteAliases(item.routeKey);
                  const isActive =
                    activeRouteKey === item.routeKey ||
                    aliases.some((alias) => alias !== "/" && pathname.startsWith(`${alias}/`));

                  return (
                    <Link
                      key={item.routeKey}
                      href={item.href}
                      prefetch={false}
                      className={`flex items-center gap-2.5 rounded border px-3 py-2.5 font-mono text-[0.72rem] tracking-[0.05em] transition ${
                        isActive
                          ? "border-[rgba(0,200,180,0.12)] bg-[rgba(0,200,180,0.15)] text-[var(--accent)]"
                          : "border border-transparent text-[#5a7080] hover:border-[rgba(0,200,180,0.12)] hover:bg-[rgba(0,200,180,0.08)] hover:text-[var(--accent)]"
                      }`}
                    >
                      <span className="w-4 text-center text-[0.82rem]">{item.icon}</span>
                      <span className="flex-1">{item.label}</span>
                      {item.badge ? (
                        <span
                          className={`rounded-full px-1.5 py-0.5 text-[0.58rem] ${
                            item.label === "Action Plans"
                              ? "bg-[var(--warning)] text-[#040810]"
                              : "bg-[var(--danger)] text-white"
                          }`}
                        >
                          {item.badge}
                        </span>
                      ) : null}
                    </Link>
                  );
                })}
            </nav>
          </div>
        ))}
      </div>

      <div className="mt-auto border-t border-[rgba(0,200,180,0.06)] px-3 py-4">
        <div className="flex items-center gap-2 rounded px-2 py-2">
          <div className="flex h-7 w-7 items-center justify-center rounded-full border border-[var(--accent)] bg-[rgba(0,200,180,0.12)] font-mono text-[0.62rem] text-[var(--accent)]">
            SG
          </div>
          <div>
            <div className="font-mono text-[0.68rem] text-[#5a7080]">
              sec-analyst
            </div>
            <div className="font-mono text-[0.58rem] text-[#3a5060]">Admin</div>
          </div>
        </div>
      </div>
    </aside>
  );
}
