import { z } from "zod";

export const uploadStatusValues = [
  "queued",
  "parsing",
  "parsed",
  "enrichment_pending",
  "failed",
] as const;

export const scannerSourceTypeValues = [
  "nessus",
  "qualys",
  "rapid7",
  "generic_csv",
  "unknown",
] as const;

export const artifactFileTypeValues = ["json", "csv", "xml", "unknown"] as const;

export const parserMessageLevelValues = ["info", "warning", "error"] as const;

export const normalizedSeverityValues = [
  "critical",
  "high",
  "medium",
  "low",
  "informational",
  "unknown",
] as const;

export const privilegeRequiredValues = ["none", "low", "high", "unknown"] as const;

export const findingStatusValues = [
  "open",
  "triaged",
  "in_progress",
  "resolved",
  "accepted_risk",
  "false_positive",
  "not_applicable",
] as const;

export const UploadStatusSchema = z.enum(uploadStatusValues);
export type UploadStatus = z.infer<typeof UploadStatusSchema>;

export const ScannerSourceTypeSchema = z.enum(scannerSourceTypeValues);
export type ScannerSourceType = z.infer<typeof ScannerSourceTypeSchema>;

export const ArtifactFileTypeSchema = z.enum(artifactFileTypeValues);
export type ArtifactFileType = z.infer<typeof ArtifactFileTypeSchema>;

export const ParserMessageLevelSchema = z.enum(parserMessageLevelValues);
export type ParserMessageLevel = z.infer<typeof ParserMessageLevelSchema>;

export const NormalizedSeveritySchema = z.enum(normalizedSeverityValues);
export type NormalizedSeverity = z.infer<typeof NormalizedSeveritySchema>;

export const PrivilegeRequiredSchema = z.enum(privilegeRequiredValues);
export type PrivilegeRequired = z.infer<typeof PrivilegeRequiredSchema>;

export const FindingStatusSchema = z.enum(findingStatusValues);
export type FindingStatus = z.infer<typeof FindingStatusSchema>;

export const TimestampSchema = z.iso.datetime();
export type Timestamp = z.infer<typeof TimestampSchema>;

export const ChecksumSha256Schema = z
  .string()
  .regex(/^[a-f0-9]{64}$/i, "Expected a SHA-256 checksum.");
export type ChecksumSha256 = z.infer<typeof ChecksumSha256Schema>;

export const TenantIdSchema = z.string().min(1).max(128).nullable();
export type TenantId = z.infer<typeof TenantIdSchema>;
export const OrganizationIdSchema = TenantIdSchema;
export type OrganizationId = TenantId;

export const RawArtifactSchema = z.object({
  id: z.string().uuid(),
  storageKey: z.string().min(1),
  originalFilename: z.string().min(1),
  mimeType: z.string().min(1),
  fileType: ArtifactFileTypeSchema,
  sizeBytes: z.number().int().nonnegative(),
  checksumSha256: ChecksumSha256Schema,
  uploadedAt: TimestampSchema,
});
export type RawArtifact = z.infer<typeof RawArtifactSchema>;

export const UploadJobSchema = z.object({
  id: z.string().uuid(),
  tenantId: TenantIdSchema,
  rawArtifactId: z.string().uuid(),
  selectedSourceType: ScannerSourceTypeSchema.nullable(),
  detectedSourceType: ScannerSourceTypeSchema.nullable(),
  status: UploadStatusSchema,
  errorSummary: z.string().max(1000).nullable(),
  warningCount: z.number().int().nonnegative(),
  findingCount: z.number().int().nonnegative(),
  checksumSha256: ChecksumSha256Schema,
  createdAt: TimestampSchema,
  updatedAt: TimestampSchema,
  parsedAt: TimestampSchema.nullable(),
});
export type UploadJob = z.infer<typeof UploadJobSchema>;

export const ParseMetadataSchema = z.object({
  scannerName: z.string().min(1),
  scannerVersion: z.string().min(1).nullable(),
  sourceType: ScannerSourceTypeSchema,
  fileType: ArtifactFileTypeSchema,
  hostCount: z.number().int().nonnegative(),
  findingCount: z.number().int().nonnegative(),
  parsedAt: TimestampSchema,
  checksumSha256: ChecksumSha256Schema,
});
export type ParseMetadata = z.infer<typeof ParseMetadataSchema>;

export const ParserWarningSchema = z.object({
  code: z.string().min(1),
  message: z.string().min(1),
  field: z.string().min(1).nullable(),
  row: z.number().int().positive().nullable(),
  level: ParserMessageLevelSchema,
});
export type ParserWarning = z.infer<typeof ParserWarningSchema>;

export const ParserErrorSchema = z.object({
  code: z.string().min(1),
  message: z.string().min(1),
  details: z.record(z.string(), z.unknown()).nullable(),
  fatal: z.boolean(),
});
export type ParserError = z.infer<typeof ParserErrorSchema>;

export const RawRecordReferenceSchema = z.object({
  recordId: z.string().min(1),
  recordIndex: z.number().int().nonnegative().nullable(),
  locationHint: z.string().min(1).nullable(),
  sourceChecksumSha256: ChecksumSha256Schema,
});
export type RawRecordReference = z.infer<typeof RawRecordReferenceSchema>;

export const NormalizedFindingSchema = z.object({
  id: z.string().uuid(),
  uploadJobId: z.string().uuid(),
  rawRecordRef: RawRecordReferenceSchema,
  assetIdentifier: z.string().min(1).nullable(),
  hostname: z.string().min(1).nullable(),
  fqdn: z.string().min(1).nullable(),
  ipAddress: z.ipv4().or(z.ipv6()).nullable(),
  port: z.number().int().min(0).max(65535).nullable(),
  protocol: z.string().min(1).nullable(),
  vulnerabilityId: z.string().min(1).nullable(),
  pluginId: z.string().min(1).nullable(),
  cveIds: z.array(z.string().min(1)).default([]),
  title: z.string().min(1),
  description: z.string().min(1).nullable(),
  severity: z.string().min(1).nullable(),
  normalizedSeverity: NormalizedSeveritySchema,
  cvssScore: z.number().min(0).max(10).nullable(),
  cvssVector: z.string().min(1).nullable(),
  remediation: z.string().min(1).nullable(),
  evidence: z.string().min(1).nullable(),
  status: FindingStatusSchema.nullable(),
  privilegeRequired: PrivilegeRequiredSchema.nullable(),
  detectedAt: TimestampSchema.nullable(),
  firstObservedAt: TimestampSchema.nullable(),
  lastObservedAt: TimestampSchema.nullable(),
  sourceType: ScannerSourceTypeSchema,
  sourceScanner: z.string().min(1),
  tags: z.array(z.string().min(1)).default([]),
  createdAt: TimestampSchema,
  updatedAt: TimestampSchema,
});
export type NormalizedFinding = z.infer<typeof NormalizedFindingSchema>;

export const ParseResultSchema = z.object({
  findings: z.array(NormalizedFindingSchema),
  parserWarnings: z.array(ParserWarningSchema),
  parserErrors: z.array(ParserErrorSchema),
  metadata: ParseMetadataSchema,
});
export type ParseResult = z.infer<typeof ParseResultSchema>;

export const StoredParseOutcomeSchema = z.object({
  uploadJobId: z.string().uuid(),
  findings: z.array(NormalizedFindingSchema),
  parserWarnings: z.array(ParserWarningSchema),
  parserErrors: z.array(ParserErrorSchema),
  metadata: ParseMetadataSchema.nullable(),
  updatedAt: TimestampSchema,
});
export type StoredParseOutcome = z.infer<typeof StoredParseOutcomeSchema>;

export const ParseContextSchema = z.object({
  uploadJob: UploadJobSchema,
  rawArtifact: RawArtifactSchema,
  selectedSourceType: ScannerSourceTypeSchema.nullable(),
  detectedSourceType: ScannerSourceTypeSchema.nullable(),
  checksumSha256: ChecksumSha256Schema,
  now: TimestampSchema,
});
export type ParseContext = z.infer<typeof ParseContextSchema>;

export const CreateUploadJobInputSchema = z.object({
  tenantId: TenantIdSchema.default(null),
  selectedSourceType: ScannerSourceTypeSchema.nullable().default(null),
  originalFilename: z.string().min(1),
  mimeType: z.string().min(1).nullable(),
  sizeBytes: z.number().int().positive(),
});
export type CreateUploadJobInput = z.infer<typeof CreateUploadJobInputSchema>;

export const UploadJobResponseSchema = z.object({
  uploadJob: UploadJobSchema,
  rawArtifact: RawArtifactSchema,
  deduplicated: z.boolean(),
  message: z.string().min(1),
});
export type UploadJobResponse = z.infer<typeof UploadJobResponseSchema>;

export const UploadJobDetailSchema = z.object({
  uploadJob: UploadJobSchema,
  rawArtifact: RawArtifactSchema,
  metadata: ParseMetadataSchema.nullable(),
  parserWarnings: z.array(ParserWarningSchema),
  parserErrors: z.array(ParserErrorSchema),
  findings: z.array(NormalizedFindingSchema),
});
export type UploadJobDetail = z.infer<typeof UploadJobDetailSchema>;

export const UploadFindingsResponseSchema = z.object({
  uploadJobId: z.string().uuid(),
  status: UploadStatusSchema,
  findingCount: z.number().int().nonnegative(),
  findings: z.array(NormalizedFindingSchema),
});
export type UploadFindingsResponse = z.infer<typeof UploadFindingsResponseSchema>;

export const UploadErrorsResponseSchema = z.object({
  uploadJobId: z.string().uuid(),
  status: UploadStatusSchema,
  warningCount: z.number().int().nonnegative(),
  errorCount: z.number().int().nonnegative(),
  parserWarnings: z.array(ParserWarningSchema),
  parserErrors: z.array(ParserErrorSchema),
});
export type UploadErrorsResponse = z.infer<typeof UploadErrorsResponseSchema>;

export const ParserDetectionHintSchema = z.object({
  filename: z.string().min(1),
  mimeType: z.string().min(1),
  fileType: ArtifactFileTypeSchema,
  leadingBytes: z.string().min(1).nullable(),
  sampleText: z.string().min(1).nullable(),
});
export type ParserDetectionHint = z.infer<typeof ParserDetectionHintSchema>;

export const ParserSelectionInputSchema = z.object({
  selectedSourceType: ScannerSourceTypeSchema.nullable(),
  detectionHint: ParserDetectionHintSchema,
});
export type ParserSelectionInput = z.infer<typeof ParserSelectionInputSchema>;

export type ScannerParser = {
  readonly sourceType: ScannerSourceType;
  readonly displayName: string;
  readonly supportedFileTypes: readonly ArtifactFileType[];
  canParse(input: ParserDetectionHint): boolean | Promise<boolean>;
  parse(input: {
    artifact: RawArtifact;
    content: string;
    context: ParseContext;
  }): Promise<ParseResult>;
};

export type ParserRegistry = {
  register(parser: ScannerParser): void;
  getBySourceType(sourceType: ScannerSourceType): ScannerParser | null;
  detectParser(input: ParserDetectionHint): Promise<ScannerParser | null>;
  listParsers(): readonly ScannerParser[];
  resolve(input: ParserSelectionInput): Promise<{
    parser: ScannerParser | null;
    error: ParserError | null;
  }>;
};

export const ParseJobRunOptionsSchema = z.object({
  force: z.boolean().default(false),
});
export type ParseJobRunOptions = z.infer<typeof ParseJobRunOptionsSchema>;

export const ParseJobRunResultSchema = z.object({
  uploadJob: UploadJobSchema,
  outcome: StoredParseOutcomeSchema.nullable(),
  skipped: z.boolean(),
  forced: z.boolean(),
  replacedExistingOutcome: z.boolean(),
  message: z.string().min(1),
});
export type ParseJobRunResult = z.infer<typeof ParseJobRunResultSchema>;

export const ReparseUploadRequestSchema = z.object({
  force: z.boolean().default(false),
});
export type ReparseUploadRequest = z.infer<typeof ReparseUploadRequestSchema>;
