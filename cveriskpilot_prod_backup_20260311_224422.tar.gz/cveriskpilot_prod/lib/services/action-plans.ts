import { actionPlanColumns, mockActionPlans } from "@/lib/mock/action-plans";
import type { ActionPlan } from "@/types/dashboard";

export function listActionPlans(): ActionPlan[] {
  return mockActionPlans;
}

export function listActionPlanColumns() {
  return actionPlanColumns;
}

export function getActionPlanById(actionPlanId: string): ActionPlan | null {
  return mockActionPlans.find((plan) => plan.id === actionPlanId) ?? null;
}

// TODO: Add Jira and ServiceNow sync orchestration when ticketing integrations are enabled.
