import { clearRuntimeCache, getOrSetRuntimeCache, invalidateRuntimeCachePrefix } from "@/lib/cache/runtime-cache";

const OVERVIEW_TTL_MS = 15_000;
const FINDINGS_TTL_MS = 15_000;
const EXECUTIVE_SUMMARY_TTL_MS = 30_000;

function orgPrefix(organizationId: string) {
  return `org:${organizationId}:`;
}

export function getCachedDashboardOverview<T>(
  organizationId: string,
  loader: () => Promise<T>,
) {
  return getOrSetRuntimeCache(
    `${orgPrefix(organizationId)}dashboard-overview`,
    OVERVIEW_TTL_MS,
    loader,
  );
}

export function getCachedFindings<T>(
  organizationId: string,
  loader: () => Promise<T>,
) {
  return getOrSetRuntimeCache(
    `${orgPrefix(organizationId)}findings`,
    FINDINGS_TTL_MS,
    loader,
  );
}

export function getCachedExecutiveSummary<T>(
  organizationId: string,
  loader: () => Promise<T>,
) {
  return getOrSetRuntimeCache(
    `${orgPrefix(organizationId)}executive-summary`,
    EXECUTIVE_SUMMARY_TTL_MS,
    loader,
  );
}

export function invalidateOrganizationWorkloadCache(organizationId: string) {
  invalidateRuntimeCachePrefix(orgPrefix(organizationId));
}

export function resetWorkloadCacheForTests() {
  clearRuntimeCache();
}
