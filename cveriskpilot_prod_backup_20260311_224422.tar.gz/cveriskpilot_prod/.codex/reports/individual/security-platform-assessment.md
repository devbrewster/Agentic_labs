## Architecture Current State
- Next.js API routes front a monolithic backend that defaults to Cloudflare D1 (or Postgres when `DATABASE_URL` is set) and silently falls back to in-memory repositories/caches whenever those bindings are missing, so runtime behavior changes by environment (`lib/platform/runtime.ts:20`, `lib/analysis/runtime.ts:15`, `lib/cache/runtime-cache.ts:6`).
- Multi-tenancy is modeled through `organizations`, `organization_members`, and a session-scoped `current_organization_id`, but authorization checks only confirm session presence without enforcing per-role logic (`database/schema.sql:3`, `lib/organizations/access.ts:4`).
- Upload ingestion stores raw artifacts on local disk/D1, creates `upload_jobs`, and expects operators to call the reparse endpoint to run parsers; there is no background worker wiring ingestion → parsing → enrichment (`lib/ingestion/storage.ts:46`, `lib/ingestion/storage.ts:90`, `app/api/uploads/[id]/reparse/route.ts:24`).
- AI analysis is a direct Claude API call with deterministic stub fallbacks, and trace persistence disappears whenever the database is unavailable (`lib/analysis/claude-client.ts:35`, `lib/analysis/service.ts:207`).
- Billing tables for customers/subscriptions/usage exist, yet entitlements are only surfaced in the billing snapshot response and are not enforced elsewhere in the codebase (`lib/billing/service.ts:50`).

## Security Gap Matrix
| Capability | Status | Evidence | Risk if Missing | Priority | Recommended Implementation |
| --- | --- | --- | --- | --- | --- |
| MFA/SSO & session hardening | Red | `app/api/auth/login/route.ts:13`, `lib/session.ts:17` | Password-only auth with 30-day cookies invites credential stuffing and long-lived hijacked sessions | P0 | Add MFA/SSO providers, brute-force throttling, shorter idle/session lifetimes, and device binding before production tenants onboard. |
| Tenant-scoped artifact storage | Red | `database/schema.sql:138`, `lib/ingestion/sql-repository.ts:299` | Raw artifacts are stored without an organization foreign key, so an attacker who acquires a storage key or query bug can read other tenants’ uploads | P0 | Stamp `tenant_id` on `raw_artifacts`, enforce tenant filters in repositories, and move bodies to S3/KMS with per-tenant prefixes and IAM policies. |
| Upload validation & malware handling | Red | `app/api/uploads/route.ts:45`, `lib/ingestion/storage.ts:46` | Files of any size/type are written verbatim to disk/database with no antivirus, leading to parser crashes or malicious payload retention | P0 | Enforce MIME/extension allow-lists, explicit size caps, checksum preflight, ClamAV/Lambda scanning, and quarantine & retention policies before parsing. |
| Automated ingestion & enrichment pipeline | Amber | `lib/uploads.ts:1`, `app/api/uploads/[id]/reparse/route.ts:24`, `app/api/enrichments/route.ts:16` | Operators must manually trigger parsing/enrichment, so uploads accumulate unprocessed and SLAs cannot be met | P1 | Stand up a queue/worker (e.g., Cloudflare Queues/SQS) that runs parsers and enrichment jobs asynchronously, with retries/idempotency. |
| AI safety & human-in-loop controls | Red | `lib/analysis/service.ts:207`, `app/api/findings/[id]/analysis/route.ts:123` | Model output is sent straight to users (or replaced with stub text) with no rate limits, provenance, or reviewer approval, risking hallucinated guidance | P0 | Introduce provider abstraction with per-tenant quotas, automated grounding/citation requirements, toxicity/hallucination checks, and mandatory analyst approval for publishing AI text. |
| CI/CD, monitoring, and health coverage | Red | `package.json:5`, `app/api/health/route.ts:1` | Only manual `npm run test/build` scripts exist, and the health endpoint does not verify DB/storage connectivity, so regressions reach prod undetected | P1 | Add CI workflows (lint, test, typecheck), runtime smoke tests, and deep health checks (DB, storage, queue, third-party APIs) feeding monitoring/alerting. |

## Architecture Gaps
- No background worker or job queue wires uploads to parsing and enrichment—the `enqueueUploadIngestion` helper is still a stub and ingestion relies on manual reparse calls (`lib/uploads.ts:1`, `app/api/uploads/[id]/reparse/route.ts:24`).
- Critical services silently downgrade to in-memory stores when platform bindings fail, meaning production instances can lose traces, enrichment state, or caches without alarms (`lib/analysis/runtime.ts:15`, `lib/cache/runtime-cache.ts:6`).
- User-facing data still depends on mock services (uploads, action plans, integrations) so real ingestion states intermix with placeholder content in APIs/UIs (`lib/services/uploads.ts:4`, `lib/services/action-plans.ts:4`, `app/api/findings/route.ts:124`).
- Configuration/secrets are read directly from environment variables with no secret rotation or validation layer (`lib/analysis/claude-client.ts:80`, `wrangler.jsonc:4`).

## Data Model Gaps
- The schema defines auth, billing, ingestion, enrichment, analyst, and AI trace tables but lacks entities for projects/apps, assets inventory, risk exceptions, audit logs, notifications, API keys, webhooks, SCIM identities, or tenant configuration (`database/schema.sql:3`).
- `raw_artifacts` does not capture `tenant_id` even though upload jobs do, preventing database-level enforcement of tenant isolation (`database/schema.sql:138`, `lib/ingestion/sql-repository.ts:299`).
- Usage/entitlement tracking exists but nothing increments the counters or gates product features, so quota enforcement is purely aspirational (`lib/billing/service.ts:131`).

## AI Readiness Gaps
- Model prompts/results are sent straight to Anthropic without redaction, context grounding, or cost tracking, and failures simply drop to canned text without alerting (`lib/analysis/service.ts:207`, `lib/analysis/claude-client.ts:35`).
- Trace persistence falls back to in-memory storage whenever the database is unavailable, erasing the evidence trail required for AI governance (`lib/analysis/runtime.ts:15`).
- The analysis API explicitly calls out missing rate limits and human approval as TODOs, demonstrating that safety checkpoints are not yet built (`app/api/findings/[id]/analysis/route.ts:123`).

## Operations Gaps
- The repository only exposes manual scripts (`npm run test`, `npm run build`) and ships no CI/CD automation, meaning linting, testing, and deployment reviews are not enforced (`package.json:5`).
- `/api/health` reports success without checking databases, storage, queues, or external APIs, so monitoring cannot detect dependency outages (`app/api/health/route.ts:1`).
- There is no instrumentation, logging policy, or alert routing for ingestion/enrichment/AI failures—errors fall back to mock data instead of paging operators (`app/api/findings/route.ts:124`, `lib/services/reports.ts:209`).

## Enterprise Gaps
- Authentication is limited to password + email verification; there is no SAML/OIDC SSO, SCIM provisioning, or MFA implementation despite enterprise readiness goals (`app/api/auth/login/route.ts:13`).
- No API key, webhook, or audit-export tables/handlers exist, so customers cannot integrate CVERiskPilot into existing platforms or download compliance evidence (`database/schema.sql:3`).
- Billing snapshots surface static entitlements but there is no support workflow, legal/compliance documents, or plan enforcement toggles within the product (`lib/billing/service.ts:131`).

## Top Platform Risks
1. **Tenant data leakage through artifact storage** – Upload bodies are written without tenant metadata, so any SQL bug or storage compromise crosses tenant boundaries (`database/schema.sql:138`, `lib/ingestion/sql-repository.ts:299`).
2. **Unsafe ingestion surface** – File uploads lack malware scanning, size/type limits, and automated parsing, leaving untrusted data at rest and delaying findings (`app/api/uploads/route.ts:45`, `lib/uploads.ts:1`).
3. **Uncontrolled AI output** – Analyst workflows consume unanalyzed Claude responses or stub text with no guardrails or review, risking incorrect remediation guidance and compliance exposure (`lib/analysis/service.ts:207`, `app/api/findings/[id]/analysis/route.ts:123`).
4. **Mock/fallback data masking production issues** – APIs silently return mock datasets when ingestion fails, hiding outages from both users and operators (`app/api/findings/route.ts:124`, `lib/services/reports.ts:209`).

## Recommendations to Orchestrator
- **Critical launch blockers**: (1) add tenant-aware artifact storage plus object-store encryption and malware scanning before accepting production uploads; (2) implement automated ingestion/enrichment workers with retries and observability; (3) ship MFA/SSO and AI review/approval so regulated customers can trust the platform.
- **Contradictions to validate with Agent 2**: (1) confirm whether any parallel effort is adding queue/worker infrastructure so we can align ingestion automation; (2) clarify if another agent owns enterprise identity (SSO/SCIM) to avoid duplicated work versus this repo’s password auth evidence (`app/api/auth/login/route.ts:13`).
- **Required implementation dependencies**: secure object storage (S3/KMS) and AV scanning service, managed queue/worker runtime (Cloudflare Queues, AWS SQS), identity provider integration (Okta/Azure AD), centralized secrets management, and monitoring/alerting stack to wire new health signals.
