import { afterEach, describe, expect, it, vi } from "vitest";

const getCveById = vi.fn();

vi.mock("@/lib/kev/client", () => ({
  KEV_CATALOG_URL: "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",
  getKevClient: () => ({
    getCveById,
  }),
}));

import { CisaKevEnrichmentProvider } from "@/lib/enrichment/providers/cisa-kev-provider";

describe("CisaKevEnrichmentProvider", () => {
  afterEach(() => {
    getCveById.mockReset();
    vi.unstubAllEnvs();
  });

  it("normalizes CISA date-only values to ISO datetime", async () => {
    vi.stubEnv("NODE_ENV", "development");

    getCveById.mockResolvedValue({
      ok: true,
      data: {
        cveId: "CVE-2024-3400",
        vendorProject: "Palo Alto",
        product: "PAN-OS",
        vulnerabilityName: "Command Injection",
        shortDescription: "Remote command execution vulnerability.",
        dateAdded: "2026-03-10",
        dueDate: "2026-03-17",
        requiredAction: "Apply vendor fixes.",
        knownRansomwareCampaignUse: "Known",
        notes: null,
      },
      meta: {
        source: "kev_live",
        fetchedAt: "2026-03-11T21:00:00.000Z",
        cacheHit: false,
        stale: false,
      },
      sourceVersion: "2026.03.11",
    });

    const provider = new CisaKevEnrichmentProvider();
    const result = await provider.enrichFinding(
      {
        findingId: "65cc6cb4-1fca-496b-9b31-61f64f6d56f4",
        cveIds: ["CVE-2024-3400"],
        title: "PAN-OS Command Injection",
        description: "test finding",
        normalizedSeverity: "critical",
        cvssScore: 10,
        sourceUpdatedAt: null,
      },
      {
        now: "2026-03-11T21:00:00.000Z",
      },
    );

    expect(result.status).toBe("enriched");
    expect(result.observedAt).toBe("2026-03-10T00:00:00.000Z");
    expect(result.payload?.kevListed).toBe(true);
  });
});
