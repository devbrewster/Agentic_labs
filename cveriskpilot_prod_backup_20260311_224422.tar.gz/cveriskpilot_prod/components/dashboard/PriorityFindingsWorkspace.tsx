"use client";

import { useEffect, useMemo, useState } from "react";

import { FindingDetailsPanel } from "@/components/dashboard/FindingDetailsPanel";
import { StatusPill } from "@/components/dashboard/StatusPill";
import {
  listFindingsFilterTabs,
  type FindingsFilterTab,
} from "@/lib/services/findings";
import type { Finding } from "@/types/dashboard";

type FindingsApiResponse = {
  ok: boolean;
  data?: {
    findings: Finding[];
    source: "ingestion";
    total: number;
  };
  error?: {
    code: string;
    message: string;
  };
};

const severityPillTone = {
  critical: "danger",
  high: "warning",
  medium: "accent",
  low: "default",
} as const;

const statusPillTone = {
  new: "danger",
  triaged: "accent",
  in_progress: "warning",
  accepted_risk: "default",
  mitigated: "accent",
  false_positive: "default",
  not_applicable: "default",
} as const;

const enrichmentStatusTone = {
  pending: "default",
  enriched: "accent",
  partial: "warning",
  failed: "danger",
  not_found: "default",
} as const;

function formatStatus(status: string) {
  return status.replaceAll("_", " ");
}

function formatEnrichmentStatus(status: NonNullable<Finding["enrichmentSummary"]>["status"]) {
  return status.replaceAll("_", " ");
}

function matchesFilter(tab: FindingsFilterTab, finding: Finding) {
  switch (tab) {
    case "Critical":
      return finding.severity === "critical";
    case "High":
      return finding.severity === "high";
    case "Medium":
      return finding.severity === "medium";
    case "Exploited":
      return finding.exploitAvailable;
    case "Unpatched":
      return finding.status !== "mitigated";
    default:
      return true;
  }
}

export function PriorityFindingsWorkspace() {
  const findingsFilterTabs = listFindingsFilterTabs();
  const [allFindings, setAllFindings] = useState<Finding[]>([]);
  const [sourceLabel, setSourceLabel] = useState("Loading real findings...");
  const [loadError, setLoadError] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<FindingsFilterTab>("Critical");
  const [query, setQuery] = useState("");
  const [selectedId, setSelectedId] = useState<string>("");

  useEffect(() => {
    let cancelled = false;

    async function loadFindings() {
      try {
        const response = await fetch("/api/findings", {
          cache: "no-store",
        });
        const payload = (await response.json()) as FindingsApiResponse;

        if (!response.ok || !payload.ok || !payload.data) {
          throw new Error(payload.error?.message ?? "Unable to load findings.");
        }

        if (cancelled) {
          return;
        }

        setAllFindings(payload.data.findings);
        setLoadError(null);
        setSourceLabel(
          payload.data.total > 0
            ? `Showing ${payload.data.total} ingested findings from parsed uploads.`
            : "No ingested findings are available yet.",
        );
      } catch (error) {
        if (!cancelled) {
          setAllFindings([]);
          setSourceLabel("Real findings are unavailable.");
          setLoadError(error instanceof Error ? error.message : "Unable to load findings.");
        }
      }
    }

    void loadFindings();

    return () => {
      cancelled = true;
    };
  }, []);

  const filteredFindings = useMemo(() => {
    const normalized = query.trim().toLowerCase();

    return allFindings.filter((finding) => {
      const filterMatch = matchesFilter(activeTab, finding);

      if (!filterMatch) {
        return false;
      }

      if (!normalized) {
        return true;
      }

      const searchable = [
        finding.cveId,
        finding.title,
        finding.assetName,
        finding.product,
      ]
        .join(" ")
        .toLowerCase();

      return searchable.includes(normalized);
    });
  }, [activeTab, allFindings, query]);

  useEffect(() => {
    setSelectedId((currentSelectedId) => {
      if (allFindings.some((finding) => finding.id === currentSelectedId)) {
        return currentSelectedId;
      }

      return allFindings[0]?.id ?? "";
    });
  }, [allFindings]);

  const selectedFinding =
    filteredFindings.find((finding) => finding.id === selectedId) ??
    filteredFindings[0] ??
    null;

  return (
    <section className="grid gap-5 xl:grid-cols-[minmax(0,1.55fr)_360px]">
      <div className="flex min-h-[420px] flex-col overflow-hidden rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] shadow-[0_18px_48px_rgba(0,0,0,0.22)]">
        <div className="flex items-center gap-3 border-b border-[rgba(0,200,180,0.06)] px-4 py-3">
          <div className="font-mono text-[0.75rem] uppercase tracking-[0.12em] text-[var(--accent)]">
            // Priority Findings
          </div>
          <div className="ml-auto font-mono text-[0.64rem] text-[#5a7080]">
            {sourceLabel}
          </div>
        </div>

        <div className="flex flex-col gap-3 border-b border-[rgba(0,200,180,0.06)] px-4 py-3 lg:flex-row lg:items-center">
          <div className="flex flex-wrap gap-2">
            {findingsFilterTabs.map((tab) => (
              <button
                key={tab}
                type="button"
                onClick={() => setActiveTab(tab)}
                className={`rounded border px-3 py-1.5 font-mono text-[0.64rem] uppercase tracking-[0.08em] transition ${
                  activeTab === tab
                    ? tab === "Critical"
                      ? "border-[rgba(255,77,109,0.3)] bg-[rgba(255,77,109,0.12)] text-[var(--danger)]"
                      : "border-[rgba(0,200,180,0.14)] bg-[rgba(0,200,180,0.12)] text-[var(--accent)]"
                    : "border-[rgba(0,200,180,0.06)] bg-transparent text-[#5a7080] hover:border-[rgba(0,200,180,0.12)] hover:text-[var(--text)]"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>

          <input
            type="search"
            value={query}
            onChange={(event) => setQuery(event.target.value)}
            placeholder="Search CVE, asset, title..."
            className="ml-auto w-full rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-1.5 font-mono text-[0.72rem] text-[var(--text)] outline-none placeholder:text-[#3a5060] focus:border-[var(--accent)] lg:w-[220px]"
          />
        </div>

        <div className="min-h-0 divide-y divide-[rgba(0,200,180,0.06)] overflow-y-auto">
          {filteredFindings.length === 0 ? (
            <div className="px-4 py-8 text-center">
              <div className="font-mono text-[0.68rem] uppercase tracking-[0.14em] text-[#5a7080]">
                {loadError ? loadError : "No findings match this filter"}
              </div>
            </div>
          ) : (
            filteredFindings.map((finding) => {
              const isSelected = selectedFinding?.id === finding.id;

              return (
                <button
                  key={finding.id}
                  type="button"
                  onClick={() => setSelectedId(finding.id)}
                  className={`grid w-full gap-3 px-4 py-4 text-left transition md:grid-cols-[4px_minmax(0,1fr)_auto] md:items-start ${
                    isSelected
                      ? "bg-[rgba(0,200,180,0.08)]"
                      : "hover:bg-[rgba(0,200,180,0.03)]"
                  }`}
                >
                  <div
                    className={`hidden rounded md:block ${
                      finding.severity === "critical"
                        ? "bg-[var(--danger)]"
                        : finding.severity === "high"
                          ? "bg-[#ff8c42]"
                          : finding.severity === "medium"
                            ? "bg-[var(--warning)]"
                            : "bg-[var(--accent)]"
                    }`}
                  />

                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2">
                      <span className="font-mono text-[0.76rem] tracking-[0.05em] text-[var(--accent)]">
                        {finding.cveId}
                      </span>
                    </div>

                    <h3 className="mt-1 truncate text-[0.9rem] text-[var(--text)]">
                      {finding.title}
                    </h3>

                    <div className="mt-2 flex flex-wrap gap-2">
                      <StatusPill tone={severityPillTone[finding.severity]}>
                        {finding.severity}
                      </StatusPill>
                      {finding.exploitAvailable ? (
                        <StatusPill tone="danger">Exploit Available</StatusPill>
                      ) : null}
                      <StatusPill>{finding.assetName}</StatusPill>
                      <StatusPill tone={statusPillTone[finding.status]}>
                        {formatStatus(finding.status)}
                      </StatusPill>
                      {finding.prioritization?.totalAdjustment ? (
                        <StatusPill
                          tone={finding.prioritization.totalAdjustment > 0 ? "warning" : "default"}
                        >
                          Adj {finding.prioritization.totalAdjustment > 0 ? "+" : ""}
                          {finding.prioritization.totalAdjustment}
                        </StatusPill>
                      ) : null}
                      <StatusPill
                        tone={
                          enrichmentStatusTone[
                            finding.enrichmentSummary?.status ?? "pending"
                          ]
                        }
                      >
                        Enrichment{" "}
                        {formatEnrichmentStatus(
                          finding.enrichmentSummary?.status ?? "pending",
                        )}
                      </StatusPill>
                    </div>
                  </div>

                  <div className="md:text-right">
                    <div
                      className={`text-[1.8rem] font-black leading-none tracking-[-0.04em] ${
                        finding.severity === "critical"
                          ? "text-[var(--danger)]"
                          : finding.severity === "high"
                            ? "text-[#ff8c42]"
                            : finding.severity === "medium"
                              ? "text-[var(--warning)]"
                              : "text-[var(--accent)]"
                      }`}
                    >
                      {finding.riskScore}
                    </div>
                    <div className="mt-1 font-mono text-[0.55rem] uppercase tracking-[0.1em] text-[#5a7080]">
                      Risk Score
                    </div>
                    <div className="mt-2 font-mono text-[0.55rem] uppercase tracking-[0.1em] text-[#5a7080]">
                      {finding.enrichmentSummary?.lastObservedAt
                        ? `NVD ${finding.enrichmentSummary.lastObservedAt.slice(0, 10)}`
                        : "NVD pending"}
                    </div>
                  </div>
                </button>
              );
            })
          )}
        </div>
      </div>

      <FindingDetailsPanel finding={selectedFinding} />
    </section>
  );
}
