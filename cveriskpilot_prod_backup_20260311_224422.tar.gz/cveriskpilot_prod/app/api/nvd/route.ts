import { NextResponse } from "next/server";

import { getNvdClient } from "@/lib/nvd/client";
import { NVD_ATTRIBUTION_NOTICE, NVD_CVE_ID_PATTERN } from "@/lib/nvd/constants";

function badRequest(message: string) {
  return NextResponse.json(
    {
      ok: false,
      error: {
        code: "invalid_request",
        message,
      },
    },
    { status: 400 },
  );
}

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const rawCveId = searchParams.get("cve")?.trim() ?? "";

    if (!rawCveId) {
      return badRequest("Missing required query parameter: cve");
    }

    if (!NVD_CVE_ID_PATTERN.test(rawCveId)) {
      return badRequest("Invalid CVE format. Expected pattern like CVE-2024-12345.");
    }

    const client = getNvdClient();
    const result = await client.getCveById(rawCveId);

    if (!result.ok) {
      return NextResponse.json(
        {
          ok: false,
          error: result.error,
          meta: result.meta,
          compliance: {
            attributionNotice: NVD_ATTRIBUTION_NOTICE,
            endorsementProhibited: true,
            modifiedContentSeparated: true,
          },
        },
        { status: result.error.status ?? 503 },
      );
    }

    const responseData = {
      ...result.data,
      nvd: {
        ...result.data.nvd,
        rawPayload: undefined,
      },
    };

    return NextResponse.json({
      ok: true,
      data: responseData,
      meta: result.meta,
      compliance: {
        attributionNotice: NVD_ATTRIBUTION_NOTICE,
        endorsementProhibited: true,
        modifiedContentSeparated: true,
      },
      warnings: result.meta.stale
        ? [
            {
              code: "nvd_stale_cache_used",
              message: "NVD was unavailable. Cached vulnerability data is shown.",
            },
          ]
        : [],
    });
  } catch (error) {
    console.error("NVD API route failure:", error);
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "nvd_route_failed",
          message: "Unable to retrieve vulnerability data from NVD.",
        },
        compliance: {
          attributionNotice: NVD_ATTRIBUTION_NOTICE,
          endorsementProhibited: true,
          modifiedContentSeparated: true,
        },
      },
      { status: 500 },
    );
  }
}
