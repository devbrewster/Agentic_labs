import { getNvdClient } from "@/lib/nvd/client";
import {
  ProviderEnrichmentResultSchema,
  type EnrichmentFindingInput,
  type ProviderEnrichmentResult,
} from "@/types/enrichment";
import type {
  EnrichmentProviderClient,
  EnrichmentProviderContext,
} from "@/lib/enrichment/providers/base";

export class NvdEnrichmentProvider implements EnrichmentProviderClient {
  readonly provider = "nvd" as const;

  async enrichFinding(
    finding: EnrichmentFindingInput,
    context: EnrichmentProviderContext,
  ): Promise<ProviderEnrichmentResult> {
    const primaryCve = finding.cveIds[0]?.trim().toUpperCase() ?? null;

    if (!primaryCve) {
      return ProviderEnrichmentResultSchema.parse({
        provider: this.provider,
        status: "not_found",
        sourceUrl: null,
        observedAt: context.now,
        payload: null,
        rawPayload: null,
        errorCode: null,
        errorMessage: null,
      });
    }

    if (process.env.NODE_ENV === "test") {
      return ProviderEnrichmentResultSchema.parse({
        provider: this.provider,
        status: "enriched",
        sourceUrl: `https://nvd.nist.gov/vuln/detail/${encodeURIComponent(primaryCve)}`,
        observedAt: context.now,
        payload: {
          kevListed: null,
          exploitAvailable: null,
          cvssScore: finding.cvssScore,
          cvssVector: null,
          references: [],
          summary: `Stub NVD enrichment result for ${primaryCve}.`,
          sourceVersion: "test-stub",
        },
        rawPayload: {
          stub: true,
          provider: "nvd",
          cveId: primaryCve,
        },
        errorCode: null,
        errorMessage: null,
      });
    }

    const result = await getNvdClient().getCveById(primaryCve);

    if (!result.ok) {
      return ProviderEnrichmentResultSchema.parse({
        provider: this.provider,
        status: "error",
        sourceUrl: `https://nvd.nist.gov/vuln/detail/${encodeURIComponent(primaryCve)}`,
        observedAt: context.now,
        payload: null,
        rawPayload: null,
        errorCode: result.error.code,
        errorMessage: result.error.message,
      });
    }

    const cvssV31 = result.data.nvd.cvssV31 as
      | { cvssData?: { baseScore?: number; vectorString?: string } }
      | undefined;
    const cvssV30 = result.data.nvd.cvssV30 as
      | { cvssData?: { baseScore?: number; vectorString?: string } }
      | undefined;
    const cvssV2 = result.data.nvd.cvssV2 as
      | { cvssData?: { baseScore?: number; vectorString?: string } }
      | undefined;
    const selectedMetric = cvssV31 ?? cvssV30 ?? cvssV2;

    return ProviderEnrichmentResultSchema.parse({
      provider: this.provider,
      status: "enriched",
      sourceUrl: `https://nvd.nist.gov/vuln/detail/${encodeURIComponent(primaryCve)}`,
      observedAt: result.data.nvd.lastModified ?? result.data.nvd.published ?? context.now,
      payload: {
        kevListed: null,
        exploitAvailable: null,
        cvssScore: selectedMetric?.cvssData?.baseScore ?? finding.cvssScore,
        cvssVector: selectedMetric?.cvssData?.vectorString ?? null,
        references: result.data.nvd.references?.map((reference) => reference.url) ?? [],
        summary: result.data.nvd.rawDescription ?? `NVD data retrieved for ${primaryCve}.`,
        sourceVersion: result.meta.source,
      },
      rawPayload: result.data.nvd.rawPayload as Record<string, unknown> | null | undefined,
      errorCode: null,
      errorMessage: null,
    });
  }
}
