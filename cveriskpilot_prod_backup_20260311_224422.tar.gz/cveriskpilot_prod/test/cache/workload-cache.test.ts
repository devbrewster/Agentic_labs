import { beforeEach, describe, expect, it, vi } from "vitest";

import {
  getCachedDashboardOverview,
  getCachedExecutiveSummary,
  getCachedFindings,
  invalidateOrganizationWorkloadCache,
  resetWorkloadCacheForTests,
} from "@/lib/cache/workload-cache";

describe("workload cache", () => {
  beforeEach(() => {
    resetWorkloadCacheForTests();
  });

  it("reuses cached dashboard overview values for the same organization", async () => {
    const loader = vi.fn(async () => ({ count: 1 }));

    const first = await getCachedDashboardOverview("org-1", loader);
    const second = await getCachedDashboardOverview("org-1", loader);

    expect(first).toEqual({ count: 1 });
    expect(second).toEqual({ count: 1 });
    expect(loader).toHaveBeenCalledTimes(1);
  });

  it("separates cached values by organization", async () => {
    const loaderA = vi.fn(async () => ({ count: 1 }));
    const loaderB = vi.fn(async () => ({ count: 2 }));

    const first = await getCachedFindings("org-1", loaderA);
    const second = await getCachedFindings("org-2", loaderB);

    expect(first).toEqual({ count: 1 });
    expect(second).toEqual({ count: 2 });
    expect(loaderA).toHaveBeenCalledTimes(1);
    expect(loaderB).toHaveBeenCalledTimes(1);
  });

  it("invalidates all workload cache entries for an organization", async () => {
    const overviewLoader = vi.fn(async () => ({ source: "overview" }));
    const summaryLoader = vi.fn(async () => ({ source: "summary" }));

    await getCachedDashboardOverview("org-1", overviewLoader);
    await getCachedExecutiveSummary("org-1", summaryLoader);

    invalidateOrganizationWorkloadCache("org-1");

    await getCachedDashboardOverview("org-1", overviewLoader);
    await getCachedExecutiveSummary("org-1", summaryLoader);

    expect(overviewLoader).toHaveBeenCalledTimes(2);
    expect(summaryLoader).toHaveBeenCalledTimes(2);
  });
});
