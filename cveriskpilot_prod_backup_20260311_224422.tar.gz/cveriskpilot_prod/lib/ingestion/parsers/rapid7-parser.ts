import {
  NormalizedFindingSchema,
  ParseResultSchema,
  type ArtifactFileType,
  type NormalizedFinding,
  type NormalizedSeverity,
  type ParseContext,
  type ParseMetadata,
  type ParseResult,
  type ParserDetectionHint,
  type ParserWarning,
  type RawArtifact,
  type ScannerParser,
} from "@/types/ingestion";

const RAPID7_SCANNER_NAME = "Rapid7 InsightVM";

type Rapid7Vulnerability = {
  id?: string;
  title?: string;
  severity?: string;
  cvss?: number;
  cvss_v3_score?: number;
  description?: string;
  solution?: string;
  cves?: string[];
  references?: Array<{ source?: string; reference?: string }>;
  proof?: string;
};

type Rapid7Service = {
  port?: number;
  protocol?: string;
  name?: string;
  vulnerabilities?: string[];
};

type Rapid7Asset = {
  id?: string;
  ip?: string;
  host_name?: string;
  hostnames?: string[];
  os?: string;
  services?: Rapid7Service[];
  vulnerabilities?: string[];
};

type Rapid7Export = {
  vulnerabilities?: Rapid7Vulnerability[];
  resources?: Rapid7Asset[];
  sites?: Array<Record<string, unknown>>;
};

function extractXmlRootTag(sampleText: string | null) {
  if (!sampleText) {
    return null;
  }

  const match = sampleText.match(/<([A-Za-z_][\w:.-]*)[^>]*>/);
  return match?.[1] ?? null;
}

function extractJsonRootKeys(sampleText: string | null) {
  if (!sampleText) {
    return [];
  }

  try {
    const parsed = JSON.parse(sampleText);

    if (Array.isArray(parsed)) {
      const firstObject = parsed.find(
        (value): value is Record<string, unknown> =>
          typeof value === "object" && value !== null && !Array.isArray(value),
      );

      return firstObject ? Object.keys(firstObject).map((key) => key.toLowerCase()) : [];
    }

    if (typeof parsed === "object" && parsed !== null) {
      return Object.keys(parsed).map((key) => key.toLowerCase());
    }

    return [];
  } catch {
    return [];
  }
}

function normalizeSeverity(value: string | undefined): NormalizedSeverity {
  switch ((value ?? "").trim().toLowerCase()) {
    case "critical":
      return "critical";
    case "severe":
    case "high":
      return "high";
    case "moderate":
    case "medium":
      return "medium";
    case "low":
      return "low";
    case "informational":
    case "info":
      return "informational";
    default:
      return "unknown";
  }
}

function buildMetadata(input: {
  artifact: RawArtifact;
  parsedAt: string;
  hostCount: number;
  findingCount: number;
}): ParseMetadata {
  return {
    scannerName: RAPID7_SCANNER_NAME,
    scannerVersion: null,
    sourceType: "rapid7",
    fileType: input.artifact.fileType,
    hostCount: input.hostCount,
    findingCount: input.findingCount,
    parsedAt: input.parsedAt,
    checksumSha256: input.artifact.checksumSha256,
  };
}

function parseRapid7Json(content: string): Rapid7Export | null {
  try {
    const parsed = JSON.parse(content) as unknown;
    if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
      return null;
    }
    return parsed as Rapid7Export;
  } catch {
    return null;
  }
}

function uniqueStrings(values: Array<string | undefined | null>) {
  return values.filter((value, index, array): value is string => {
    return typeof value === "string" && value.length > 0 && array.indexOf(value) === index;
  });
}

function normalizeCveIds(values: string[] | undefined) {
  return uniqueStrings(
    (values ?? []).flatMap((value) =>
      value
        .split(/[\s,;|]+/)
        .map((entry) => entry.trim().toUpperCase()),
    ),
  ).filter((value) => /^CVE-\d{4}-\d{4,}$/i.test(value));
}

function buildRapid7Finding(input: {
  uploadJobId: string;
  artifact: RawArtifact;
  parsedAt: string;
  asset: Rapid7Asset;
  vulnerability: Rapid7Vulnerability;
  service: Rapid7Service | null;
  recordIndex: number;
}): NormalizedFinding {
  const hostname = input.asset.host_name ?? input.asset.hostnames?.[0] ?? null;
  const cvssScore = input.vulnerability.cvss_v3_score ?? input.vulnerability.cvss ?? null;
  const pluginId = input.vulnerability.id ?? null;
  const cveIds = normalizeCveIds(input.vulnerability.cves);

  return NormalizedFindingSchema.parse({
    id: crypto.randomUUID(),
    uploadJobId: input.uploadJobId,
    rawRecordRef: {
      recordId: `${input.asset.id ?? input.asset.ip ?? "unknown-asset"}:${pluginId ?? "unknown-vuln"}:${input.recordIndex}`,
      recordIndex: input.recordIndex,
      locationHint: hostname ?? input.asset.ip ?? input.asset.id ?? null,
      sourceChecksumSha256: input.artifact.checksumSha256,
    },
    assetIdentifier: input.asset.id ?? input.asset.ip ?? null,
    hostname,
    fqdn: hostname,
    ipAddress: input.asset.ip ?? null,
    port: input.service?.port ?? null,
    protocol: input.service?.protocol ?? input.service?.name ?? null,
    vulnerabilityId: pluginId,
    pluginId,
    cveIds,
    title: input.vulnerability.title ?? `Rapid7 vulnerability ${pluginId ?? "unknown"}`,
    description: input.vulnerability.description ?? null,
    severity: input.vulnerability.severity ?? null,
    normalizedSeverity: normalizeSeverity(input.vulnerability.severity),
    cvssScore,
    cvssVector: null,
    remediation: input.vulnerability.solution ?? null,
    evidence: input.vulnerability.proof ?? null,
    status: "open",
    privilegeRequired: "unknown",
    detectedAt: input.parsedAt,
    firstObservedAt: input.parsedAt,
    lastObservedAt: input.parsedAt,
    sourceType: "rapid7",
    sourceScanner: RAPID7_SCANNER_NAME,
    tags: uniqueStrings(["rapid7", input.asset.os ?? null]),
    createdAt: input.parsedAt,
    updatedAt: input.parsedAt,
  });
}

export class Rapid7Parser implements ScannerParser {
  readonly sourceType = "rapid7" as const;
  readonly displayName = RAPID7_SCANNER_NAME;
  readonly supportedFileTypes: readonly ArtifactFileType[] = ["json", "xml"];

  async canParse(input: ParserDetectionHint) {
    if (!this.supportedFileTypes.includes(input.fileType)) {
      return false;
    }

    const rootTag = extractXmlRootTag(input.sampleText)?.toLowerCase();
    const jsonRootKeys = extractJsonRootKeys(input.sampleText);

    const xmlSignature = rootTag === "nexposereport" || rootTag === "nexposesimplexml";
    const jsonSignature =
      jsonRootKeys.includes("resources") ||
      jsonRootKeys.includes("vulnerabilities") ||
      jsonRootKeys.includes("sites");

    return /rapid7|insightvm|nexpose/i.test(input.filename) || xmlSignature || jsonSignature;
  }

  async parse(input: {
    artifact: RawArtifact;
    content: string;
    context: ParseContext;
  }): Promise<ParseResult> {
    const parsedAt = input.context.now;

    if (input.artifact.fileType === "xml") {
      return ParseResultSchema.parse({
        findings: [],
        parserWarnings: [
          {
            code: "rapid7_xml_partial_support",
            message:
              "Rapid7 XML detection is implemented, but current CR-3 coverage only normalizes Rapid7 JSON exports.",
            field: null,
            row: null,
            level: "warning",
          },
        ],
        parserErrors: [
          {
            code: "rapid7_xml_not_implemented",
            message:
              "Rapid7 XML parsing is not implemented yet. Use InsightVM/Nexpose JSON export for current supported workflow.",
            details: {
              supportedToday: ["Rapid7 JSON export parsing"],
            },
            fatal: true,
          },
        ],
        metadata: buildMetadata({
          artifact: input.artifact,
          parsedAt,
          hostCount: 0,
          findingCount: 0,
        }),
      });
    }

    const parsed = parseRapid7Json(input.content);
    if (!parsed) {
      return ParseResultSchema.parse({
        findings: [],
        parserWarnings: [],
        parserErrors: [
          {
            code: "rapid7_invalid_json",
            message: "Rapid7 JSON export could not be parsed.",
            details: null,
            fatal: true,
          },
        ],
        metadata: buildMetadata({
          artifact: input.artifact,
          parsedAt,
          hostCount: 0,
          findingCount: 0,
        }),
      });
    }

    const vulnerabilitiesById = new Map<string, Rapid7Vulnerability>();
    const parserWarnings: ParserWarning[] = [];
    const findings: NormalizedFinding[] = [];

    for (const vulnerability of parsed.vulnerabilities ?? []) {
      if (vulnerability.id) {
        vulnerabilitiesById.set(vulnerability.id, vulnerability);
      }
    }

    for (const [assetIndex, asset] of (parsed.resources ?? []).entries()) {
      const vulnerabilityIds = uniqueStrings([
        ...(asset.vulnerabilities ?? []),
        ...((asset.services ?? []).flatMap((service) => service.vulnerabilities ?? [])),
      ]);

      if (vulnerabilityIds.length === 0) {
        parserWarnings.push({
          code: "rapid7_asset_without_vulnerabilities",
          message: `Rapid7 asset '${asset.host_name ?? asset.ip ?? `index-${assetIndex}`}' did not include vulnerability references.`,
          field: "vulnerabilities",
          row: assetIndex + 1,
          level: "warning",
        });
      }

      for (const vulnerabilityId of vulnerabilityIds) {
        const vulnerability = vulnerabilitiesById.get(vulnerabilityId);
        const service =
          asset.services?.find((candidate) =>
            (candidate.vulnerabilities ?? []).includes(vulnerabilityId),
          ) ?? null;

        if (!vulnerability) {
          parserWarnings.push({
            code: "rapid7_missing_vulnerability_definition",
            message: `Rapid7 vulnerability '${vulnerabilityId}' referenced by an asset was not defined in the export payload.`,
            field: "vulnerabilities",
            row: assetIndex + 1,
            level: "warning",
          });
          continue;
        }

        findings.push(
          buildRapid7Finding({
            uploadJobId: input.context.uploadJob.id,
            artifact: input.artifact,
            parsedAt,
            asset,
            vulnerability,
            service,
            recordIndex: findings.length,
          }),
        );
      }
    }

    if (findings.some((finding) => finding.cveIds.length === 0)) {
      parserWarnings.push({
        code: "rapid7_missing_cve",
        message: "One or more Rapid7 findings did not include CVE identifiers.",
        field: "cves",
        row: null,
        level: "warning",
      });
    }

    return ParseResultSchema.parse({
      findings,
      parserWarnings,
      parserErrors:
        findings.length === 0
          ? [
              {
                code: "rapid7_no_findings_extracted",
                message: "Rapid7 JSON was detected but no findings could be normalized.",
                details: null,
                fatal: true,
              },
            ]
          : [],
      metadata: buildMetadata({
        artifact: input.artifact,
        parsedAt,
        hostCount: parsed.resources?.length ?? 0,
        findingCount: findings.length,
      }),
    });
  }
}
