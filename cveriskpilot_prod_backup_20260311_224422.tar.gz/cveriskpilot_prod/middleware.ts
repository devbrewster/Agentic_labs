import type { NextRequest } from "next/server";
import { NextResponse } from "next/server";

import { getAppDomainHost } from "@/lib/app-routes";

const SECURITY_HEADERS: Record<string, string> = {
  "X-Frame-Options": "DENY",
  "X-Content-Type-Options": "nosniff",
  "Referrer-Policy": "strict-origin-when-cross-origin",
  "Permissions-Policy": "camera=(), microphone=(), geolocation=()",
  "Content-Security-Policy":
    "default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; script-src 'self' 'unsafe-inline'; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; font-src 'self' data: https:; connect-src 'self' https:; frame-src 'self'; upgrade-insecure-requests",
};

function getDeploymentMode() {
  const configured =
    process.env.NEXT_PUBLIC_APP_DEPLOYMENT_MODE ??
    process.env.APP_DEPLOYMENT_MODE ??
    "path_dashboard";

  return configured === "subdomain_root" ? "subdomain_root" : "path_dashboard";
}

function shouldBypass(pathname: string) {
  return (
    pathname.startsWith("/api") ||
    pathname.startsWith("/_next") ||
    pathname.startsWith("/favicon") ||
    pathname.startsWith("/robots.txt") ||
    pathname.startsWith("/sitemap")
  );
}

function rewriteForAppRoot(pathname: string) {
  switch (pathname) {
    case "/":
      return "/dashboard";
    case "/uploads":
      return "/dashboard/uploads";
    case "/findings":
      return "/dashboard/findings";
    case "/action-plans":
      return "/dashboard/action-plans";
    case "/reports":
      return "/dashboard/reports";
    case "/integrations":
      return "/dashboard/integrations";
    case "/settings":
      return "/dashboard/settings";
    default:
      return null;
  }
}

function isDevAccessProtectionEnabled() {
  return (process.env.DEV_ACCESS_ENABLED ?? "false").toLowerCase() === "true";
}

function requiresDevAccessAuth(pathname: string) {
  return (
    pathname.startsWith("/dashboard") ||
    pathname.startsWith("/uploads") ||
    pathname.startsWith("/findings") ||
    pathname.startsWith("/action-plans") ||
    pathname.startsWith("/reports") ||
    pathname.startsWith("/integrations") ||
    pathname.startsWith("/settings")
  );
}

function applySecurityHeaders(response: NextResponse) {
  for (const [key, value] of Object.entries(SECURITY_HEADERS)) {
    response.headers.set(key, value);
  }

  return response;
}

function isAuthorizedForDevAccess(request: NextRequest) {
  const username = process.env.DEV_ACCESS_USERNAME?.trim();
  const password = process.env.DEV_ACCESS_PASSWORD?.trim();

  if (!username || !password) {
    return false;
  }

  const authorization = request.headers.get("authorization");

  if (!authorization?.startsWith("Basic ")) {
    return false;
  }

  try {
    const encoded = authorization.slice("Basic ".length);
    const decoded = atob(encoded);
    const separatorIndex = decoded.indexOf(":");

    if (separatorIndex < 0) {
      return false;
    }

    const suppliedUsername = decoded.slice(0, separatorIndex);
    const suppliedPassword = decoded.slice(separatorIndex + 1);

    return suppliedUsername === username && suppliedPassword === password;
  } catch {
    return false;
  }
}

function unauthorizedResponse() {
  const response = new NextResponse("Authentication required", {
    status: 401,
    headers: {
      "WWW-Authenticate": 'Basic realm="CVERiskPilot Dev", charset="UTF-8"',
      "Cache-Control": "no-store",
    },
  });

  return applySecurityHeaders(response);
}

export function middleware(request: NextRequest) {
  const { pathname } = request.nextUrl;

  if (isDevAccessProtectionEnabled() && requiresDevAccessAuth(pathname)) {
    if (!isAuthorizedForDevAccess(request)) {
      return unauthorizedResponse();
    }
  }

  if (getDeploymentMode() !== "subdomain_root") {
    return applySecurityHeaders(NextResponse.next());
  }

  const host = request.headers.get("host")?.toLowerCase() ?? "";
  const expectedHost = getAppDomainHost().toLowerCase();

  if (host !== expectedHost) {
    return applySecurityHeaders(NextResponse.next());
  }

  if (shouldBypass(pathname)) {
    return applySecurityHeaders(NextResponse.next());
  }

  const rewriteTarget = rewriteForAppRoot(pathname);

  if (!rewriteTarget) {
    return applySecurityHeaders(NextResponse.next());
  }

  const url = request.nextUrl.clone();
  url.pathname = rewriteTarget;
  return applySecurityHeaders(NextResponse.rewrite(url));
}

export const config = {
  matcher: ["/((?!.*\\..*).*)"],
};
