type AuthContext = {
  userId: string;
  organizationId: string;
  headers: HeadersInit;
};

export async function createAuthenticatedTestContext(label = "integration"): Promise<AuthContext> {
  const userId = crypto.randomUUID();
  const organizationId = crypto.randomUUID();

  return {
    userId,
    organizationId,
    headers: {
      "x-test-user-id": userId,
      "x-test-organization-id": organizationId,
    },
  };
}

export function withAuthHeaders(authHeaders: HeadersInit, headers?: HeadersInit) {
  const nextHeaders = new Headers(headers);
  const source = new Headers(authHeaders);

  source.forEach((value, key) => {
    nextHeaders.set(key, value);
  });

  return nextHeaders;
}
