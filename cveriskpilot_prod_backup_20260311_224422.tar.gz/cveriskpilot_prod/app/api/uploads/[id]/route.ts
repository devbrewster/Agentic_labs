import { NextResponse } from "next/server";

import { handleIngestionRouteError } from "@/lib/ingestion/http";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function GET(request: Request, context: RouteContext) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const { id } = await context.params;
    const { uploadService } = await getIngestionRuntime();
    const detail = await uploadService.getUploadJobDetail(id, auth.organizationId);

    if (!detail) {
      return NextResponse.json(
        {
          ok: false,
          error: {
            code: "upload_not_found",
            message: "Upload job was not found.",
          },
        },
        { status: 404 },
      );
    }

    return NextResponse.json({
      ok: true,
      data: detail,
    });
  } catch (error) {
    return handleIngestionRouteError(error, {
      code: "upload_detail_failed",
      message: "Unable to retrieve upload job details.",
    });
  }
}
