import {
  FindingAnalysisOutputSchema,
  GeneratedFindingAnalysisSchema,
  type AnalysisMode,
  type AnalysisPromptContext,
  type GeneratedFindingAnalysis,
} from "@/types/analysis";
import type { PromptEnvelope } from "@/types/analysis";
import { buildPromptEnvelope } from "@/lib/analysis/prompt-template";
import { getClaudeClient } from "@/lib/analysis/claude-client";

function createStubOutput(context: AnalysisPromptContext) {
  const confidenceBase =
    context.enrichment.status === "enriched"
      ? 0.82
      : context.enrichment.status === "partial"
        ? 0.68
        : 0.52;

  const output = FindingAnalysisOutputSchema.parse({
    businessImpact: `${context.finding.cveId} impacts ${context.finding.assetName} in ${context.finding.environment}. Prioritize remediation based on ${context.finding.severity} severity and risk score ${context.finding.riskScore}.`,
    exploitabilityAssessment: context.enrichment.exploitAvailable
      ? "Exploit signal present from enrichment data. Treat as elevated exploitation risk."
      : "No direct exploit signal available yet. Validate attack path and exposed services.",
    falsePositiveAssessment: context.analyst.decision === "false_positive"
      ? "Analyst previously marked as false positive. Re-validate scanner evidence before suppressing."
      : "No confirmed false-positive disposition. Keep finding in active triage until validated.",
    recommendedAction:
      context.finding.remediationSummary ??
      "Create remediation ticket, assign owner, and verify patch or mitigation controls.",
    confidence: confidenceBase,
  });

  return output;
}

function extractJsonCandidate(text: string) {
  const trimmed = text.trim();

  const fencedMatch = trimmed.match(/```(?:json)?\s*([\s\S]*?)\s*```/i);
  if (fencedMatch?.[1]) {
    return fencedMatch[1].trim();
  }

  const firstBrace = trimmed.indexOf("{");
  const lastBrace = trimmed.lastIndexOf("}");

  if (firstBrace >= 0 && lastBrace > firstBrace) {
    return trimmed.slice(firstBrace, lastBrace + 1).trim();
  }

  return trimmed;
}

const CLAUDE_OUTPUT_KEY_ALIASES = {
  businessImpact: [
    "businessImpact",
    "business_impact",
    "impact",
    "business impact",
  ],
  exploitabilityAssessment: [
    "exploitabilityAssessment",
    "exploitability_assessment",
    "exploitability",
    "exploitability assessment",
  ],
  falsePositiveAssessment: [
    "falsePositiveAssessment",
    "false_positive_assessment",
    "falsePositive",
    "false_positive",
    "false positive assessment",
  ],
  recommendedAction: [
    "recommendedAction",
    "recommended_action",
    "action",
    "recommended action",
    "remediation",
  ],
  confidence: ["confidence", "confidence_score", "score"],
} as const;

type ClaudeOutputCandidate = {
  businessImpact?: unknown;
  exploitabilityAssessment?: unknown;
  falsePositiveAssessment?: unknown;
  recommendedAction?: unknown;
  confidence?: unknown;
};

function normalizeConfidenceValue(value: unknown) {
  if (value && typeof value === "object" && !Array.isArray(value)) {
    const overall = (value as Record<string, unknown>).overall;
    return normalizeConfidenceValue(overall);
  }

  if (typeof value === "number" && Number.isFinite(value)) {
    return value > 1 ? value / 100 : value;
  }

  if (typeof value === "string") {
    const confidenceLabelMatch = value.match(
      /overall["']?\s*[:=]\s*["']?(low|medium|high|critical)/i,
    );

    if (confidenceLabelMatch?.[1]) {
      const label = confidenceLabelMatch[1].toLowerCase();
      return label === "critical"
        ? 0.95
        : label === "high"
          ? 0.85
          : label === "medium"
            ? 0.65
            : 0.35;
    }

    if (/^\s*(low|medium|high|critical)\s*$/i.test(value)) {
      const label = value.trim().toLowerCase();
      return label === "critical"
        ? 0.95
        : label === "high"
          ? 0.85
          : label === "medium"
            ? 0.65
            : 0.35;
    }

    const normalized = value.trim().replace(/%$/, "");
    const numeric = Number(normalized);

    if (Number.isFinite(numeric)) {
      return value.trim().endsWith("%") || numeric > 1 ? numeric / 100 : numeric;
    }
  }

  return value;
}

function getAliasedValue(
  source: Record<string, unknown>,
  aliases: readonly string[],
) {
  for (const alias of aliases) {
    if (alias in source && source[alias] != null) {
      return source[alias];
    }
  }

  return undefined;
}

function mapAliasedClaudeOutput(source: Record<string, unknown>) {
  const candidate: ClaudeOutputCandidate = {
    businessImpact: getAliasedValue(source, CLAUDE_OUTPUT_KEY_ALIASES.businessImpact),
    exploitabilityAssessment: getAliasedValue(
      source,
      CLAUDE_OUTPUT_KEY_ALIASES.exploitabilityAssessment,
    ),
    falsePositiveAssessment: getAliasedValue(
      source,
      CLAUDE_OUTPUT_KEY_ALIASES.falsePositiveAssessment,
    ),
    recommendedAction: getAliasedValue(
      source,
      CLAUDE_OUTPUT_KEY_ALIASES.recommendedAction,
    ),
    confidence: normalizeConfidenceValue(
      getAliasedValue(source, CLAUDE_OUTPUT_KEY_ALIASES.confidence),
    ),
  };

  return candidate;
}

function extractNestedClaudeOutput(parsed: Record<string, unknown>) {
  const directCandidate = mapAliasedClaudeOutput(parsed);

  const hasDirectMatch = Object.values(directCandidate).some((value) => value != null);
  if (hasDirectMatch) {
    return directCandidate;
  }

  for (const value of Object.values(parsed)) {
    if (!value || typeof value !== "object" || Array.isArray(value)) {
      continue;
    }

    const nestedCandidate = mapAliasedClaudeOutput(value as Record<string, unknown>);
    const hasNestedMatch = Object.values(nestedCandidate).some((entry) => entry != null);

    if (hasNestedMatch) {
      return nestedCandidate;
    }
  }

  return directCandidate;
}

function extractLooseField(text: string, aliases: readonly string[]) {
  const escaped = aliases
    .map((alias) => alias.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
    .join("|");
  const match = text.match(
    new RegExp(
      `(?:^|\\n)\\s*(?:["']?(?:${escaped})["']?)\\s*[:=-]\\s*["']?([\\s\\S]*?)(?=(?:\\n\\s*["']?(?:${escaped}|businessImpact|business_impact|impact|exploitabilityAssessment|exploitability_assessment|exploitability|falsePositiveAssessment|false_positive_assessment|falsePositive|false_positive|recommendedAction|recommended_action|action|remediation|confidence|confidence_score|score)["']?\\s*[:=-])|$)`,
      "i",
    ),
  );

  return match?.[1]?.trim().replace(/^["']|["']$/g, "");
}

function parseLooseClaudeOutput(text: string) {
  const candidate = {
    businessImpact: extractLooseField(text, CLAUDE_OUTPUT_KEY_ALIASES.businessImpact),
    exploitabilityAssessment: extractLooseField(
      text,
      CLAUDE_OUTPUT_KEY_ALIASES.exploitabilityAssessment,
    ),
    falsePositiveAssessment: extractLooseField(
      text,
      CLAUDE_OUTPUT_KEY_ALIASES.falsePositiveAssessment,
    ),
    recommendedAction: extractLooseField(
      text,
      CLAUDE_OUTPUT_KEY_ALIASES.recommendedAction,
    ),
    confidence: normalizeConfidenceValue(
      extractLooseField(text, CLAUDE_OUTPUT_KEY_ALIASES.confidence),
    ),
  };

  return candidate;
}

function sanitizeClaudeResponsePreview(text: string) {
  return text
    .replace(/\s+/g, " ")
    .slice(0, 500);
}

function normalizeClaudeOutputShape(parsed: unknown) {
  if (!parsed || typeof parsed !== "object") {
    return parsed;
  }

  return extractNestedClaudeOutput(parsed as Record<string, unknown>);
}

function parseClaudeJson(text: string) {
  try {
    const parsed = JSON.parse(extractJsonCandidate(text)) as unknown;
    return FindingAnalysisOutputSchema.parse(normalizeClaudeOutputShape(parsed));
  } catch {
    try {
      const looseCandidate = parseLooseClaudeOutput(text);
      if (looseCandidate.confidence == null) {
        const confidenceObjectMatch = text.match(
          /"confidence"\s*:\s*\{[\s\S]*?"overall"\s*:\s*"([^"]+)"/i,
        );

        if (confidenceObjectMatch?.[1]) {
          looseCandidate.confidence = normalizeConfidenceValue(confidenceObjectMatch[1]);
        }
      }

      return FindingAnalysisOutputSchema.parse(looseCandidate);
    } catch {
      console.warn(
        "Claude parse fallback failed. Response preview:",
        sanitizeClaudeResponsePreview(text),
      );
      throw new Error("Claude response was not valid JSON matching expected analysis schema.");
    }
  }
}

function createFallbackAnalysis(
  context: AnalysisPromptContext,
  mode: AnalysisMode,
  warning: string,
  fallbackReason: string,
) {
  return GeneratedFindingAnalysisSchema.parse({
    mode,
    provider: "stub",
    model: "cveriskpilot-p3-7-stub",
    generatedAt: new Date().toISOString(),
    traceStatus: "fallback",
    fallbackReason,
    output: createStubOutput(context),
    warnings: [warning],
  });
}

export function buildAnalysisPromptEnvelope(context: AnalysisPromptContext): PromptEnvelope {
  return buildPromptEnvelope(context);
}

export async function generateFindingAnalysis(
  context: AnalysisPromptContext,
  mode: AnalysisMode,
): Promise<GeneratedFindingAnalysis> {
  const prompt = buildAnalysisPromptEnvelope(context);
  const now = new Date().toISOString();

  if (mode === "stub") {
    return GeneratedFindingAnalysisSchema.parse({
      mode: "stub",
      provider: "stub",
      model: "cveriskpilot-p3-7-stub",
      generatedAt: now,
      traceStatus: "completed",
      fallbackReason: null,
      output: createStubOutput(context),
      warnings: [],
    });
  }

  const client = getClaudeClient();
  if (!client) {
    return createFallbackAnalysis(
      context,
      "live",
      "ANTHROPIC_API_KEY is not configured. Returning deterministic stub output.",
      "anthropic_api_key_missing",
    );
  }

  try {
    const text = await client.generateText({
      systemPrompt: prompt.systemPrompt,
      userPrompt: prompt.userPrompt,
    });
    const output = parseClaudeJson(text);

    return GeneratedFindingAnalysisSchema.parse({
      mode: "live",
      provider: "claude",
      model: process.env.ANTHROPIC_MODEL?.trim() || "claude-sonnet-4-6",
      generatedAt: now,
      traceStatus: "completed",
      fallbackReason: null,
      output,
      warnings: [],
    });
  } catch (error) {
    const safeMessage =
      error instanceof Error ? error.message : "Claude generation failed unexpectedly.";

    return createFallbackAnalysis(
      context,
      "live",
      `Claude live generation failed. Returning deterministic stub output. ${safeMessage}`,
      "claude_live_generation_failed",
    );
  }
}
