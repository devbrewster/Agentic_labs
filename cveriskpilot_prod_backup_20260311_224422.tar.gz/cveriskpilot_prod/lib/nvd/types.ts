import { z } from "zod";

export const NvdReferenceSchema = z.object({
  url: z.string().url(),
  source: z.string().optional(),
  tags: z.array(z.string()).optional(),
});

export type NvdReference = z.infer<typeof NvdReferenceSchema>;

export const VulnerabilityRecordSchema = z.object({
  cveId: z.string().min(1),
  nvd: z.object({
    source: z.literal("NVD"),
    rawDescription: z.string().optional(),
    published: z.string().optional(),
    lastModified: z.string().optional(),
    cvssV31: z.unknown().optional(),
    cvssV30: z.unknown().optional(),
    cvssV2: z.unknown().optional(),
    weaknesses: z.array(z.string()).optional(),
    references: z.array(NvdReferenceSchema).optional(),
    configurations: z.unknown().optional(),
    rawPayload: z.unknown().optional(),
  }),
  analysis: z.object({
    source: z.literal("CVERiskPilot"),
    businessImpact: z.string().optional(),
    exploitabilityAssessment: z.string().optional(),
    falsePositiveAssessment: z.string().optional(),
    recommendedAction: z.string().optional(),
    confidence: z.number().min(0).max(1).optional(),
  }),
  enrichments: z.object({
    kev: z.unknown().optional(),
    epss: z.unknown().optional(),
    vendor: z.unknown().optional(),
    scannerContext: z.unknown().optional(),
    enterpriseArchitecture: z.unknown().optional(),
  }),
  compliance: z.object({
    attributionRequired: z.literal(true),
    endorsementProhibited: z.literal(true),
    modifiedContentSeparated: z.literal(true),
  }),
});

export type VulnerabilityRecord = z.infer<typeof VulnerabilityRecordSchema>;

export type NvdApiResponse = {
  vulnerabilities?: Array<{
    cve?: {
      id?: string;
      descriptions?: Array<{ lang?: string; value?: string }>;
      references?: Array<{ url?: string; source?: string; tags?: string[] }>;
      weaknesses?: Array<{
        description?: Array<{ lang?: string; value?: string }>;
      }>;
      configurations?: unknown;
      metrics?: {
        cvssMetricV31?: unknown[];
        cvssMetricV30?: unknown[];
        cvssMetricV2?: unknown[];
      };
      published?: string;
      lastModified?: string;
    };
  }>;
};

export type NvdClientErrorCode =
  | "invalid_cve_id"
  | "request_timeout"
  | "rate_limited"
  | "upstream_error"
  | "network_error"
  | "bad_response";

export type NvdClientError = {
  code: NvdClientErrorCode;
  message: string;
  status?: number;
  retriable: boolean;
  fromCache: boolean;
};

export type NvdClientResult = {
  ok: true;
  data: VulnerabilityRecord;
  meta: {
    source: "nvd_live" | "nvd_cache_fresh" | "nvd_cache_stale";
    fetchedAt: string;
    cacheHit: boolean;
    stale: boolean;
  };
} | {
  ok: false;
  error: NvdClientError;
  meta: {
    source: "nvd_live" | "nvd_cache_stale" | "none";
    fetchedAt: string | null;
    cacheHit: boolean;
    stale: boolean;
  };
};
