import { NextResponse } from "next/server";

import { handleEnrichmentRouteError } from "@/lib/enrichment/http";
import { getEnrichmentRuntime } from "@/lib/enrichment/runtime";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function GET(request: Request, context: RouteContext) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const { id } = await context.params;
    const { uploadRepository } = await getIngestionRuntime();
    const finding = await uploadRepository.findFindingByIdForTenant(id, auth.organizationId);

    if (!finding) {
      return NextResponse.json(
        {
          ok: false,
          error: {
            code: "finding_not_found",
            message: "Finding was not found.",
          },
        },
        { status: 404 },
      );
    }

    const { enrichmentRepository } = await getEnrichmentRuntime();
    const snapshots = await enrichmentRepository.listSnapshotsByFindingId(id);

    return NextResponse.json({
      ok: true,
      data: {
        findingId: id,
        snapshotCount: snapshots.length,
        snapshots,
      },
    });
  } catch (error) {
    return handleEnrichmentRouteError(error, {
      code: "finding_enrichment_fetch_failed",
      message: "Unable to retrieve enrichment snapshots for finding.",
    });
  }
}
