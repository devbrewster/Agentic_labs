# CVERiskPilot

## Documentation

- User guide (living): [docs/user-guide.md](/home/gonti/cveriskpilot_prod/docs/user-guide.md)
- Phase 3 plan: [docs/phase-3-plan.md](/home/gonti/cveriskpilot_prod/docs/phase-3-plan.md)
- Admin runbook: [docs/admin-runbook.md](/home/gonti/cveriskpilot_prod/docs/admin-runbook.md)
- TODO backlog: [docs/todo-backlog.md](/home/gonti/cveriskpilot_prod/docs/todo-backlog.md)
- Upload stabilization plan: [docs/upload-stabilization-plan.md](/home/gonti/cveriskpilot_prod/docs/upload-stabilization-plan.md)
- Upload stabilization log: [docs/upload-stabilization-log.md](/home/gonti/cveriskpilot_prod/docs/upload-stabilization-log.md)
- AWS bootstrap: [infra/aws/README.md](/home/gonti/cveriskpilot_prod/infra/aws/README.md)
- AWS SaaS migration plan: [docs/aws-saas-migration-plan.md](/home/gonti/cveriskpilot_prod/docs/aws-saas-migration-plan.md)

## Local auth setup

1. Install dependencies:
```bash
npm install
```

2. Create your local env file:
```bash
cp .env.local.example .env.local
```

If you want verification emails delivered to a real inbox, configure SMTP in `.env.local`.
Recommended provider: Resend SMTP.

3. Apply the D1 schema to the local database:
```bash
npm run db:migrate:local
```

If you add new tenancy or auth schema changes later, rerun the migration before testing sessions or uploads.

4. Run the standard Next.js dev server:
```bash
npm run dev
```

5. Run the OpenNext Cloudflare preview runtime:
```bash
npm run preview
```

## Local auth testing checklist

- Open `http://localhost:3000/signup`
- Create a new account with a unique email and password
- Confirm the signup response shows a verification email preview URL in local development
- Open the Ethereal preview URL and click the verification link
- Confirm the browser redirects to `/login?verified=success`
- Log in with the verified account at `http://localhost:3000/login`
- Open `http://localhost:3000/account`
- Test profile update, password change, logout, logout all, and account delete

## Exact commands

Install dependencies:
```bash
npm install
```

Apply local D1 schema:
```bash
npm run db:migrate:local
```

Run `next dev`:
```bash
npm run dev
```

Run Workers preview:
```bash
npm run preview
```

## Workers preview ingestion verification

Use this flow when you want to confirm the upload parsing pipeline works inside the OpenNext + Cloudflare Workers runtime instead of only `next dev`.

1. Apply the latest local D1 schema:
```bash
npm run db:migrate:local
```

2. Start the Workers preview runtime:
```bash
npm run preview
```

3. Open the uploads page:
```text
http://localhost:3000/dashboard/uploads
```

4. Upload a real CSV scan file from the UI.

Expected result:
- the dropzone shows upload / parse progress
- a recent upload job appears in the table
- the job status advances to `ENRICHMENT_PENDING`
- the findings count is greater than `0`

5. Verify the parsed findings page:
```text
http://localhost:3000/dashboard/findings
```

Expected result:
- the page shows ingested findings instead of the mock fallback
- filters, search, sort, and row selection still work

6. Verify the overview dashboard:
```text
http://localhost:3000/dashboard
```

Expected result:
- summary cards switch from mock counts to ingestion-backed counts
- the priority findings panel uses ingested findings when parsed uploads exist

7. Verify upload provenance on a parsed finding:
- click an ingested finding in `/dashboard` or `/dashboard/findings`

Expected result:
- the right-side details panel shows `Upload Provenance`
- provenance includes upload job ID, artifact filename, checksum prefix, and warning/error counts

8. Optional API verification:
```bash
curl -s http://localhost:3000/api/uploads
curl -s http://localhost:3000/api/findings
```

Expected result:
- `/api/uploads` returns ingestion jobs with real statuses
- `/api/findings` returns `source: "ingestion"` once parsed findings exist

If uploads fail in preview after schema changes, re-run:
```bash
npm run db:migrate:local
```

## Real email delivery

For real verification emails, configure Resend SMTP in `.env.local`:

```env
APP_BASE_URL=http://localhost:3000
MAIL_FROM=CVERiskPilot <noreply@yourdomain.com>
SMTP_HOST=smtp.resend.com
SMTP_PORT=465
SMTP_USER=resend
SMTP_PASS=re_your_resend_api_key
SMTP_SECURE=true
```

Then restart the dev server:

```bash
npm run dev
```

Notes:

- `MAIL_FROM` should use a sender address on a domain verified in Resend.
- If SMTP vars are unset, the app falls back to Ethereal preview emails instead of real delivery.
- `APP_BASE_URL=http://localhost:3000` means verification links only work on the same machine running the app.

## NVD API configuration

For server-side NVD enrichment and `/api/nvd`:

```env
NVD_API_KEY=
NVD_API_BASE_URL=https://services.nvd.nist.gov/rest/json
NVD_RATE_LIMIT_PUBLIC_PER_30S=5
NVD_RATE_LIMIT_KEYED_PER_30S=50
NVD_REQUEST_TIMEOUT_MS=15000
NVD_CACHE_TTL_MINUTES=1440
```

Notes:

- `NVD_API_KEY` is optional but recommended for higher rate limits.
- The key is used server-side only and is never returned in API responses.
- Required attribution is displayed in footer/about/CVE detail sections.

## Notes

- If `SMTP_HOST` is not set, the app uses Nodemailer with an Ethereal test inbox for local verification emails.
- `APP_BASE_URL` should stay `http://localhost:3000` for `next dev`.
- The Workers preview uses the existing `DB` binding from `wrangler.jsonc`.

## Deploying under /dashboard

This app is configured to mount under `/dashboard` in production.

Deploy steps:

```bash
npm install
npm run deploy
```

Attach the deployed Worker to this route in Cloudflare:

```text
cveriskpilot.com/dashboard*
```

Expected production URLs:

- `https://cveriskpilot.com/dashboard`
- `https://cveriskpilot.com/dashboard/findings`
- `https://cveriskpilot.com/dashboard/uploads`
- `https://cveriskpilot.com/dashboard/action-plans`
- `https://cveriskpilot.com/dashboard/reports`
- `https://cveriskpilot.com/dashboard/integrations`
- `https://cveriskpilot.com/dashboard/settings`

Important:

- Do not route the entire domain to this app unless you want this repo to own `/`.
- Route only `/dashboard*` if your landing page or waitlist is served by a different app.
