output "app_domain" {
  description = "Target application hostname."
  value       = local.app_domain
}

output "alb_dns_name" {
  description = "ALB DNS name. Use this for initial smoke tests if DNS is not yet wired."
  value       = aws_lb.app.dns_name
}

output "alb_http_url" {
  description = "Initial HTTP URL for smoke testing the environment."
  value       = "http://${aws_lb.app.dns_name}"
}

output "ecr_repository_url" {
  description = "Push your future app image here and update container_image."
  value       = aws_ecr_repository.app.repository_url
}

output "uploads_bucket_name" {
  description = "S3 bucket intended for raw upload artifacts."
  value       = aws_s3_bucket.uploads.bucket
}

output "database_endpoint" {
  description = "Postgres endpoint hostname."
  value       = aws_db_instance.postgres.address
}

output "database_name" {
  description = "Initial database name."
  value       = aws_db_instance.postgres.db_name
}

output "app_secret_name" {
  description = "Secrets Manager secret storing bootstrap application env values."
  value       = aws_secretsmanager_secret.app_env.name
}

output "manual_acm_validation_records" {
  description = "DNS validation records to create manually if Route53 is not managed by this stack."
  value = var.enable_https && !var.manage_route53_records ? [
    for dvo in aws_acm_certificate.app[0].domain_validation_options : {
      domain_name = dvo.domain_name
      record_name = dvo.resource_record_name
      record_type = dvo.resource_record_type
      record_value = dvo.resource_record_value
    }
  ] : []
}
