# Session Notes

Start here for future sessions.

Detailed handoff:

- [docs/progress-log.md](/home/gonti/cveriskpilot_prod/docs/progress-log.md)
- [docs/user-guide.md](/home/gonti/cveriskpilot_prod/docs/user-guide.md)
- [docs/phase-3-plan.md](/home/gonti/cveriskpilot_prod/docs/phase-3-plan.md)

## Current status

- Dashboard shell is built and deployed under `/dashboard`
- Upload parsing works for real CSV files
- Uploads UI is wired to ingestion APIs
- Findings and overview can read ingested data
- Preview/runtime artifact storage uses D1-backed artifact content storage
- Upload stabilization now has a dedicated execution plan and resumable log:
  - [docs/upload-stabilization-plan.md](/home/gonti/cveriskpilot_prod/docs/upload-stabilization-plan.md)
  - [docs/upload-stabilization-log.md](/home/gonti/cveriskpilot_prod/docs/upload-stabilization-log.md)

## Most important local command

Apply schema before testing ingestion changes:

```bash
npm run db:migrate:local
```

## Recommended next task

Upload stabilization is complete through Chunk G. Continue Phase 3 with Chunk P3-6 from [docs/phase-3-plan.md](/home/gonti/cveriskpilot_prod/docs/phase-3-plan.md): analyst disposition persistence.

Important carry-forward check:
- scope stabilized for currently supported parser scope (`generic_csv`)
- Phase 3 P3-1 completed:
  - `types/enrichment.ts` added
  - `enrichment_runs` and `finding_enrichment_snapshots` added to D1 schema
  - local migration validated and tables confirmed present
- Phase 3 P3-2 completed:
  - provider abstraction added under `lib/enrichment/providers`
  - stub clients implemented for NVD and CISA KEV
  - orchestration service added in `lib/enrichment/service.ts`
  - tests added in `test/enrichment/service.test.ts`
- Phase 3 P3-3 completed:
  - enrichment lifecycle runner added in `lib/enrichment/job-runner.ts`
  - D1 + in-memory enrichment repositories added under `lib/enrichment/`
  - runtime wiring added in `lib/enrichment/runtime.ts`
  - idempotent skip and forced rerun behavior validated in tests
- Phase 3 P3-4 completed:
  - enrichment trigger endpoint added at `POST /api/enrichments`
  - enrichment run detail endpoint added at `GET /api/enrichments/:id`
  - finding enrichment snapshots endpoint added at `GET /api/findings/:id/enrichment`
  - integration tests added in `test/api/enrichments.integration.test.ts`
- Phase 3 P3-5 completed:
  - `/api/findings` returns per-finding enrichment summaries
  - enrichment status is visible in priority findings and findings management table
  - finding details panel shows enrichment signal metadata and source timestamps
  - integration tests added in `test/api/findings.integration.test.ts`
- Phase 3 P3-6 completed:
  - analyst disposition persistence added via `GET/PATCH /api/findings/:id/disposition`
  - persisted analyst decision/rationale merged into `/api/findings`
  - finding details panel now saves/loads analyst disposition state
  - integration tests added in `test/api/disposition.integration.test.ts`
- Claude key prep for P3-7:
  - set `ANTHROPIC_API_KEY` in `.env.local`
  - optional model override: `ANTHROPIC_MODEL`
- Phase 3 P3-7 completed:
  - analysis prompt contracts/scaffolding added (`types/analysis.ts`)
  - finding analysis route added: `GET/POST /api/findings/:id/analysis`
  - details panel can generate stub drafts and Claude drafts (server-side key only)
  - tests added:
    - `test/analysis/prompt-scaffolding.test.ts`
    - `test/api/analysis.integration.test.ts`
- manual admin cleanup path is documented until superadmin tooling exists:
  - [docs/admin-runbook.md](/home/gonti/cveriskpilot_prod/docs/admin-runbook.md)
- future implementation items are tracked in:
  - [docs/todo-backlog.md](/home/gonti/cveriskpilot_prod/docs/todo-backlog.md)

After that, the next major phase should be enrichment pipeline work.
