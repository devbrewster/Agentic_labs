import { NVD_WINDOW_MS } from "@/lib/nvd/constants";

function sleep(ms: number) {
  return new Promise<void>((resolve) => {
    setTimeout(resolve, ms);
  });
}

export class RollingWindowRateLimiter {
  private readonly timestamps: number[] = [];
  private tail: Promise<void> = Promise.resolve();

  constructor(
    private readonly limitPerWindow: number,
    private readonly windowMs = NVD_WINDOW_MS,
  ) {}

  private evict(now: number) {
    const minTime = now - this.windowMs;
    while (this.timestamps.length > 0 && this.timestamps[0] <= minTime) {
      this.timestamps.shift();
    }
  }

  private async acquire() {
    while (true) {
      const now = Date.now();
      this.evict(now);

      if (this.timestamps.length < this.limitPerWindow) {
        this.timestamps.push(now);
        return;
      }

      const earliest = this.timestamps[0];
      const waitMs = Math.max(earliest + this.windowMs - now, 1);
      await sleep(waitMs);
    }
  }

  async schedule<T>(task: () => Promise<T>) {
    const waitTurn = this.tail.then(async () => {
      await this.acquire();
    });
    this.tail = waitTurn.catch(() => undefined);
    await waitTurn;
    return task();
  }
}
