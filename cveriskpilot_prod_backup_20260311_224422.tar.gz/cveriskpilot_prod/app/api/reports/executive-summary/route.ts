import { NextResponse } from "next/server";

import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";
import { getExecutiveSummaryReport } from "@/lib/services/reports";

export async function GET(request: Request) {
  const auth = await requireCurrentOrganizationAccess(request);

  if (!auth.ok) {
    return auth.response;
  }

  const report = await getExecutiveSummaryReport(auth.organizationId);

  return NextResponse.json({
    ok: true,
    data: report,
  });
}
