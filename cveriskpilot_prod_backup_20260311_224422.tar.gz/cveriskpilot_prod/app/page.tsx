import Link from "next/link";

const steps = [
  {
    num: "01",
    title: "Upload Your Scan",
    desc: "Import any scanner output — JSON, CSV, XML. Nessus, Qualys, Rapid7, Trivy, and more supported.",
  },
  {
    num: "02",
    title: "AI Triage Engine",
    desc: "Claude AI correlates CVE data with exploit availability, asset criticality, and your business context.",
  },
  {
    num: "03",
    title: "Prioritized Findings",
    desc: "Every finding gets a risk score, business impact statement, and remediation guidance automatically.",
  },
  {
    num: "04",
    title: "Act Immediately",
    desc: "Copy ticket-ready action plans directly to Jira or ServiceNow. Zero reformatting required.",
  },
];

const features = [
  {
    icon: "⚡",
    title: "AI Risk Prioritization",
    desc: "Stop treating CVSS 9.8 findings equally. AI scores each finding against exploit availability, asset exposure, and business context.",
  },
  {
    icon: "◈",
    title: "Business Impact Statements",
    desc: "Auto-generated plain-language explanations of what each vulnerability means for your business — ready for execs and boards.",
  },
  {
    icon: "✦",
    title: "Remediation Guidance",
    desc: "Step-by-step fix instructions for every finding, tailored to your environment and tech stack.",
  },
  {
    icon: "▦",
    title: "Ticket-Ready Action Plans",
    desc: "Pre-formatted Jira and ServiceNow tickets with priority, assignee, ETA, and labels.",
  },
  {
    icon: "≡",
    title: "Multi-Scanner Support",
    desc: "Ingest from Nessus, Qualys, Rapid7, Trivy, Grype, Snyk, and any JSON/CSV/XML format.",
  },
  {
    icon: "◎",
    title: "Exploit Intelligence",
    desc: "Real-time KEV and exploit availability data surfaces the findings attackers are actively targeting right now.",
  },
];

const pricing = [
  {
    tier: "Free",
    price: "$0",
    suffix: "/month",
    desc: "Perfect for evaluation and solo use",
    featured: false,
    cta: "Get Started Free",
    ctaPrimary: false,
    features: [
      { label: "3 scan uploads / month", locked: false },
      { label: "10 AI triage analyses / month", locked: false },
      { label: "10 CVE lookups / day", locked: false },
      { label: "1 action plan export / month", locked: false },
      { label: "Triage dashboard", locked: false },
      { label: "Jira / ServiceNow integration", locked: true },
      { label: "Executive PDF reports", locked: true },
      { label: "Team collaboration", locked: true },
    ],
  },
  {
    tier: "Pro",
    price: "$49",
    suffix: "/month",
    desc: "For serious security practitioners",
    featured: true,
    cta: "Start Pro Trial",
    ctaPrimary: true,
    features: [
      { label: "Unlimited scan uploads", locked: false },
      { label: "Unlimited AI analyses", locked: false },
      { label: "Unlimited CVE lookups", locked: false },
      { label: "Unlimited exports", locked: false },
      { label: "Jira integration", locked: false },
      { label: "Executive PDF reports", locked: false },
      { label: "API access", locked: false },
      { label: "Team collaboration", locked: true },
    ],
  },
  {
    tier: "Team",
    price: "$149",
    suffix: "/month",
    desc: "For AppSec teams up to 10 users",
    featured: false,
    cta: "Start Team Trial",
    ctaPrimary: false,
    features: [
      { label: "Everything in Pro", locked: false },
      { label: "Up to 10 team members", locked: false },
      { label: "Shared workspaces", locked: false },
      { label: "Role-based access control", locked: false },
      { label: "ServiceNow integration", locked: false },
      { label: "Custom asset tagging", locked: false },
      { label: "Trend analysis", locked: false },
      { label: "Priority support", locked: false },
    ],
  },
];

export default function HomePage() {
  return (
    <main className="min-h-screen overflow-x-hidden bg-[#040810] text-[#c8d8e8]">
      <div className="pointer-events-none fixed inset-0 z-0 bg-[linear-gradient(rgba(0,200,180,0.025)_1px,transparent_1px),linear-gradient(90deg,rgba(0,200,180,0.025)_1px,transparent_1px)] bg-[size:40px_40px]" />

      <div className="pointer-events-none fixed -left-[200px] top-[-200px] z-0 h-[700px] w-[700px] rounded-full bg-[radial-gradient(circle,rgba(0,200,180,0.10)_0%,transparent_70%)] blur-[140px]" />
      <div className="pointer-events-none fixed bottom-0 right-[-100px] z-0 h-[500px] w-[500px] rounded-full bg-[radial-gradient(circle,rgba(255,69,96,0.08)_0%,transparent_70%)] blur-[140px]" />

      <div className="pointer-events-none fixed left-0 right-0 top-0 z-[999] h-px animate-[scan_8s_linear_infinite] bg-[linear-gradient(90deg,transparent,#00c8b4,transparent)] opacity-20" />

      <nav className="fixed left-0 right-0 top-0 z-50 border-b border-[rgba(0,200,180,0.12)] bg-[rgba(4,8,16,0.7)] px-5 py-4 backdrop-blur md:px-10">
        <div className="mx-auto flex max-w-7xl items-center gap-6">
          <Link href="/" className="text-lg font-extrabold tracking-tight text-white">
            CVE<span className="text-[#00c8b4]">Risk</span>Pilot
          </Link>

          <div className="ml-6 hidden gap-5 md:flex">
            <a
              href="#how"
              className="text-xs uppercase tracking-[0.08em] text-[#4a6070] transition hover:text-[#00c8b4]"
            >
              How It Works
            </a>
            <a
              href="#features"
              className="text-xs uppercase tracking-[0.08em] text-[#4a6070] transition hover:text-[#00c8b4]"
            >
              Features
            </a>
            <a
              href="#pricing"
              className="text-xs uppercase tracking-[0.08em] text-[#4a6070] transition hover:text-[#00c8b4]"
            >
              Pricing
            </a>
          </div>

          <div className="ml-auto flex items-center gap-3">
            <Link
              href="/login"
              className="rounded border border-[rgba(0,200,180,0.12)] px-4 py-2 text-xs uppercase tracking-[0.08em] text-[#4a6070] transition hover:border-[#00c8b4] hover:text-[#00c8b4]"
            >
              Log In
            </Link>
            <Link
              href="/signup"
              className="rounded border border-[#00c8b4] bg-[#00c8b4] px-4 py-2 text-xs font-bold uppercase tracking-[0.08em] text-[#040810] transition hover:bg-[#00ffe8]"
            >
              Get Started Free
            </Link>
          </div>
        </div>
      </nav>

      <section className="relative z-10 flex min-h-screen flex-col items-center justify-center px-6 pb-20 pt-32 text-center">
        <div className="mb-6 inline-flex items-center gap-3 text-xs uppercase tracking-[0.2em] text-[#00c8b4]">
          <span className="h-px w-8 bg-[#00c8b4]/50" />
          Agentic AI · Vulnerability Intelligence
          <span className="h-px w-8 bg-[#00c8b4]/50" />
        </div>

        <h1 className="max-w-5xl text-5xl font-extrabold leading-none tracking-[-0.03em] text-white sm:text-6xl md:text-7xl">
          Turn CVE Noise Into
          <br />
          <span className="bg-gradient-to-r from-[#00c8b4] to-[#4af0e0] bg-clip-text text-transparent">
            Decisive Action.
          </span>
        </h1>

        <p className="mt-6 max-w-2xl text-base leading-8 text-[#c8d8e8]/80 sm:text-lg">
          CVERiskPilot transforms raw vulnerability findings into prioritized
          risk decisions — auto-generating business impact, remediation
          guidance, and ticket-ready action plans in minutes.
        </p>

        <div className="mt-10 flex flex-wrap items-center justify-center gap-3">
          <Link
            href="/signup"
            className="rounded border border-[#00c8b4] bg-[#00c8b4] px-5 py-3 text-xs font-bold uppercase tracking-[0.08em] text-[#040810] transition hover:bg-[#00ffe8]"
          >
            Start Free — No Credit Card
          </Link>
          <a
            href="#how"
            className="rounded border border-[rgba(0,200,180,0.12)] px-5 py-3 text-xs uppercase tracking-[0.08em] text-[#4a6070] transition hover:border-[#00c8b4] hover:text-[#00c8b4]"
          >
            See How It Works →
          </a>
        </div>

        <p className="mt-4 text-[11px] uppercase tracking-[0.08em] text-[#4a6070]">
          Free tier includes 3 scans + 10 AI analyses per month
        </p>

        <div className="relative z-10 mt-16 w-full max-w-4xl overflow-hidden rounded-md border border-[rgba(0,200,180,0.12)] bg-[#070e1a] shadow-[0_0_80px_rgba(0,200,180,0.08),0_40px_100px_rgba(0,0,0,0.6)]">
          <div className="flex items-center gap-2 border-b border-[rgba(0,200,180,0.12)] bg-white/5 px-4 py-3">
            <div className="h-2.5 w-2.5 rounded-full bg-[#ff4560]" />
            <div className="h-2.5 w-2.5 rounded-full bg-[#ffd060]" />
            <div className="h-2.5 w-2.5 rounded-full bg-[#00c8b4]" />
            <div className="mx-auto text-[11px] uppercase tracking-[0.1em] text-[#4a6070]">
              cveriskpilot — live triage demo
            </div>
          </div>

          <div className="space-y-1 px-6 py-6 text-left font-mono text-sm leading-8">
            <div>
              <span className="text-[#00c8b4]">▶ </span>
              <span className="text-[#c8d8e8]">
                upload scan_results.json --context &quot;production k8s
                cluster&quot;
              </span>
            </div>
            <div className="text-[#4a6070]">
              [✦] Ingesting 847 findings from 12 scanners...
            </div>
            <div className="text-[#4a6070]">
              [✦] Running AI risk correlation engine...
            </div>

            <br />

            <div className="text-[#4a6070]">
              <span className="text-[#ff4560] font-bold">CRITICAL</span>{" "}
              CVE-2024-3400 · PAN-OS RCE · CVSS 10.0 · KEV ⚡
            </div>
            <div className="text-[#4a6070]">
              └─ <span className="text-[#ffd060]">Impact:</span> Perimeter
              firewall fully exposed — APT exploitation active
            </div>
            <div className="text-[#4a6070]">
              └─ <span className="text-[#00c8b4]">Action:</span> Apply PAN-OS
              hotfix · ETA 2h · Ticket #INC-0042 ✓
            </div>

            <br />

            <div className="text-[#4a6070]">
              <span className="text-[#00c8b4]">[✓]</span> 847 findings →{" "}
              <span className="text-[#00c8b4]">9 critical decisions</span> ready
              for your team
            </div>
            <div>
              <span className="text-[#00c8b4]">▶ </span>
              <span className="inline-block h-4 w-2 animate-pulse bg-[#00c8b4] align-middle" />
            </div>
          </div>
        </div>
      </section>

      <section id="how" className="relative z-10 mx-auto max-w-7xl px-6 py-24">
        <div className="text-[11px] uppercase tracking-[0.2em] text-[#00c8b4]">
          // How It Works
        </div>
        <h2 className="mt-3 text-3xl font-extrabold leading-tight tracking-[-0.02em] text-white sm:text-5xl">
          From scan file to action plan
          <br />
          in under 3 minutes.
        </h2>
        <p className="mt-4 max-w-2xl text-base leading-7 text-[#c8d8e8]/70">
          No manual research. No copy-paste. No analyst burnout. Just
          prioritized decisions.
        </p>

        <div className="mt-14 grid gap-5 md:grid-cols-2 xl:grid-cols-4">
          {steps.map((step) => (
            <div
              key={step.num}
              className="relative overflow-hidden rounded border border-[rgba(0,200,180,0.12)] bg-[#070e1a] px-6 py-7 transition hover:border-[#00c8b4]"
            >
              <div className="absolute inset-x-0 top-0 h-0.5 bg-[#00c8b4]/50" />
              <div className="text-5xl font-extrabold leading-none text-[rgba(0,200,180,0.08)]">
                {step.num}
              </div>
              <h3 className="mt-3 text-lg font-bold text-white">
                {step.title}
              </h3>
              <p className="mt-2 text-sm leading-6 text-[#4a6070]">
                {step.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section id="features" className="relative z-10 mx-auto max-w-7xl px-6 py-24">
        <div className="text-[11px] uppercase tracking-[0.2em] text-[#00c8b4]">
          // Features
        </div>
        <h2 className="mt-3 text-3xl font-extrabold leading-tight tracking-[-0.02em] text-white sm:text-5xl">
          Everything your team needs
          <br />
          to move fast on risk.
        </h2>

        <div className="mt-14 grid gap-4 md:grid-cols-2 xl:grid-cols-3">
          {features.map((feature) => (
            <div
              key={feature.title}
              className="rounded border border-[rgba(0,200,180,0.12)] bg-[#070e1a] p-6 transition hover:-translate-y-0.5 hover:border-[#00c8b4]"
            >
              <div className="mb-3 text-2xl">{feature.icon}</div>
              <h3 className="text-lg font-bold text-white">{feature.title}</h3>
              <p className="mt-2 text-sm leading-6 text-[#4a6070]">
                {feature.desc}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section id="pricing" className="relative z-10 mx-auto max-w-7xl px-6 py-24">
        <div className="text-[11px] uppercase tracking-[0.2em] text-[#00c8b4]">
          // Pricing
        </div>
        <h2 className="mt-3 text-3xl font-extrabold leading-tight tracking-[-0.02em] text-white sm:text-5xl">
          Start free. Scale when
          <br />
          you need to.
        </h2>
        <p className="mt-4 max-w-2xl text-base leading-7 text-[#c8d8e8]/70">
          No credit card required for the free tier. Upgrade anytime.
        </p>

        <div className="mt-14 grid gap-4 lg:grid-cols-3">
          {pricing.map((plan) => (
            <div
              key={plan.tier}
              className={`relative rounded-md border bg-[#070e1a] p-8 transition ${
                plan.featured
                  ? "border-[#00c8b4] shadow-[0_0_40px_rgba(0,200,180,0.1)]"
                  : "border-[rgba(0,200,180,0.12)]"
              }`}
            >
              {plan.featured ? (
                <div className="absolute left-1/2 top-0 -translate-x-1/2 rounded-b bg-[#00c8b4] px-3 py-1 text-[10px] font-bold uppercase tracking-[0.12em] text-[#040810]">
                  Most Popular
                </div>
              ) : null}

              <div className="text-[11px] uppercase tracking-[0.15em] text-[#4a6070]">
                {plan.tier}
              </div>
              <div className="mt-2 text-4xl font-extrabold text-white">
                {plan.price}
                <span className="ml-1 text-base font-normal text-[#4a6070]">
                  {plan.suffix}
                </span>
              </div>
              <p className="mt-2 text-sm text-[#4a6070]">{plan.desc}</p>

              <ul className="mt-6 space-y-3">
                {plan.features.map((item) => (
                  <li
                    key={item.label}
                    className={`flex items-start gap-2 text-sm ${
                      item.locked ? "text-[#4a6070]/60" : "text-[#c8d8e8]"
                    }`}
                  >
                    <span
                      className={
                        item.locked ? "text-[#4a6070]" : "text-[#00c8b4]"
                      }
                    >
                      {item.locked ? "⊘" : "✓"}
                    </span>
                    <span>{item.label}</span>
                  </li>
                ))}
              </ul>

              <Link
                href="/signup"
                className={`mt-8 inline-flex w-full items-center justify-center rounded border px-4 py-3 text-xs uppercase tracking-[0.08em] transition ${
                  plan.ctaPrimary
                    ? "border-[#00c8b4] bg-[#00c8b4] font-bold text-[#040810] hover:bg-[#00ffe8]"
                    : "border-[rgba(0,200,180,0.12)] text-[#4a6070] hover:border-[#00c8b4] hover:text-[#00c8b4]"
                }`}
              >
                {plan.cta}
              </Link>
            </div>
          ))}
        </div>
      </section>

      <footer className="relative z-10 border-t border-[rgba(0,200,180,0.12)] px-6 py-10 text-center text-xs uppercase tracking-[0.08em] text-[#4a6070]">
        © 2026 CVERiskPilot · Built for defenders · cveriskpilot.com ·{" "}
        <Link href="/login" className="transition hover:text-[#00c8b4]">
          Login
        </Link>
      </footer>
    </main>
  );
}
