import { NextResponse } from "next/server";

import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { getCachedDashboardOverview } from "@/lib/cache/workload-cache";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";
import {
  createDashboardStatsFromFindings,
} from "@/lib/services/dashboard";

export async function GET(request: Request) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const data = await getCachedDashboardOverview(auth.organizationId, async () => {
      const { uploadRepository } = await getIngestionRuntime();
      const [normalizedFindings, uploadRecords] = await Promise.all([
        uploadRepository.listFindingsByTenant(auth.organizationId),
        uploadRepository.listByTenant(auth.organizationId),
      ]);

      const parsedUploadCount = uploadRecords.filter(
        ({ uploadJob }) =>
          uploadJob.status === "parsed" || uploadJob.status === "enrichment_pending",
      ).length;

      return {
        source: "ingestion" as const,
        stats: createDashboardStatsFromFindings(normalizedFindings),
        parsedUploadCount,
        totalFindingCount: normalizedFindings.length,
      };
    });

    return NextResponse.json({
      ok: true,
      data,
    });
  } catch (error) {
    console.error("Dashboard overview failed:", error);
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "overview_unavailable",
          message: "Unable to load dashboard overview.",
        },
      },
      { status: 500 },
    );
  }
}
