import { getDb } from "@/lib/db";
import { D1BillingRepository } from "@/lib/billing/d1-repository";
import { PostgresBillingRepository } from "@/lib/billing/postgres-repository";
import {
  InMemoryBillingRepository,
  type BillingRepository,
} from "@/lib/billing/repository";
import { getOrCreatePostgresQueryClient } from "@/lib/platform/postgres";
import { getPlatformProfile } from "@/lib/platform/runtime";

type BillingRuntime = {
  billingRepository: BillingRepository;
};

const fallbackRuntime: BillingRuntime = {
  billingRepository: new InMemoryBillingRepository(),
};

function isFallbackRuntimeError(error: unknown) {
  if (!(error instanceof Error)) {
    return false;
  }

  return (
    /Cloudflare D1 binding/i.test(error.message) ||
    /getCloudflareContext/i.test(error.message) ||
    /Database schema is not initialized/i.test(error.message)
  );
}

export async function getBillingRuntime(): Promise<BillingRuntime> {
  const platform = getPlatformProfile();

  if (platform.databaseDriver === "postgres") {
    const postgresClient = await getOrCreatePostgresQueryClient();

    if (postgresClient) {
      return {
        billingRepository: new PostgresBillingRepository(postgresClient),
      };
    }
  }

  try {
    const db = await getDb();
    return {
      billingRepository: new D1BillingRepository(db),
    };
  } catch (error) {
    if (isFallbackRuntimeError(error)) {
      return fallbackRuntime;
    }

    throw error;
  }
}
