import type { PostgresQueryClient } from "@/lib/platform/database";
import { PostgresAppDatabase } from "@/lib/platform/database";
import {
  SqlNormalizedFindingRepository,
  SqlParseOutcomeRepository,
  SqlRawArtifactRepository,
  SqlUploadJobRepository,
  SqlUploadRepository,
} from "@/lib/ingestion/sql-repository";

export class PostgresRawArtifactRepository extends SqlRawArtifactRepository {
  constructor(client: PostgresQueryClient) {
    super(new PostgresAppDatabase(client));
  }
}

export class PostgresUploadJobRepository extends SqlUploadJobRepository {
  constructor(client: PostgresQueryClient) {
    super(new PostgresAppDatabase(client));
  }
}

export class PostgresParseOutcomeRepository extends SqlParseOutcomeRepository {
  constructor(client: PostgresQueryClient) {
    super(new PostgresAppDatabase(client));
  }
}

export class PostgresNormalizedFindingRepository extends SqlNormalizedFindingRepository {
  constructor(client: PostgresQueryClient) {
    super(new PostgresAppDatabase(client));
  }
}

export class PostgresUploadRepository extends SqlUploadRepository {
  constructor(client: PostgresQueryClient) {
    super(new PostgresAppDatabase(client));
  }
}
