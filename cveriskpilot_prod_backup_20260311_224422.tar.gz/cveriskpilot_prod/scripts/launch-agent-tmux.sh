#!/usr/bin/env bash
set -euo pipefail

SESSION_NAME="${1:-cveriskpilot-agents}"
REPO_ROOT="${2:-.}"
REPO_ROOT="$(cd "$REPO_ROOT" && pwd)"

if ! command -v tmux >/dev/null 2>&1; then
  echo "tmux is not installed. Run: sudo apt update && sudo apt install -y tmux"
  exit 1
fi

if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
  echo "Session already exists: $SESSION_NAME"
  echo "Attach with: tmux attach -t $SESSION_NAME"
  exit 0
fi

tmux new-session -d -s "$SESSION_NAME" -c "$REPO_ROOT" -n orchestrator
tmux send-keys -t "$SESSION_NAME:orchestrator" "clear; echo 'Role: Orchestrator Agent'" C-m

tmux new-window -t "$SESSION_NAME" -n pm -c "$REPO_ROOT"
tmux send-keys -t "$SESSION_NAME:pm" "clear; echo 'Role: Program Manager Agent'" C-m

tmux new-window -t "$SESSION_NAME" -n product -c "$REPO_ROOT"
tmux send-keys -t "$SESSION_NAME:product" "clear; echo 'Role: SaaS Product & UX Audit Agent'" C-m

tmux new-window -t "$SESSION_NAME" -n security -c "$REPO_ROOT"
tmux send-keys -t "$SESSION_NAME:security" "clear; echo 'Role: Security / Architecture / Platform Audit Agent'" C-m

echo "Created tmux session: $SESSION_NAME"
echo "Attach with: tmux attach -t $SESSION_NAME"