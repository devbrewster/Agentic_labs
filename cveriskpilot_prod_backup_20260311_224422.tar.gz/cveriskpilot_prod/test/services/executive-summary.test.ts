import { describe, expect, it } from "vitest";

import { getExecutiveSummaryReport } from "@/lib/services/reports";

describe("executive summary report", () => {
  it("returns a safe empty summary when no organization is provided", async () => {
    const report = await getExecutiveSummaryReport();

    expect(report.generatedAt).toBeTruthy();
    expect(report.source).toBe("ingestion");
    expect(report.totals.findings).toBe(0);
    expect(report.topFindings).toEqual([]);
  });

  it("includes explicit uncertainty tracking in the empty summary", async () => {
    const report = await getExecutiveSummaryReport();

    expect(report.uncertainty.count).toBe(0);
    expect(report.uncertainty.items).toEqual([]);
  });
});
