export type RuntimePlatform = "cloudflare" | "aws" | "local";

export type DatabaseDriver = "cloudflare_d1" | "postgres" | "in_memory";

export type ArtifactStorageDriver = "d1" | "local_fs" | "s3";

export type AppPlatformProfile = {
  runtimePlatform: RuntimePlatform;
  databaseDriver: DatabaseDriver;
  artifactStorageDriver: ArtifactStorageDriver;
  appBaseUrl: string | null;
  organizationIsolationRequired: true;
};
