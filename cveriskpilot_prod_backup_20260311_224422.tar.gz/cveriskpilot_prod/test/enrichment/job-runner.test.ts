import { describe, expect, it } from "vitest";

import { createDefaultEnrichmentService } from "@/lib/enrichment";
import { EnrichmentJobRunner } from "@/lib/enrichment/job-runner";
import { InMemoryEnrichmentRepository } from "@/lib/enrichment/repository";
import { genericCsvExampleInput } from "@/lib/ingestion/examples/generic-csv-example";
import { createIngestionTestContext } from "@/test/helpers/create-ingestion-test-context";
import type { EnrichmentProvider } from "@/types/enrichment";

async function createParsedUpload() {
  const context = await createIngestionTestContext();
  const upload = await context.uploadService.createUploadJob({
    tenantId: null,
    selectedSourceType: "generic_csv",
    originalFilename: "findings.csv",
    mimeType: "text/csv",
    sizeBytes: Buffer.byteLength(genericCsvExampleInput),
    body: Buffer.from(genericCsvExampleInput, "utf8"),
  });

  const parseResult = await context.parseJobRunner.run(upload.uploadJob.id, { force: true });

  expect(parseResult.uploadJob.status).toBe("enrichment_pending");
  expect(parseResult.outcome?.findings.length).toBeGreaterThan(0);

  return {
    context,
    uploadJobId: upload.uploadJob.id,
    findingCount: parseResult.outcome?.findings.length ?? 0,
  };
}

describe("EnrichmentJobRunner", () => {
  it("runs enrichment and stores snapshots for every finding/provider pair", async () => {
    const { context, uploadJobId, findingCount } = await createParsedUpload();
    const enrichmentRepository = new InMemoryEnrichmentRepository();
    const runner = new EnrichmentJobRunner(
      context.repository,
      enrichmentRepository,
      createDefaultEnrichmentService(),
    );
    const providers: EnrichmentProvider[] = ["nvd", "cisa_kev"];

    const result = await runner.run({
      uploadJobId,
      providers,
      triggeredBy: "test-suite",
      force: false,
    });

    expect(result.skipped).toBe(false);
    expect(result.run.status).toBe("completed");
    expect(result.run.providerCount).toBe(findingCount * providers.length);
    expect(result.snapshots.length).toBe(findingCount * providers.length);
    expect(result.run.successCount).toBe(result.run.providerCount);
    expect(result.run.errorCount).toBe(0);
  });

  it("skips duplicate runs unless forced", async () => {
    const { context, uploadJobId } = await createParsedUpload();
    const enrichmentRepository = new InMemoryEnrichmentRepository();
    const runner = new EnrichmentJobRunner(
      context.repository,
      enrichmentRepository,
      createDefaultEnrichmentService(),
    );
    const providers: EnrichmentProvider[] = ["nvd", "cisa_kev"];

    const firstRun = await runner.run({
      uploadJobId,
      providers,
      triggeredBy: "test-suite",
      force: false,
    });
    const secondRun = await runner.run({
      uploadJobId,
      providers,
      triggeredBy: "test-suite",
      force: false,
    });
    const forcedRun = await runner.run({
      uploadJobId,
      providers,
      triggeredBy: "test-suite",
      force: true,
    });

    expect(firstRun.skipped).toBe(false);
    expect(secondRun.skipped).toBe(true);
    expect(secondRun.run.id).toBe(firstRun.run.id);
    expect(forcedRun.skipped).toBe(false);
    expect(forcedRun.run.id).not.toBe(firstRun.run.id);
  });

  it("returns partial status when at least one provider fails", async () => {
    const { context, uploadJobId, findingCount } = await createParsedUpload();
    const enrichmentRepository = new InMemoryEnrichmentRepository();
    const runner = new EnrichmentJobRunner(
      context.repository,
      enrichmentRepository,
      createDefaultEnrichmentService(),
    );

    const result = await runner.run({
      uploadJobId,
      providers: ["nvd", "wiz"],
      triggeredBy: "test-suite",
      force: false,
    });

    expect(result.run.status).toBe("partial");
    expect(result.run.errorCount).toBe(findingCount);
    expect(result.snapshots.some((snapshot) => snapshot.provider === "wiz")).toBe(true);
    expect(result.snapshots.some((snapshot) => snapshot.status === "error")).toBe(true);
  });
});
