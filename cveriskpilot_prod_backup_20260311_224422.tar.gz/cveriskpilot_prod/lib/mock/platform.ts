export const reportCards = [
  {
    title: "Executive Summary",
    description:
      "High-level risk posture summary for leadership review with business-impact framing and remediation priorities.",
    badge: "PDF / Export Ready",
  },
  {
    title: "Trend Analysis",
    description:
      "Historical finding movement, remediation velocity, and severity drift across reporting windows.",
    badge: "Future Charts",
  },
  {
    title: "Asset Risk Map",
    description:
      "Asset-centric risk concentration view to highlight exposed systems and recurring hotspots.",
    badge: "Topology Placeholder",
  },
  {
    title: "Analyst Disposition Summary",
    description:
      "Breakdown of true risk, mitigated, false positive, accepted risk, and not-applicable decisions.",
    badge: "Audit Trail Ready",
  },
  {
    title: "Open Critical Findings",
    description:
      "Focused export for unresolved critical issues and associated remediation ownership.",
    badge: "Board Export",
  },
] as const;

export const integrationCards = [
  { name: "NVD", status: "Configured", category: "Intel" },
  { name: "CISA KEV", status: "Configured", category: "Intel" },
  { name: "Wiz", status: "Configured", category: "Scanner" },
  { name: "Snyk", status: "Configured", category: "Scanner" },
  { name: "Tenable", status: "Coming Soon", category: "Scanner" },
  { name: "Qualys", status: "Coming Soon", category: "Scanner" },
  { name: "Rapid7", status: "Not Connected", category: "Scanner" },
  { name: "Jira", status: "Configured", category: "Workflow" },
  { name: "ServiceNow", status: "Coming Soon", category: "Workflow" },
  { name: "Claude API", status: "Configured", category: "AI" },
] as const;

export const settingsSections = [
  {
    title: "Workspace Settings",
    description:
      "Organization profile, workspace naming, default environment labels, and team scoping controls.",
  },
  {
    title: "AI Settings",
    description:
      "Model routing, prompt policy, confidence thresholds, and future generation guardrails.",
  },
  {
    title: "Upload Settings",
    description:
      "Accepted report types, ingestion defaults, source tagging, and parser behavior preferences.",
  },
  {
    title: "Risk Scoring Settings",
    description:
      "Severity weighting, exploit influence, KEV boost, business criticality modifiers, and environment weighting.",
  },
  {
    title: "Analyst Feedback Rules",
    description:
      "Disposition policies, rationale requirements, and future rules for retaining analyst override decisions.",
  },
] as const;
