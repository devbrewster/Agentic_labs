import { afterEach, describe, expect, it } from "vitest";

import type { PostgresQueryClient } from "@/lib/platform/database";
import { clearPostgresQueryClient, configurePostgresQueryClient } from "@/lib/platform/postgres";
import { getEnrichmentRuntime } from "@/lib/enrichment/runtime";

describe("enrichment runtime", () => {
  afterEach(() => {
    clearPostgresQueryClient();
    delete process.env.DATABASE_URL;
    delete process.env.UPLOAD_STORAGE_DRIVER;
  });

  it("selects the Postgres enrichment repository when a Postgres client is configured", async () => {
    process.env.DATABASE_URL = "postgres://example";
    process.env.UPLOAD_STORAGE_DRIVER = "local_fs";

    const client: PostgresQueryClient = {
      async query() {
        return {
          rows: [],
          rowCount: 0,
        };
      },
    };

    configurePostgresQueryClient(client);

    const runtime = await getEnrichmentRuntime();

    expect(runtime.enrichmentRepository.constructor.name).toBe(
      "PostgresEnrichmentRepository",
    );
  });
});
