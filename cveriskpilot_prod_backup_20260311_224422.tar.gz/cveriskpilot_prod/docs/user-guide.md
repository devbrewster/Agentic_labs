# CVERiskPilot User Guide (Living Document)

Last updated: 2026-03-11
Owner: Product Engineering

## Purpose

This guide explains:

- what CVERiskPilot currently does
- how to use each implemented area
- known issues you may hit
- exact fixes/workarounds
- how to keep this guide updated after every chunk/phase completion

This is a living document and should be updated whenever a chunk or phase changes behavior.

## Product Scope (Current)

CVERiskPilot currently supports:

- SOC-style dashboard shell and navigation
- upload intake for scan files
- parsing for `generic_csv`
- normalized findings storage in D1
- upload diagnostics (metadata, warnings, errors, findings preview)
- findings and dashboard overview APIs reading ingestion-backed data

Not fully implemented yet:

- real Nessus parser
- real Qualys parser
- real Rapid7 parser
- enrichment pipeline (NVD/KEV/Wiz/Snyk)
- full AI triage generation pipeline

Enrichment status:

- P3-1 to P3-3 complete with NVD + CISA KEV provider stubs
- enrichment run lifecycle is implemented (`queued`, `running`, `completed`, `partial`, `failed`)
- NVD can run live API lookups when `NVD_API_KEY` is configured

Live NVD testing:

- set `NVD_API_KEY` in `.env.local` to enable live NVD lookups
- if `NVD_API_KEY` is unset, NVD uses deterministic stub results
- browser clients should call `GET /api/nvd?cve=...` instead of direct NVD calls

## Environment Setup

1. Install dependencies:
```bash
npm install
```

2. Configure local env:
```bash
cp .env.local.example .env.local
```

3. Apply local D1 schema:
```bash
npm run db:migrate:local
```

4. Run app in Next dev:
```bash
npm run dev
```

5. Run app in Workers preview:
```bash
npm run preview
```

## Core Routes

Main app routes:

- `/dashboard`
- `/dashboard/findings`
- `/dashboard/uploads`
- `/dashboard/action-plans`
- `/dashboard/reports`
- `/dashboard/integrations`
- `/dashboard/settings`
- `/about`

Upload/ingestion API routes:

- `GET /api/uploads`
- `POST /api/uploads`
- `GET /api/uploads/:id`
- `GET /api/uploads/:id/findings`
- `GET /api/uploads/:id/errors`
- `POST /api/uploads/:id/reparse`
- `GET /api/findings`
- `GET /api/findings/:id/disposition`
- `PATCH /api/findings/:id/disposition`
- `GET /api/dashboard/overview`

Enrichment API routes:

- `POST /api/enrichments`
- `GET /api/enrichments/:id`
- `GET /api/findings/:id/enrichment`
- `GET /api/nvd?cve=CVE-YYYY-NNNN`
- `GET /api/findings/:id/analysis`
- `POST /api/findings/:id/analysis`

## How to Use the App

### 1) Dashboard Overview (`/dashboard`)

Use this for high-level metrics and triage context.

What you should see:

- summary cards
- priority findings area
- right-hand finding details/analysis panel
- persisted analyst disposition controls (save/load decision + rationale + context)
- AI narrative draft scaffold controls:
  - `Generate Stub Draft` (deterministic local output)
  - `Run Claude Draft` (uses server-side `ANTHROPIC_API_KEY` when configured)

### Claude setup for P3-7 scaffold

Add to `.env.local`:

```bash
ANTHROPIC_API_KEY=your_key_here
ANTHROPIC_MODEL=claude-3-5-sonnet-latest
```

Optional timeout:

```bash
CLAUDE_REQUEST_TIMEOUT_MS=20000
```

### 2) Findings Management (`/dashboard/findings`)

Use this for filter/sort/search and finding review.

What you should see:

- findings table
- filters and sorting
- ingestion-backed rows when parsed uploads exist

### 3) Upload Workflow (`/dashboard/uploads`)

Use this for scan ingestion and parser diagnostics.

Standard flow:

1. Drop CSV file in upload zone
2. Upload job appears in recent jobs
3. Parse runs and status transitions
4. Select job in table to see diagnostics

Expected statuses:

- `queued`
- `parsing`
- `parsed`
- `enrichment_pending`
- `failed`

Diagnostics panel includes:

- parse metadata
- parser warnings
- parser errors
- findings preview

### 4) Action Plans / Reports / Integrations / Settings

These are currently shell views for structure and roadmap alignment.

## Status Meanings

- `queued`: artifact accepted, waiting parse execution
- `parsing`: parser running
- `parsed`: parse completed
- `enrichment_pending`: parse completed and waiting enrichment stage
- `failed`: parse failed (see diagnostics for structured errors)

## Known Issues and Fixes

### Issue A: `D1_ERROR: no such table ...`

Cause:

- local schema not migrated after table changes

Fix:

```bash
npm run db:migrate:local
```

### Issue B: `Artifact content not found for storage key ...`

Cause:

- stale/orphaned DB record where `raw_artifacts` exists but `raw_artifact_contents` is missing

Fix (admin manual cleanup until superadmin UI exists):

1. Identify failing checksum/storage key
2. Delete only targeted stale rows in local D1
3. Re-upload file
4. Log cleanup in `docs/upload-stabilization-log.md`

Important:

- cleanup must be checksum/storage-key scoped only
- do not run broad deletes

### Issue C: Upload job shows findings count but details/findings endpoint empty

Previously caused by:

- `INSERT OR REPLACE` parent row replacement deleting child rows via cascade

Fix already applied:

- repository now uses `INSERT ... ON CONFLICT(id) DO UPDATE` in
  - `raw_artifacts`
  - `upload_jobs`

## Failure Triage Checklist

When upload/parsing fails:

1. Verify schema:
```bash
npm run db:migrate:local
```
2. Check upload details:
```bash
curl -s http://localhost:3000/api/uploads/<UPLOAD_JOB_ID>
```
3. Check parser errors:
```bash
curl -s http://localhost:3000/api/uploads/<UPLOAD_JOB_ID>/errors
```
4. If artifact read error occurs, inspect stale records by checksum/storage key
5. Perform targeted admin cleanup and retry upload

## Current Validation Snapshot

Completed stabilization chunks:

- Chunk A: schema/environment verification
- Chunk B: `next dev` real upload verification
- Chunk C: `npm run preview` real upload verification
- Chunk D: dedupe + forced reparse verification
- Chunk E: diagnostics/operator visibility verification
- Chunk F: failure-path verification
- Chunk G: scope closeout review

Pending:

- none for upload stabilization scope

Source of truth:

- `docs/upload-stabilization-plan.md`
- `docs/upload-stabilization-log.md`
- `docs/admin-runbook.md`
- `docs/todo-backlog.md`

## Guide Update Policy (Required)

Update this file after every completed chunk or phase.

Required updates each time:

1. Update `Last updated` date
2. Add/modify behavior in `Product Scope` or `How to Use`
3. Add any new bug/fix in `Known Issues and Fixes`
4. Update `Current Validation Snapshot`
5. Add a short entry in the changelog below

## User Guide Changelog

### 2026-03-11

- created initial full user guide
- documented implemented dashboard + ingestion behavior
- added known bug/fix playbooks
- recorded completion status through Chunk E
- updated completion status through Chunk F
- updated completion status through Chunk G (stabilization complete)
- Phase 3 started: enrichment schema and typed contracts (P3-1) added
- Phase 3 P3-2 completed: enrichment provider abstraction + NVD/CISA KEV stub clients + service tests
- Phase 3 P3-3 completed: enrichment job runner lifecycle + idempotency skip/force behavior + tests
- Phase 3 P3-4 completed: enrichment trigger/detail APIs and finding-level enrichment snapshots endpoint
- NVD compliance scaffolding completed:
  - footer/about/CVE attribution notice
  - source-separated CVE detail sections
  - backend-safe NVD route with cache/fallback and rate limiting primitives
- Phase 3 P3-5 completed: findings UI now surfaces per-finding enrichment status/signals in list, table, and details panel
