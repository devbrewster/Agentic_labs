export type AuthErrorCode =
  | "account_delete_failed"
  | "email_send_failed"
  | "email_taken"
  | "invalid_credentials"
  | "invalid_current"
  | "invalid_input"
  | "invalid_organization"
  | "invalid_session"
  | "invalid_token"
  | "method_not_allowed"
  | "not_authenticated"
  | "organization_forbidden"
  | "not_verified"
  | "server_error"
  | "token_expired"
  | "todo_not_implemented";

export type AuthApiError = {
  code: AuthErrorCode;
  message: string;
  details?: Record<string, string> | undefined;
};

export type AuthApiSuccess<T = Record<string, never>> = {
  ok: true;
  data: T;
};

export type AuthApiFailure = {
  ok: false;
  reason: AuthErrorCode;
  error: AuthApiError;
};

export type AuthApiResponse<T = Record<string, never>> =
  | AuthApiSuccess<T>
  | AuthApiFailure;

export type SignupPayload = {
  email: string;
  password: string;
  display_name: string;
};

export type LoginPayload = {
  email: string;
  password: string;
};

export type MagicLinkPayload = {
  email: string;
};

export type DisplayNamePatchPayload = {
  display_name: string;
};

export type PasswordChangePayload = {
  current_password: string;
  new_password: string;
};

export type PasswordResetRequestPayload = {
  email: string;
};

export type PasswordResetPayload = {
  token: string;
  new_password: string;
};

export type UserRecord = {
  id: string;
  email: string;
  password_hash: string;
  display_name: string;
  email_verified: number;
  created_at: string;
};

export type SafeUser = {
  id: string;
  email: string;
  display_name: string;
  email_verified: boolean;
  created_at: string;
  current_organization_id?: string | null;
  organization_context?: CurrentOrganizationContext;
};

export type SessionRecord = {
  id: string;
  user_id: string;
  active_organization_id: string | null;
  expires_at: string;
  created_at: string;
  user_agent: string | null;
  ip_address: string | null;
  revoked_at: string | null;
};

export type EmailVerificationTokenRecord = {
  id: string;
  user_id: string;
  email: string;
  token_hash: string;
  expires_at: string;
  created_at: string;
  used_at: string | null;
};

export type PasswordResetTokenRecord = {
  id: string;
  user_id: string;
  email: string;
  token_hash: string;
  expires_at: string;
  created_at: string;
  used_at: string | null;
};
import type { CurrentOrganizationContext } from "@/types/organization";
