import {
  apiError,
  apiSuccess,
  buildVerificationUrl,
  createEmailVerificationToken,
  getUserByEmail,
  readJsonBody,
  sanitizeUser,
  withAuthRoute,
} from "@/lib/auth";
import { dbRun } from "@/lib/db";
import { sendVerificationEmail } from "@/lib/mailer";
import { createDefaultOrganizationForUser } from "@/lib/organizations/service";
import { hashPassword } from "@/lib/passwords";
import { validateSignupPayload } from "@/lib/validators";

export const POST = withAuthRoute(async function POST(request: Request) {
  const payload = await readJsonBody(request);
  const validation = validateSignupPayload(payload);

  if (!validation.success) {
    return apiError("invalid_input", validation.message, 400, validation.fieldErrors);
  }

  const existingUser = await getUserByEmail(validation.data.email);

  if (existingUser) {
    return apiError("email_taken", "An account with that email already exists.", 409);
  }

  const now = new Date().toISOString();
  const userId = crypto.randomUUID();
  const passwordHash = await hashPassword(validation.data.password);

  await dbRun(
    `INSERT INTO users (
      id,
      email,
      password_hash,
      display_name,
      email_verified,
      created_at
    ) VALUES (?, ?, ?, ?, 0, ?)`,
    userId,
    validation.data.email,
    passwordHash,
    validation.data.display_name,
    now,
  );

  let tokenId: string | null = null;
  let organizationId: string | null = null;

  try {
    const organization = await createDefaultOrganizationForUser({
      userId,
      email: validation.data.email,
      displayName: validation.data.display_name,
      createdAt: now,
    });
    organizationId = organization.organizationId;

    const verificationToken = await createEmailVerificationToken(
      userId,
      validation.data.email,
    );
    tokenId = verificationToken.id;

    const mail = await sendVerificationEmail({
      to: validation.data.email,
      displayName: validation.data.display_name,
      verificationUrl: buildVerificationUrl(request, verificationToken.token),
    });

    return apiSuccess(
      {
        user: sanitizeUser({
          id: userId,
          email: validation.data.email,
          password_hash: passwordHash,
          display_name: validation.data.display_name,
          email_verified: 0,
          created_at: now,
        }),
        organization_id: organization.organizationId,
        verification_expires_at: verificationToken.expiresAt,
        email_preview_url: mail.previewUrl,
        message: "Signup successful. Check your email to verify your account.",
      },
      201,
    );
  } catch (error) {
    console.error("Signup email send failed:", error);

    if (tokenId) {
      await dbRun("DELETE FROM email_verification_tokens WHERE id = ?", tokenId);
    }

    await dbRun("DELETE FROM users WHERE id = ?", userId);
    if (organizationId) {
      await dbRun("DELETE FROM organizations WHERE id = ?", organizationId);
    }

    return apiError("email_send_failed", "Unable to send verification email.", 500);
  }
});
