# AWS Staging Cutover Runbook

Last updated: 2026-03-11  
Status: active

## Purpose

This runbook defines the staging deployment path for the application under:

- `app.cveriskpilot.com`

It assumes:

- AWS infrastructure has already been created from `infra/aws`
- the application image is built from this repo
- PostgreSQL will be the active database
- S3 will store uploaded artifacts

## Preconditions

Complete these before cutover:

1. Terraform stack applied successfully.
2. ECR repository exists.
3. RDS PostgreSQL instance is available.
4. S3 uploads bucket exists.
5. Secrets Manager secret exists.
6. ACM certificate validation records are added if DNS is not managed in Route53.
7. DNS for `app.cveriskpilot.com` can be pointed to the ALB.

## Required inputs

You need:

- AWS account access
- Docker installed locally or in CI
- AWS CLI authenticated
- `psql` available for schema migration
- Terraform outputs from `infra/aws`

Important outputs:

- `ecr_repository_url`
- `alb_dns_name`
- `database_endpoint`
- `database_name`
- `app_secret_name`
- `uploads_bucket_name`

## Runtime configuration

The ECS app expects these values:

```env
APP_BASE_URL=https://app.cveriskpilot.com
APP_DEPLOYMENT_MODE=subdomain_root
NEXT_PUBLIC_APP_DEPLOYMENT_MODE=subdomain_root
APP_DOMAIN_HOST=app.cveriskpilot.com
NEXT_PUBLIC_APP_DOMAIN_HOST=app.cveriskpilot.com

DATABASE_URL=postgres://...
POSTGRES_SSL_MODE=require
POSTGRES_POOL_MAX=10
POSTGRES_IDLE_TIMEOUT_MS=30000
POSTGRES_CONNECTION_TIMEOUT_MS=10000

UPLOAD_STORAGE_DRIVER=s3
UPLOAD_S3_BUCKET=<bucket>
AWS_REGION=us-east-1

JWT_SECRET=<secret>
SESSION_SECRET=<secret>

NVD_API_KEY=<optional>
ANTHROPIC_API_KEY=<optional>
MAIL_FROM=<required for mail flows>
SMTP_HOST=<optional>
SMTP_PORT=<optional>
SMTP_USER=<optional>
SMTP_PASS=<optional>
```

## Step 1: Build and push the application image

Use the helper script:

```bash
AWS_REGION=us-east-1 \
APP_DOMAIN_HOST=app.cveriskpilot.com \
./scripts/aws/build_and_push_ecr.sh <ecr_repository_url> latest
```

Or manually:

```bash
npm run docker:build:aws
docker tag cveriskpilot-app:aws <ecr_repository_url>:latest
aws ecr get-login-password --region us-east-1 | docker login --username AWS --password-stdin <account>.dkr.ecr.us-east-1.amazonaws.com
docker push <ecr_repository_url>:latest
```

## Step 2: Update Terraform variables

Set these in `infra/aws/terraform.tfvars`:

```hcl
container_image   = "<ecr_repository_url>:latest"
container_port    = 3000
health_check_path = "/api/health"
```

If this is a staging cutover test, keep:

```hcl
desired_count = 1
```

## Step 3: Apply infrastructure changes

```bash
cd infra/aws
terraform init
terraform plan
terraform apply
```

## Step 4: Run PostgreSQL schema migration

Use the PostgreSQL schema track:

```bash
psql "$DATABASE_URL" -v ON_ERROR_STOP=1 -f database/postgres/schema.sql
```

This must succeed before the application receives traffic.

## Step 5: Populate Secrets Manager values

Update the ECS application secret with real values:

- `APP_BASE_URL`
- `DATABASE_URL`
- `JWT_SECRET`
- `SESSION_SECRET`
- `AWS_REGION`
- `UPLOAD_STORAGE_DRIVER`
- `UPLOAD_S3_BUCKET`
- optional API keys and SMTP values

At minimum, verify:

- `UPLOAD_STORAGE_DRIVER=s3`
- `UPLOAD_S3_BUCKET=<terraform output bucket>`
- `DATABASE_URL` points to RDS
- `APP_BASE_URL=https://app.cveriskpilot.com`

## Step 6: Smoke test using the ALB DNS name

Before DNS cutover:

1. Open `http://<alb_dns_name>/api/health`
2. Expect:
   - HTTP `200`
   - JSON `{ "ok": true, ... }`
3. Open:
   - `http://<alb_dns_name>/`
   - `http://<alb_dns_name>/findings`
   - `http://<alb_dns_name>/uploads`
4. Confirm the app resolves under root-mode routing.

## Step 7: DNS cutover for staging

If DNS remains in Cloudflare:

1. Create or update the `app.cveriskpilot.com` record to point at the ALB.
2. Ensure ACM certificate validation is complete first.
3. Wait for propagation.

## Step 8: Post-cutover validation

Validate these flows:

1. `GET /api/health` returns `200`
2. Login route loads
3. Dashboard overview loads
4. Uploads page loads
5. A test file upload succeeds
6. Reparse works
7. Findings load
8. Enrichment loads
9. Claude fallback or live generation behaves as expected
10. Org isolation still works across two separate test users/orgs

## Rollback plan

If the staging cutover fails:

1. Point DNS back to the previous target.
2. Reduce ECS desired count to `0` if needed.
3. Inspect:
   - ECS task logs
   - ALB target health
   - RDS connectivity
   - Secrets Manager values
4. Fix and redeploy a new image tag.

## Known risks

- The app now supports AWS runtime bootstrapping, but AWS staging has not yet been proven end-to-end in this repo.
- SMTP/API secrets must be populated before testing auth and live enrichment.
- The Cloudflare/OpenNext deploy path still exists; AWS should be treated as a separate runtime target, not mixed with the Workers deploy path.

## Exit criteria

AWS staging is considered successful only when:

1. ALB health checks stay green
2. App root routing works on `app.cveriskpilot.com`
3. PostgreSQL-backed app boot completes without D1 fallback
4. S3-backed upload flow works
5. Dashboard, findings, uploads, enrichment, and analysis flows complete successfully
