import type { ReactNode } from "react";

import { StatusPill } from "@/components/dashboard/StatusPill";

type AnalysisSectionCardProps = {
  title: string;
  badge?: string;
  children: ReactNode;
};

export function AnalysisSectionCard({
  title,
  badge,
  children,
}: AnalysisSectionCardProps) {
  return (
    <section className="border-t border-[rgba(0,200,180,0.06)] pt-4">
      <div className="mb-2 flex items-center gap-2 font-mono text-[0.62rem] uppercase tracking-[0.15em] text-[#5a7080]">
        <span>{title}</span>
        {badge ? <StatusPill tone="accent">{badge}</StatusPill> : null}
      </div>
      {children}
    </section>
  );
}
