"use client";

import { useMemo, useState } from "react";

import { StatusPill } from "@/components/dashboard/StatusPill";
import type { UploadJob } from "@/types/dashboard";

const statusTone = {
  queued: "default",
  processing: "warning",
  parsing: "warning",
  parsed: "accent",
  enrichment_pending: "accent",
  completed: "accent",
  failed: "danger",
} as const;

type UploadHistoryTableProps = {
  isLoading?: boolean;
  jobs: UploadJob[];
  onSelect?: (uploadJobId: string) => void;
  selectedUploadJobId?: string | null;
};

export function UploadHistoryTable({
  isLoading = false,
  jobs,
  onSelect,
  selectedUploadJobId = null,
}: UploadHistoryTableProps) {
  const uploadJobs = jobs;
  const rowsPerPage = 10;
  const [page, setPage] = useState(1);

  const totalPages = Math.max(1, Math.ceil(uploadJobs.length / rowsPerPage));
  const currentPage = Math.min(page, totalPages);

  const pagedJobs = useMemo(() => {
    const start = (currentPage - 1) * rowsPerPage;
    return uploadJobs.slice(start, start + rowsPerPage);
  }, [currentPage, uploadJobs]);

  return (
    <section className="overflow-hidden rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] shadow-[0_16px_40px_rgba(0,0,0,0.18)]">
      <div className="flex items-center gap-3 border-b border-[rgba(0,200,180,0.06)] px-4 py-3">
        <div className="font-mono text-[0.72rem] uppercase tracking-[0.14em] text-[var(--accent)]">
          // Recent Upload Jobs
        </div>
        <div className="ml-auto font-mono text-[0.62rem] uppercase tracking-[0.12em] text-[#5a7080]">
          {isLoading ? "loading..." : `${uploadJobs.length} jobs · page ${currentPage}/${totalPages}`}
        </div>
      </div>

      <div className="max-h-[26rem] overflow-x-auto overflow-y-auto">
        <table className="min-w-full table-fixed divide-y divide-[rgba(0,200,180,0.06)]">
          <thead>
            <tr className="bg-[rgba(255,255,255,0.01)]">
              {["Filename", "Source", "Status", "Uploaded", "Findings", "Operator"].map((header) => (
                <th
                  key={header}
                  className="sticky top-0 z-10 bg-[var(--bg-elevated)] px-4 py-3 text-left font-mono text-[0.58rem] uppercase tracking-[0.16em] text-[#5a7080]"
                >
                  {header}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-[rgba(0,200,180,0.06)]">
            {uploadJobs.length === 0 ? (
              <tr>
                <td
                  colSpan={6}
                  className="px-4 py-10 text-center font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#5a7080]"
                >
                  {isLoading ? "Loading upload jobs..." : "No ingestion jobs yet"}
                </td>
              </tr>
            ) : null}
            {pagedJobs.map((job) => (
              <tr
                key={job.id}
                onClick={() => onSelect?.(job.id)}
                className={`${
                  onSelect ? "cursor-pointer" : ""
                } hover:bg-[rgba(0,200,180,0.03)] ${
                  job.id === selectedUploadJobId ? "bg-[rgba(0,200,180,0.04)]" : ""
                }`}
              >
                <td className="px-4 py-3">
                  <div
                    title={job.filename}
                    className="max-w-[22rem] truncate whitespace-nowrap font-mono text-[0.72rem] text-[var(--text)]"
                  >
                    {job.filename}
                  </div>
                </td>
                <td className="px-4 py-3 font-mono text-[0.68rem] text-[#5a7080]">
                  {job.sourceType}
                </td>
                <td className="px-4 py-3">
                  <StatusPill tone={statusTone[job.status]}>{job.status}</StatusPill>
                </td>
                <td className="px-4 py-3 font-mono text-[0.68rem] text-[#5a7080]">
                  {job.uploadedAt.slice(0, 16).replace("T", " ")}
                </td>
                <td className="px-4 py-3 font-mono text-[0.72rem] text-[var(--text)]">
                  {job.findingsDetected ?? "pending"}
                </td>
                <td className="px-4 py-3 font-mono text-[0.68rem] text-[#5a7080]">
                  {job.uploadedBy}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {uploadJobs.length > rowsPerPage ? (
        <div className="flex items-center justify-end gap-2 border-t border-[rgba(0,200,180,0.06)] px-4 py-3">
          <button
            type="button"
            onClick={() => setPage((value) => Math.max(1, value - 1))}
            disabled={currentPage === 1}
            className="rounded border border-[rgba(0,200,180,0.2)] px-3 py-1 font-mono text-[0.64rem] uppercase tracking-[0.1em] text-[#9ab3c4] disabled:cursor-not-allowed disabled:opacity-40"
          >
            Prev
          </button>
          <button
            type="button"
            onClick={() => setPage((value) => Math.min(totalPages, value + 1))}
            disabled={currentPage === totalPages}
            className="rounded border border-[rgba(0,200,180,0.2)] px-3 py-1 font-mono text-[0.64rem] uppercase tracking-[0.1em] text-[#9ab3c4] disabled:cursor-not-allowed disabled:opacity-40"
          >
            Next
          </button>
        </div>
      ) : null}
    </section>
  );
}
