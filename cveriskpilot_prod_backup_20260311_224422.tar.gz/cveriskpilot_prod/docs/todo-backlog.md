# CVERiskPilot TODO Backlog

Last updated: 2026-03-11

## Priority Guide

- `P0 Now` = blocking core product behavior or trust in the data shown to users
- `P1 Next` = important reliability/performance issue that should follow once blockers are cleared
- `P2 Later` = worthwhile polish or operational improvement, but not blocking near-term use

## Ingestion and Audit

- [P1 Next] Implement append-only `upload_audit_events` persistence for compliance-grade traceability.
- [P1 Next] Capture event types at minimum:
  - upload received
  - parse started
  - parse completed
  - parse failed
  - reparse requested
  - manual admin cleanup executed
- [P1 Next] Store event metadata:
  - `event_id`
  - `upload_job_id`
  - `raw_artifact_id`
  - `event_type`
  - `event_status`
  - `actor_id` (or `system`)
  - `actor_role`
  - `source_ip` (when available)
  - `user_agent` (when available)
  - `details_json`
  - `created_at`
- [P1 Next] Add API endpoint(s) for audit retrieval by upload job and date range.
- [P1 Next] Add admin/superadmin audit view in dashboard UI.
- [P2 Later] Add retention policy for audit events.

## Admin Operations

- [P2 Later] Implement dedicated superadmin cleanup UI for stale upload artifacts.
- [P2 Later] Add guardrails in UI to require checksum/storage-key scoped deletions only.
- [P1 Next] Add explicit confirmation/audit entry for every manual cleanup action.

## Enrichment Visibility

- [P0 Now] Fix selected-finding enrichment signal rendering so the detail panel always shows persisted provider data after enrichment runs complete.
- [P0 Now] Verify the source-of-truth contract between:
  - `/api/findings`
  - `/api/findings/:id/enrichment`
  - `FindingDetailsPanel`
  - `CveSourceSections`
  so KEV/NVD/provider signals do not silently fall back to `pending`.
- [P0 Now] Add an integration test that simulates a larger findings list beyond the hydration threshold and confirms the selected detail view still renders enrichment signals correctly.
- [P1 Next] Add provider-level UI telemetry in the detail rail:
  - last successful provider refresh
  - source URL
  - per-provider status
  - stale-cache indicator
- [P1 Next] Add a manual refresh control for selected-finding enrichment data to help operators verify live provider state during debugging.

## Dashboard UX

- [P2 Later] Improve Recent Upload Jobs table UX:
  - adjustable rows-per-page selector
  - persistent column widths at all breakpoints
  - optional expanded row for full filename/notes without truncation
- [P2 Later] Revisit dashboard action-button typography on uploads/topbar if browser rendering still shows size mismatch after the current mono-scale normalization pass.

## NVD Integration Hardening

- [P1 Next] Replace in-memory NVD cache with persistent provider (Cloudflare KV or D1) for multi-instance consistency.
- [P1 Next] Add cache invalidation tooling for CVE re-ingest and emergency purge.
- [P2 Later] Add scheduled modified-date sync workflow for bulk NVD refresh.
- [P1 Next] Add provider telemetry counters:
  - rate-limit waits
  - stale-cache fallbacks
  - upstream 429/5xx counts
- [P1 Next] Add integration tests for `/api/nvd` in `npm run preview` runtime with deterministic fixtures.
