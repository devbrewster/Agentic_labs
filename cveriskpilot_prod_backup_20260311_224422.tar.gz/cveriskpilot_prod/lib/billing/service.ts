import { getBillingRuntime } from "@/lib/billing/runtime";
import type { BillingRepository } from "@/lib/billing/repository";
import type {
  BillingEntitlements,
  BillingPlan,
  BillingSnapshot,
  BillingSubscription,
  UsageCounter,
} from "@/types/billing";
import type { OrganizationId } from "@/types/organization";

const FREE_ENTITLEMENTS: BillingEntitlements = {
  uploadsPerMonth: 3,
  analysesPerMonth: 10,
  cveLookupsPerDay: 10,
  exportsPerMonth: 1,
  sharedWorkspaces: 1,
  advancedReports: false,
  premiumIntegrations: false,
};

const PRO_ENTITLEMENTS: BillingEntitlements = {
  uploadsPerMonth: 250,
  analysesPerMonth: 500,
  cveLookupsPerDay: 500,
  exportsPerMonth: 100,
  sharedWorkspaces: 10,
  advancedReports: true,
  premiumIntegrations: true,
};

export function getBillingPlanForSubscription(
  subscription: BillingSubscription | null,
): BillingPlan {
  if (!subscription) {
    return "free";
  }

  if (
    subscription.status === "active" ||
    subscription.status === "trialing" ||
    subscription.status === "past_due"
  ) {
    return "pro";
  }

  return "free";
}

export function getEntitlementsForPlan(plan: BillingPlan) {
  return plan === "pro" ? PRO_ENTITLEMENTS : FREE_ENTITLEMENTS;
}

export function getUsageWindow(date = new Date()) {
  const year = date.getUTCFullYear();
  const month = date.getUTCMonth();
  const periodStart = new Date(Date.UTC(year, month, 1, 0, 0, 0, 0));
  const periodEnd = new Date(Date.UTC(year, month + 1, 1, 0, 0, 0, 0));

  return {
    periodStart: periodStart.toISOString(),
    periodEnd: periodEnd.toISOString(),
  };
}

function buildEmptyUsageCounter(
  organizationId: OrganizationId,
  periodStart: string,
  periodEnd: string,
): UsageCounter {
  return {
    organizationId,
    periodStart,
    periodEnd,
    uploadsUsed: 0,
    analysesUsed: 0,
    cveLookupsUsed: 0,
    exportsUsed: 0,
    updatedAt: new Date().toISOString(),
  };
}

export async function ensureUsageCounterForOrganization(
  organizationId: OrganizationId,
  repository: BillingRepository,
  date = new Date(),
) {
  const { periodStart, periodEnd } = getUsageWindow(date);
  const existingCounter = await repository.findUsageCounter(
    organizationId,
    periodStart,
    periodEnd,
  );

  if (existingCounter) {
    return existingCounter;
  }

  const counter = buildEmptyUsageCounter(organizationId, periodStart, periodEnd);
  await repository.upsertUsageCounter(counter);
  return counter;
}

export function isStripeUpgradeReady() {
  return Boolean(
    process.env.STRIPE_SECRET_KEY?.trim() &&
      process.env.STRIPE_PRICE_PRO_MONTHLY?.trim() &&
      process.env.NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY?.trim(),
  );
}

export async function getOrganizationBillingSnapshot(
  organizationId: OrganizationId,
): Promise<BillingSnapshot> {
  const { billingRepository } = await getBillingRuntime();
  const [customer, subscription, usage] = await Promise.all([
    billingRepository.findCustomerByOrganizationId(organizationId),
    billingRepository.findSubscriptionByOrganizationId(organizationId),
    ensureUsageCounterForOrganization(organizationId, billingRepository),
  ]);

  const plan = getBillingPlanForSubscription(subscription);

  return {
    organizationId,
    plan,
    provider: customer || subscription ? "stripe" : "none",
    customer,
    subscription,
    usage,
    entitlements: getEntitlementsForPlan(plan),
    upgradeReady: isStripeUpgradeReady(),
  };
}
