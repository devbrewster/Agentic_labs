import { FindingsManagementWorkspace } from "@/components/dashboard/FindingsManagementWorkspace";

export default function FindingsPage() {
  return <FindingsManagementWorkspace />;
}
