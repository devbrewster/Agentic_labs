# Upload Stabilization Log

Use this file as the recovery point for future sessions while driving file uploads to a stable state.

Last updated: 2026-03-10

## Current baseline snapshot

- `npm test` passed
- `npm run typecheck` passed
- latest passing count:
  - 7 test files
  - 19 tests
- real CSV upload has succeeded in local development
- recent blocker encountered:
  - missing `raw_artifact_contents` table before local migration

Required migration command before local upload testing:

```bash
npm run db:migrate:local
```

## Session checklist

Use this checklist at the start of any new session:

1. Open:
   - `SESSION_NOTES.md`
   - `docs/progress-log.md`
   - `docs/upload-stabilization-plan.md`
   - `docs/upload-stabilization-log.md`
2. Re-apply local schema:
```bash
npm run db:migrate:local
```
3. Validate baseline:
```bash
npm test
npm run typecheck
```
4. Resume from the first incomplete chunk below

## Admin operations note

There is currently no separate superadmin cleanup UI/dashboard for stale upload artifacts.

If stale records block re-upload (for example missing `raw_artifact_contents` for an existing `raw_artifacts` checksum), admins may perform manual D1 cleanup with strict targeting:

- identify failing `checksum_sha256` and `storage_key`
- delete only rows for that checksum/key
- prefer deleting from `raw_artifacts` (cascade handles dependent rows)
- log the cleanup action in this file with checksum, reason, and commands used

## Chunk status tracker

### Chunk A — Schema and environment verification
Status: completed

Notes:
- confirm ingestion tables exist locally before any upload verification
- local schema migration succeeded on 2026-03-10
- verified ingestion tables with the project-local Wrangler runtime

### Chunk B — `next dev` real upload verification
Status: completed

Notes:
- upload a known-good CSV
- confirm `enrichment_pending`
- confirm findings count matches expected
- note: `/api/uploads/:id/findings` readback currently reports zero findings for the tested job despite job-level `finding_count > 0`; tracked for follow-up in Chunk C/D

### Chunk C — `npm run preview` real upload verification
Status: completed

Notes:
- repeat the same known-good CSV flow in Workers preview
- confirm no filesystem readback regression
- preview upload/reparse works and reaches `enrichment_pending`
- no filesystem readback regression observed
- persistence/readback mismatch fixed in repository upsert logic

### Chunk D — Dedupe and reparse verification
Status: completed

Notes:
- same file upload should deduplicate
- forced reparse should replace, not duplicate
- completed in `next dev`
- dedupe and forced reparse semantics validated with DB checks

### Chunk E — Diagnostics and operator visibility verification
Status: completed

Notes:
- confirm upload diagnostics show metadata, warnings, errors, findings preview
- verified against real warning and error upload jobs
- diagnostics UI now shows warning level and parser error details payloads

### Chunk F — Failure-path verification
Status: completed

Notes:
- test malformed CSV and unsupported cases
- malformed CSV path validated with structured parser error
- unsupported selected source path validated with structured parser error

### Chunk G — Scope closeout review
Status: completed

Notes:
- only after A-F are green should uploads be considered stable enough to unblock Phase 3
- A-F completed with logged verification evidence
- decision: current upload scope is stable; Phase 3 is unblocked

## Execution log

Append new entries below instead of overwriting older entries.

### Entry template

```text
Date:
Environment:
Chunk:
File used:
Action:
Result:
Findings count:
Warnings:
Errors:
Blocker:
Next action:
```

### 2026-03-10
Environment:
- local repo audit

Chunk:
- baseline validation

File used:
- n/a

Action:
- reviewed current ingestion docs and runtime state
- ran `npm test`
- ran `npm run typecheck`

Result:
- baseline is green

Findings count:
- n/a

Warnings:
- none at baseline

Errors:
- no active test or typecheck failures

Blocker:
- upload flow is not yet considered fully stabilized because the remaining operational checklist has not been completed in both `next dev` and `npm run preview`

Next action:
- start with Chunk A from `docs/upload-stabilization-plan.md`

### 2026-03-10
Environment:
- local D1 schema verification

Chunk:
- Chunk A — Schema and environment verification

File used:
- `database/schema.sql`

Action:
- ran `npm run db:migrate:local`
- attempted local table verification with:
  - `wrangler d1 execute cveriskpilot-db --local --command "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"`

Result:
- local migration completed successfully
- Wrangler reported `26 commands executed successfully`
- project-local table inspection succeeded and confirmed the required ingestion tables exist

Findings count:
- n/a

Warnings:
- global Wrangler remains unusable in this Linux environment because it resolves the wrong `workerd` binary
- project-local Wrangler works and should be used for local D1 inspection

Errors:
- none for Chunk A completion

Blocker:
- global Wrangler is resolving `@cloudflare/workerd-windows-64` instead of the Linux binary, causing:
  - `You installed workerd on another platform than the one you're currently using`
- workaround confirmed:
  - use `./node_modules/.bin/wrangler ...` for local project checks

Next action:
- move to Chunk B — `next dev` real upload verification
- verified tables:
  - `raw_artifacts`
  - `raw_artifact_contents`
  - `upload_jobs`
  - `parse_outcomes`
  - `normalized_findings`

### 2026-03-11
Environment:
- `next dev` on local `http://localhost:3000`

Chunk:
- Chunk B — `next dev` real upload verification

File used:
- `/tmp/chunk-b-good.csv`

Action:
- started local dev server
- posted multipart upload to `POST /api/uploads` with:
  - `file=/tmp/chunk-b-good.csv`
  - `selectedSourceType=generic_csv`
- triggered parse via:
  - `POST /api/uploads/4f94b166-3c8a-412f-9c0a-0dec6cec36f5/reparse`
- verified route availability:
  - `GET /dashboard` => `200`
  - `GET /dashboard/findings` => `200`
- verified local D1 state for the upload job

Result:
- upload succeeded
- parse succeeded
- lifecycle reached `enrichment_pending`
- upload job shows nonzero findings

Findings count:
- expected from test file: `2`
- observed on upload job row: `finding_count = 2`

Warnings:
- none returned by parser for this file

Errors:
- no route-level error during upload/reparse

Blocker:
- findings readback inconsistency detected:
  - `GET /api/uploads/:id/findings` returned `findingCount: 0`
  - local D1 query also showed:
    - no new `parse_outcomes` row for this job
    - no `normalized_findings` rows for this job
  - while `upload_jobs.status = enrichment_pending` and `finding_count = 2`

Next action:
- proceed to Chunk C (`npm run preview` verification) and include targeted checks for parse outcome + normalized finding persistence/readback consistency

### 2026-03-11
Environment:
- Workers preview runtime on local `http://localhost:8787`

Chunk:
- Chunk C — `npm run preview` real upload verification

File used:
- `/tmp/chunk-c-good.csv`

Action:
- ran `npm run preview`
- uploaded CSV to `POST /api/uploads` with `selectedSourceType=generic_csv`
- triggered parse with:
  - `POST /api/uploads/22fb8f03-862d-460a-afb8-6743d0f2658d/reparse`
- verified route availability:
  - `GET /dashboard` => `200`
  - `GET /dashboard/findings` => `200`
- inspected preview logs for runtime readback failures
- checked local D1 state for upload/persistence rows

Result:
- upload succeeded
- parse succeeded
- lifecycle reached `enrichment_pending`
- no `/bundle/.data/uploads/...` filesystem readback error observed in preview logs
- findings readback mismatch was reproduced and root cause identified

Findings count:
- expected from test file: `2`
- observed in upload job row: `finding_count = 2`
- observed in `GET /api/uploads/:id/findings`: `findingCount = 0`
- observed in local D1 for that upload:
  - `parse_outcomes` row missing
  - `normalized_findings` row count `0`

Warnings:
- none returned by parser for this file

Errors:
- no route-level error during upload/reparse

Blocker:
- root cause was `INSERT OR REPLACE` on `upload_jobs` (parent table):
  - row replacement deleted/reinserted parent rows
  - `ON DELETE CASCADE` removed child rows in `parse_outcomes` and `normalized_findings`
  - symptom: `finding_count` stayed nonzero on job while detail/findings readback returned empty

Next action:
- apply UPSERT fix and re-verify preview behavior

### 2026-03-11
Environment:
- code fix + Workers preview runtime on local `http://localhost:8787`

Chunk:
- Chunk C follow-up — persistence/readback fix verification

File used:
- `/tmp/chunk-c-fix.csv`

Action:
- changed repository writes in `lib/ingestion/d1-repository.ts`:
  - replaced `INSERT OR REPLACE` with `INSERT ... ON CONFLICT(id) DO UPDATE` for:
    - `raw_artifacts`
    - `upload_jobs`
- ran validation:
  - `npm run typecheck`
  - `npm test`
  - `npm run preview`
  - upload + reparse for fresh CSV
  - readback checks for:
    - `GET /api/uploads/:id`
    - `GET /api/uploads/:id/findings`
    - local D1 rows in `parse_outcomes` and `normalized_findings`

Result:
- fix confirmed
- `GET /api/uploads/:id/findings` now returns nonzero findings
- `GET /api/uploads/:id` now returns metadata + findings
- local D1 now contains:
  - `parse_outcomes` row for the upload
  - `normalized_findings` rows for the upload

Findings count:
- expected from test file: `2`
- observed via API: `2`
- observed in local D1 `normalized_findings`: `2`

Warnings:
- none

Errors:
- none

Blocker:
- none remaining for Chunk C

Next action:
- start Chunk D — dedupe and reparse verification

### 2026-03-11
Environment:
- local `next dev` on `http://localhost:3000`

Chunk:
- cleanup + Chunk D — dedupe and reparse verification

File used:
- stale test artifact:
  - `jfrog_xray_artifactory_cve_vulnerability_report_10_rows.csv`
  - checksum `306f1c90f178f5819429760210a485b2a0d7f0d59633707b5bb0feb10bb99524`
- dedupe/reparse fixture:
  - `/tmp/chunk-d-dedupe.csv`

Action:
- investigated error:
  - `Artifact content not found for storage key '2026-03-11/306f.../jfrog_xray_artifactory_cve_vulnerability_report_10_rows.csv'`
- DB findings for that checksum:
  - `raw_artifacts` row existed
  - `upload_jobs` row existed with `status=failed`
  - `raw_artifact_contents` row was missing
- removed stale records so the same file can be uploaded fresh:
  - deleted matching `raw_artifacts` row
  - deleted any matching `raw_artifact_contents` row
  - verified checksum rows are now absent
- ran Chunk D checks:
  - uploaded fixture once (`deduplicated=false`)
  - parsed to `enrichment_pending` with `finding_count=2`
  - uploaded same fixture again (`deduplicated=true`, same upload job id)
  - forced reparse with `{"force":true}`
  - confirmed `replacedExistingOutcome=true`
  - confirmed no finding duplication in DB

Result:
- stale checksum/state causing artifact-missing error was cleaned
- same file can now be re-uploaded as a new artifact/job
- dedupe behavior works
- forced reparse replaces findings, does not duplicate

Findings count:
- baseline parse: `2`
- after duplicate upload: still one job for checksum
- after forced reparse: `2` findings for the upload job

Warnings:
- none

Errors:
- none during Chunk D validation

Blocker:
- none for Chunk D

Next action:
- proceed to Chunk E — diagnostics and operator visibility verification

### 2026-03-11
Environment:
- local `next dev` on `http://localhost:3000`

Chunk:
- Chunk E — Diagnostics and operator visibility verification

File used:
- `/tmp/chunk-e-warning.csv` (warning-case)
- `/tmp/chunk-e-error.csv` (error-case)

Action:
- enhanced diagnostics panel in:
  - `components/dashboard/UploadJobDetailsPanel.tsx`
  - added warning `level` display
  - added parser error `details` JSON rendering
  - added parsed findings preview count (`showing x of y`)
- created and parsed two uploads:
  - warning-case job `43c4a77f-1c75-4a83-a0ac-752f64e2aac5`
  - error-case job `0a0f2fe5-07a7-4556-ad28-2d3469618043`
- verified diagnostics routes:
  - `GET /dashboard/uploads` => `200`
  - `GET /api/uploads/43c4a77f-1c75-4a83-a0ac-752f64e2aac5`
  - `GET /api/uploads/0a0f2fe5-07a7-4556-ad28-2d3469618043`
  - `GET /api/uploads/0a0f2fe5-07a7-4556-ad28-2d3469618043/errors`

Result:
- upload diagnostics visibility meets Chunk E criteria:
  - parse metadata visible
  - parser warnings visible
  - parser errors visible
  - findings preview visible

Findings count:
- warning-case: `1`
- error-case: `0`

Warnings:
- warning-case produced:
  - `csv_unmapped_header` on `unmapped_col`

Errors:
- error-case produced:
  - `csv_missing_rows` with `details: { rowCount: 1 }`

Blocker:
- none for Chunk E

Next action:
- proceed to Chunk F — failure-path verification

### 2026-03-11
Environment:
- local `next dev` on `http://localhost:3000`

Chunk:
- Chunk F — Failure-path verification

File used:
- `/tmp/chunk-f-malformed.csv`
- `/tmp/chunk-f-unsupported.json`

Action:
- uploaded malformed CSV with `selectedSourceType=generic_csv`
- uploaded unsupported JSON with `selectedSourceType=unknown`
- triggered parse for both jobs with:
  - `POST /api/uploads/3c073a6e-03ab-4d40-9bd6-15b0c9e2f17a/reparse`
  - `POST /api/uploads/d9e62e52-f146-459c-9559-7cb601342633/reparse`
- verified structured error responses:
  - `GET /api/uploads/3c073a6e-03ab-4d40-9bd6-15b0c9e2f17a/errors`
  - `GET /api/uploads/d9e62e52-f146-459c-9559-7cb601342633/errors`
- verified failed jobs appear in uploads listing (`GET /api/uploads`)

Result:
- both failure paths behave predictably and return structured parser errors
- uploads list includes failed rows for operator visibility

Findings count:
- malformed CSV job: `0`
- unsupported source job: `0`

Warnings:
- none for either failure case

Errors:
- malformed CSV:
  - `code: csv_missing_rows`
  - `details: { rowCount: 1 }`
  - `fatal: true`
- unsupported source:
  - `code: selected_source_unsupported`
  - `details: { selectedSourceType: "unknown", fileType: "json" }`
  - `fatal: true`

Blocker:
- none for Chunk F

Next action:
- proceed to Chunk G — scope closeout review

### 2026-03-11
Environment:
- local verification + docs closeout

Chunk:
- Chunk G — Scope closeout review

File used:
- n/a

Action:
- verified chunk tracker state: A-F completed
- re-ran baseline checks:
  - `npm test`
  - `npm run typecheck`
- reviewed stabilization criteria and execution evidence in this log

Result:
- closeout criteria met for current supported scope (`generic_csv`)
- upload stabilization effort is complete for Phase 1/2 target behavior

Findings count:
- n/a for closeout

Warnings:
- none

Errors:
- none in baseline validation

Blocker:
- none blocking transition to next phase

Next action:
- begin Phase 3 planning/implementation (enrichment pipeline and downstream integrations)
