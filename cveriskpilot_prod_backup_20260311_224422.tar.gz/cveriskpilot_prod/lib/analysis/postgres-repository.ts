import type { PostgresQueryClient } from "@/lib/platform/database";
import { PostgresAppDatabase } from "@/lib/platform/database";
import { SqlAnalysisTraceRepository } from "@/lib/analysis/sql-repository";

export class PostgresAnalysisTraceRepository extends SqlAnalysisTraceRepository {
  constructor(client: PostgresQueryClient) {
    super(new PostgresAppDatabase(client));
  }
}
