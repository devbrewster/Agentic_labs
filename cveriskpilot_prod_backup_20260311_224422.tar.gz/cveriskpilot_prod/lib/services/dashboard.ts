import {
  dashboardEnvironmentBadges,
  dashboardNavItems,
  dashboardStats,
  type DashboardNavItem,
  type DashboardStat,
} from "@/lib/mock/dashboard";
import { listActionPlans } from "@/lib/services/action-plans";
import { getPendingIssueSummary } from "@/lib/services/issues";
import type { NormalizedFinding } from "@/types/ingestion";

export type { DashboardNavItem, DashboardStat } from "@/lib/mock/dashboard";

export function listDashboardNavItems(): DashboardNavItem[] {
  const issueSummary = getPendingIssueSummary();

  return dashboardNavItems.map((item) =>
    item.routeKey === "issues"
      ? {
          ...item,
          badge: String(issueSummary.total),
        }
      : item,
  );
}

export function listDashboardEnvironmentBadges(): string[] {
  return dashboardEnvironmentBadges;
}

export function listDashboardStats(): DashboardStat[] {
  return dashboardStats;
}

export function createDashboardStatsFromFindings(
  findings: NormalizedFinding[],
): DashboardStat[] {
  const severityCounts = findings.reduce(
    (counts, finding) => {
      switch (finding.normalizedSeverity) {
        case "critical":
          counts.critical += 1;
          break;
        case "high":
          counts.high += 1;
          break;
        case "medium":
          counts.medium += 1;
          break;
        default:
          counts.low += 1;
          break;
      }

      return counts;
    },
    {
      critical: 0,
      high: 0,
      medium: 0,
      low: 0,
    },
  );

  const actionPlanCount = listActionPlans().length;
  const totalFindingCount =
    severityCounts.critical +
    severityCounts.high +
    severityCounts.medium +
    severityCounts.low;

  return [
    {
      label: "Critical",
      value: severityCounts.critical,
      delta: `${severityCounts.critical} critical findings currently parsed`,
      deltaValue: severityCounts.critical,
      direction: severityCounts.critical > 0 ? "up" : "neutral",
      tone: "critical",
    },
    {
      label: "High",
      value: severityCounts.high,
      delta: `${severityCounts.high} high findings currently parsed`,
      deltaValue: severityCounts.high,
      direction: severityCounts.high > 0 ? "up" : "neutral",
      tone: "high",
    },
    {
      label: "Medium",
      value: severityCounts.medium,
      delta: `${severityCounts.medium} medium findings currently parsed`,
      deltaValue: severityCounts.medium,
      direction: severityCounts.medium > 0 ? "down" : "neutral",
      tone: "medium",
    },
    {
      label: "Low",
      value: severityCounts.low,
      delta: `${severityCounts.low} low or informational findings currently parsed`,
      deltaValue: severityCounts.low,
      direction: severityCounts.low > 0 ? "down" : "neutral",
      tone: "accent",
    },
    {
      label: "Action Plans",
      value: actionPlanCount,
      delta: `${totalFindingCount} total ingested findings tracked`,
      deltaValue: totalFindingCount,
      direction: totalFindingCount > 0 ? "neutral" : "neutral",
      tone: "low",
    },
  ];
}
