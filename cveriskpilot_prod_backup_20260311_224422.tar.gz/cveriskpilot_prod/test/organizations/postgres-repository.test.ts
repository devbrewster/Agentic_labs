import { describe, expect, it } from "vitest";

import { PostgresOrganizationRepository } from "@/lib/organizations/postgres-repository";
import type { PostgresQueryClient } from "@/lib/platform/database";

describe("PostgresOrganizationRepository", () => {
  it("maps organization memberships through the shared SQL repository implementation", async () => {
    const organizationId = crypto.randomUUID();
    const userId = crypto.randomUUID();
    const now = new Date().toISOString();

    const client: PostgresQueryClient = {
      async query<T>(sql: string, params?: readonly unknown[]) {
        if (sql.includes("FROM organization_members")) {
          expect(sql).toContain("WHERE om.user_id = $1");
          expect(params).toEqual([userId]);

          return {
            rows: [
              {
                organization_id: organizationId,
                organization_name: "Acme Security",
                organization_slug: "acme-security",
                organization_status: "active",
                organization_created_at: now,
                organization_updated_at: now,
                member_id: crypto.randomUUID(),
                user_id: userId,
                role: "admin",
                joined_at: now,
                invited_by_user_id: null,
              },
            ] as T[],
            rowCount: 1,
          };
        }

        throw new Error(`Unexpected SQL in test client: ${sql}`);
      },
    };

    const repository = new PostgresOrganizationRepository(client);
    const context = await repository.getCurrentContextForUser(userId);

    expect(context.organizationId).toBe(organizationId);
    expect(context.memberships).toHaveLength(1);
    expect(context.memberships[0]?.organization.slug).toBe("acme-security");
    expect(context.memberships[0]?.member.role).toBe("admin");
  });
});
