# Upload Stabilization Plan

Last updated: 2026-03-10

## Objective

Reach a point where file upload can be treated as operationally complete for the currently supported scope.

Current supported scope:

- real upload from the dashboard UI
- persisted upload jobs in D1
- D1-backed raw artifact content storage
- parse lifecycle transitions
- real parsing for `generic_csv`
- findings retrieval in dashboard views

Not yet required for declaring the current upload flow stable:

- real Nessus parsing
- real Qualys parsing
- real Rapid7 parsing
- enrichment pipeline
- R2 production storage

## Verified baseline

These checks are currently green:

- `npm test`
- `npm run typecheck`

Latest validated results:

- 7 test files passed
- 19 tests passed

## Primary known blocker classes

1. Schema drift
- Uploads fail if local D1 schema is not migrated after ingestion table changes.
- Most recent example:
  - missing `raw_artifact_contents`

2. Runtime boundary differences
- `next dev` and `npm run preview` do not exercise exactly the same runtime path.
- Upload flow must be proven in both.

3. Real-file variability
- Only `generic_csv` is fully implemented.
- A file upload may succeed while parse semantics still fail for unsupported formats.

4. Operator visibility
- The dashboard now exposes diagnostics, but the stabilization process still needs a consistent checklist and recorded outcomes per environment.

## Definition of “uploads at 100%” for current scope

The current upload implementation can be treated as stable only when all items below pass:

1. Local schema is current
2. `npm test` passes
3. `npm run typecheck` passes
4. Real CSV upload works in `npm run dev`
5. Real CSV upload works in `npm run preview`
6. Parsed job reaches `enrichment_pending`
7. Findings count matches expectation
8. `/dashboard/findings` shows ingested findings
9. `/dashboard` summary cards show ingestion-backed counts
10. Upload diagnostics show metadata, warnings, errors, and findings preview
11. Re-uploading identical file deduplicates correctly
12. Forced reparse replaces findings instead of duplicating them

## Remaining chunks

### Chunk A — Schema and environment verification
Goal:
- ensure local D1 contains all ingestion tables before any upload testing

Success criteria:
- `raw_artifacts`
- `raw_artifact_contents`
- `upload_jobs`
- `parse_outcomes`
- `normalized_findings`
all exist locally

Commands:
```bash
npm run db:migrate:local
wrangler d1 execute cveriskpilot-db --local --command "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name;"
```

### Chunk B — `next dev` real upload verification
Goal:
- prove the dashboard upload flow works in standard local development

Success criteria:
- upload succeeds
- parse succeeds
- status becomes `enrichment_pending`
- findings count is nonzero

Routes to verify:
- `/dashboard/uploads`
- `/dashboard/findings`
- `/dashboard`

### Chunk C — `npm run preview` real upload verification
Goal:
- prove the same upload flow works in the Workers runtime

Success criteria:
- no filesystem readback errors
- upload succeeds
- parse succeeds
- findings render from ingested data

Critical regression to watch:
- `no such file or directory, readAll '/bundle/.data/uploads/...'`

### Chunk D — Dedupe and reparse verification
Goal:
- confirm idempotency and forced reparse semantics behave exactly as intended

Success criteria:
- same file content re-upload returns deduplicated upload job
- forced reparse does not duplicate normalized findings
- forced reparse replaces prior parse outcome cleanly

### Chunk E — Diagnostics and operator visibility verification
Goal:
- confirm the UI exposes enough information to debug upload issues without opening code

Success criteria:
- upload diagnostics panel shows:
  - parse metadata
  - parser warnings
  - parser errors
  - findings preview

### Chunk F — Failure-path verification
Goal:
- confirm predictable failure behavior for malformed or unsupported uploads

Success criteria:
- malformed CSV produces failed job with parser error
- unsupported source detection produces structured error
- uploads page shows visible failure state

### Chunk G — Scope closeout review
Goal:
- confirm current upload scope is stable enough to unblock Phase 3

Decision rule:
- move to Phase 3 only if Chunks A through F have been completed and logged successfully for the current supported file type scope

## Recommended execution order

1. Chunk A
2. Chunk B
3. Chunk C
4. Chunk D
5. Chunk E
6. Chunk F
7. Chunk G

## Important note

Do not expand scope during stabilization.

Stabilize the currently implemented path first:

- `generic_csv`
- dashboard uploads UI
- D1-backed storage
- findings/dashboard rendering

Only after that should work continue into:

- more parser adapters
- enrichment
- Phase 3

## Admin manual cleanup note (until superadmin UI exists)

If upload errors indicate stale artifact state (for example, `Artifact content not found for storage key ...`), admins should perform targeted D1 cleanup by `checksum_sha256` or exact `storage_key`.

Required safeguards:

- only delete rows tied to the failing checksum/storage key
- use project-local Wrangler (`./node_modules/.bin/wrangler`) for local operations
- prefer deleting parent `raw_artifacts` rows and let `ON DELETE CASCADE` clean child `upload_jobs`/`parse_outcomes`/`normalized_findings`
- document each manual cleanup in `docs/upload-stabilization-log.md` (date, checksum, reason, commands)

This is a temporary operator workflow until a dedicated superadmin cleanup UI/dashboard is implemented.
