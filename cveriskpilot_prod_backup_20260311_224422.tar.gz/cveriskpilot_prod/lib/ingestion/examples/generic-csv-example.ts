export const genericCsvExampleInput = `CVE,Title,Severity,Host,IP,Port,Description,Remediation
CVE-2024-21413,Microsoft Outlook RCE via Hyperlink Preview,Critical,mail-prod-01,10.10.20.15,443,Remote code execution through crafted hyperlink preview handling in Outlook,Patch Outlook immediately and disable hyperlink preview until updated
CVE-2024-27198,JetBrains TeamCity Auth Bypass,High,ci-teamcity-01,10.10.40.22,8111,Authentication bypass on TeamCity administrative endpoints,Upgrade TeamCity to 2023.11.4 or later`;

export const genericCsvExampleParsedOutput = {
  findings: [
    {
      title: "Microsoft Outlook RCE via Hyperlink Preview",
      cveIds: ["CVE-2024-21413"],
      normalizedSeverity: "critical",
      hostname: "mail-prod-01",
      ipAddress: "10.10.20.15",
      port: 443,
      remediation:
        "Patch Outlook immediately and disable hyperlink preview until updated",
    },
    {
      title: "JetBrains TeamCity Auth Bypass",
      cveIds: ["CVE-2024-27198"],
      normalizedSeverity: "high",
      hostname: "ci-teamcity-01",
      ipAddress: "10.10.40.22",
      port: 8111,
      remediation: "Upgrade TeamCity to 2023.11.4 or later",
    },
  ],
  parserWarnings: [],
  parserErrors: [],
  metadata: {
    scannerName: "Generic CSV Import",
    sourceType: "generic_csv",
    fileType: "csv",
    hostCount: 2,
    findingCount: 2,
  },
} as const;
