import { describe, expect, it } from "vitest";

import {
  buildDiscordPendingIssuesReport,
  buildInternalPendingIssuesReport,
  getPendingIssueSummary,
  listPendingIssues,
} from "@/lib/services/issues";

describe("pending issues service", () => {
  it("returns priority-sorted issues with a summary", () => {
    const issues = listPendingIssues();
    const summary = getPendingIssueSummary();

    expect(issues.length).toBeGreaterThan(0);
    expect(issues[0]?.priority).toBe("P0 Now");
    expect(summary.total).toBe(issues.length);
    expect(summary.byPriority.p0).toBeGreaterThan(0);
  });

  it("builds discord and internal markdown reports", () => {
    const discordReport = buildDiscordPendingIssuesReport();
    const internalReport = buildInternalPendingIssuesReport();

    expect(discordReport).toContain("CVERiskPilot Pending Issues Status");
    expect(discordReport).toContain("ISSUE-001");
    expect(internalReport).toContain("Structured issue list");
    expect(internalReport).toContain("ISSUE-001");
  });
});
