import { PendingIssuesReport } from "@/components/dashboard/PendingIssuesReport";
import { StatusPill } from "@/components/dashboard/StatusPill";
import { SurfaceCard } from "@/components/dashboard/SurfaceCard";
import { requireServerAuthenticatedSession } from "@/lib/auth/server";
import { listReportCards } from "@/lib/services/platform";
import { getExecutiveSummaryReport } from "@/lib/services/reports";

const severityTone = {
  critical: "danger",
  high: "warning",
  medium: "accent",
  low: "default",
} as const;

export default async function ReportsPage() {
  const auth = await requireServerAuthenticatedSession("/dashboard/reports");
  const reportCards = listReportCards();
  const executiveSummary = await getExecutiveSummaryReport(
    auth.user.current_organization_id ?? auth.session.active_organization_id ?? undefined,
  );

  return (
    <div className="space-y-5">
      <SurfaceCard
        eyebrow="// Reports"
        title="Reporting and export workspace"
        description="Stakeholder reporting includes an executive-ready summary with explicit source provenance, current uncertainty, and remediation priorities. Additional export formats will appear here as they become available."
        meta={<StatusPill tone="accent">Executive Summary Live</StatusPill>}
      />

      <SurfaceCard
        eyebrow="// Executive Summary"
        title="Leadership risk posture"
        description="This summary separates original source data, CVERiskPilot analysis coverage, and other enrichment signals so security leadership can communicate risk without overstating confidence."
        meta={
          <StatusPill tone={executiveSummary.source === "ingestion" ? "accent" : "warning"}>
            {executiveSummary.source === "ingestion" ? "Ingested Data" : "Mock Fallback"}
          </StatusPill>
        }
      >
        <div className="grid gap-4 md:grid-cols-4">
          <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4">
            <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#5a7080]">
              Findings
            </div>
            <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-white">
              {executiveSummary.totals.findings}
            </div>
          </div>
          <div className="rounded border border-[rgba(255,77,109,0.18)] bg-[rgba(255,77,109,0.08)] p-4">
            <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#ff9cab]">
              Open Critical
            </div>
            <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-[var(--danger)]">
              {executiveSummary.totals.criticalOpen}
            </div>
          </div>
          <div className="rounded border border-[rgba(255,208,96,0.18)] bg-[rgba(255,208,96,0.08)] p-4">
            <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#f3c46d]">
              Open High
            </div>
            <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-[var(--warning)]">
              {executiveSummary.totals.highOpen}
            </div>
          </div>
          <div className="rounded border border-[rgba(0,200,180,0.12)] bg-[rgba(0,200,180,0.08)] p-4">
            <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[var(--accent)]">
              Action Plans
            </div>
            <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-white">
              {executiveSummary.totals.actionPlans}
            </div>
          </div>
        </div>

        <div className="mt-4 grid gap-4 xl:grid-cols-[1.2fr_0.8fr]">
          <div className="space-y-4">
            <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4">
              <div className="mb-3 font-mono text-[0.64rem] uppercase tracking-[0.14em] text-[var(--accent)]">
                Original Source Data
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <div className="text-[0.84rem] leading-7 text-[var(--text)]">
                  Findings sourced from scanner/import data:{" "}
                  <span className="font-semibold text-white">
                    {executiveSummary.posture.originalSourceDataCount}
                  </span>
                </div>
                <div className="text-[0.84rem] leading-7 text-[var(--text)]">
                  Other enrichment coverage:{" "}
                  <span className="font-semibold text-white">
                    {executiveSummary.posture.enrichmentCoverageCount}
                  </span>
                </div>
              </div>
            </div>

            <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4">
              <div className="mb-3 font-mono text-[0.64rem] uppercase tracking-[0.14em] text-[var(--accent)]">
                CVERiskPilot Analysis
              </div>
              <div className="grid gap-3 md:grid-cols-2">
                <div className="text-[0.84rem] leading-7 text-[var(--text)]">
                  AI analysis traces available:{" "}
                  <span className="font-semibold text-white">
                    {executiveSummary.posture.aiAnalysisCount}
                  </span>
                </div>
                <div className="text-[0.84rem] leading-7 text-[var(--text)]">
                  Analyst-reviewed findings:{" "}
                  <span className="font-semibold text-white">
                    {executiveSummary.posture.analystReviewedCount}
                  </span>
                </div>
              </div>
            </div>

            <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4">
              <div className="mb-3 font-mono text-[0.64rem] uppercase tracking-[0.14em] text-[var(--accent)]">
                Priority Findings
              </div>
              <div className="space-y-3">
                {executiveSummary.topFindings.map((finding) => (
                  <div
                    key={finding.id}
                    className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] p-3"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="font-mono text-[0.72rem] text-[var(--accent)]">
                        {finding.cveId}
                      </div>
                      <StatusPill tone={severityTone[finding.severity]}>
                        {finding.severity}
                      </StatusPill>
                      <StatusPill>{finding.status.replaceAll("_", " ")}</StatusPill>
                      <StatusPill tone="warning">
                        {finding.adjustedRiskScore}
                      </StatusPill>
                    </div>
                    <div className="mt-2 text-[0.92rem] text-white">{finding.title}</div>
                    <div className="mt-2 text-[0.8rem] leading-7 text-[var(--text-dim)]">
                      Asset: {finding.assetName} · Source: {finding.originalSourceData.join(" · ")}
                    </div>
                    <div className="mt-2 text-[0.8rem] leading-7 text-[var(--text-dim)]">
                      CVERiskPilot Analysis: {finding.analysisStatus.replaceAll("_", " ")} · Other Enrichment Sources:{" "}
                      {finding.otherEnrichmentSources.length
                        ? finding.otherEnrichmentSources.join(", ")
                        : "none"}
                    </div>
                    <ul className="mt-2 space-y-1 text-[0.78rem] leading-6 text-[var(--text-dim)]">
                      {finding.rationale.slice(0, 3).map((reason) => (
                        <li key={reason}>- {reason}</li>
                      ))}
                    </ul>
                  </div>
                ))}
              </div>
            </div>
          </div>

          <div className="space-y-4">
            <div className="rounded border border-[rgba(255,208,96,0.18)] bg-[rgba(255,208,96,0.08)] p-4">
              <div className="mb-3 font-mono text-[0.64rem] uppercase tracking-[0.14em] text-[var(--warning)]">
                Uncertainty And Caveats
              </div>
              <div className="text-[0.9rem] leading-7 text-[var(--text)]">
                {executiveSummary.uncertainty.count} findings currently carry caveats that should be disclosed to stakeholders.
              </div>
              <div className="mt-3 space-y-2">
                {executiveSummary.uncertainty.items.length ? (
                  executiveSummary.uncertainty.items.map((item) => (
                    <div
                      key={`${item.findingId}:${item.message}`}
                      className="rounded border border-[rgba(255,208,96,0.16)] bg-[#040810] p-3"
                    >
                      <div className="font-mono text-[0.68rem] text-[var(--warning)]">
                        {item.cveId}
                      </div>
                      <div className="mt-1 text-[0.82rem] text-white">{item.title}</div>
                      <div className="mt-1 text-[0.78rem] leading-6 text-[var(--text-dim)]">
                        {item.message}
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-3 text-[0.8rem] text-[var(--text)]">
                    No active stakeholder caveats are currently flagged.
                  </div>
                )}
              </div>
            </div>

            <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4">
              <div className="mb-3 font-mono text-[0.64rem] uppercase tracking-[0.14em] text-[var(--accent)]">
                Ticket-ready Action Plans
              </div>
              <div className="space-y-3">
                {executiveSummary.actionPlans.map((plan) => (
                  <div
                    key={`${plan.findingId}:${plan.cveId}`}
                    className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] p-3"
                  >
                    <div className="flex flex-wrap items-center gap-2">
                      <div className="font-mono text-[0.68rem] text-[var(--accent)]">
                        {plan.cveId}
                      </div>
                      <StatusPill tone="warning">{plan.priority}</StatusPill>
                    </div>
                    <div className="mt-2 text-[0.8rem] leading-7 text-[var(--text-dim)]">
                      Assignee: {plan.assignee} · ETA: {plan.eta} · Component: {plan.component}
                    </div>
                    <div className="mt-1 text-[0.76rem] leading-6 text-[var(--text-dim)]">
                      Labels: {plan.labels.length ? plan.labels.join(", ") : "none"}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </SurfaceCard>

      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {reportCards.map((report) => (
          <SurfaceCard
            key={report.title}
            title={report.title}
            description={report.description}
            meta={<StatusPill>{report.badge}</StatusPill>}
          />
        ))}
      </div>

      <PendingIssuesReport />
    </div>
  );
}
