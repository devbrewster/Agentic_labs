import {
  ProviderEnrichmentResultSchema,
  type EnrichmentFindingInput,
  type ProviderEnrichmentResult,
} from "@/types/enrichment";
import type { EnrichmentProviderClient, EnrichmentProviderContext } from "@/lib/enrichment/providers/base";
import { KEV_CATALOG_URL, getKevClient } from "@/lib/kev/client";

const TEST_KEV_CVE_STUB_SET = new Set<string>([
  "CVE-2024-21413",
  "CVE-2024-3400",
  "CVE-2024-1709",
  "CVE-2023-46604",
]);

function normalizeKevObservedAt(value: string | null | undefined) {
  if (!value) {
    return null;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return null;
  }

  if (/^\d{4}-\d{2}-\d{2}$/.test(trimmed)) {
    return `${trimmed}T00:00:00.000Z`;
  }

  const timestamp = Date.parse(trimmed);
  if (Number.isNaN(timestamp)) {
    return null;
  }

  return new Date(timestamp).toISOString();
}

export class CisaKevEnrichmentProvider implements EnrichmentProviderClient {
  readonly provider = "cisa_kev" as const;

  async enrichFinding(
    finding: EnrichmentFindingInput,
    context: EnrichmentProviderContext,
  ): Promise<ProviderEnrichmentResult> {
    const primaryCve = finding.cveIds[0]?.trim().toUpperCase() ?? null;

    if (!primaryCve) {
      return ProviderEnrichmentResultSchema.parse({
        provider: this.provider,
        status: "not_found",
        sourceUrl: KEV_CATALOG_URL,
        observedAt: context.now,
        payload: {
          kevListed: false,
          exploitAvailable: null,
          cvssScore: null,
          cvssVector: null,
          references: [],
          summary: "No CVE was available for KEV lookup.",
          sourceVersion: null,
        },
        rawPayload: null,
        errorCode: null,
        errorMessage: null,
      });
    }

    if (process.env.NODE_ENV === "test") {
      const kevHit = TEST_KEV_CVE_STUB_SET.has(primaryCve);

      if (!kevHit) {
        return ProviderEnrichmentResultSchema.parse({
          provider: this.provider,
          status: "not_found",
          sourceUrl: KEV_CATALOG_URL,
          observedAt: context.now,
          payload: {
            kevListed: false,
            exploitAvailable: null,
            cvssScore: null,
            cvssVector: null,
            references: [],
            summary: "No KEV match found in test stub dataset.",
            sourceVersion: "test-stub",
          },
          rawPayload: {
            stub: true,
            provider: "cisa_kev",
            matched: false,
          },
          errorCode: null,
          errorMessage: null,
        });
      }

      return ProviderEnrichmentResultSchema.parse({
        provider: this.provider,
        status: "enriched",
        sourceUrl: KEV_CATALOG_URL,
        observedAt: context.now,
        payload: {
          kevListed: true,
          exploitAvailable: true,
          cvssScore: null,
          cvssVector: null,
          references: [KEV_CATALOG_URL],
          summary: `${primaryCve} appears in the test KEV set.`,
          sourceVersion: "test-stub",
        },
        rawPayload: {
          stub: true,
          provider: "cisa_kev",
          matched: true,
          cveId: primaryCve,
        },
        errorCode: null,
        errorMessage: null,
      });
    }

    const result = await getKevClient().getCveById(primaryCve);

    if (!result.ok) {
      return ProviderEnrichmentResultSchema.parse({
        provider: this.provider,
        status: "error",
        sourceUrl: KEV_CATALOG_URL,
        observedAt: context.now,
        payload: null,
        rawPayload: null,
        errorCode: result.error.code,
        errorMessage: result.error.message,
      });
    }

    if (!result.data) {
      return ProviderEnrichmentResultSchema.parse({
        provider: this.provider,
        status: "not_found",
        sourceUrl: KEV_CATALOG_URL,
        observedAt: result.meta.fetchedAt ?? context.now,
        payload: {
          kevListed: false,
          exploitAvailable: null,
          cvssScore: null,
          cvssVector: null,
          references: [KEV_CATALOG_URL],
          summary: `${primaryCve} is not listed in the CISA KEV catalog.`,
          sourceVersion: result.sourceVersion ?? result.meta.source,
        },
        rawPayload: {
          cveId: primaryCve,
          matched: false,
          stale: result.meta.stale,
        },
        errorCode: null,
        errorMessage: null,
      });
    }

    const ransomwareNote =
      result.data.knownRansomwareCampaignUse &&
      result.data.knownRansomwareCampaignUse.toLowerCase() !== "unknown"
        ? `Ransomware campaign use: ${result.data.knownRansomwareCampaignUse}.`
        : null;
    const summaryParts = [
      result.data.vulnerabilityName
        ? `${primaryCve} is listed in the CISA KEV catalog for ${result.data.vulnerabilityName}.`
        : `${primaryCve} is listed in the CISA KEV catalog.`,
      result.data.requiredAction ? `Required action: ${result.data.requiredAction}` : null,
      ransomwareNote,
    ].filter(Boolean);

    return ProviderEnrichmentResultSchema.parse({
      provider: this.provider,
      status: "enriched",
      sourceUrl: KEV_CATALOG_URL,
      observedAt:
        normalizeKevObservedAt(result.data.dateAdded) ??
        normalizeKevObservedAt(result.meta.fetchedAt) ??
        context.now,
      payload: {
        kevListed: true,
        exploitAvailable: true,
        cvssScore: null,
        cvssVector: null,
        references: [KEV_CATALOG_URL],
        summary: summaryParts.join(" "),
        sourceVersion: result.sourceVersion ?? result.meta.source,
      },
      rawPayload: result.data as Record<string, unknown>,
      errorCode: null,
      errorMessage: null,
    });
  }
}
