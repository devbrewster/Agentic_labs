import type { ReactNode } from "react";

type StatusPillProps = {
  children: ReactNode;
  tone?: "default" | "accent" | "danger" | "warning" | "success";
};

const toneClasses = {
  default:
    "border-[rgba(255,255,255,0.06)] bg-[rgba(255,255,255,0.03)] text-[#5a7080]",
  accent:
    "border-[rgba(0,200,180,0.12)] bg-[rgba(0,200,180,0.12)] text-[var(--accent)]",
  danger:
    "border-[rgba(255,77,109,0.18)] bg-[rgba(255,77,109,0.12)] text-[var(--danger)]",
  warning:
    "border-[rgba(255,208,96,0.18)] bg-[rgba(255,208,96,0.12)] text-[var(--warning)]",
  success:
    "border-[rgba(76,201,163,0.18)] bg-[rgba(76,201,163,0.12)] text-[#76f1c7]",
} as const;

export function StatusPill({
  children,
  tone = "default",
}: StatusPillProps) {
  return (
    <span
      className={`inline-flex min-h-9 items-center rounded-sm border px-3 py-2 font-mono text-[0.62rem] font-semibold uppercase leading-none tracking-[0.12em] ${toneClasses[tone]}`}
    >
      {children}
    </span>
  );
}
