export type AppDeploymentMode = "path_dashboard" | "subdomain_root";

export type DashboardRouteKey =
  | "overview"
  | "uploads"
  | "findings"
  | "actionPlans"
  | "issues"
  | "reports"
  | "integrations"
  | "settings";

type DashboardRouteConfig = {
  pathMode: string;
  subdomainMode: string;
};

const dashboardRoutes: Record<DashboardRouteKey, DashboardRouteConfig> = {
  overview: {
    pathMode: "/dashboard",
    subdomainMode: "/",
  },
  uploads: {
    pathMode: "/dashboard/uploads",
    subdomainMode: "/uploads",
  },
  findings: {
    pathMode: "/dashboard/findings",
    subdomainMode: "/findings",
  },
  actionPlans: {
    pathMode: "/dashboard/action-plans",
    subdomainMode: "/action-plans",
  },
  issues: {
    pathMode: "/dashboard/issues",
    subdomainMode: "/issues",
  },
  reports: {
    pathMode: "/dashboard/reports",
    subdomainMode: "/reports",
  },
  integrations: {
    pathMode: "/dashboard/integrations",
    subdomainMode: "/integrations",
  },
  settings: {
    pathMode: "/dashboard/settings",
    subdomainMode: "/settings",
  },
};

function getDeploymentMode(): AppDeploymentMode {
  const configured =
    process.env.NEXT_PUBLIC_APP_DEPLOYMENT_MODE ??
    process.env.APP_DEPLOYMENT_MODE ??
    "path_dashboard";

  return configured === "subdomain_root" ? "subdomain_root" : "path_dashboard";
}

export function getDashboardHref(routeKey: DashboardRouteKey) {
  const route = dashboardRoutes[routeKey];
  return getDeploymentMode() === "subdomain_root"
    ? route.subdomainMode
    : route.pathMode;
}

export function getDashboardRouteAliases(routeKey: DashboardRouteKey) {
  const route = dashboardRoutes[routeKey];
  return [route.pathMode, route.subdomainMode];
}

export function getDashboardRouteKeyFromPathname(pathname: string): DashboardRouteKey | null {
  const normalized = pathname.replace(/\/+$/, "") || "/";

  for (const [routeKey, route] of Object.entries(dashboardRoutes) as Array<
    [DashboardRouteKey, DashboardRouteConfig]
  >) {
    const aliases = [route.pathMode, route.subdomainMode].map(
      (value) => value.replace(/\/+$/, "") || "/",
    );

    if (aliases.includes(normalized)) {
      return routeKey;
    }

    if (
      routeKey !== "overview" &&
      aliases.some((alias) => alias !== "/" && normalized.startsWith(`${alias}/`))
    ) {
      return routeKey;
    }
  }

  return null;
}

export function isDashboardRoutePath(pathname: string) {
  return getDashboardRouteKeyFromPathname(pathname) !== null;
}

export function getAppDomainHost() {
  return process.env.NEXT_PUBLIC_APP_DOMAIN_HOST ?? process.env.APP_DOMAIN_HOST ?? "app.cveriskpilot.com";
}
