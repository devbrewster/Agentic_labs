#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 6 ]]; then
  echo "Usage: $0 <repo_root> <agent_key> <phase> <prompt_file> <task_file> <output_file>"
  exit 1
fi

REPO_ROOT="$(cd "$1" && pwd)"
AGENT_KEY="$2"
PHASE="$3"
PROMPT_FILE="$4"
TASK_FILE="$5"
OUTPUT_FILE="$6"

DRY_RUN="${DRY_RUN:-0}"
MODEL="${CODEX_MODEL:-gpt-5-codex}"
STATE_DIR="$REPO_ROOT/.codex/state"
LOG_DIR="$STATE_DIR/logs"

mkdir -p "$STATE_DIR" "$LOG_DIR" "$(dirname "$OUTPUT_FILE")"

STATUS_FILE="$STATE_DIR/${AGENT_KEY}-${PHASE}.status"
PROMPT_SNAPSHOT="$STATE_DIR/${AGENT_KEY}-${PHASE}.prompt.md"
LOG_FILE="$LOG_DIR/${AGENT_KEY}-${PHASE}.log"
TMP_OUTPUT="$(mktemp "$STATE_DIR/${AGENT_KEY}-${PHASE}.output.XXXXXX")"

cat "$PROMPT_FILE" > "$PROMPT_SNAPSHOT"
printf '\n\n---\n\n' >> "$PROMPT_SNAPSHOT"
cat "$TASK_FILE" >> "$PROMPT_SNAPSHOT"

printf 'agent=%s\nphase=%s\nstatus=running\nstarted_at=%s\n' \
  "$AGENT_KEY" "$PHASE" "$(date -Iseconds)" > "$STATUS_FILE"

if [[ "$DRY_RUN" == "1" ]]; then
  cat > "$OUTPUT_FILE" <<EOF
# ${AGENT_KEY} ${PHASE} (dry run)

- Prompt file: ${PROMPT_FILE}
- Task file: ${TASK_FILE}
- Repo root: ${REPO_ROOT}
- Model: ${MODEL}

This is a dry run placeholder. No Codex model call was executed.
EOF
  printf 'agent=%s\nphase=%s\nstatus=dry_run_complete\ncompleted_at=%s\n' \
    "$AGENT_KEY" "$PHASE" "$(date -Iseconds)" > "$STATUS_FILE"
  exit 0
fi

if codex exec \
  --cd "$REPO_ROOT" \
  --skip-git-repo-check \
  --full-auto \
  --model "$MODEL" \
  --output-last-message "$TMP_OUTPUT" \
  - < "$PROMPT_SNAPSHOT" >"$LOG_FILE" 2>&1; then
  if [[ -s "$OUTPUT_FILE" ]]; then
    rm -f "$TMP_OUTPUT"
  else
    mv "$TMP_OUTPUT" "$OUTPUT_FILE"
  fi

  printf 'agent=%s\nphase=%s\nstatus=completed\ncompleted_at=%s\noutput=%s\n' \
    "$AGENT_KEY" "$PHASE" "$(date -Iseconds)" "$OUTPUT_FILE" > "$STATUS_FILE"
else
  rm -f "$TMP_OUTPUT"
  printf 'agent=%s\nphase=%s\nstatus=failed\nfailed_at=%s\nlog=%s\n' \
    "$AGENT_KEY" "$PHASE" "$(date -Iseconds)" "$LOG_FILE" > "$STATUS_FILE"
  exit 1
fi
