import { DbSchemaNotInitializedError, getDb } from "@/lib/db";
import { D1EnrichmentRepository } from "@/lib/enrichment/d1-repository";
import { PostgresEnrichmentRepository } from "@/lib/enrichment/postgres-repository";
import { createDefaultEnrichmentService } from "@/lib/enrichment";
import { EnrichmentJobRunner } from "@/lib/enrichment/job-runner";
import { InMemoryEnrichmentRepository, type EnrichmentRepository } from "@/lib/enrichment/repository";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { getOrCreatePostgresQueryClient } from "@/lib/platform/postgres";
import { getPlatformProfile } from "@/lib/platform/runtime";

type EnrichmentRuntime = {
  enrichmentRepository: EnrichmentRepository;
  enrichmentJobRunner: EnrichmentJobRunner;
};

const fallbackEnrichmentRepository = new InMemoryEnrichmentRepository();
let fallbackRuntime: EnrichmentRuntime | null = null;

function buildRuntime(enrichmentRepository: EnrichmentRepository) {
  return getIngestionRuntime().then(({ uploadRepository }) => ({
    enrichmentRepository,
    enrichmentJobRunner: new EnrichmentJobRunner(
      uploadRepository,
      enrichmentRepository,
      createDefaultEnrichmentService(),
    ),
  }));
}

function isFallbackRuntimeError(error: unknown) {
  if (!(error instanceof Error)) {
    return false;
  }

  return (
    /Cloudflare D1 binding/i.test(error.message) ||
    /getCloudflareContext/i.test(error.message) ||
    /Database schema is not initialized/i.test(error.message)
  );
}

async function getFallbackRuntime() {
  if (!fallbackRuntime) {
    fallbackRuntime = await buildRuntime(fallbackEnrichmentRepository);
  }

  return fallbackRuntime;
}

export async function getEnrichmentRuntime(): Promise<EnrichmentRuntime> {
  const platform = getPlatformProfile();

  if (platform.databaseDriver === "postgres") {
    const postgresClient = await getOrCreatePostgresQueryClient();

    if (postgresClient) {
      return buildRuntime(new PostgresEnrichmentRepository(postgresClient));
    }
  }

  try {
    const db = await getDb();
    return buildRuntime(new D1EnrichmentRepository(db));
  } catch (error) {
    if (error instanceof DbSchemaNotInitializedError) {
      throw error;
    }

    if (isFallbackRuntimeError(error)) {
      return getFallbackRuntime();
    }

    throw error;
  }
}
