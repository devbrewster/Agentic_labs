export const AI_TRIAGE_RUN_EVENT = "cveriskpilot:run-ai-triage";
export const AI_TRIAGE_STATUS_EVENT = "cveriskpilot:ai-triage-status";

export type AiTriageRunDetail = {
  mode: "live";
};

export type AiTriageStatusDetail = {
  status: "idle" | "running" | "success" | "error";
  message?: string;
};

export function dispatchAiTriageRun(detail: AiTriageRunDetail = { mode: "live" }) {
  window.dispatchEvent(new CustomEvent<AiTriageRunDetail>(AI_TRIAGE_RUN_EVENT, { detail }));
}

export function dispatchAiTriageStatus(detail: AiTriageStatusDetail) {
  window.dispatchEvent(
    new CustomEvent<AiTriageStatusDetail>(AI_TRIAGE_STATUS_EVENT, { detail }),
  );
}
