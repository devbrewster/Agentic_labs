import { describe, expect, it } from "vitest";
import { renderToStaticMarkup } from "react-dom/server";

import AboutPage from "@/app/about/page";
import { CveSourceSections } from "@/components/CveSourceSections";
import { FooterAttribution } from "@/components/FooterAttribution";
import { NVD_ATTRIBUTION_NOTICE } from "@/lib/nvd/constants";

describe("NVD compliance UI", () => {
  it("renders required NVD disclaimer in footer", () => {
    const html = renderToStaticMarkup(<FooterAttribution />);
    expect(html).toContain(NVD_ATTRIBUTION_NOTICE);
  });

  it("renders disclaimer and source-separation language on About page", () => {
    const html = renderToStaticMarkup(<AboutPage />);
    expect(html).toContain(NVD_ATTRIBUTION_NOTICE);
    expect(html).toContain("Source: NVD");
    expect(html).toContain("CVERiskPilot Analysis");
    expect(html).toContain("Other Enrichment Sources");
  });

  it("renders distinct sections for source separation in CVE details", () => {
    const html = renderToStaticMarkup(
      <CveSourceSections
        record={{
          cveId: "CVE-2024-7777",
          nvd: { source: "NVD", rawDescription: "nvd text" },
          analysis: { source: "CVERiskPilot", businessImpact: "analysis text" },
          enrichments: { kev: { listed: true } },
          compliance: {
            attributionRequired: true,
            endorsementProhibited: true,
            modifiedContentSeparated: true,
          },
        }}
        enrichmentSummary={{
          status: "enriched",
          providers: ["nvd", "cisa_kev", "manual"],
          kevListed: true,
        }}
      />,
    );

    expect(html).toContain("Original NVD Data");
    expect(html).toContain("CVERiskPilot Analysis");
    expect(html).toContain("Other Enrichment Sources");
    expect(html).toContain("nvd, cisa_kev, manual");
    expect(html).toContain("KEV");
  });
});
