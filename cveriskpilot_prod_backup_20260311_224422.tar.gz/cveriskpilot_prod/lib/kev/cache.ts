import type { KevCatalogResponse, KevCatalogIndex } from "@/lib/kev/types";

export type KevCacheEntry = {
  key: string;
  fetchedAt: string;
  expiresAt: string;
  rawPayload: KevCatalogResponse;
  catalog: KevCatalogIndex;
};

export type KevCacheProvider = {
  get(key: string): Promise<KevCacheEntry | null>;
  set(entry: KevCacheEntry): Promise<void>;
};

export class InMemoryKevCache implements KevCacheProvider {
  private readonly map = new Map<string, KevCacheEntry>();

  async get(key: string): Promise<KevCacheEntry | null> {
    return this.map.get(key) ?? null;
  }

  async set(entry: KevCacheEntry) {
    this.map.set(entry.key, entry);
  }
}

export function buildKevCacheKey() {
  return "cisa_kev:catalog";
}

export function isKevCacheEntryFresh(entry: KevCacheEntry, nowIso: string) {
  return entry.expiresAt > nowIso;
}
