import { apiError, apiSuccess, readJsonBody, withAuthRoute } from "@/lib/auth";
import { requireAuthenticatedSession, setActiveOrganizationForSession } from "@/lib/session";

type OrganizationSwitchPayload = {
  organization_id?: string;
};

export const POST = withAuthRoute(async function POST(request: Request) {
  const auth = await requireAuthenticatedSession(request);

  if (!auth.ok) {
    return auth.response;
  }

  const payload = await readJsonBody<OrganizationSwitchPayload>(request);
  const organizationId = payload?.organization_id?.trim();

  if (!organizationId) {
    return apiError("invalid_organization", "A valid organization id is required.", 400);
  }

  const updated = await setActiveOrganizationForSession(
    auth.session.session.id,
    auth.session.user.id,
    organizationId,
  );

  if (!updated) {
    return apiError(
      "organization_forbidden",
      "You do not belong to the requested organization.",
      403,
    );
  }

  return apiSuccess({
    active_organization_id: organizationId,
  });
});
