import type { ReactNode } from "react";

type Props = {
  title: string;
  children: ReactNode;
};

export default function AuthCard({ title, children }: Props) {
  return (
    <div className="rounded-xl border border-slate-800 bg-slate-900 p-6 text-white">
      <h2 className="text-2xl font-bold">{title}</h2>
      <div className="mt-4">{children}</div>
    </div>
  );
}
