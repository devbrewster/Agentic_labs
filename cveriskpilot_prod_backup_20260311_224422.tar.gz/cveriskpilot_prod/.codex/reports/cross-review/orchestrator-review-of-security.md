# Orchestrator Cross-Review – Security / Platform Assessment

## Agreements
- **Runtime fallbacks hide prod failures** – `lib/analysis/runtime.ts:1-58` proves the API silently drops to the in-memory trace repository whenever D1/Postgres access fails, matching the agent’s risk call-out about mock data masking outages.
- **Password-only auth with month-long cookies** – `app/api/auth/login/route.ts:13-56` and `lib/session.ts:17-166` show there is no MFA, IP/device binding, or session shortening; sessions live for 30 days, so the red status on MFA/SSO is warranted.
- **Ingestion remains manual and stubbed** – `lib/uploads.ts:1-6` plus `app/api/uploads/[id]/reparse/route.ts:15-45` confirm there is no worker orchestration; operators must ping `reparse`, exactly as described.
- **Uploads accept arbitrary files without safety controls** – `app/api/uploads/route.ts:37-92` simply reads `formData` and passes bytes to `UploadService` while `lib/ingestion/storage.ts:46-149` writes bodies straight to disk/D1 without scanning or quotas; agreement with the “upload validation & malware handling” gap.
- **Mock fallbacks leak into user APIs** – `app/api/findings/route.ts:18-134` drops to `listFindings()` (mock data) on any exception, and `lib/services/uploads.ts:1-12` exposes the same pattern for uploads; aligns with the report’s “mock data masking production issues” risk.

## Blind Spots & Missing Evidence
- **AI artefacts lack tenant metadata** – Neither `database/schema.sql:289-343` (analyst dispositions, analysis_runs) nor `lib/analysis/sql-repository.ts:1-154` store or filter by `tenant_id`. Any future route that skips the extra `findFindingByIdForTenant` guard could expose other tenants’ AI prompts/traces. The assessment did not mention this row-level isolation gap.
- **Raw artifact tenancy bug** – The schema *does* include `tenant_id`, but `UploadService` never populates it and `SqlRawArtifactRepository.save` hardcodes `null` (`lib/ingestion/upload-service.ts:32-77`, `lib/ingestion/sql-repository.ts:274-309`). The report treats this as “schema missing tenant_id,” but the actual issue is a persistence bug that leaves every artifact unattached.
- **No storage encryption or tenancy scoping** – Local and D1 providers write plaintext bodies under `.data/uploads/...` or `raw_artifact_contents.body_text` with no per-tenant prefixing or encryption keys (`lib/ingestion/storage.ts:46-149`). This increases blast radius beyond the missing tenant metadata the report highlighted, yet the assessment never flagged encryption/KMS gaps.

## Conflicts / Clarifications
- **Tenant-scoped artifact storage wording** – Agree with the underlying risk, but it is more precise to document that tenant columns exist and are never set (`lib/ingestion/sql-repository.ts:274-309`) rather than saying “raw artifacts are stored without an organization foreign key.” This nuance impacts the remediation plan (fix the repository + backfill) versus reworking the schema.

## Recommended Adjustments to the Security Report
1. **Call out missing tenant columns for AI/analyst tables** so engineers add `tenant_id` (and constraints) to `analyst_dispositions`, `analyst_disposition_events`, and `analysis_runs`, plus enforce tenant filters in `lib/analysis/sql-repository.ts`.
2. **Reframe the artifact storage risk** to highlight the `UploadService`/repository bug that drops tenant_id on write; add a TODO for data backfill/migration in addition to bucket hardening.
3. **Add encryption / KMS requirements** for upload storage. Today’s implementations (`lib/ingestion/storage.ts`) never encrypt, so S3 bucket policies alone won’t meet enterprise expectations.
4. **Note dependency on route-level guards for AI traces** – suggest adding tenant-aware scopes inside the repositories instead of assuming every caller already verified organization membership.
