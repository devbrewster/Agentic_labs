import { getDashboardHref, type DashboardRouteKey } from "@/lib/app-routes";
import type { Severity } from "@/types/dashboard";

export type DashboardNavItem = {
  label: string;
  href: string;
  routeKey: DashboardRouteKey;
  icon: string;
  badge?: string;
  section: "workspace" | "reporting" | "platform";
};

export const dashboardNavItems: DashboardNavItem[] = [
  {
    label: "Triage Dashboard",
    href: getDashboardHref("overview"),
    routeKey: "overview",
    icon: "◈",
    badge: "live",
    section: "workspace",
  },
  {
    label: "New Scan / Uploads",
    href: getDashboardHref("uploads"),
    routeKey: "uploads",
    icon: "↑",
    section: "workspace",
  },
  {
    label: "All Findings",
    href: getDashboardHref("findings"),
    routeKey: "findings",
    icon: "≡",
    section: "workspace",
  },
  {
    label: "Action Plans",
    href: getDashboardHref("actionPlans"),
    routeKey: "actionPlans",
    icon: "✦",
    section: "workspace",
  },
  {
    label: "Issues",
    href: getDashboardHref("issues"),
    routeKey: "issues",
    icon: "!",
    badge: "6",
    section: "reporting",
  },
  {
    label: "Reports",
    href: getDashboardHref("reports"),
    routeKey: "reports",
    icon: "▦",
    section: "reporting",
  },
  {
    label: "Integrations",
    href: getDashboardHref("integrations"),
    routeKey: "integrations",
    icon: "◎",
    section: "platform",
  },
  {
    label: "Settings",
    href: getDashboardHref("settings"),
    routeKey: "settings",
    icon: "○",
    section: "platform",
  },
];

export const dashboardEnvironmentBadges = [
  "Mock Mode",
  "Worker Ready",
  "AI Placeholders",
];

export type DashboardStat = {
  label: string;
  value: number;
  delta: string;
  deltaValue: number | null;
  direction: "up" | "down" | "neutral";
  tone: Severity | "accent";
};

export const dashboardStats: DashboardStat[] = [
  {
    label: "Critical",
    value: 9,
    delta: "+3 since last scan",
    deltaValue: 3,
    direction: "up",
    tone: "critical",
  },
  {
    label: "High",
    value: 24,
    delta: "+7 since last scan",
    deltaValue: 7,
    direction: "up",
    tone: "high",
  },
  {
    label: "Medium",
    value: 118,
    delta: "-12 resolved",
    deltaValue: -12,
    direction: "down",
    tone: "medium",
  },
  {
    label: "Low",
    value: 696,
    delta: "-44 resolved",
    deltaValue: -44,
    direction: "down",
    tone: "accent",
  },
  {
    label: "Action Plans",
    value: 3,
    delta: "AI generated",
    deltaValue: null,
    direction: "neutral",
    tone: "low",
  },
];
