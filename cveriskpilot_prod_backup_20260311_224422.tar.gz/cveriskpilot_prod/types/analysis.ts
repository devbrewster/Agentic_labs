import { z } from "zod";

import { AnalystDecisionSchema, ArchitectureInfluenceFactorsSchema } from "@/types/analyst";
import { EnrichmentProviderSchema } from "@/types/enrichment";

export const AnalysisModeSchema = z.enum(["stub", "live"]);
export type AnalysisMode = z.infer<typeof AnalysisModeSchema>;
export const AnalysisTraceStatusSchema = z.enum(["completed", "fallback"]);
export type AnalysisTraceStatus = z.infer<typeof AnalysisTraceStatusSchema>;

export const PromptTemplateVersion = "p3-7.v1" as const;

export const FindingPromptContextSchema = z.object({
  findingId: z.string().min(1),
  cveId: z.string().min(1),
  title: z.string().min(1),
  description: z.string().nullable(),
  severity: z.enum(["critical", "high", "medium", "low"]),
  riskScore: z.number().min(0).max(100),
  cvssScore: z.number().min(0).max(10).nullable(),
  assetName: z.string().min(1),
  environment: z.enum(["production", "staging", "development", "corporate"]),
  status: z.string().min(1),
  remediationSummary: z.string().nullable(),
  discoveredAt: z.string().min(1),
  tags: z.array(z.string()),
});
export type FindingPromptContext = z.infer<typeof FindingPromptContextSchema>;

export const EnrichmentPromptContextSchema = z.object({
  status: z.enum(["pending", "enriched", "partial", "failed", "not_found"]),
  providers: z.array(EnrichmentProviderSchema),
  kevListed: z.boolean().nullable(),
  exploitAvailable: z.boolean().nullable(),
  cvssVector: z.string().nullable(),
  references: z.array(z.string().url()),
  lastObservedAt: z.string().nullable(),
  summarySnippets: z.array(z.string()),
});
export type EnrichmentPromptContext = z.infer<typeof EnrichmentPromptContextSchema>;

export const AnalystPromptContextSchema = z.object({
  decision: AnalystDecisionSchema.nullable(),
  rationale: z.string().nullable(),
  architectureContextSummary: z.string().nullable(),
  influenceFactors: ArchitectureInfluenceFactorsSchema.nullable(),
});
export type AnalystPromptContext = z.infer<typeof AnalystPromptContextSchema>;

export const AnalysisPromptContextSchema = z.object({
  templateVersion: z.string().min(1),
  generatedAt: z.iso.datetime(),
  finding: FindingPromptContextSchema,
  enrichment: EnrichmentPromptContextSchema,
  analyst: AnalystPromptContextSchema,
  compliance: z.object({
    sourceSeparationRequired: z.literal(true),
    nvdAttributionRequired: z.literal(true),
    noEndorsementLanguage: z.literal(true),
  }),
});
export type AnalysisPromptContext = z.infer<typeof AnalysisPromptContextSchema>;

export const PromptEnvelopeSchema = z.object({
  templateVersion: z.string().min(1),
  systemPrompt: z.string().min(1),
  userPrompt: z.string().min(1),
  context: AnalysisPromptContextSchema,
});
export type PromptEnvelope = z.infer<typeof PromptEnvelopeSchema>;

export const FindingAnalysisOutputSchema = z.object({
  businessImpact: z.string().min(1),
  exploitabilityAssessment: z.string().min(1),
  falsePositiveAssessment: z.string().min(1),
  recommendedAction: z.string().min(1),
  confidence: z.number().min(0).max(1),
});
export type FindingAnalysisOutput = z.infer<typeof FindingAnalysisOutputSchema>;

export const GeneratedFindingAnalysisSchema = z.object({
  mode: AnalysisModeSchema,
  provider: z.enum(["claude", "stub"]),
  model: z.string().min(1),
  generatedAt: z.iso.datetime(),
  traceStatus: AnalysisTraceStatusSchema,
  fallbackReason: z.string().min(1).nullable().default(null),
  output: FindingAnalysisOutputSchema,
  warnings: z.array(z.string()),
});
export type GeneratedFindingAnalysis = z.infer<typeof GeneratedFindingAnalysisSchema>;

export const GenerateFindingAnalysisRequestSchema = z.object({
  mode: AnalysisModeSchema.default("stub"),
});
export type GenerateFindingAnalysisRequest = z.infer<typeof GenerateFindingAnalysisRequestSchema>;

export const AnalysisTraceRecordSchema = z.object({
  id: z.string().uuid(),
  findingId: z.string().min(1),
  source: z.enum(["ingestion", "mock"]),
  requestedMode: AnalysisModeSchema,
  provider: z.enum(["claude", "stub"]),
  model: z.string().min(1),
  templateVersion: z.string().min(1),
  traceStatus: AnalysisTraceStatusSchema,
  fallbackReason: z.string().min(1).nullable(),
  warningCount: z.number().int().nonnegative(),
  generatedAt: z.iso.datetime(),
  createdAt: z.iso.datetime(),
  promptContextJson: z.record(z.string(), z.unknown()),
  promptEnvelopeJson: z.record(z.string(), z.unknown()),
  outputJson: z.record(z.string(), z.unknown()),
  warningsJson: z.array(z.string()),
});
export type AnalysisTraceRecord = z.infer<typeof AnalysisTraceRecordSchema>;

export const CreateAnalysisTraceInputSchema = z.object({
  findingId: z.string().min(1),
  source: z.enum(["ingestion", "mock"]),
  requestedMode: AnalysisModeSchema,
  generated: GeneratedFindingAnalysisSchema,
  prompt: PromptEnvelopeSchema,
});
export type CreateAnalysisTraceInput = z.infer<typeof CreateAnalysisTraceInputSchema>;
