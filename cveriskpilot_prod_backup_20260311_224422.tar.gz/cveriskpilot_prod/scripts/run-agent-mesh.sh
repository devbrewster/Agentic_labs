#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DRY_RUN=0

if [[ "${1:-}" == "--dry-run" ]]; then
  DRY_RUN=1
fi

RUNNER="$REPO_ROOT/scripts/agent-runtime/run-codex-agent.sh"
PROMPTS_DIR="$REPO_ROOT/.codex/prompts"
INDIVIDUAL_DIR="$REPO_ROOT/.codex/reports/individual"
CROSS_DIR="$REPO_ROOT/.codex/reports/cross-review"
FINAL_DIR="$REPO_ROOT/.codex/reports/final"
STATE_DIR="$REPO_ROOT/.codex/state"
TASK_DIR="$STATE_DIR/tasks"
FINAL_REPORT="$FINAL_DIR/unified-production-saas-assessment.md"
BUNDLE_FILE="$FINAL_DIR/unified-source-bundle.md"

mkdir -p "$TASK_DIR" "$INDIVIDUAL_DIR" "$CROSS_DIR" "$FINAL_DIR"

find "$STATE_DIR" -maxdepth 1 -type f \( -name '*.status' -o -name '*.prompt.md' -o -name '*.output.*' \) -delete 2>/dev/null || true
find "$TASK_DIR" -maxdepth 1 -type f -delete 2>/dev/null || true
find "$STATE_DIR/logs" -maxdepth 1 -type f -name '*.log' -delete 2>/dev/null || true
find "$INDIVIDUAL_DIR" -maxdepth 1 -type f -name '*.md' -delete 2>/dev/null || true
find "$CROSS_DIR" -maxdepth 1 -type f -name '*.md' -delete 2>/dev/null || true
find "$FINAL_DIR" -maxdepth 1 -type f -name '*.md' -delete 2>/dev/null || true

if [[ ! -x "$RUNNER" ]]; then
  echo "Missing executable runner: $RUNNER"
  exit 1
fi

if [[ "$DRY_RUN" != "1" ]] && ! command -v codex >/dev/null 2>&1; then
  echo "codex CLI is required for a live mesh run."
  exit 1
fi

log() {
  printf '[mesh] %s\n' "$1"
}

write_task() {
  local path="$1"
  local content="$2"
  printf "%s" "$content" > "$path"
}

run_agent() {
  local agent_key="$1"
  local phase="$2"
  local prompt_file="$3"
  local task_file="$4"
  local output_file="$5"

  DRY_RUN="$DRY_RUN" "$RUNNER" \
    "$REPO_ROOT" \
    "$agent_key" \
    "$phase" \
    "$prompt_file" \
    "$task_file" \
    "$output_file"
}

log "phase 1: independent reviews"

declare -A PROMPTS=(
  [orchestrator]="$PROMPTS_DIR/orchestrator.md"
  [pm_agent]="$PROMPTS_DIR/pm_agent.md"
  [product_ux]="$PROMPTS_DIR/product-ux.md"
  [security_platform]="$PROMPTS_DIR/security-platform.md"
)

declare -A OUTPUTS=(
  [orchestrator]="$INDIVIDUAL_DIR/orchestrator-assessment.md"
  [pm_agent]="$INDIVIDUAL_DIR/pm-agent-assessment.md"
  [product_ux]="$INDIVIDUAL_DIR/product-ux-assessment.md"
  [security_platform]="$INDIVIDUAL_DIR/security-platform-assessment.md"
)

for agent_key in orchestrator pm_agent product_ux security_platform; do
  task_file="$TASK_DIR/${agent_key}-independent.md"
  write_task "$task_file" "You are running in the CVERiskPilot autonomous multi-agent mesh.

Phase: Independent review

Review the current repository state from your role perspective.

Requirements:
- produce a complete markdown report
- write only the final report content
- focus on concrete gaps, risks, and recommended next steps
- cite file paths when relevant
- do not mention internal chain-of-thought

Output target: ${OUTPUTS[$agent_key]}
"

  run_agent "$agent_key" "independent" "${PROMPTS[$agent_key]}" "$task_file" "${OUTPUTS[$agent_key]}" &
done
wait

log "phase 2: cross-review"

cross_review() {
  local reviewer_key="$1"
  local subject_key="$2"
  local reviewer_prompt="$3"
  local subject_file="$4"
  local output_file="$5"
  local task_file="$TASK_DIR/${reviewer_key}-review-of-${subject_key}.md"

  write_task "$task_file" "You are running in the CVERiskPilot autonomous multi-agent mesh.

Phase: Cross-review

Review this report from another agent:
- ${subject_file}

Requirements:
- produce a markdown review
- identify agreements, blind spots, conflicts, and recommended changes
- write only the final review content
- cite file paths or repo areas when relevant

Output target: ${output_file}
"

  run_agent "$reviewer_key" "cross-review-of-${subject_key}" "$reviewer_prompt" "$task_file" "$output_file"
}

cross_review orchestrator pm "${PROMPTS[orchestrator]}" "$INDIVIDUAL_DIR/pm-agent-assessment.md" "$CROSS_DIR/orchestrator-review-of-pm.md"
cross_review orchestrator product "${PROMPTS[orchestrator]}" "$INDIVIDUAL_DIR/product-ux-assessment.md" "$CROSS_DIR/orchestrator-review-of-product.md"
cross_review orchestrator security "${PROMPTS[orchestrator]}" "$INDIVIDUAL_DIR/security-platform-assessment.md" "$CROSS_DIR/orchestrator-review-of-security.md"
cross_review pm_agent orchestrator "${PROMPTS[pm_agent]}" "$INDIVIDUAL_DIR/orchestrator-assessment.md" "$CROSS_DIR/pm-review-of-orchestrator.md"
cross_review pm_agent product "${PROMPTS[pm_agent]}" "$INDIVIDUAL_DIR/product-ux-assessment.md" "$CROSS_DIR/pm-review-of-product.md"
cross_review pm_agent security "${PROMPTS[pm_agent]}" "$INDIVIDUAL_DIR/security-platform-assessment.md" "$CROSS_DIR/pm-review-of-security.md"
cross_review product_ux orchestrator "${PROMPTS[product_ux]}" "$INDIVIDUAL_DIR/orchestrator-assessment.md" "$CROSS_DIR/product-review-of-orchestrator.md"
cross_review product_ux pm "${PROMPTS[product_ux]}" "$INDIVIDUAL_DIR/pm-agent-assessment.md" "$CROSS_DIR/product-review-of-pm.md"
cross_review product_ux security "${PROMPTS[product_ux]}" "$INDIVIDUAL_DIR/security-platform-assessment.md" "$CROSS_DIR/product-review-of-security.md"
cross_review security_platform orchestrator "${PROMPTS[security_platform]}" "$INDIVIDUAL_DIR/orchestrator-assessment.md" "$CROSS_DIR/security-review-of-orchestrator.md"
cross_review security_platform pm "${PROMPTS[security_platform]}" "$INDIVIDUAL_DIR/pm-agent-assessment.md" "$CROSS_DIR/security-review-of-pm.md"
cross_review security_platform product "${PROMPTS[security_platform]}" "$INDIVIDUAL_DIR/product-ux-assessment.md" "$CROSS_DIR/security-review-of-product.md"

matrix_task="$TASK_DIR/orchestrator-cross-review-matrix.md"
write_task "$matrix_task" "You are running in the CVERiskPilot autonomous multi-agent mesh.

Phase: Cross-review matrix

Build a consolidated matrix from the individual and cross-review reports.

Requirements:
- produce markdown only
- capture shared findings, conflicts, blind spots, uncovered areas, and unified priority order
- write only the final matrix content

Input directories:
- ${INDIVIDUAL_DIR}
- ${CROSS_DIR}

Output target: ${CROSS_DIR}/cross-review-matrix.md
"
run_agent orchestrator "cross-review-matrix" "${PROMPTS[orchestrator]}" "$matrix_task" "$CROSS_DIR/cross-review-matrix.md"

log "phase 3: source bundle"
"$REPO_ROOT/scripts/merge-agent-assessments.sh" "$REPO_ROOT"

log "phase 4: final synthesis"
final_task="$TASK_DIR/orchestrator-final.md"
write_task "$final_task" "You are running in the CVERiskPilot autonomous multi-agent mesh.

Phase: Final synthesis

Read the consolidated source bundle:
- ${BUNDLE_FILE}

Produce the final unified report.

Requirements:
- output markdown only
- synthesize the strongest findings, not a raw concatenation
- give a final recommended implementation order
- keep the report actionable for the engineering team

Output target: ${FINAL_REPORT}
"
run_agent orchestrator "final" "${PROMPTS[orchestrator]}" "$final_task" "$FINAL_REPORT"

log "mesh run complete"
log "final report: $FINAL_REPORT"
