import path from "node:path";

import { sha256Hex, toBuffer } from "@/lib/ingestion/checksum";
import { buildRawArtifactRecord } from "@/lib/ingestion/files";
import { ParseJobRunner } from "@/lib/ingestion/parse-job-runner";
import { DefaultParserRegistry } from "@/lib/ingestion/parser-registry";
import { GenericCsvParser } from "@/lib/ingestion/parsers/generic-csv-parser";
import { NessusParser } from "@/lib/ingestion/parsers/nessus-parser";
import { QualysParser } from "@/lib/ingestion/parsers/qualys-parser";
import { Rapid7Parser } from "@/lib/ingestion/parsers/rapid7-parser";
import { InMemoryUploadRepository } from "@/lib/ingestion/repository";
import { UploadService } from "@/lib/ingestion/upload-service";
import type { SaveArtifactInput, SaveArtifactOutput, StorageProvider } from "@/lib/ingestion/storage";

class InMemoryTestStorageProvider implements StorageProvider {
  private readonly content = new Map<string, Buffer>();

  async saveArtifact(input: SaveArtifactInput): Promise<SaveArtifactOutput> {
    const body = toBuffer(input.body);
    const checksumSha256 = sha256Hex(body);
    const uploadedAt = input.uploadedAt ?? new Date().toISOString();
    const storageKey = path.join(uploadedAt.slice(0, 10), checksumSha256, input.originalFilename);

    this.content.set(storageKey, body);

    return {
      checksumSha256,
      artifact: buildRawArtifactRecord({
        checksumSha256,
        originalFilename: input.originalFilename,
        mimeType: input.mimeType,
        sizeBytes: body.byteLength,
        storageKey,
        uploadedAt,
      }),
    };
  }

  async readArtifact(storageKey: string) {
    const content = this.content.get(storageKey);

    if (!content) {
      throw new Error(`Artifact content not found for storage key '${storageKey}'.`);
    }

    return content;
  }
}

export async function createIngestionTestContext() {
  const repository = new InMemoryUploadRepository();
  const storageProvider = new InMemoryTestStorageProvider();
  const parserRegistry = new DefaultParserRegistry();

  parserRegistry.register(new GenericCsvParser());
  parserRegistry.register(new NessusParser());
  parserRegistry.register(new QualysParser());
  parserRegistry.register(new Rapid7Parser());

  const uploadService = new UploadService(repository, storageProvider);
  const parseJobRunner = new ParseJobRunner(repository, storageProvider, parserRegistry);

  return {
    repository,
    storageProvider,
    parserRegistry,
    uploadService,
    parseJobRunner,
  };
}
