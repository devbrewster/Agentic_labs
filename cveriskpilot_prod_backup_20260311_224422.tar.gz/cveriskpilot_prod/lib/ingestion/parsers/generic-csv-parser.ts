import {
  ParseResultSchema,
  type ArtifactFileType,
  type NormalizedFinding,
  type NormalizedSeverity,
  type ParseContext,
  type ParseMetadata,
  type ParseResult,
  type ParserDetectionHint,
  type ParserError,
  type ParserWarning,
  type RawArtifact,
  type ScannerParser,
} from "@/types/ingestion";

const GENERIC_CSV_SCANNER_NAME = "Generic CSV Import";

const headerAliases = {
  assetIdentifier: ["asset id", "asset identifier", "device id", "resource id"],
  cvssScore: ["cvss", "cvss score", "cvssv3", "cvss v3", "base score"],
  cvssVector: ["cvss vector", "cvssv3 vector", "vector"],
  cveIds: ["cve", "cve id", "cve_id", "cve ids", "cves"],
  description: ["description", "details", "summary", "synopsis"],
  detectedAt: ["detected at", "discovered at", "found at", "first detected"],
  evidence: ["evidence", "plugin output", "output", "proof"],
  firstObservedAt: ["first observed", "first seen"],
  fqdn: ["fqdn", "dns", "domain"],
  hostname: ["host", "hostname", "asset", "asset name", "target", "host name"],
  ipAddress: ["ip", "ip address", "address", "host ip"],
  lastObservedAt: ["last observed", "last seen", "updated at"],
  pluginId: ["plugin id", "pluginid", "qid", "check id"],
  port: ["port", "service port"],
  protocol: ["protocol", "service", "transport"],
  remediation: ["remediation", "solution", "fix", "recommendation"],
  severity: ["severity", "risk", "priority", "level"],
  status: ["status", "state"],
  title: ["title", "name", "vulnerability", "vulnerability title", "plugin name"],
  vulnerabilityId: ["vulnerability id", "vuln id", "finding id", "issue id"],
} as const;

type CanonicalField = keyof typeof headerAliases;

type CsvRowRecord = Record<string, string>;

function normalizeHeader(header: string) {
  return header.trim().toLowerCase().replace(/[_-]+/g, " ").replace(/\s+/g, " ");
}

function splitCveIds(value: string | undefined) {
  if (!value) {
    return [];
  }

  return value
    .split(/[;,|\s]+/)
    .map((entry) => entry.trim().toUpperCase())
    .filter((entry) => /^CVE-\d{4}-\d{4,}$/i.test(entry));
}

function normalizeSeverity(value: string | undefined): NormalizedSeverity {
  const normalized = value?.trim().toLowerCase() ?? "";

  if (["critical", "urgent", "severe", "5"].includes(normalized)) {
    return "critical";
  }

  if (["high", "important", "4"].includes(normalized)) {
    return "high";
  }

  if (["medium", "moderate", "3"].includes(normalized)) {
    return "medium";
  }

  if (["low", "minor", "2"].includes(normalized)) {
    return "low";
  }

  if (["informational", "info", "1"].includes(normalized)) {
    return "informational";
  }

  return "unknown";
}

function normalizeFindingStatus(value: string | undefined) {
  const normalized = value?.trim().toLowerCase() ?? "";

  switch (normalized) {
    case "open":
    case "new":
      return "open" as const;
    case "triaged":
      return "triaged" as const;
    case "in progress":
    case "in_progress":
      return "in_progress" as const;
    case "resolved":
    case "closed":
    case "fixed":
      return "resolved" as const;
    case "accepted risk":
    case "accepted_risk":
      return "accepted_risk" as const;
    case "false positive":
    case "false_positive":
      return "false_positive" as const;
    case "not applicable":
    case "not_applicable":
      return "not_applicable" as const;
    default:
      return null;
  }
}

function parseNumber(value: string | undefined) {
  if (!value) {
    return null;
  }

  const parsed = Number(value.trim());
  return Number.isFinite(parsed) ? parsed : null;
}

function parsePort(value: string | undefined) {
  const parsed = parseNumber(value);

  if (parsed === null) {
    return null;
  }

  if (parsed < 0 || parsed > 65535) {
    return null;
  }

  return Math.trunc(parsed);
}

function parseDate(value: string | undefined) {
  if (!value) {
    return null;
  }

  const parsed = new Date(value);
  return Number.isNaN(parsed.getTime()) ? null : parsed.toISOString();
}

function mapHeaders(headers: string[]) {
  const canonicalHeaderMap = new Map<CanonicalField, string>();
  const unmappedHeaders: string[] = [];

  for (const header of headers) {
    const normalized = normalizeHeader(header);
    const matchedField = (Object.keys(headerAliases) as CanonicalField[]).find((field) =>
      (headerAliases[field] as readonly string[]).includes(normalized),
    );

    if (matchedField) {
      if (!canonicalHeaderMap.has(matchedField)) {
        canonicalHeaderMap.set(matchedField, header);
      }
    } else {
      unmappedHeaders.push(header);
    }
  }

  return {
    canonicalHeaderMap,
    unmappedHeaders,
  };
}

function parseCsvContent(content: string): { rows: string[][]; error: ParserError | null } {
  const rows: string[][] = [];
  const currentRow: string[] = [];
  let currentValue = "";
  let inQuotes = false;

  for (let index = 0; index < content.length; index += 1) {
    const char = content[index];
    const nextChar = content[index + 1];

    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        currentValue += '"';
        index += 1;
        continue;
      }

      inQuotes = !inQuotes;
      continue;
    }

    if (char === "," && !inQuotes) {
      currentRow.push(currentValue);
      currentValue = "";
      continue;
    }

    if ((char === "\n" || char === "\r") && !inQuotes) {
      if (char === "\r" && nextChar === "\n") {
        index += 1;
      }

      currentRow.push(currentValue);
      rows.push([...currentRow]);
      currentRow.length = 0;
      currentValue = "";
      continue;
    }

    currentValue += char;
  }

  if (inQuotes) {
    return {
      rows: [],
      error: {
        code: "csv_unclosed_quote",
        message: "CSV parsing failed because a quoted field was not closed.",
        details: null,
        fatal: true,
      },
    };
  }

  if (currentValue.length > 0 || currentRow.length > 0) {
    currentRow.push(currentValue);
    rows.push([...currentRow]);
  }

  return {
    rows,
    error: null,
  };
}

function trimRow(row: string[]) {
  return row.map((value) => value.trim());
}

function rowToRecord(headers: string[], row: string[]) {
  const record: CsvRowRecord = {};

  headers.forEach((header, index) => {
    record[header] = row[index]?.trim() ?? "";
  });

  return record;
}

function getValue(
  record: CsvRowRecord,
  canonicalHeaderMap: Map<CanonicalField, string>,
  field: CanonicalField,
) {
  const header = canonicalHeaderMap.get(field);
  return header ? record[header] : undefined;
}

function buildMetadata(input: {
  artifact: RawArtifact;
  findings: NormalizedFinding[];
  parsedAt: string;
}) {
  const uniqueHosts = new Set(
    input.findings
      .map((finding) => finding.hostname || finding.ipAddress || finding.assetIdentifier)
      .filter(Boolean),
  );

  return {
    scannerName: GENERIC_CSV_SCANNER_NAME,
    scannerVersion: null,
    sourceType: "generic_csv",
    fileType: input.artifact.fileType,
    hostCount: uniqueHosts.size,
    findingCount: input.findings.length,
    parsedAt: input.parsedAt,
    checksumSha256: input.artifact.checksumSha256,
  } satisfies ParseMetadata;
}

export class GenericCsvParser implements ScannerParser {
  readonly sourceType = "generic_csv" as const;
  readonly displayName = GENERIC_CSV_SCANNER_NAME;
  readonly supportedFileTypes: readonly ArtifactFileType[] = ["csv"];

  async canParse(input: ParserDetectionHint) {
    if (input.fileType !== "csv") {
      return false;
    }

    const sample = input.sampleText?.trim() ?? "";
    if (!sample) {
      return false;
    }

    return !sample.startsWith("{") && !sample.startsWith("[") && !sample.startsWith("<");
  }

  async parse(input: {
    artifact: RawArtifact;
    content: string;
    context: ParseContext;
  }): Promise<ParseResult> {
    const parsedAt = input.context.now;
    const parserWarnings: ParserWarning[] = [];
    const parserErrors: ParserError[] = [];
    const findings: NormalizedFinding[] = [];

    const { rows, error } = parseCsvContent(input.content);

    if (error) {
      parserErrors.push(error);
      return ParseResultSchema.parse({
        findings,
        parserWarnings,
        parserErrors,
        metadata: buildMetadata({
          artifact: input.artifact,
          findings,
          parsedAt,
        }),
      });
    }

    if (rows.length < 2) {
      parserErrors.push({
        code: "csv_missing_rows",
        message: "CSV file does not contain a header row and at least one data row.",
        details: {
          rowCount: rows.length,
        },
        fatal: true,
      });

      return ParseResultSchema.parse({
        findings,
        parserWarnings,
        parserErrors,
        metadata: buildMetadata({
          artifact: input.artifact,
          findings,
          parsedAt,
        }),
      });
    }

    const headers = trimRow(rows[0]);
    const { canonicalHeaderMap, unmappedHeaders } = mapHeaders(headers);

    for (const header of unmappedHeaders) {
      parserWarnings.push({
        code: "csv_unmapped_header",
        message: `Unmapped CSV column '${header}' was ignored during normalization.`,
        field: header,
        row: 1,
        level: "warning",
      });
    }

    const hasUsefulMappings =
      canonicalHeaderMap.has("title") ||
      canonicalHeaderMap.has("cveIds") ||
      canonicalHeaderMap.has("description") ||
      canonicalHeaderMap.has("vulnerabilityId");

    if (!hasUsefulMappings) {
      parserErrors.push({
        code: "csv_no_mappable_columns",
        message: "CSV file does not include enough recognizable columns to build findings.",
        details: {
          headers,
        },
        fatal: true,
      });

      return ParseResultSchema.parse({
        findings,
        parserWarnings,
        parserErrors,
        metadata: buildMetadata({
          artifact: input.artifact,
          findings,
          parsedAt,
        }),
      });
    }

    for (let rowIndex = 1; rowIndex < rows.length; rowIndex += 1) {
      const rowNumber = rowIndex + 1;
      const row = trimRow(rows[rowIndex]);

      if (row.every((value) => value.length === 0)) {
        parserWarnings.push({
          code: "csv_empty_row",
          message: "Encountered an empty CSV row that was skipped.",
          field: null,
          row: rowNumber,
          level: "warning",
        });
        continue;
      }

      const record = rowToRecord(headers, row);
      const cveIds = splitCveIds(getValue(record, canonicalHeaderMap, "cveIds"));
      const vulnerabilityId = getValue(record, canonicalHeaderMap, "vulnerabilityId") || null;
      const pluginId = getValue(record, canonicalHeaderMap, "pluginId") || null;
      const description = getValue(record, canonicalHeaderMap, "description") || null;
      const title =
        getValue(record, canonicalHeaderMap, "title") ||
        cveIds[0] ||
        vulnerabilityId ||
        pluginId;

      if (!title) {
        parserWarnings.push({
          code: "csv_row_skipped_missing_title",
          message: "Skipped a CSV row because no title, CVE, or identifier could be derived.",
          field: null,
          row: rowNumber,
          level: "warning",
        });
        continue;
      }

      const severity = getValue(record, canonicalHeaderMap, "severity") || null;
      const normalizedSeverity = normalizeSeverity(severity ?? undefined);

      findings.push({
        id: crypto.randomUUID(),
        uploadJobId: input.context.uploadJob.id,
        rawRecordRef: {
          recordId: `${input.artifact.id}:row:${rowNumber}`,
          recordIndex: rowIndex - 1,
          locationHint: `CSV row ${rowNumber}`,
          sourceChecksumSha256: input.artifact.checksumSha256,
        },
        assetIdentifier: getValue(record, canonicalHeaderMap, "assetIdentifier") || null,
        hostname: getValue(record, canonicalHeaderMap, "hostname") || null,
        fqdn: getValue(record, canonicalHeaderMap, "fqdn") || null,
        ipAddress: getValue(record, canonicalHeaderMap, "ipAddress") || null,
        port: parsePort(getValue(record, canonicalHeaderMap, "port")),
        protocol: getValue(record, canonicalHeaderMap, "protocol") || null,
        vulnerabilityId,
        pluginId,
        cveIds,
        title,
        description,
        severity,
        normalizedSeverity,
        cvssScore: parseNumber(getValue(record, canonicalHeaderMap, "cvssScore")),
        cvssVector: getValue(record, canonicalHeaderMap, "cvssVector") || null,
        remediation: getValue(record, canonicalHeaderMap, "remediation") || null,
        evidence: getValue(record, canonicalHeaderMap, "evidence") || null,
        status: normalizeFindingStatus(getValue(record, canonicalHeaderMap, "status")),
        privilegeRequired: null,
        detectedAt: parseDate(getValue(record, canonicalHeaderMap, "detectedAt")),
        firstObservedAt: parseDate(getValue(record, canonicalHeaderMap, "firstObservedAt")),
        lastObservedAt: parseDate(getValue(record, canonicalHeaderMap, "lastObservedAt")),
        sourceType: "generic_csv",
        sourceScanner: GENERIC_CSV_SCANNER_NAME,
        tags: [],
        createdAt: parsedAt,
        updatedAt: parsedAt,
      });
    }

    if (findings.length === 0) {
      parserErrors.push({
        code: "csv_no_findings_generated",
        message: "CSV file was readable but did not produce any normalized findings.",
        details: {
          rowCount: rows.length - 1,
        },
        fatal: true,
      });
    }

    return ParseResultSchema.parse({
      findings,
      parserWarnings,
      parserErrors,
      metadata: buildMetadata({
        artifact: input.artifact,
        findings,
        parsedAt,
      }),
    });
  }
}
