"use client";

import Link from "next/link";
import { FormEvent, KeyboardEvent, Suspense, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

import { getDashboardHref } from "@/lib/app-routes";

type Tab = "pw" | "magic";

function LoginPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [tab, setTab] = useState<Tab>("pw");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [magicEmail, setMagicEmail] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  const [loginLoading, setLoginLoading] = useState(false);
  const [magicLoading, setMagicLoading] = useState(false);
  const [forgotLoading, setForgotLoading] = useState(false);

  const verifiedStatus = searchParams.get("verified");
  const [successMessage, setSuccessMessage] = useState(
    verifiedStatus === "success"
      ? "✓ Email verified. You can log in now."
      : "",
  );
  const [errorMessage, setErrorMessage] = useState(
    verifiedStatus === "expired"
      ? "✗ Verification link expired. Sign up again to receive a new link."
      : verifiedStatus === "invalid"
        ? "✗ Verification link is invalid or already used."
        : "",
  );

  const activePanelIsPassword = useMemo(() => tab === "pw", [tab]);
  const authPrimaryButtonClass =
    "mb-6 w-full rounded-[3px] bg-[#00c8b4] px-4 py-3 font-mono text-[0.8rem] font-semibold uppercase tracking-[0.12em] text-[#040810] transition hover:bg-[#00ffe8] hover:shadow-[0_0_24px_rgba(0,200,180,0.4)] disabled:cursor-not-allowed disabled:opacity-50";
  const authTextLinkClass = "font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[#00c8b4] transition hover:text-[#00ffe8]";

  function clearAlerts() {
    setSuccessMessage("");
    setErrorMessage("");
  }

  function handleTabChange(nextTab: Tab) {
    setTab(nextTab);
    clearAlerts();
  }

  async function handleLogin(e?: FormEvent) {
    e?.preventDefault();
    clearAlerts();

    const trimmedEmail = email.trim();

    if (!trimmedEmail || !password) {
      setErrorMessage("✗ Please enter your email and password.");
      return;
    }

    setLoginLoading(true);

    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: trimmedEmail,
          password,
        }),
      });

      const data = await res.json().catch(() => ({}));

      if (res.ok) {
        router.push(getDashboardHref("overview"));
        return;
      }

      if (data.reason === "invalid_credentials") {
        setErrorMessage("✗ Invalid email or password.");
      } else if (data.reason === "not_verified") {
        setErrorMessage("✗ Verify your email before logging in.");
      } else if (data.reason === "invalid_input") {
        setErrorMessage("✗ Please enter a valid email and password.");
      } else {
        setErrorMessage("✗ Login failed. Please try again.");
      }
    } catch {
      setErrorMessage("✗ Network error — please check your connection.");
    } finally {
      setLoginLoading(false);
    }
  }

  async function handleMagic(e?: FormEvent) {
    e?.preventDefault();
    clearAlerts();

    const trimmedEmail = magicEmail.trim();
    const validEmail = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!trimmedEmail || !validEmail.test(trimmedEmail)) {
      setErrorMessage("✗ Please enter a valid email address.");
      return;
    }

    setMagicLoading(true);

    try {
      const res = await fetch("/api/auth/magic", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: trimmedEmail,
        }),
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        setErrorMessage(
          data.reason === "todo_not_implemented"
            ? "✗ Magic link login is not implemented yet."
            : "✗ Unable to send a magic link.",
        );
        return;
      }

      setSuccessMessage(
        "✓ Magic link sent — check your email. Link expires in 15 minutes.",
      );
      setMagicEmail("");
    } catch {
      setErrorMessage("✗ Network error — please try again.");
    } finally {
      setMagicLoading(false);
    }
  }

  async function handleForgotPassword() {
    clearAlerts();

    const targetEmail = email.trim();

    if (!targetEmail) {
      setErrorMessage("✗ Enter your email address first to reset your password.");
      return;
    }

    setForgotLoading(true);

    try {
      const res = await fetch("/api/auth/forgot", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: targetEmail,
        }),
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok || !data.ok) {
        setErrorMessage("✗ Unable to start password reset. Please try again.");
        return;
      }

      setSuccessMessage(
        "✓ If that email exists, a password reset link has been sent.",
      );
    } catch {
      setErrorMessage("✗ Network error — please try again.");
    } finally {
      setForgotLoading(false);
    }
  }

  function handleKeyDown(e: KeyboardEvent<HTMLDivElement>) {
    if (e.key !== "Enter") return;

    if (activePanelIsPassword) {
      void handleLogin();
    } else {
      void handleMagic();
    }
  }

  return (
    <main
      className="relative min-h-screen overflow-hidden bg-[#040810] text-[#c8d8e8]"
      onKeyDown={handleKeyDown}
    >
      <div className="pointer-events-none fixed inset-0 z-0 bg-[linear-gradient(rgba(0,200,180,0.025)_1px,transparent_1px),linear-gradient(90deg,rgba(0,200,180,0.025)_1px,transparent_1px)] bg-[size:40px_40px]" />
      <div className="pointer-events-none fixed -right-[100px] -top-[100px] z-0 h-[500px] w-[500px] rounded-full bg-[radial-gradient(circle,rgba(0,200,180,0.09)_0%,transparent_70%)] blur-[140px]" />
      <div className="pointer-events-none fixed -bottom-[100px] -left-[100px] z-0 h-[400px] w-[400px] rounded-full bg-[radial-gradient(circle,rgba(255,69,96,0.07)_0%,transparent_70%)] blur-[140px]" />

      <Link
        href="/"
        className="fixed left-6 top-6 z-20 text-[0.72rem] uppercase tracking-[0.08em] text-[#4a6070] transition hover:text-[#00c8b4]"
      >
        ← Back to Home
      </Link>

      <div className="relative z-10 flex min-h-screen items-center justify-center px-6 py-10">
        <div className="w-full max-w-[420px] rounded-lg border border-[rgba(0,200,180,0.15)] bg-[#070e1a] px-11 py-12 shadow-[0_40px_100px_rgba(0,0,0,0.6),0_0_60px_rgba(0,200,180,0.05)]">
          <div className="mb-1 text-[1.2rem] font-extrabold text-white">
            CVE<span className="text-[#00c8b4]">Risk</span>Pilot
          </div>
          <div className="mb-9 font-mono text-[0.68rem] uppercase tracking-[0.1em] text-[#4a6070]">
            // Secure Access — Restricted
          </div>

          <div className="mb-8 flex overflow-hidden rounded-[3px] border border-[rgba(0,200,180,0.15)]">
            <button
              type="button"
              onClick={() => handleTabChange("pw")}
              className={`flex-1 px-3 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] transition ${
                tab === "pw"
                  ? "bg-[#00c8b4] font-bold text-[#040810]"
                  : "bg-transparent text-[#4a6070]"
              }`}
            >
              Password
            </button>
            <button
              type="button"
              onClick={() => handleTabChange("magic")}
              className={`flex-1 px-3 py-2 font-mono text-[0.72rem] uppercase tracking-[0.08em] transition ${
                tab === "magic"
                  ? "bg-[#00c8b4] font-bold text-[#040810]"
                  : "bg-transparent text-[#4a6070]"
              }`}
            >
              Magic Link
            </button>
          </div>

          {successMessage ? (
            <div className="mb-5 rounded-[3px] border border-[#00c8b4] bg-[rgba(0,200,180,0.08)] px-4 py-3 font-mono text-[0.75rem] tracking-[0.05em] text-[#00c8b4]">
              {successMessage}
            </div>
          ) : null}

          {errorMessage ? (
            <div className="mb-5 rounded-[3px] border border-[#ff4560] bg-[rgba(255,69,96,0.08)] px-4 py-3 font-mono text-[0.75rem] tracking-[0.05em] text-[#ff4560]">
              {errorMessage}
            </div>
          ) : null}

          {tab === "pw" ? (
            <form onSubmit={handleLogin}>
              <label className="mb-2 block font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#4a6070]">
                Email Address
              </label>
              <input
                type="email"
                autoComplete="email"
                placeholder="you@company.com"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mb-5 w-full rounded-[3px] border border-[rgba(0,200,180,0.15)] bg-[#040810] px-4 py-[13px] font-mono text-[0.88rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] focus:border-[#00c8b4]"
              />

              <label className="mb-2 block font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#4a6070]">
                Password
              </label>

              <div className="relative mb-2">
                <input
                  type={showPassword ? "text" : "password"}
                  autoComplete="current-password"
                  placeholder="Your password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full rounded-[3px] border border-[rgba(0,200,180,0.15)] bg-[#040810] px-4 py-[13px] pr-12 font-mono text-[0.88rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] focus:border-[#00c8b4]"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword((v) => !v)}
                  className="absolute right-3 top-1/2 -translate-y-1/2 p-1 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[#4a6070] transition hover:text-[#00c8b4]"
                >
                  👁
                </button>
              </div>

              <div className="mb-6 flex items-center justify-between gap-3">
                <button
                  type="button"
                  onClick={() => void handleForgotPassword()}
                  disabled={forgotLoading || loginLoading}
                  className="shrink-0 whitespace-nowrap font-mono text-[0.62rem] uppercase tracking-[0.12em] leading-5 text-[#00c8b4] transition hover:text-[#00ffe8] disabled:opacity-50"
                >
                  {forgotLoading ? "Sending..." : "Forgot Password?"}
                </button>
              </div>

              <button
                type="submit"
                disabled={loginLoading}
                className={authPrimaryButtonClass}
              >
                {loginLoading ? "Authenticating..." : "Log In →"}
              </button>

              <div className="text-center text-[0.82rem] text-[#4a6070]">
                Don&apos;t have an account?{" "}
                <Link
                  href="/signup"
                  className={authTextLinkClass}
                >
                  Sign up free
                </Link>
              </div>
            </form>
          ) : (
            <form onSubmit={handleMagic}>
              <p className="mb-6 text-[0.85rem] leading-7 text-[#4a6070]">
                Enter your email and we&apos;ll send you a secure, one-time
                login link. No password needed.
              </p>

              <label className="mb-2 block font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#4a6070]">
                Email Address
              </label>
              <input
                type="email"
                autoComplete="email"
                placeholder="you@company.com"
                value={magicEmail}
                onChange={(e) => setMagicEmail(e.target.value)}
                className="mb-5 w-full rounded-[3px] border border-[rgba(0,200,180,0.15)] bg-[#040810] px-4 py-[13px] font-mono text-[0.88rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] focus:border-[#00c8b4]"
              />

              <button
                type="submit"
                disabled={magicLoading}
                className={authPrimaryButtonClass}
              >
                {magicLoading ? "Sending..." : "Send Magic Link →"}
              </button>

              <div className="text-center text-[0.82rem] text-[#4a6070]">
                Don&apos;t have an account?{" "}
                <Link
                  href="/signup"
                  className={authTextLinkClass}
                >
                  Sign up free
                </Link>
              </div>
            </form>
          )}
        </div>
      </div>
    </main>
  );
}

export default function LoginPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center bg-[#040810] text-[#c8d8e8]">
          <div className="font-mono text-[0.75rem] uppercase tracking-[0.1em] text-[#00c8b4]">
            Loading access console...
          </div>
        </main>
      }
    >
      <LoginPageContent />
    </Suspense>
  );
}
