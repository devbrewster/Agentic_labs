import type { PostgresQueryClient } from "@/lib/platform/database";
import { PostgresAppDatabase } from "@/lib/platform/database";
import { SqlEnrichmentRepository } from "@/lib/enrichment/sql-repository";

export class PostgresEnrichmentRepository extends SqlEnrichmentRepository {
  constructor(client: PostgresQueryClient) {
    super(new PostgresAppDatabase(client));
  }
}
