import {
  RawArtifactSchema,
  StoredParseOutcomeSchema,
  UploadJobSchema,
  NormalizedFindingSchema,
  type ChecksumSha256,
  type NormalizedFinding,
  type RawArtifact,
  type StoredParseOutcome,
  type UploadJob,
} from "@/types/ingestion";

export type UploadRecord = {
  uploadJob: UploadJob;
  rawArtifact: RawArtifact;
};

export type UploadRecordWithOutcome = UploadRecord & {
  outcome: StoredParseOutcome | null;
};

export type RawArtifactRepository = {
  findById(rawArtifactId: string): Promise<RawArtifact | null>;
  findByChecksum(checksumSha256: ChecksumSha256): Promise<RawArtifact | null>;
  save(rawArtifact: RawArtifact): Promise<void>;
};

export type UploadJobRepository = {
  findById(uploadJobId: string): Promise<UploadJob | null>;
  findByChecksum(checksumSha256: ChecksumSha256): Promise<UploadJob | null>;
  findByChecksumForTenant(
    checksumSha256: ChecksumSha256,
    tenantId: string | null,
  ): Promise<UploadJob | null>;
  save(uploadJob: UploadJob): Promise<void>;
  update(uploadJob: UploadJob): Promise<void>;
  list(): Promise<UploadJob[]>;
  listByTenant(tenantId: string): Promise<UploadJob[]>;
};

export type ParseOutcomeRepository = {
  findByUploadJobId(uploadJobId: string): Promise<StoredParseOutcome | null>;
  listByUploadJobIds(uploadJobIds: string[]): Promise<StoredParseOutcome[]>;
  save(outcome: StoredParseOutcome): Promise<void>;
};

export type NormalizedFindingRepository = {
  findByUploadJobId(uploadJobId: string): Promise<NormalizedFinding[]>;
  listAll(): Promise<NormalizedFinding[]>;
  listAllByTenant(tenantId: string): Promise<NormalizedFinding[]>;
  replaceForUploadJob(uploadJobId: string, findings: NormalizedFinding[]): Promise<void>;
};

export type UploadRepository = {
  rawArtifacts: RawArtifactRepository;
  uploadJobs: UploadJobRepository;
  parseOutcomes: ParseOutcomeRepository;
  normalizedFindings: NormalizedFindingRepository;
  findByChecksum(checksumSha256: ChecksumSha256): Promise<UploadRecord | null>;
  findByChecksumForTenant(
    checksumSha256: ChecksumSha256,
    tenantId: string | null,
  ): Promise<UploadRecord | null>;
  findById(uploadJobId: string): Promise<UploadRecordWithOutcome | null>;
  findByIdForTenant(
    uploadJobId: string,
    tenantId: string,
  ): Promise<UploadRecordWithOutcome | null>;
  save(input: { uploadJob: UploadJob; rawArtifact: RawArtifact }): Promise<void>;
  updateUploadJob(uploadJob: UploadJob): Promise<void>;
  saveParseOutcome(outcome: StoredParseOutcome): Promise<void>;
  list(): Promise<UploadRecord[]>;
  listByTenant(tenantId: string): Promise<UploadRecord[]>;
  listFindingsByTenant(tenantId: string): Promise<NormalizedFinding[]>;
  findFindingByIdForTenant(
    findingId: string,
    tenantId: string,
  ): Promise<NormalizedFinding | null>;
};

export class InMemoryUploadRepository implements UploadRepository {
  private readonly checksumToJobId = new Map<ChecksumSha256, string>();
  private readonly uploadJobRecords = new Map<string, UploadJob>();
  private readonly rawArtifactRecords = new Map<string, RawArtifact>();
  private readonly parseOutcomeRecords = new Map<string, StoredParseOutcome>();
  private readonly normalizedFindingRecords = new Map<string, NormalizedFinding[]>();

  readonly rawArtifacts: RawArtifactRepository = {
    findById: async (rawArtifactId: string) => {
      const artifact = this.rawArtifactRecords.get(rawArtifactId);
      return artifact ? RawArtifactSchema.parse(artifact) : null;
    },
    findByChecksum: async (checksumSha256: ChecksumSha256) => {
      const uploadJobId = this.checksumToJobId.get(checksumSha256);

      if (!uploadJobId) {
        return null;
      }

      const uploadJob = this.uploadJobRecords.get(uploadJobId);

      if (!uploadJob) {
        return null;
      }

      const artifact = this.rawArtifactRecords.get(uploadJob.rawArtifactId);
      return artifact ? RawArtifactSchema.parse(artifact) : null;
    },
    save: async (rawArtifact: RawArtifact) => {
      this.rawArtifactRecords.set(rawArtifact.id, RawArtifactSchema.parse(rawArtifact));
    },
  };

  readonly uploadJobs: UploadJobRepository = {
    findById: async (uploadJobId: string) => {
      const uploadJob = this.uploadJobRecords.get(uploadJobId);
      return uploadJob ? UploadJobSchema.parse(uploadJob) : null;
    },
    findByChecksum: async (checksumSha256: ChecksumSha256) => {
      const uploadJobId = this.checksumToJobId.get(checksumSha256);

      if (!uploadJobId) {
        return null;
      }

      const uploadJob = this.uploadJobRecords.get(uploadJobId);
      return uploadJob ? UploadJobSchema.parse(uploadJob) : null;
    },
    findByChecksumForTenant: async (checksumSha256: ChecksumSha256, tenantId: string | null) => {
      const uploadJobId = this.checksumToJobId.get(checksumSha256);

      if (!uploadJobId) {
        return null;
      }

      const uploadJob = this.uploadJobRecords.get(uploadJobId);

      if (!uploadJob || uploadJob.tenantId !== tenantId) {
        return null;
      }

      return UploadJobSchema.parse(uploadJob);
    },
    save: async (uploadJob: UploadJob) => {
      const parsed = UploadJobSchema.parse(uploadJob);
      this.uploadJobRecords.set(parsed.id, parsed);
      this.checksumToJobId.set(parsed.checksumSha256, parsed.id);
    },
    update: async (uploadJob: UploadJob) => {
      this.uploadJobRecords.set(uploadJob.id, UploadJobSchema.parse(uploadJob));
    },
    list: async () =>
      Array.from(this.uploadJobRecords.values()).map((uploadJob) =>
        UploadJobSchema.parse(uploadJob),
      ),
    listByTenant: async (tenantId: string) =>
      Array.from(this.uploadJobRecords.values())
        .filter((uploadJob) => uploadJob.tenantId === tenantId)
        .map((uploadJob) => UploadJobSchema.parse(uploadJob)),
  };

  readonly parseOutcomes: ParseOutcomeRepository = {
    findByUploadJobId: async (uploadJobId: string) => {
      const outcome = this.parseOutcomeRecords.get(uploadJobId);
      return outcome ? StoredParseOutcomeSchema.parse(outcome) : null;
    },
    listByUploadJobIds: async (uploadJobIds: string[]) =>
      uploadJobIds.flatMap((uploadJobId) => {
        const outcome = this.parseOutcomeRecords.get(uploadJobId);
        return outcome ? [StoredParseOutcomeSchema.parse(outcome)] : [];
      }),
    save: async (outcome: StoredParseOutcome) => {
      this.parseOutcomeRecords.set(
        outcome.uploadJobId,
        StoredParseOutcomeSchema.parse(outcome),
      );
    },
  };

  readonly normalizedFindings: NormalizedFindingRepository = {
    findByUploadJobId: async (uploadJobId: string) =>
      (this.normalizedFindingRecords.get(uploadJobId) ?? []).map((finding) =>
        NormalizedFindingSchema.parse(finding),
      ),
    listAll: async () =>
      Array.from(this.normalizedFindingRecords.values()).flatMap((findings) =>
        findings.map((finding) => NormalizedFindingSchema.parse(finding)),
      ),
    listAllByTenant: async (tenantId: string) =>
      Array.from(this.uploadJobRecords.values())
        .filter((uploadJob) => uploadJob.tenantId === tenantId)
        .flatMap(
          (uploadJob) =>
            this.normalizedFindingRecords.get(uploadJob.id)?.map((finding) =>
              NormalizedFindingSchema.parse(finding),
            ) ?? [],
        ),
    replaceForUploadJob: async (uploadJobId: string, findings: NormalizedFinding[]) => {
      this.normalizedFindingRecords.set(
        uploadJobId,
        findings.map((finding) => NormalizedFindingSchema.parse(finding)),
      );
    },
  };

  async findByChecksum(checksumSha256: ChecksumSha256) {
    const uploadJob = await this.uploadJobs.findByChecksum(checksumSha256);

    if (!uploadJob) {
      return null;
    }
    const rawArtifact = await this.rawArtifacts.findById(uploadJob.rawArtifactId);
    if (!rawArtifact) {
      return null;
    }
    return {
      uploadJob,
      rawArtifact,
    };
  }

  async findByChecksumForTenant(checksumSha256: ChecksumSha256, tenantId: string | null) {
    const uploadJob = await this.uploadJobs.findByChecksumForTenant(checksumSha256, tenantId);

    if (!uploadJob) {
      return null;
    }

    const rawArtifact = await this.rawArtifacts.findById(uploadJob.rawArtifactId);
    if (!rawArtifact) {
      return null;
    }

    return {
      uploadJob,
      rawArtifact,
    };
  }

  async save(input: { uploadJob: UploadJob; rawArtifact: RawArtifact }) {
    await this.rawArtifacts.save(input.rawArtifact);
    await this.uploadJobs.save(input.uploadJob);
  }

  async findById(uploadJobId: string) {
    const uploadJob = await this.uploadJobs.findById(uploadJobId);
    if (!uploadJob) {
      return null;
    }
    const rawArtifact = await this.rawArtifacts.findById(uploadJob.rawArtifactId);
    if (!rawArtifact) {
      return null;
    }
    return {
      uploadJob,
      rawArtifact,
      outcome: await this.parseOutcomes.findByUploadJobId(uploadJobId),
    };
  }

  async findByIdForTenant(uploadJobId: string, tenantId: string) {
    const record = await this.findById(uploadJobId);

    if (!record || record.uploadJob.tenantId !== tenantId) {
      return null;
    }

    return record;
  }

  async updateUploadJob(uploadJob: UploadJob) {
    await this.uploadJobs.update(uploadJob);
  }

  async saveParseOutcome(outcome: StoredParseOutcome) {
    await this.parseOutcomes.save(outcome);
    await this.normalizedFindings.replaceForUploadJob(outcome.uploadJobId, outcome.findings);
  }

  async list() {
    const records = await this.uploadJobs.list();
    return Promise.all(
      records.map(async (uploadJob) => {
        const rawArtifact = await this.rawArtifacts.findById(uploadJob.rawArtifactId);
        if (!rawArtifact) {
          throw new Error(`Missing raw artifact for upload job ${uploadJob.id}.`);
        }
        return {
          uploadJob,
          rawArtifact,
        };
      }),
    ).then((items) => items.map((item) => {
      if (!item.rawArtifact) {
        throw new Error(`Missing raw artifact for upload job ${item.uploadJob.id}.`);
      }
      return item;
    }));
  }

  async listByTenant(tenantId: string) {
    const records = await this.list();
    return records.filter(({ uploadJob }) => uploadJob.tenantId === tenantId);
  }

  async listFindingsByTenant(tenantId: string) {
    return this.normalizedFindings.listAllByTenant(tenantId);
  }

  async findFindingByIdForTenant(findingId: string, tenantId: string) {
    const findings = await this.listFindingsByTenant(tenantId);
    return findings.find((finding) => finding.id === findingId) ?? null;
  }
}
