import type { D1Database } from "@cloudflare/workers-types";

import { D1AppDatabase } from "@/lib/platform/database";
import { SqlBillingRepository } from "@/lib/billing/sql-repository";

export class D1BillingRepository extends SqlBillingRepository {
  constructor(db: D1Database) {
    super(new D1AppDatabase(db));
  }
}
