import { getDb } from "@/lib/db";
import { D1OrganizationRepository } from "@/lib/organizations/d1-repository";
import { PostgresOrganizationRepository } from "@/lib/organizations/postgres-repository";
import {
  InMemoryOrganizationRepository,
  type OrganizationRepository,
} from "@/lib/organizations/repository";
import { getOrCreatePostgresQueryClient } from "@/lib/platform/postgres";
import { getPlatformProfile } from "@/lib/platform/runtime";

type OrganizationRuntime = {
  organizationRepository: OrganizationRepository;
};

const fallbackRuntime: OrganizationRuntime = {
  organizationRepository: new InMemoryOrganizationRepository(),
};

function isFallbackRuntimeError(error: unknown) {
  if (!(error instanceof Error)) {
    return false;
  }

  return (
    /Cloudflare D1 binding/i.test(error.message) ||
    /getCloudflareContext/i.test(error.message) ||
    /Database schema is not initialized/i.test(error.message)
  );
}

export async function getOrganizationRuntime(): Promise<OrganizationRuntime> {
  const platform = getPlatformProfile();

  if (platform.databaseDriver === "postgres") {
    const postgresClient = await getOrCreatePostgresQueryClient();

    if (postgresClient) {
      return {
        organizationRepository: new PostgresOrganizationRepository(postgresClient),
      };
    }
  }

  try {
    const db = await getDb();
    return {
      organizationRepository: new D1OrganizationRepository(db),
    };
  } catch (error) {
    if (isFallbackRuntimeError(error)) {
      return fallbackRuntime;
    }

    throw error;
  }
}
