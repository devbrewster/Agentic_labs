import { GetObjectCommand, PutObjectCommand } from "@aws-sdk/client-s3";
import { describe, expect, it } from "vitest";

import { S3ArtifactStorage, type S3StorageClient } from "@/lib/ingestion/storage";

class FakeS3Client implements S3StorageClient {
  readonly objects = new Map<string, Buffer>();

  async send(command: GetObjectCommand | PutObjectCommand) {
    if (command instanceof PutObjectCommand) {
      const input = command.input;
      const key = `${input.Bucket}/${input.Key}`;
      const body = input.Body;

      if (!(body instanceof Uint8Array) && !Buffer.isBuffer(body)) {
        throw new Error("Unexpected body type in fake S3 PutObjectCommand.");
      }

      this.objects.set(key, Buffer.from(body));
      return {};
    }

    if (command instanceof GetObjectCommand) {
      const input = command.input;
      const key = `${input.Bucket}/${input.Key}`;
      const body = this.objects.get(key);

      if (!body) {
        return { Body: undefined };
      }

      return {
        Body: {
          async transformToByteArray() {
            return Uint8Array.from(body);
          },
        },
      };
    }

    throw new Error("Unexpected S3 command in fake client.");
  }
}

describe("S3ArtifactStorage", () => {
  it("saves and reads artifact content through S3-backed storage", async () => {
    const client = new FakeS3Client();
    const storage = new S3ArtifactStorage({
      bucketName: "test-upload-bucket",
      client,
    });

    const result = await storage.saveArtifact({
      originalFilename: "scanner-results.csv",
      mimeType: "text/csv",
      body: Buffer.from("cve,title\nCVE-2024-21413,Example finding\n"),
      uploadedAt: "2026-03-11T03:00:00.000Z",
    });

    expect(result.artifact.storageKey).toContain("scanner-results.csv");
    expect(result.artifact.fileType).toBe("csv");

    const content = await storage.readArtifact(result.artifact.storageKey);
    expect(content.toString("utf8")).toContain("CVE-2024-21413");
  });

  it("throws a clear error when the S3 object is missing", async () => {
    const storage = new S3ArtifactStorage({
      bucketName: "test-upload-bucket",
      client: new FakeS3Client(),
    });

    await expect(storage.readArtifact("2026-03-11/missing/example.csv")).rejects.toThrow(
      "Artifact content not found",
    );
  });
});
