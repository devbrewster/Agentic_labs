#!/usr/bin/env bash
set -euo pipefail

PROJECT_NAME="${1:-CVERiskPilot}"
ROOT_DIR="${2:-.}"
FORCE="${FORCE:-0}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/.." && pwd)"

PROMPT_SOURCE_DIR="${PROMPT_SOURCE_DIR:-agent-prompts}"
ORCH_SOURCE_FILE="${ORCH_SOURCE_FILE:-orchestrator.md}"
PM_SOURCE_FILE="${PM_SOURCE_FILE:-pm_agent.md}"
PRODUCT_SOURCE_FILE="${PRODUCT_SOURCE_FILE:-product-ux.md}"
SECURITY_SOURCE_FILE="${SECURITY_SOURCE_FILE:-security-platform.md}"

info() { printf "\033[1;36m[INFO]\033[0m %s\n" "$1"; }
ok()   { printf "\033[1;32m[ OK ]\033[0m %s\n" "$1"; }
warn() { printf "\033[1;33m[WARN]\033[0m %s\n" "$1"; }
fail() { printf "\033[1;31m[FAIL]\033[0m %s\n" "$1" >&2; exit 1; }

ensure_dir() {
  local path="$1"
  mkdir -p "$path"
  ok "Ensured directory: $path"
}

write_file_safe() {
  local path="$1"
  local content="$2"

  if [[ -f "$path" && "$FORCE" != "1" ]]; then
    warn "Skipped existing file: $path"
    return 0
  fi

  mkdir -p "$(dirname "$path")"
  printf "%s" "$content" > "$path"
  ok "Wrote file: $path"
}

copy_prompt_file() {
  local src="$1"
  local dst="$2"

  if [[ ! -f "$src" ]]; then
    fail "Missing prompt source file: $src"
  fi

  if [[ -f "$dst" && "$FORCE" != "1" ]]; then
    warn "Skipped existing prompt file: $dst"
    return 0
  fi

  mkdir -p "$(dirname "$dst")"
  cp "$src" "$dst"
  ok "Copied prompt: $src -> $dst"
}

ROOT_DIR="$(cd "$ROOT_DIR" && pwd)"
PROMPT_SOURCE_PATH="$ROOT_DIR/$PROMPT_SOURCE_DIR"

if [[ ! -d "$PROMPT_SOURCE_PATH" ]]; then
  FALLBACK_PROMPT_SOURCE_PATH="$REPO_ROOT/$PROMPT_SOURCE_DIR"
  if [[ -d "$FALLBACK_PROMPT_SOURCE_PATH" ]]; then
    PROMPT_SOURCE_PATH="$FALLBACK_PROMPT_SOURCE_PATH"
  fi
fi

ORCH_SOURCE_PATH="$PROMPT_SOURCE_PATH/$ORCH_SOURCE_FILE"
PM_SOURCE_PATH="$PROMPT_SOURCE_PATH/$PM_SOURCE_FILE"
PRODUCT_SOURCE_PATH="$PROMPT_SOURCE_PATH/$PRODUCT_SOURCE_FILE"
SECURITY_SOURCE_PATH="$PROMPT_SOURCE_PATH/$SECURITY_SOURCE_FILE"

info "Scaffolding multi-agent Codex workspace in: $ROOT_DIR"
info "Using prompt source directory: $PROMPT_SOURCE_PATH"

[[ -f "$ORCH_SOURCE_PATH" ]] || fail "Expected orchestrator prompt at: $ORCH_SOURCE_PATH"
[[ -f "$PM_SOURCE_PATH" ]] || fail "Expected PM agent prompt at: $PM_SOURCE_PATH"
[[ -f "$PRODUCT_SOURCE_PATH" ]] || fail "Expected product UX prompt at: $PRODUCT_SOURCE_PATH"
[[ -f "$SECURITY_SOURCE_PATH" ]] || fail "Expected security/platform prompt at: $SECURITY_SOURCE_PATH"

DIRS=(
  ".codex"
  ".codex/prompts"
  ".codex/templates"
  ".codex/state"
  ".codex/reports"
  ".codex/reports/individual"
  ".codex/reports/cross-review"
  ".codex/reports/final"
  ".codex/transcripts"
  "docs"
  "docs/agent-handoffs"
  "docs/assessments"
  "docs/assessment-evidence"
  "scripts"
  "scripts/agent-runtime"
  "tmp"
  ".vscode"
)

for dir in "${DIRS[@]}"; do
  ensure_dir "$ROOT_DIR/$dir"
done

CODEX_CONFIG=$(cat <<EOF
# Project-level Codex configuration
model = "gpt-5-codex"

[project]
name = "${PROJECT_NAME}"
description = "Multi-agent implementation and review workspace for ${PROJECT_NAME}"

[paths]
reports = ".codex/reports"
prompts = ".codex/prompts"
templates = ".codex/templates"
state = ".codex/state"

[defaults]
approval_mode = "suggest"
sandbox_mode = "workspace-write"

[agents.orchestrator]
name = "Orchestrator Agent"
prompt_file = ".codex/prompts/orchestrator.md"
output_file = ".codex/reports/individual/orchestrator-assessment.md"

[agents.pm_agent]
name = "Program Manager Agent"
prompt_file = ".codex/prompts/pm_agent.md"
output_file = ".codex/reports/individual/pm-agent-assessment.md"

[agents.product_ux]
name = "SaaS Product & UX Audit Agent"
prompt_file = ".codex/prompts/product-ux.md"
output_file = ".codex/reports/individual/product-ux-assessment.md"

[agents.security_platform]
name = "Security / Architecture / Platform Audit Agent"
prompt_file = ".codex/prompts/security-platform.md"
output_file = ".codex/reports/individual/security-platform-assessment.md"
EOF
)
write_file_safe "$ROOT_DIR/.codex/config.toml" "$CODEX_CONFIG"

copy_prompt_file "$ORCH_SOURCE_PATH" "$ROOT_DIR/.codex/prompts/orchestrator.md"
copy_prompt_file "$PM_SOURCE_PATH" "$ROOT_DIR/.codex/prompts/pm_agent.md"
copy_prompt_file "$PRODUCT_SOURCE_PATH" "$ROOT_DIR/.codex/prompts/product-ux.md"
copy_prompt_file "$SECURITY_SOURCE_PATH" "$ROOT_DIR/.codex/prompts/security-platform.md"

INDIVIDUAL_TEMPLATE=$(cat <<EOF
# {{AGENT_NAME}} Review

## Scope Reviewed
- Product
- Architecture
- Security
- UX
- Platform
- Operations
- SaaS business readiness

## Project
- ${PROJECT_NAME}

## Current State Observed
- 

## Missing for True Production SaaS
### Critical
- 

### High
- 

### Medium
- 

### Low
- 

## Evidence / Code Areas Reviewed
- 

## Risks if Not Addressed
- 

## Recommended Next Steps
1. 
2. 
3. 

## Cross-Review of Other Agents
### Agreements
- 

### Blind Spots Found
- 

### Disagreements / Conflicts
- 

## Final Agent Verdict
- Not production ready / Partially ready / Ready with conditions
EOF
)
write_file_safe "$ROOT_DIR/.codex/templates/individual-assessment-template.md" "$INDIVIDUAL_TEMPLATE"

CROSS_REVIEW_TEMPLATE=$(cat <<EOF
# ${PROJECT_NAME} Cross-Review Matrix

## Shared Findings
- 

## Conflicting Findings
- 

## Blind Spots Discovered
- 

## Missing Areas None of the Agents Fully Covered
- 

## Unified Priority Order
1. 
2. 
3. 
4. 
5. 
EOF
)
write_file_safe "$ROOT_DIR/.codex/templates/cross-review-template.md" "$CROSS_REVIEW_TEMPLATE"

FINAL_TEMPLATE=$(cat <<EOF
# ${PROJECT_NAME} Unified Multi-Agent Review

## Executive Summary
- 

## What Exists Today
- 

## What Is Missing Before Production Release
### Product / UX
- 

### Security / Platform / Architecture
- 

### Operations / Reliability / DevOps
- 

### SaaS Business / Admin / Billing / Compliance
- 

## Cross-Agent Agreements
- 

## Cross-Agent Disagreements
- 

## Final Unified Gap List
### Critical Blockers
- 

### High Priority
- 

### Medium Priority
- 

### Nice-to-Have
- 

## Recommended Implementation Order
1. 
2. 
3. 
4. 
5. 

## Production Readiness Verdict
- 
EOF
)
write_file_safe "$ROOT_DIR/.codex/templates/final-unified-template.md" "$FINAL_TEMPLATE"

TASK_BOARD=$(cat <<EOF
# ${PROJECT_NAME} Multi-Agent Task Board

## Objective
Coordinate multi-agent review work for ${PROJECT_NAME} and capture what still needs implementation before a production-ready release.

## Agents
- Orchestrator Agent
- Program Manager Agent
- SaaS Product & UX Audit Agent
- Security / Architecture / Platform Audit Agent

## Rules
- Each agent produces an independent assessment first.
- Each agent cross-reviews the other assessments.
- All conflicts must be captured explicitly.
- Final output must be one unified assessment.
- No agent should assume another agent covered an area unless cited.

## Current Status
- [ ] Prompts loaded
- [ ] Repo reviewed
- [ ] Individual assessments completed
- [ ] Cross-reviews completed
- [ ] Conflicts resolved
- [ ] Final unified assessment completed
EOF
)
write_file_safe "$ROOT_DIR/docs/task-board.md" "$TASK_BOARD"

HANDOFF_LOG=$(cat <<'EOF'
# Agent Handoff Log

## Current repo / branch
- 

## What was reviewed
- 

## Important files / folders
- 

## Questions for other agents
- 

## Risks / blockers
- 

## Suggested next action
- 
EOF
)
write_file_safe "$ROOT_DIR/docs/agent-handoffs/handoff-log.md" "$HANDOFF_LOG"

RUNBOOK=$(cat <<EOF
# Multi-Agent Runbook

## Phase 1 - Independent Reviews
Each agent reviews the codebase and writes its own assessment to:
- .codex/reports/individual/orchestrator-assessment.md
- .codex/reports/individual/pm-agent-assessment.md
- .codex/reports/individual/product-ux-assessment.md
- .codex/reports/individual/security-platform-assessment.md

## Phase 2 - Cross-Review
Each agent reads the other reports and writes feedback into:
- .codex/reports/cross-review/

## Phase 3 - Unified Final
The Orchestrator merges:
- the 4 individual reports
- all cross-reviews
- unresolved conflicts
into:
- .codex/reports/final/unified-production-saas-assessment.md

## Required Final Output
The final report must clearly answer:
1. What exists today
2. What is missing
3. What is critically blocking production release
4. What should be built first
5. What can wait
EOF
)
write_file_safe "$ROOT_DIR/docs/assessments/runbook.md" "$RUNBOOK"

write_file_safe "$ROOT_DIR/.codex/reports/individual/orchestrator-assessment.md" "${INDIVIDUAL_TEMPLATE//\{\{AGENT_NAME\}\}/Orchestrator Agent}"
write_file_safe "$ROOT_DIR/.codex/reports/individual/pm-agent-assessment.md" "${INDIVIDUAL_TEMPLATE//\{\{AGENT_NAME\}\}/Program Manager Agent}"
write_file_safe "$ROOT_DIR/.codex/reports/individual/product-ux-assessment.md" "${INDIVIDUAL_TEMPLATE//\{\{AGENT_NAME\}\}/SaaS Product & UX Audit Agent}"
write_file_safe "$ROOT_DIR/.codex/reports/individual/security-platform-assessment.md" "${INDIVIDUAL_TEMPLATE//\{\{AGENT_NAME\}\}/Security / Architecture / Platform Audit Agent}"

CROSS_FILES=(
  "orchestrator-review-of-pm.md"
  "orchestrator-review-of-product.md"
  "orchestrator-review-of-security.md"
  "pm-review-of-orchestrator.md"
  "pm-review-of-product.md"
  "pm-review-of-security.md"
  "product-review-of-orchestrator.md"
  "product-review-of-pm.md"
  "product-review-of-security.md"
  "security-review-of-orchestrator.md"
  "security-review-of-pm.md"
  "security-review-of-product.md"
  "cross-review-matrix.md"
)

for file in "${CROSS_FILES[@]}"; do
  if [[ "$file" == "cross-review-matrix.md" ]]; then
    write_file_safe "$ROOT_DIR/.codex/reports/cross-review/$file" "$CROSS_REVIEW_TEMPLATE"
  else
    REVIEW_CONTENT=$(cat <<EOF
# $file

## Summary
- 

## Agreements
- 

## Blind Spots
- 

## Conflicts
- 

## Recommended Changes
- 
EOF
)
    write_file_safe "$ROOT_DIR/.codex/reports/cross-review/$file" "$REVIEW_CONTENT"
  fi
done

write_file_safe "$ROOT_DIR/.codex/reports/final/unified-production-saas-assessment.md" "$FINAL_TEMPLATE"

VSCODE_SETTINGS=$(cat <<'EOF'
{
  "files.exclude": {
    "**/.git": true,
    "**/.DS_Store": true
  },
  "search.exclude": {
    "**/node_modules": true,
    "**/.next": true,
    "**/dist": true,
    "**/build": true
  },
  "editor.wordWrap": "on",
  "markdown.preview.breaks": true
}
EOF
)
write_file_safe "$ROOT_DIR/.vscode/settings.json" "$VSCODE_SETTINGS"

EXTENSIONS=$(cat <<'EOF'
{
  "recommendations": [
    "ms-vscode-remote.remote-wsl",
    "yzhang.markdown-all-in-one",
    "ms-vscode.powershell"
  ]
}
EOF
)
write_file_safe "$ROOT_DIR/.vscode/extensions.json" "$EXTENSIONS"

LAUNCH_WINDOWS=$(cat <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-.}"
REPO_ROOT="$(cd "$REPO_ROOT" && pwd)"

code "$REPO_ROOT" --new-window
sleep 1
code "$REPO_ROOT" --new-window
sleep 1
code "$REPO_ROOT" --new-window
sleep 1
code "$REPO_ROOT" --new-window

echo "Opened 4 VS Code windows."
echo "Assign roles:"
echo "1. Orchestrator Agent"
echo "2. Program Manager Agent"
echo "3. SaaS Product & UX Audit Agent"
echo "4. Security / Architecture / Platform Audit Agent"
EOF
)
write_file_safe "$ROOT_DIR/scripts/launch-agent-windows.sh" "$LAUNCH_WINDOWS"
chmod +x "$ROOT_DIR/scripts/launch-agent-windows.sh"

PREPARE_SESSION=$(cat <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-.}"
REPO_ROOT="$(cd "$REPO_ROOT" && pwd)"

echo "Prompt files in use:"
echo "$REPO_ROOT/.codex/prompts/orchestrator.md"
echo "$REPO_ROOT/.codex/prompts/pm_agent.md"
echo "$REPO_ROOT/.codex/prompts/product-ux.md"
echo "$REPO_ROOT/.codex/prompts/security-platform.md"
echo
echo "Workflow:"
echo "1. Independent assessments"
echo "2. Cross-review"
echo "3. Merge"
echo "4. Final unified assessment"
echo
echo "Automation:"
echo "./scripts/run-agent-mesh.sh"
echo "./scripts/run-agent-mesh.sh --dry-run"
EOF
)
write_file_safe "$ROOT_DIR/scripts/prepare-codex-session.sh" "$PREPARE_SESSION"
chmod +x "$ROOT_DIR/scripts/prepare-codex-session.sh"

MERGE_SCRIPT=$(cat <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-.}"
REPO_ROOT="$(cd "$REPO_ROOT" && pwd)"

INDIVIDUAL_DIR="$REPO_ROOT/.codex/reports/individual"
CROSS_DIR="$REPO_ROOT/.codex/reports/cross-review"
BUNDLE_FILE="$REPO_ROOT/.codex/reports/final/unified-source-bundle.md"

FILES=(
  "$INDIVIDUAL_DIR/orchestrator-assessment.md"
  "$INDIVIDUAL_DIR/pm-agent-assessment.md"
  "$INDIVIDUAL_DIR/product-ux-assessment.md"
  "$INDIVIDUAL_DIR/security-platform-assessment.md"
  "$CROSS_DIR/orchestrator-review-of-pm.md"
  "$CROSS_DIR/orchestrator-review-of-product.md"
  "$CROSS_DIR/orchestrator-review-of-security.md"
  "$CROSS_DIR/pm-review-of-orchestrator.md"
  "$CROSS_DIR/pm-review-of-product.md"
  "$CROSS_DIR/pm-review-of-security.md"
  "$CROSS_DIR/product-review-of-orchestrator.md"
  "$CROSS_DIR/product-review-of-pm.md"
  "$CROSS_DIR/product-review-of-security.md"
  "$CROSS_DIR/security-review-of-orchestrator.md"
  "$CROSS_DIR/security-review-of-pm.md"
  "$CROSS_DIR/security-review-of-product.md"
  "$CROSS_DIR/cross-review-matrix.md"
)

{
  echo "# CVERiskPilot Unified Source Bundle"
  echo
  echo "> Auto-assembled source bundle"
  echo "> Generated: $(date '+%Y-%m-%d %H:%M:%S')"
  echo
  echo "## Source Reports Included"
  for file in "${FILES[@]}"; do
    echo "- $(basename "$file")"
  done
  echo
  echo "## Consolidated Input Bundle"
  echo

  for file in "${FILES[@]}"; do
    if [[ -f "$file" ]]; then
      echo "---"
      echo
      echo "## BEGIN: $(basename "$file")"
      echo
      cat "$file"
      echo
      echo "## END: $(basename "$file")"
      echo
    fi
  done
} > "$BUNDLE_FILE"

echo "Merged assessment source bundle into:"
echo "$BUNDLE_FILE"
EOF
)
write_file_safe "$ROOT_DIR/scripts/merge-agent-assessments.sh" "$MERGE_SCRIPT"
chmod +x "$ROOT_DIR/scripts/merge-agent-assessments.sh"

RUNNER_SCRIPT=$(cat <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

if [[ $# -lt 6 ]]; then
  echo "Usage: $0 <repo_root> <agent_key> <phase> <prompt_file> <task_file> <output_file>"
  exit 1
fi

REPO_ROOT="$(cd "$1" && pwd)"
AGENT_KEY="$2"
PHASE="$3"
PROMPT_FILE="$4"
TASK_FILE="$5"
OUTPUT_FILE="$6"

DRY_RUN="${DRY_RUN:-0}"
MODEL="${CODEX_MODEL:-gpt-5-codex}"
STATE_DIR="$REPO_ROOT/.codex/state"
LOG_DIR="$STATE_DIR/logs"

mkdir -p "$STATE_DIR" "$LOG_DIR" "$(dirname "$OUTPUT_FILE")"

STATUS_FILE="$STATE_DIR/${AGENT_KEY}-${PHASE}.status"
PROMPT_SNAPSHOT="$STATE_DIR/${AGENT_KEY}-${PHASE}.prompt.md"
LOG_FILE="$LOG_DIR/${AGENT_KEY}-${PHASE}.log"
TMP_OUTPUT="$(mktemp "$STATE_DIR/${AGENT_KEY}-${PHASE}.output.XXXXXX")"

cat "$PROMPT_FILE" > "$PROMPT_SNAPSHOT"
printf '\n\n---\n\n' >> "$PROMPT_SNAPSHOT"
cat "$TASK_FILE" >> "$PROMPT_SNAPSHOT"

printf 'agent=%s\nphase=%s\nstatus=running\nstarted_at=%s\n' \
  "$AGENT_KEY" "$PHASE" "$(date -Iseconds)" > "$STATUS_FILE"

if [[ "$DRY_RUN" == "1" ]]; then
  cat > "$OUTPUT_FILE" <<EOF2
# ${AGENT_KEY} ${PHASE} (dry run)

- Prompt file: ${PROMPT_FILE}
- Task file: ${TASK_FILE}
- Repo root: ${REPO_ROOT}
- Model: ${MODEL}

This is a dry run placeholder. No Codex model call was executed.
EOF2
  printf 'agent=%s\nphase=%s\nstatus=dry_run_complete\ncompleted_at=%s\n' \
    "$AGENT_KEY" "$PHASE" "$(date -Iseconds)" > "$STATUS_FILE"
  exit 0
fi

codex exec \
  --cd "$REPO_ROOT" \
  --full-auto \
  --model "$MODEL" \
  --output-last-message "$TMP_OUTPUT" \
  - < "$PROMPT_SNAPSHOT" >"$LOG_FILE" 2>&1

mv "$TMP_OUTPUT" "$OUTPUT_FILE"

printf 'agent=%s\nphase=%s\nstatus=completed\ncompleted_at=%s\noutput=%s\n' \
  "$AGENT_KEY" "$PHASE" "$(date -Iseconds)" "$OUTPUT_FILE" > "$STATUS_FILE"
EOF
)
write_file_safe "$ROOT_DIR/scripts/agent-runtime/run-codex-agent.sh" "$RUNNER_SCRIPT"
chmod +x "$ROOT_DIR/scripts/agent-runtime/run-codex-agent.sh"

MESH_SCRIPT=$(cat <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
DRY_RUN=0

if [[ "${1:-}" == "--dry-run" ]]; then
  DRY_RUN=1
fi

RUNNER="$REPO_ROOT/scripts/agent-runtime/run-codex-agent.sh"
PROMPTS_DIR="$REPO_ROOT/.codex/prompts"
INDIVIDUAL_DIR="$REPO_ROOT/.codex/reports/individual"
CROSS_DIR="$REPO_ROOT/.codex/reports/cross-review"
FINAL_DIR="$REPO_ROOT/.codex/reports/final"
STATE_DIR="$REPO_ROOT/.codex/state"
TASK_DIR="$STATE_DIR/tasks"
FINAL_REPORT="$FINAL_DIR/unified-production-saas-assessment.md"
BUNDLE_FILE="$FINAL_DIR/unified-source-bundle.md"

mkdir -p "$TASK_DIR" "$INDIVIDUAL_DIR" "$CROSS_DIR" "$FINAL_DIR"

if [[ ! -x "$RUNNER" ]]; then
  echo "Missing executable runner: $RUNNER"
  exit 1
fi

if [[ "$DRY_RUN" != "1" ]] && ! command -v codex >/dev/null 2>&1; then
  echo "codex CLI is required for a live mesh run."
  exit 1
fi

log() {
  printf '[mesh] %s\n' "$1"
}

write_task() {
  local path="$1"
  local content="$2"
  printf "%s" "$content" > "$path"
}

run_agent() {
  local agent_key="$1"
  local phase="$2"
  local prompt_file="$3"
  local task_file="$4"
  local output_file="$5"

  DRY_RUN="$DRY_RUN" "$RUNNER" \
    "$REPO_ROOT" \
    "$agent_key" \
    "$phase" \
    "$prompt_file" \
    "$task_file" \
    "$output_file"
}

log "phase 1: independent reviews"

declare -A PROMPTS=(
  [orchestrator]="$PROMPTS_DIR/orchestrator.md"
  [pm_agent]="$PROMPTS_DIR/pm_agent.md"
  [product_ux]="$PROMPTS_DIR/product-ux.md"
  [security_platform]="$PROMPTS_DIR/security-platform.md"
)

declare -A OUTPUTS=(
  [orchestrator]="$INDIVIDUAL_DIR/orchestrator-assessment.md"
  [pm_agent]="$INDIVIDUAL_DIR/pm-agent-assessment.md"
  [product_ux]="$INDIVIDUAL_DIR/product-ux-assessment.md"
  [security_platform]="$INDIVIDUAL_DIR/security-platform-assessment.md"
)

for agent_key in orchestrator pm_agent product_ux security_platform; do
  task_file="$TASK_DIR/${agent_key}-independent.md"
  write_task "$task_file" "You are running in the CVERiskPilot autonomous multi-agent mesh.

Phase: Independent review

Review the current repository state from your role perspective.

Requirements:
- produce a complete markdown report
- write only the final report content
- focus on concrete gaps, risks, and recommended next steps
- cite file paths when relevant
- do not mention internal chain-of-thought

Output target: ${OUTPUTS[$agent_key]}
"

  run_agent "$agent_key" "independent" "${PROMPTS[$agent_key]}" "$task_file" "${OUTPUTS[$agent_key]}" &
done
wait

log "phase 2: cross-review"

cross_review() {
  local reviewer_key="$1"
  local subject_key="$2"
  local reviewer_prompt="$3"
  local subject_file="$4"
  local output_file="$5"
  local task_file="$TASK_DIR/${reviewer_key}-review-of-${subject_key}.md"

  write_task "$task_file" "You are running in the CVERiskPilot autonomous multi-agent mesh.

Phase: Cross-review

Review this report from another agent:
- ${subject_file}

Requirements:
- produce a markdown review
- identify agreements, blind spots, conflicts, and recommended changes
- write only the final review content
- cite file paths or repo areas when relevant

Output target: ${output_file}
"

  run_agent "$reviewer_key" "cross-review-of-${subject_key}" "$reviewer_prompt" "$task_file" "$output_file"
}

cross_review orchestrator pm "${PROMPTS[orchestrator]}" "$INDIVIDUAL_DIR/pm-agent-assessment.md" "$CROSS_DIR/orchestrator-review-of-pm.md"
cross_review orchestrator product "${PROMPTS[orchestrator]}" "$INDIVIDUAL_DIR/product-ux-assessment.md" "$CROSS_DIR/orchestrator-review-of-product.md"
cross_review orchestrator security "${PROMPTS[orchestrator]}" "$INDIVIDUAL_DIR/security-platform-assessment.md" "$CROSS_DIR/orchestrator-review-of-security.md"
cross_review pm_agent orchestrator "${PROMPTS[pm_agent]}" "$INDIVIDUAL_DIR/orchestrator-assessment.md" "$CROSS_DIR/pm-review-of-orchestrator.md"
cross_review pm_agent product "${PROMPTS[pm_agent]}" "$INDIVIDUAL_DIR/product-ux-assessment.md" "$CROSS_DIR/pm-review-of-product.md"
cross_review pm_agent security "${PROMPTS[pm_agent]}" "$INDIVIDUAL_DIR/security-platform-assessment.md" "$CROSS_DIR/pm-review-of-security.md"
cross_review product_ux orchestrator "${PROMPTS[product_ux]}" "$INDIVIDUAL_DIR/orchestrator-assessment.md" "$CROSS_DIR/product-review-of-orchestrator.md"
cross_review product_ux pm "${PROMPTS[product_ux]}" "$INDIVIDUAL_DIR/pm-agent-assessment.md" "$CROSS_DIR/product-review-of-pm.md"
cross_review product_ux security "${PROMPTS[product_ux]}" "$INDIVIDUAL_DIR/security-platform-assessment.md" "$CROSS_DIR/product-review-of-security.md"
cross_review security_platform orchestrator "${PROMPTS[security_platform]}" "$INDIVIDUAL_DIR/orchestrator-assessment.md" "$CROSS_DIR/security-review-of-orchestrator.md"
cross_review security_platform pm "${PROMPTS[security_platform]}" "$INDIVIDUAL_DIR/pm-agent-assessment.md" "$CROSS_DIR/security-review-of-pm.md"
cross_review security_platform product "${PROMPTS[security_platform]}" "$INDIVIDUAL_DIR/product-ux-assessment.md" "$CROSS_DIR/security-review-of-product.md"

matrix_task="$TASK_DIR/orchestrator-cross-review-matrix.md"
write_task "$matrix_task" "You are running in the CVERiskPilot autonomous multi-agent mesh.

Phase: Cross-review matrix

Build a consolidated matrix from the individual and cross-review reports.

Requirements:
- produce markdown only
- capture shared findings, conflicts, blind spots, uncovered areas, and unified priority order
- write only the final matrix content

Input directories:
- ${INDIVIDUAL_DIR}
- ${CROSS_DIR}

Output target: ${CROSS_DIR}/cross-review-matrix.md
"
run_agent orchestrator "cross-review-matrix" "${PROMPTS[orchestrator]}" "$matrix_task" "$CROSS_DIR/cross-review-matrix.md"

log "phase 3: source bundle"
"$REPO_ROOT/scripts/merge-agent-assessments.sh" "$REPO_ROOT"

log "phase 4: final synthesis"
final_task="$TASK_DIR/orchestrator-final.md"
write_task "$final_task" "You are running in the CVERiskPilot autonomous multi-agent mesh.

Phase: Final synthesis

Read the consolidated source bundle:
- ${BUNDLE_FILE}

Produce the final unified report.

Requirements:
- output markdown only
- synthesize the strongest findings, not a raw concatenation
- give a final recommended implementation order
- keep the report actionable for the engineering team

Output target: ${FINAL_REPORT}
"
run_agent orchestrator "final" "${PROMPTS[orchestrator]}" "$final_task" "$FINAL_REPORT"

log "mesh run complete"
log "final report: $FINAL_REPORT"
EOF
)
write_file_safe "$ROOT_DIR/scripts/run-agent-mesh.sh" "$MESH_SCRIPT"
chmod +x "$ROOT_DIR/scripts/run-agent-mesh.sh"

TMUX_LAUNCHER=$(cat <<'EOF'
#!/usr/bin/env bash
set -euo pipefail

SESSION_NAME="${1:-cveriskpilot-agents}"
REPO_ROOT="${2:-.}"
REPO_ROOT="$(cd "$REPO_ROOT" && pwd)"

if ! command -v tmux >/dev/null 2>&1; then
  echo "tmux is not installed. Run: sudo apt update && sudo apt install -y tmux"
  exit 1
fi

if tmux has-session -t "$SESSION_NAME" 2>/dev/null; then
  echo "Session already exists: $SESSION_NAME"
  echo "Attach with: tmux attach -t $SESSION_NAME"
  exit 0
fi

tmux new-session -d -s "$SESSION_NAME" -c "$REPO_ROOT" -n orchestrator
tmux send-keys -t "$SESSION_NAME:orchestrator" "clear; echo 'Role: Orchestrator Agent'" C-m

tmux new-window -t "$SESSION_NAME" -n pm -c "$REPO_ROOT"
tmux send-keys -t "$SESSION_NAME:pm" "clear; echo 'Role: Program Manager Agent'" C-m

tmux new-window -t "$SESSION_NAME" -n product -c "$REPO_ROOT"
tmux send-keys -t "$SESSION_NAME:product" "clear; echo 'Role: SaaS Product & UX Audit Agent'" C-m

tmux new-window -t "$SESSION_NAME" -n security -c "$REPO_ROOT"
tmux send-keys -t "$SESSION_NAME:security" "clear; echo 'Role: Security / Architecture / Platform Audit Agent'" C-m

echo "Created tmux session: $SESSION_NAME"
echo "Attach with: tmux attach -t $SESSION_NAME"
EOF
)
write_file_safe "$ROOT_DIR/scripts/launch-agent-tmux.sh" "$TMUX_LAUNCHER"
chmod +x "$ROOT_DIR/scripts/launch-agent-tmux.sh"

README_MULTIAGENT=$(cat <<EOF
# ${PROJECT_NAME} Codex Multi-Agent Workspace

## Prompt source directory
The script auto-loads prompts from:
- ${PROMPT_SOURCE_DIR}/${ORCH_SOURCE_FILE}
- ${PROMPT_SOURCE_DIR}/${PM_SOURCE_FILE}
- ${PROMPT_SOURCE_DIR}/${PRODUCT_SOURCE_FILE}
- ${PROMPT_SOURCE_DIR}/${SECURITY_SOURCE_FILE}

## Flow
1. Independent assessments
2. Cross-review
3. Merge source bundle
4. Final unified assessment

## Commands
./scripts/launch-agent-windows.sh
./scripts/prepare-codex-session.sh
./scripts/merge-agent-assessments.sh
./scripts/launch-agent-tmux.sh
./scripts/run-agent-mesh.sh

## Autonomous Run
Run the full mesh workflow:

```bash
./scripts/run-agent-mesh.sh
```

Preview the workflow without calling Codex:

```bash
./scripts/run-agent-mesh.sh --dry-run
```
EOF
)
write_file_safe "$ROOT_DIR/README.multiagent.md" "$README_MULTIAGENT"

cat <<EOF

==============================================
Multi-agent Codex workspace scaffold complete.
==============================================

Prompts loaded from:
- $ORCH_SOURCE_PATH
- $PM_SOURCE_PATH
- $PRODUCT_SOURCE_PATH
- $SECURITY_SOURCE_PATH

Next steps:
1. Preview the mesh workflow with --dry-run
2. Run the full autonomous mesh
3. Inspect individual and cross-review outputs
4. Review the final unified report

Useful commands:
  ./scripts/launch-agent-windows.sh
  ./scripts/prepare-codex-session.sh
  ./scripts/merge-agent-assessments.sh
  ./scripts/launch-agent-tmux.sh
  ./scripts/run-agent-mesh.sh
EOF
