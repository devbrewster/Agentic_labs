import { describe, expect, it, vi } from "vitest";

vi.mock("@/lib/agent-mesh/monitor", () => ({
  getAgentMeshMonitorSnapshot: vi.fn(async () => ({
    phaseStates: [],
    statuses: [],
    recentLogLines: [],
    reports: {
      individual: [],
      crossReview: [],
      final: [],
    },
  })),
}));

import { GET as getAgentMesh } from "@/app/api/agent-mesh/route";

describe("agent mesh route", () => {
  it("requires organization-scoped access even in local development", async () => {
    const response = await getAgentMesh(new Request("http://localhost/api/agent-mesh"));
    const json = await response.json();

    expect(response.status).toBe(401);
    expect(json.ok).toBe(false);
    expect(json.reason).toBe("not_authenticated");
  });

  it("returns the local mesh snapshot when test org access is provided", async () => {
    const response = await getAgentMesh(
      new Request("http://localhost/api/agent-mesh", {
        headers: {
          "x-test-organization-id": "org-test",
        },
      }),
    );
    const json = await response.json();

    expect(response.status).toBe(200);
    expect(json.ok).toBe(true);
    expect(Array.isArray(json.data.phaseStates)).toBe(true);
  });
});
