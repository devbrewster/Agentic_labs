import type { ReactNode } from "react";

import { DashboardMobileNav } from "@/components/dashboard/DashboardMobileNav";
import { DashboardSidebar } from "@/components/dashboard/DashboardSidebar";
import { DashboardTopbar } from "@/components/dashboard/DashboardTopbar";

type DashboardShellProps = {
  children: ReactNode;
  title?: string;
  subtitle?: string;
};

export function DashboardShell({
  children,
  title = "CVERiskPilot",
  subtitle = "Mock environment · dashboard foundation active",
}: DashboardShellProps) {
  return (
    <div className="dashboard-shell h-screen overflow-hidden bg-[var(--bg)] text-[var(--text)]">
      <div className="pointer-events-none fixed inset-0 z-0 bg-[linear-gradient(rgba(0,200,180,0.02)_1px,transparent_1px),linear-gradient(90deg,rgba(0,200,180,0.02)_1px,transparent_1px)] bg-[size:32px_32px]" />
      <div className="pointer-events-none fixed inset-0 z-0 bg-[radial-gradient(circle_at_top_left,rgba(0,200,180,0.06),transparent_24%),radial-gradient(circle_at_bottom_right,rgba(255,69,96,0.05),transparent_22%)]" />
      <div className="pointer-events-none fixed inset-x-0 top-0 z-20 h-px bg-[linear-gradient(90deg,transparent,var(--accent),transparent)] opacity-25 animate-[scanline_8s_linear_infinite]" />

      <div className="relative z-10 flex h-full">
        <DashboardSidebar />

        <div className="flex min-w-0 flex-1 flex-col overflow-hidden">
          <DashboardTopbar title={title} subtitle={subtitle} />
          <DashboardMobileNav />
          <main className="flex-1 overflow-y-auto px-4 py-4 md:px-6 xl:px-6">
            {children}
          </main>
          <div className="flex h-6 items-center gap-4 border-t border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] px-5 font-mono text-[0.58rem] uppercase tracking-[0.12em] text-[var(--muted)]">
            <div className="flex items-center gap-2">
              <span className="h-1.5 w-1.5 rounded-full bg-[var(--accent)]" />
              Connected · D1 Database
            </div>
            <div>· Worker Online</div>
            <div>· AI Engine Ready</div>
            <div className="ml-auto">CVERISKPILOT v1.0.0</div>
          </div>
        </div>
      </div>
    </div>
  );
}
