# CVERiskPilot Core Readiness Checklist

Last updated: 2026-03-11  
Owner: Product Engineering  
Status: complete

## Purpose

This checklist defines the **mandatory go-live gates** for core security decision functionality.  
Billing/paywall implementation is blocked until this checklist is complete.

## Go/No-Go Rule

Do **not** implement Stripe/paywall until all sections below are marked:

- `Status: complete`

## 1) File Upload + Parsing Coverage

Status: complete

- `generic_csv` parser stable in `dev` and `preview`
- Nessus parser implemented (real mapping, not placeholder)
- Qualys parser implemented (real mapping, not placeholder)
- Rapid7 parser implemented (real mapping, not placeholder)
- Per-parser validation and warning/error contracts normalized
- Idempotent reparse behavior verified for all supported parser types
- Parser fixtures and regression tests added for each source type

## 2) Enrichment Reliability (NVD + KEV)

Status: complete

- NVD enrichment returns structured data for valid CVEs
- KEV enrichment returns consistent `listed` signal
- Enrichment service handles provider partial failures without crashing
- Retry/backoff/rate-limit behavior tested
- Cache and stale fallback behavior verified
- Enrichment provenance visible per finding (provider + observed timestamp)
- Integration tests cover success, partial, failure, and stale-cache paths

## 3) AI Analysis Quality + Safety

Status: complete

- Prompt payload contract deterministic from finding + enrichment + analyst context
- Claude live mode works server-side only (no client secret exposure)
- Stub mode available for deterministic testing
- AI output schema validated and enforced
- Fallback behavior defined when Claude unavailable
- Prompt/result traces logged for auditability (without secret leakage)
- Tests cover live-disabled path, schema errors, and fallback behavior

## 4) Security Reviewer Feedback Loop

Status: complete

- Analyst disposition persisted (`true_risk`, `false_positive`, `mitigated`, `accepted_risk`, `not_applicable`)
- Decision rationale persisted and queryable
- Architecture influence factors persisted and queryable
- Disposition history timeline available
- Feedback is reflected in finding details and summary APIs
- Feedback influence on future prioritization defined and implemented

## 5) Business Decision Readiness (Stakeholder Insight)

Status: complete

- Finding view clearly separates:
  - original source data
  - AI-generated analysis
  - other enrichment sources
- Risk rationale is explainable with source provenance
- Action plans are generated with owner/ETA/priority scaffolding
- Executive-ready summary view available for stakeholder communication
- Error/uncertainty states are explicit (no silent confidence inflation)

## 6) Operational Hardening

Status: complete

- End-to-end tests run in `npm run dev` and `npm run preview`
- D1 schema migration flow is documented and repeatable
- Known failure runbooks documented (upload errors, enrichment outage, stale artifacts)
- Core endpoints have structured JSON errors
- No critical/High unresolved defects in upload, enrichment, analysis, or feedback paths

## 7) Definition of Core Complete

Status: complete

Core is complete only when:

1. All sections (1-6) are marked `complete`.
2. Test suite passes with core scenarios.
3. Manual validation run is documented in `docs/progress-log.md`.
4. Phase status explicitly records “Core Ready for Billing Phase”.

Phase status: Core Ready for Billing Phase

## 8) Post-Core Trigger

When section 7 is complete:

- Start billing roadmap from `docs/production-roadmap.md` Phase P4-1.
- Keep billing launch behind feature flag until first production cohort passes.
