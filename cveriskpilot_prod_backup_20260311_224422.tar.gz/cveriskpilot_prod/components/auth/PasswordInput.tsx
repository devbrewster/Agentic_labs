"use client";

import { useState } from "react";

type Props = React.InputHTMLAttributes<HTMLInputElement> & {
  label: string;
};

export default function PasswordInput({ label, ...props }: Props) {
  const [show, setShow] = useState(false);

  return (
    <label className="block">
      <span className="mb-2 block text-sm text-slate-300">{label}</span>
      <div className="flex gap-2">
        <input
          {...props}
          type={show ? "text" : "password"}
          className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-white outline-none"
        />
        <button
          type="button"
          onClick={() => setShow((v) => !v)}
          className="rounded-lg border border-slate-700 px-3 py-2 text-sm text-slate-300"
        >
          {show ? "Hide" : "Show"}
        </button>
      </div>
    </label>
  );
}
