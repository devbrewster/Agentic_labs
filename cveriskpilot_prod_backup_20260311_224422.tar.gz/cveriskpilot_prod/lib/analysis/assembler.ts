import type { Finding } from "@/types/dashboard";
import type { AnalystDispositionRecord } from "@/types/analyst";
import type { FindingEnrichmentSnapshot } from "@/types/enrichment";
import {
  AnalysisPromptContextSchema,
  PromptTemplateVersion,
  type AnalysisPromptContext,
} from "@/types/analysis";
import { buildEnrichmentSummary } from "@/lib/services/enrichment-summary";

type BuildAnalysisPromptContextInput = {
  finding: Finding;
  snapshots: FindingEnrichmentSnapshot[];
  disposition: AnalystDispositionRecord | null;
};

function extractReferenceUrls(snapshots: FindingEnrichmentSnapshot[]) {
  const urls = new Set<string>();

  for (const snapshot of snapshots) {
    const references = snapshot.summaryJson?.references;
    if (!Array.isArray(references)) {
      continue;
    }

    for (const reference of references) {
      if (typeof reference === "string" && reference.startsWith("http")) {
        urls.add(reference);
      }
    }
  }

  return Array.from(urls);
}

function extractSummarySnippets(snapshots: FindingEnrichmentSnapshot[]) {
  return snapshots
    .map((snapshot) => snapshot.summaryJson?.summary)
    .filter((value): value is string => typeof value === "string" && value.trim().length > 0)
    .slice(0, 6);
}

export function buildAnalysisPromptContext({
  finding,
  snapshots,
  disposition,
}: BuildAnalysisPromptContextInput): AnalysisPromptContext {
  const enrichmentSummary = buildEnrichmentSummary(snapshots);

  return AnalysisPromptContextSchema.parse({
    templateVersion: PromptTemplateVersion,
    generatedAt: new Date().toISOString(),
    finding: {
      findingId: finding.id,
      cveId: finding.cveId,
      title: finding.title,
      description: finding.description ?? null,
      severity: finding.severity,
      riskScore: finding.riskScore,
      cvssScore: finding.cvssScore ?? null,
      assetName: finding.assetName,
      environment: finding.environment,
      status: finding.status,
      remediationSummary: finding.remediationSummary ?? null,
      discoveredAt: finding.discoveredAt,
      tags: finding.tags,
    },
    enrichment: {
      status: enrichmentSummary.status,
      providers: enrichmentSummary.providers,
      kevListed: enrichmentSummary.kevListed ?? null,
      exploitAvailable: enrichmentSummary.exploitAvailable ?? null,
      cvssVector: enrichmentSummary.cvssVector ?? null,
      references: extractReferenceUrls(snapshots),
      lastObservedAt: enrichmentSummary.lastObservedAt ?? null,
      summarySnippets: extractSummarySnippets(snapshots),
    },
    analyst: {
      decision: disposition?.decision ?? null,
      rationale: disposition?.rationale ?? null,
      architectureContextSummary: finding.architectureContextSummary ?? null,
      influenceFactors: disposition?.factors ?? null,
    },
    compliance: {
      sourceSeparationRequired: true,
      nvdAttributionRequired: true,
      noEndorsementLanguage: true,
    },
  });
}
