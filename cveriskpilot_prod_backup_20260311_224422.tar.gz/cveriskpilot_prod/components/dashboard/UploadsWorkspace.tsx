"use client";

import { useEffect, useState } from "react";

import { SectionPlaceholder } from "@/components/dashboard/SectionPlaceholder";
import { StatusPill } from "@/components/dashboard/StatusPill";
import { UploadDropzone } from "@/components/dashboard/UploadDropzone";
import { UploadHistoryTable } from "@/components/dashboard/UploadHistoryTable";
import { UploadJobDetailsPanel } from "@/components/dashboard/UploadJobDetailsPanel";
import { listSupportedUploadFormats } from "@/lib/services/uploads";
import type { UploadJob } from "@/types/dashboard";

type IngestionListResponse = {
  ok: boolean;
  data?: {
    ingestionJobs: Array<{
      uploadJob: {
        id: string;
        status: string;
        findingCount: number;
        parsedAt: string | null;
        updatedAt: string;
        errorSummary: string | null;
      };
      rawArtifact: {
        originalFilename: string;
      };
    }>;
  };
  error?: {
    code: string;
    message: string;
  };
};

type UploadCreateResponse = {
  ok: boolean;
  data?: {
    uploadJob: {
      id: string;
    };
    deduplicated: boolean;
    message: string;
  };
  error?: {
    code: string;
    message: string;
  };
};

type ReparseResponse = {
  ok: boolean;
  data?: {
    uploadJob: {
      id: string;
      status: string;
      findingCount: number;
      errorSummary: string | null;
    };
    skipped: boolean;
    message: string;
  };
  error?: {
    code: string;
    message: string;
  };
};

type UploadDetailResponse = {
  ok: boolean;
  data?: {
    findings: Array<{
      id: string;
      title: string;
      normalizedSeverity: string;
    }>;
    metadata: {
      checksumSha256: string;
      fileType: string;
      findingCount: number;
      hostCount: number;
      parsedAt: string;
      scannerName: string;
      scannerVersion: string | null;
      sourceType: string;
    } | null;
    parserErrors: Array<{
      code: string;
      details?: Record<string, unknown> | null;
      fatal: boolean;
      message: string;
    }>;
    parserWarnings: Array<{
      code: string;
      field: string | null;
      level: string;
      message: string;
      row: number | null;
    }>;
    rawArtifact: {
      checksumSha256: string;
      fileType: string;
      mimeType: string;
      originalFilename: string;
      uploadedAt: string;
    };
    uploadJob: {
      id: string;
      status: string;
      selectedSourceType: string | null;
      updatedAt: string;
    };
  };
  error?: {
    code: string;
    message: string;
  };
};

function mapIngestionStatusToUiStatus(
  status: string,
): UploadJob["status"] {
  switch (status) {
    case "queued":
      return "queued";
    case "parsing":
      return "parsing";
    case "parsed":
      return "parsed";
    case "enrichment_pending":
      return "enrichment_pending";
    case "failed":
      return "failed";
    default:
      return "queued";
  }
}

function mapIngestionJobsToUploadRows(
  ingestionJobs: NonNullable<IngestionListResponse["data"]>["ingestionJobs"],
): UploadJob[] {
  return ingestionJobs.map(({ uploadJob, rawArtifact }) => ({
    id: uploadJob.id,
    filename: rawArtifact.originalFilename,
    sourceType: "Ingestion API",
    status: mapIngestionStatusToUiStatus(uploadJob.status),
    uploadedAt: uploadJob.parsedAt ?? uploadJob.updatedAt,
    findingsDetected: uploadJob.findingCount,
    uploadedBy: "dashboard-operator",
    notes: uploadJob.errorSummary ?? "Ready for parsing and enrichment.",
  }));
}

export function UploadsWorkspace() {
  const supportedUploadFormats = listSupportedUploadFormats();
  const [jobs, setJobs] = useState<UploadJob[]>([]);
  const [isLoadingJobs, setIsLoadingJobs] = useState(true);
  const [isUploading, setIsUploading] = useState(false);
  const [isParsing, setIsParsing] = useState(false);
  const [selectedFileName, setSelectedFileName] = useState<string | null>(null);
  const [lastUploadJobId, setLastUploadJobId] = useState<string | null>(null);
  const [selectedUploadJobId, setSelectedUploadJobId] = useState<string | null>(null);
  const [selectedUploadJobDetail, setSelectedUploadJobDetail] =
    useState<UploadDetailResponse["data"] | null>(null);
  const [isLoadingSelectedJobDetail, setIsLoadingSelectedJobDetail] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  async function loadJobs() {
    setIsLoadingJobs(true);

    try {
      const response = await fetch("/api/uploads", {
        cache: "no-store",
      });
      const payload = (await response.json()) as IngestionListResponse;

      if (!response.ok || !payload.ok || !payload.data) {
        throw new Error(payload.error?.message ?? "Unable to load upload jobs.");
      }

      const mappedJobs = mapIngestionJobsToUploadRows(payload.data.ingestionJobs);
      setJobs(mappedJobs);
      setSelectedUploadJobId((currentSelectedUploadJobId) => {
        if (currentSelectedUploadJobId && mappedJobs.some((job) => job.id === currentSelectedUploadJobId)) {
          return currentSelectedUploadJobId;
        }

        return mappedJobs[0]?.id ?? null;
      });
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : "Unable to load upload jobs.",
      );
    } finally {
      setIsLoadingJobs(false);
    }
  }

  useEffect(() => {
    void loadJobs();
  }, []);

  useEffect(() => {
    let cancelled = false;

    async function loadSelectedJobDetail(uploadJobId: string) {
      setIsLoadingSelectedJobDetail(true);

      try {
        const response = await fetch(`/api/uploads/${uploadJobId}`, {
          cache: "no-store",
        });
        const payload = (await response.json()) as UploadDetailResponse;

        if (!response.ok || !payload.ok || !payload.data) {
          throw new Error(payload.error?.message ?? "Unable to load upload diagnostics.");
        }

        if (!cancelled) {
          setSelectedUploadJobDetail(payload.data);
        }
      } catch (error) {
        if (!cancelled) {
          setSelectedUploadJobDetail(null);
          setErrorMessage(
            error instanceof Error ? error.message : "Unable to load upload diagnostics.",
          );
        }
      } finally {
        if (!cancelled) {
          setIsLoadingSelectedJobDetail(false);
        }
      }
    }

    if (!selectedUploadJobId) {
      setSelectedUploadJobDetail(null);
      return () => {
        cancelled = true;
      };
    }

    void loadSelectedJobDetail(selectedUploadJobId);

    return () => {
      cancelled = true;
    };
  }, [selectedUploadJobId]);

  async function handleUpload(file: File) {
    setIsUploading(true);
    setErrorMessage(null);
    setStatusMessage(null);
    setSelectedFileName(file.name);

    try {
      const formData = new FormData();
      formData.set("file", file);
      formData.set("selectedSourceType", "generic_csv");

      const response = await fetch("/api/uploads", {
        method: "POST",
        body: formData,
      });
      const payload = (await response.json()) as UploadCreateResponse;

      if (!response.ok || !payload.ok || !payload.data) {
        throw new Error(payload.error?.message ?? "Upload failed.");
      }

      setLastUploadJobId(payload.data.uploadJob.id);
      setSelectedUploadJobId(payload.data.uploadJob.id);
      setStatusMessage(payload.data.message);
      await loadJobs();

      return payload.data.uploadJob.id;
    } finally {
      setIsUploading(false);
    }
  }

  async function handleParse(uploadJobId: string) {
    setIsParsing(true);
    setErrorMessage(null);
    setStatusMessage(null);

    try {
      const response = await fetch(`/api/uploads/${uploadJobId}/reparse`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ force: true }),
      });
      const payload = (await response.json()) as ReparseResponse;

      if (!response.ok || !payload.ok || !payload.data) {
        throw new Error(payload.error?.message ?? "Parse run failed.");
      }

      setStatusMessage(payload.data.message);
      setSelectedUploadJobId(uploadJobId);
      await loadJobs();
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : "Unable to parse upload job.",
      );
    } finally {
      setIsParsing(false);
    }
  }

  async function handleUploadAndParse(file: File) {
    try {
      const uploadJobId = await handleUpload(file);
      await handleParse(uploadJobId);
    } catch (error) {
      setErrorMessage(
        error instanceof Error ? error.message : "Unable to upload and parse file.",
      );
    }
  }

  return (
    <div className="space-y-5">
      <div className="grid gap-5 xl:grid-cols-[minmax(0,1.45fr)_360px]">
        <UploadDropzone
          isUploading={isUploading}
          isParsing={isParsing}
          selectedFileName={selectedFileName}
          statusMessage={statusMessage}
          errorMessage={errorMessage}
          onUpload={handleUploadAndParse}
        />

        <section className="rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] p-5 shadow-[0_16px_40px_rgba(0,0,0,0.18)]">
          <div className="mb-3 font-mono text-[0.72rem] uppercase tracking-[0.14em] text-[var(--accent)]">
            // Supported Formats
          </div>
          <div className="space-y-3">
            {supportedUploadFormats.map((format) => (
              <div
                key={format.label}
                className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] p-3"
              >
                <div className="flex items-center gap-2">
                  <StatusPill tone={format.label === "SARIF" ? "warning" : "accent"}>
                    {format.label}
                  </StatusPill>
                </div>
                <p className="mt-3 text-sm leading-7 text-[var(--text-dim)]">
                  {format.description}
                </p>
              </div>
            ))}
          </div>
        </section>
      </div>

      <UploadHistoryTable
        jobs={jobs}
        isLoading={isLoadingJobs}
        onSelect={setSelectedUploadJobId}
        selectedUploadJobId={selectedUploadJobId ?? lastUploadJobId}
      />

      <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_360px]">
        <SectionPlaceholder
          eyebrow="// Ingestion Pipeline"
          title="Raw artifact intake and parsing is now wired"
          description="Files dropped here are sent to the ingestion API, stored as raw artifacts, queued as upload jobs, and immediately reparsed through the current parser stack. Findings retrieval is available through the upload APIs while dashboard findings views remain on mock data until the next integration pass."
        />

        <UploadJobDetailsPanel
          detail={selectedUploadJobDetail ?? null}
          isLoading={isLoadingSelectedJobDetail}
          selectedJob={
            jobs.find((job) => job.id === (selectedUploadJobId ?? lastUploadJobId)) ?? null
          }
        />
      </div>
    </div>
  );
}
