import { NextResponse } from "next/server";

import { apiError, getUserById, readJsonBody, withAuthRoute } from "@/lib/auth";
import { dbRun } from "@/lib/db";
import { hashPassword, verifyPassword } from "@/lib/passwords";
import {
  clearSessionCookie,
  requireAuthenticatedSession,
  revokeAllSessions,
} from "@/lib/session";
import { validatePasswordChangePayload } from "@/lib/validators";

export const PATCH = withAuthRoute(async function PATCH(request: Request) {
  const auth = await requireAuthenticatedSession(request);

  if (!auth.ok) {
    return auth.response;
  }

  const payload = await readJsonBody(request);
  const validation = validatePasswordChangePayload(payload);

  if (!validation.success) {
    return apiError("invalid_input", validation.message, 400, validation.fieldErrors);
  }

  const user = await getUserById(auth.session.user.id);

  if (!user) {
    return apiError("not_authenticated", "Authentication is required.", 401);
  }

  const currentPasswordValid = await verifyPassword(
    validation.data.current_password,
    user.password_hash,
  );

  if (!currentPasswordValid) {
    return apiError("invalid_current", "Current password is incorrect.", 400);
  }

  const newPasswordHash = await hashPassword(validation.data.new_password);

  await dbRun(
    `UPDATE users
     SET password_hash = ?
     WHERE id = ?`,
    newPasswordHash,
    user.id,
  );

  await revokeAllSessions(user.id);

  const response = NextResponse.json(
    {
      ok: true,
      data: {
        message: "Password updated. All sessions have been revoked.",
      },
    },
    { status: 200 },
  );

  clearSessionCookie(response, request);
  return response;
});
