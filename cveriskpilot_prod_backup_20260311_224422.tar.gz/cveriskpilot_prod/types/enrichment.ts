import { z } from "zod";

export const enrichmentProviderValues = [
  "nvd",
  "cisa_kev",
  "wiz",
  "snyk",
  "tenable",
  "qualys",
  "rapid7",
  "manual",
] as const;

export const enrichmentRunStatusValues = [
  "queued",
  "running",
  "completed",
  "partial",
  "failed",
] as const;

export const enrichmentSnapshotStatusValues = [
  "enriched",
  "not_found",
  "error",
] as const;

export const EnrichmentProviderSchema = z.enum(enrichmentProviderValues);
export type EnrichmentProvider = z.infer<typeof EnrichmentProviderSchema>;

export const EnrichmentRunStatusSchema = z.enum(enrichmentRunStatusValues);
export type EnrichmentRunStatus = z.infer<typeof EnrichmentRunStatusSchema>;

export const EnrichmentSnapshotStatusSchema = z.enum(enrichmentSnapshotStatusValues);
export type EnrichmentSnapshotStatus = z.infer<typeof EnrichmentSnapshotStatusSchema>;

export const TimestampSchema = z.iso.datetime();
export type Timestamp = z.infer<typeof TimestampSchema>;

export const JsonRecordSchema = z.record(z.string(), z.unknown());
export type JsonRecord = z.infer<typeof JsonRecordSchema>;

export const EnrichmentRunSchema = z.object({
  id: z.string().uuid(),
  uploadJobId: z.string().uuid().nullable(),
  triggeredBy: z.string().min(1).max(128),
  status: EnrichmentRunStatusSchema,
  providerCount: z.number().int().nonnegative(),
  successCount: z.number().int().nonnegative(),
  errorCount: z.number().int().nonnegative(),
  errorSummary: z.string().max(1000).nullable(),
  startedAt: TimestampSchema.nullable(),
  completedAt: TimestampSchema.nullable(),
  createdAt: TimestampSchema,
  updatedAt: TimestampSchema,
});
export type EnrichmentRun = z.infer<typeof EnrichmentRunSchema>;

export const FindingEnrichmentSnapshotSchema = z.object({
  id: z.string().uuid(),
  enrichmentRunId: z.string().uuid(),
  findingId: z.string().uuid(),
  provider: EnrichmentProviderSchema,
  status: EnrichmentSnapshotStatusSchema,
  sourceUrl: z.string().url().nullable(),
  sourceVersion: z.string().min(1).nullable(),
  observedAt: TimestampSchema.nullable(),
  errorCode: z.string().min(1).nullable(),
  errorMessage: z.string().min(1).nullable(),
  summaryJson: JsonRecordSchema.nullable(),
  rawPayloadJson: JsonRecordSchema.nullable(),
  createdAt: TimestampSchema,
  updatedAt: TimestampSchema,
});
export type FindingEnrichmentSnapshot = z.infer<typeof FindingEnrichmentSnapshotSchema>;

export const CreateEnrichmentRunInputSchema = z.object({
  uploadJobId: z.string().uuid().nullable().default(null),
  providers: z.array(EnrichmentProviderSchema).min(1),
  triggeredBy: z.string().min(1).max(128).default("system"),
  force: z.boolean().default(false),
});
export type CreateEnrichmentRunInput = z.infer<typeof CreateEnrichmentRunInputSchema>;

export const EnrichmentRunResponseSchema = z.object({
  enrichmentRun: EnrichmentRunSchema,
  message: z.string().min(1),
});
export type EnrichmentRunResponse = z.infer<typeof EnrichmentRunResponseSchema>;

export const EnrichmentFindingInputSchema = z.object({
  findingId: z.string().uuid(),
  cveIds: z.array(z.string().min(1)).default([]),
  title: z.string().min(1),
  description: z.string().nullable().default(null),
  normalizedSeverity: z.string().min(1),
  cvssScore: z.number().min(0).max(10).nullable().default(null),
  sourceUpdatedAt: TimestampSchema.nullable().default(null),
});
export type EnrichmentFindingInput = z.infer<typeof EnrichmentFindingInputSchema>;

export const ProviderEnrichmentPayloadSchema = z.object({
  kevListed: z.boolean().nullable().default(null),
  exploitAvailable: z.boolean().nullable().default(null),
  cvssScore: z.number().min(0).max(10).nullable().default(null),
  cvssVector: z.string().nullable().default(null),
  references: z.array(z.string().url()).default([]),
  summary: z.string().nullable().default(null),
  sourceVersion: z.string().nullable().default(null),
});
export type ProviderEnrichmentPayload = z.infer<typeof ProviderEnrichmentPayloadSchema>;

export const ProviderEnrichmentResultSchema = z.object({
  provider: EnrichmentProviderSchema,
  status: EnrichmentSnapshotStatusSchema,
  sourceUrl: z.string().url().nullable().default(null),
  observedAt: TimestampSchema.nullable().default(null),
  payload: ProviderEnrichmentPayloadSchema.nullable().default(null),
  rawPayload: JsonRecordSchema.nullable().default(null),
  errorCode: z.string().nullable().default(null),
  errorMessage: z.string().nullable().default(null),
});
export type ProviderEnrichmentResult = z.infer<typeof ProviderEnrichmentResultSchema>;

export const RunFindingEnrichmentInputSchema = z.object({
  finding: EnrichmentFindingInputSchema,
  providers: z.array(EnrichmentProviderSchema).min(1),
  triggeredBy: z.string().min(1).max(128).default("system"),
});
export type RunFindingEnrichmentInput = z.infer<typeof RunFindingEnrichmentInputSchema>;

export const RunFindingEnrichmentResultSchema = z.object({
  findingId: z.string().uuid(),
  requestedProviders: z.array(EnrichmentProviderSchema),
  completedProviders: z.array(ProviderEnrichmentResultSchema),
  runStatus: EnrichmentRunStatusSchema,
  errorCount: z.number().int().nonnegative(),
  warningCount: z.number().int().nonnegative(),
  startedAt: TimestampSchema,
  completedAt: TimestampSchema,
});
export type RunFindingEnrichmentResult = z.infer<typeof RunFindingEnrichmentResultSchema>;

export const RunEnrichmentJobInputSchema = z.object({
  uploadJobId: z.string().uuid(),
  providers: z.array(EnrichmentProviderSchema).min(1),
  triggeredBy: z.string().min(1).max(128).default("system"),
  force: z.boolean().default(false),
});
export type RunEnrichmentJobInput = z.infer<typeof RunEnrichmentJobInputSchema>;

export const EnrichmentRunWithSnapshotsSchema = z.object({
  run: EnrichmentRunSchema,
  snapshots: z.array(FindingEnrichmentSnapshotSchema),
});
export type EnrichmentRunWithSnapshots = z.infer<typeof EnrichmentRunWithSnapshotsSchema>;

export const RunEnrichmentJobResultSchema = z.object({
  run: EnrichmentRunSchema,
  snapshots: z.array(FindingEnrichmentSnapshotSchema),
  skipped: z.boolean(),
  forced: z.boolean(),
  replacedExisting: z.boolean(),
  message: z.string().min(1),
});
export type RunEnrichmentJobResult = z.infer<typeof RunEnrichmentJobResultSchema>;
