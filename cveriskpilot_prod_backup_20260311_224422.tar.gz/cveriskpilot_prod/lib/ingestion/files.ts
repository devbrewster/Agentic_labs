import path from "node:path";

import {
  ArtifactFileTypeSchema,
  RawArtifactSchema,
  type ArtifactFileType,
  type ChecksumSha256,
  type RawArtifact,
} from "@/types/ingestion";

export type FileMetadataInput = {
  checksumSha256: ChecksumSha256;
  originalFilename: string;
  mimeType?: string | null;
  sizeBytes: number;
  storageKey: string;
  uploadedAt?: string;
};

const extensionToFileType: Record<string, ArtifactFileType> = {
  ".csv": "csv",
  ".json": "json",
  ".nessus": "xml",
  ".xml": "xml",
};

const mimeToFileType: Record<string, ArtifactFileType> = {
  "application/csv": "csv",
  "application/json": "json",
  "application/xml": "xml",
  "text/csv": "csv",
  "text/xml": "xml",
};

export function normalizeMimeType(mimeType?: string | null) {
  if (!mimeType) {
    return "application/octet-stream";
  }

  return mimeType.split(";")[0]?.trim().toLowerCase() || "application/octet-stream";
}

export function inferFileType(input: {
  originalFilename: string;
  mimeType?: string | null;
}): ArtifactFileType {
  const normalizedMimeType = normalizeMimeType(input.mimeType);
  const byMime = mimeToFileType[normalizedMimeType];

  if (byMime) {
    return ArtifactFileTypeSchema.parse(byMime);
  }

  const extension = path.extname(input.originalFilename).toLowerCase();
  const byExtension = extensionToFileType[extension] ?? "unknown";

  return ArtifactFileTypeSchema.parse(byExtension);
}

export function sanitizeFilename(filename: string) {
  const base = path.basename(filename).replace(/[^a-zA-Z0-9._-]/g, "_");
  return base || "upload.bin";
}

export function buildRawArtifactRecord(input: FileMetadataInput): RawArtifact {
  const uploadedAt = input.uploadedAt ?? new Date().toISOString();

  return RawArtifactSchema.parse({
    id: crypto.randomUUID(),
    storageKey: input.storageKey,
    originalFilename: sanitizeFilename(input.originalFilename),
    mimeType: normalizeMimeType(input.mimeType),
    fileType: inferFileType({
      originalFilename: input.originalFilename,
      mimeType: input.mimeType,
    }),
    sizeBytes: input.sizeBytes,
    checksumSha256: input.checksumSha256,
    uploadedAt,
  });
}
