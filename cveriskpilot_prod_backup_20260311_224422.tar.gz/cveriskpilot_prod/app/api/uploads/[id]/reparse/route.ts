import { NextResponse } from "next/server";

import { invalidateOrganizationWorkloadCache } from "@/lib/cache/workload-cache";
import { handleIngestionRouteError } from "@/lib/ingestion/http";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";
import { ReparseUploadRequestSchema } from "@/types/ingestion";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function POST(request: Request, context: RouteContext) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const { id } = await context.params;
    const { parseJobRunner, uploadService } = await getIngestionRuntime();
    const body = await request.json().catch(() => ({}));
    const input = ReparseUploadRequestSchema.parse(body);
    const result = await uploadService.reparseUpload(
      id,
      parseJobRunner,
      auth.organizationId,
      input,
    );

    invalidateOrganizationWorkloadCache(auth.organizationId);

    return NextResponse.json({
      ok: true,
      data: result,
    });
  } catch (error) {
    return handleIngestionRouteError(error, {
      code: "upload_reparse_failed",
      message: "Unable to reparse upload job.",
    });
  }
}
