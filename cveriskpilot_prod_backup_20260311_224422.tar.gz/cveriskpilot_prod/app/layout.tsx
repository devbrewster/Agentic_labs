import type { Metadata } from "next";

import { FooterAttribution } from "@/components/FooterAttribution";

import "./globals.css";

export const metadata: Metadata = {
  title: "CVERiskPilot — AI-Powered CVE Triage",
  description:
    "Turn raw vulnerability findings into prioritized risk decisions, remediation guidance, and ticket-ready action plans.",
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        <div className="flex min-h-screen flex-col">
          <div className="flex-1">{children}</div>
          <FooterAttribution />
        </div>
      </body>
    </html>
  );
}
