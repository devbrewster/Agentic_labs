import { describe, expect, it } from "vitest";

import { InMemoryKevCache } from "@/lib/kev/cache";
import { KevClient, type KevClientOptions } from "@/lib/kev/client";

function createOptions(overrides?: Partial<KevClientOptions>): KevClientOptions {
  return {
    feedUrl: "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json",
    requestTimeoutMs: 5000,
    cacheTtlMinutes: 60,
    ...overrides,
  };
}

describe("KevClient", () => {
  it("returns a KEV match from the live catalog response", async () => {
    const fetcher: typeof fetch = (async () =>
      new Response(
        JSON.stringify({
          catalogVersion: "2026.03.11",
          vulnerabilities: [
            {
              cveID: "CVE-2024-3400",
              vendorProject: "Palo Alto",
              product: "PAN-OS",
              vulnerabilityName: "Command Injection",
              shortDescription: "Remote command execution vulnerability.",
              dateAdded: "2026-03-10",
              dueDate: "2026-03-17",
              requiredAction: "Apply vendor fixes.",
              knownRansomwareCampaignUse: "Known",
            },
          ],
        }),
        { status: 200 },
      )) as typeof fetch;

    const client = new KevClient(createOptions(), new InMemoryKevCache(), fetcher);
    const result = await client.getCveById("CVE-2024-3400");

    expect(result.ok).toBe(true);
    if (!result.ok) {
      return;
    }

    expect(result.meta.source).toBe("kev_live");
    expect(result.data?.cveId).toBe("CVE-2024-3400");
    expect(result.data?.product).toBe("PAN-OS");
    expect(result.sourceVersion).toBe("2026.03.11");
  });

  it("uses stale cache fallback when the feed fetch fails", async () => {
    const cache = new InMemoryKevCache();
    const fetchedAt = new Date(Date.now() - 120_000).toISOString();
    const expiresAt = new Date(Date.now() - 60_000).toISOString();

    await cache.set({
      key: "cisa_kev:catalog",
      fetchedAt,
      expiresAt,
      rawPayload: {
        catalogVersion: "cached-v1",
        vulnerabilities: [],
      },
      catalog: {
        sourceVersion: "cached-v1",
        fetchedAt,
        entriesByCve: {
          "CVE-2024-21413": {
            cveId: "CVE-2024-21413",
            vendorProject: "Microsoft",
            product: "Outlook",
            vulnerabilityName: "Hyperlink Preview RCE",
            shortDescription: "Cached KEV record.",
            dateAdded: "2026-03-01",
            dueDate: "2026-03-15",
            requiredAction: "Patch immediately.",
            knownRansomwareCampaignUse: "Unknown",
            notes: null,
          },
        },
      },
    });

    const failingFetcher: typeof fetch = (async () => {
      throw new Error("KEV unavailable");
    }) as typeof fetch;

    const client = new KevClient(createOptions(), cache, failingFetcher);
    const result = await client.getCveById("CVE-2024-21413");

    expect(result.ok).toBe(true);
    if (!result.ok) {
      return;
    }

    expect(result.meta.source).toBe("kev_cache_stale");
    expect(result.meta.stale).toBe(true);
    expect(result.data?.cveId).toBe("CVE-2024-21413");
  });
});
