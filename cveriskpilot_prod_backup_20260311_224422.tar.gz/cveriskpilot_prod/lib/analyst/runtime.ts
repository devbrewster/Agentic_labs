import { getDb } from "@/lib/db";
import { D1AnalystDispositionRepository } from "@/lib/analyst/d1-repository";
import { PostgresAnalystDispositionRepository } from "@/lib/analyst/postgres-repository";
import {
  InMemoryAnalystDispositionRepository,
  type AnalystDispositionRepository,
} from "@/lib/analyst/repository";
import { getOrCreatePostgresQueryClient } from "@/lib/platform/postgres";
import { getPlatformProfile } from "@/lib/platform/runtime";

type AnalystRuntime = {
  analystDispositionRepository: AnalystDispositionRepository;
};

const fallbackAnalystDispositionRepository = new InMemoryAnalystDispositionRepository();

const fallbackRuntime: AnalystRuntime = {
  analystDispositionRepository: fallbackAnalystDispositionRepository,
};

function isFallbackRuntimeError(error: unknown) {
  if (!(error instanceof Error)) {
    return false;
  }

  return (
    /Cloudflare D1 binding/i.test(error.message) ||
    /getCloudflareContext/i.test(error.message) ||
    /Database schema is not initialized/i.test(error.message)
  );
}

export async function getAnalystRuntime(): Promise<AnalystRuntime> {
  const platform = getPlatformProfile();

  if (platform.databaseDriver === "postgres") {
    const postgresClient = await getOrCreatePostgresQueryClient();

    if (postgresClient) {
      return {
        analystDispositionRepository: new PostgresAnalystDispositionRepository(postgresClient),
      };
    }
  }

  try {
    const db = await getDb();
    return {
      analystDispositionRepository: new D1AnalystDispositionRepository(db),
    };
  } catch (error) {
    if (isFallbackRuntimeError(error)) {
      return fallbackRuntime;
    }

    throw error;
  }
}
