import { describe, expect, it } from "vitest";

import { D1ArtifactStorage } from "@/lib/ingestion/storage";

type StoredArtifactContent = {
  checksumSha256: string;
  bodyText: string;
  createdAt: string;
};

class FakeD1PreparedStatement {
  private values: unknown[] = [];

  constructor(
    private readonly sql: string,
    private readonly storage: Map<string, StoredArtifactContent>,
  ) {}

  bind(...values: unknown[]) {
    this.values = values;
    return this;
  }

  async run() {
    if (!this.sql.includes("INSERT OR REPLACE INTO raw_artifact_contents")) {
      throw new Error(`Unsupported SQL in fake D1 run: ${this.sql}`);
    }

    const [storageKey, checksumSha256, bodyText, createdAt] = this.values as [
      string,
      string,
      string,
      string,
    ];

    this.storage.set(storageKey, {
      checksumSha256,
      bodyText,
      createdAt,
    });

    return {
      success: true,
      meta: {
        changes: 1,
      },
    };
  }

  async first<T>() {
    if (!this.sql.includes("SELECT body_text")) {
      throw new Error(`Unsupported SQL in fake D1 first: ${this.sql}`);
    }

    const [storageKey] = this.values as [string];
    const content = this.storage.get(storageKey);

    if (!content) {
      return null;
    }

    return {
      body_text: content.bodyText,
    } as T;
  }
}

class FakeD1Database {
  private readonly storage = new Map<string, StoredArtifactContent>();

  prepare(sql: string) {
    return new FakeD1PreparedStatement(sql, this.storage);
  }
}

describe("D1ArtifactStorage", () => {
  it("saves and reads artifact content through D1-backed storage", async () => {
    const db = new FakeD1Database();
    const storage = new D1ArtifactStorage(db as never);

    const result = await storage.saveArtifact({
      originalFilename: "sample-findings.csv",
      mimeType: "text/csv",
      body: Buffer.from("cve,title\nCVE-2024-21413,Example finding\n"),
      uploadedAt: "2026-03-11T03:00:00.000Z",
    });

    expect(result.artifact.storageKey).toContain("sample-findings.csv");
    expect(result.artifact.fileType).toBe("csv");
    expect(result.checksumSha256).toHaveLength(64);

    const content = await storage.readArtifact(result.artifact.storageKey);

    expect(content.toString("utf8")).toBe(
      "cve,title\nCVE-2024-21413,Example finding\n",
    );
  });

  it("throws a clear error when artifact content is missing", async () => {
    const db = new FakeD1Database();
    const storage = new D1ArtifactStorage(db as never);

    await expect(
      storage.readArtifact("2026-03-11/missing/example.csv"),
    ).rejects.toThrow("Artifact content not found");
  });
});
