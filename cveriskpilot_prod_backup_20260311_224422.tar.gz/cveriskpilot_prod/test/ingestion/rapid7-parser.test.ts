import { describe, expect, it } from "vitest";

import { Rapid7Parser } from "@/lib/ingestion/parsers/rapid7-parser";
import { rapid7JsonFixture } from "@/test/fixtures/generic-csv";
import type { ParseContext, RawArtifact } from "@/types/ingestion";

function createArtifact(): RawArtifact {
  return {
    id: crypto.randomUUID(),
    storageKey: "test/rapid7-export.json",
    originalFilename: "rapid7-export.json",
    mimeType: "application/json",
    fileType: "json",
    sizeBytes: 2048,
    checksumSha256: "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
    uploadedAt: "2026-03-10T00:00:00.000Z",
  };
}

function createContext(uploadJobId = crypto.randomUUID()): ParseContext {
  return {
    uploadJob: {
      id: uploadJobId,
      tenantId: null,
      rawArtifactId: crypto.randomUUID(),
      selectedSourceType: "rapid7",
      detectedSourceType: "rapid7",
      status: "parsing",
      errorSummary: null,
      warningCount: 0,
      findingCount: 0,
      checksumSha256: "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
      createdAt: "2026-03-10T00:00:00.000Z",
      updatedAt: "2026-03-10T00:00:00.000Z",
      parsedAt: null,
    },
    rawArtifact: createArtifact(),
    selectedSourceType: "rapid7",
    detectedSourceType: "rapid7",
    checksumSha256: "dddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddddd",
    now: "2026-03-10T00:00:00.000Z",
  };
}

describe("Rapid7Parser", () => {
  it("detects and parses Rapid7 JSON exports into normalized findings", async () => {
    const parser = new Rapid7Parser();
    const canParse = await parser.canParse({
      filename: "insightvm-export.json",
      mimeType: "application/json",
      fileType: "json",
      leadingBytes: rapid7JsonFixture.slice(0, 128),
      sampleText: rapid7JsonFixture.slice(0, 2048),
    });

    expect(canParse).toBe(true);

    const result = await parser.parse({
      artifact: createArtifact(),
      content: rapid7JsonFixture,
      context: createContext(),
    });

    expect(result.parserErrors).toHaveLength(0);
    expect(result.findings).toHaveLength(2);
    const jenkinsFinding = result.findings.find((finding) =>
      finding.title.includes("Jenkins Arbitrary File Read via CLI"),
    );
    expect(jenkinsFinding?.hostname).toBe("jenkins-prod-01");
    expect(jenkinsFinding?.cveIds).toContain("CVE-2024-23897");
    expect(jenkinsFinding?.normalizedSeverity).toBe("critical");
    expect(result.metadata.hostCount).toBe(1);
    expect(result.metadata.findingCount).toBe(2);
  });

  it("preserves warnings when Rapid7 vulnerabilities omit CVEs", async () => {
    const parser = new Rapid7Parser();
    const result = await parser.parse({
      artifact: createArtifact(),
      content: rapid7JsonFixture,
      context: createContext(),
    });

    expect(
      result.parserWarnings.some((warning) => warning.code === "rapid7_missing_cve"),
    ).toBe(true);
  });
});
