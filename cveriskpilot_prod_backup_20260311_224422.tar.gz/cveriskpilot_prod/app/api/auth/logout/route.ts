import { NextResponse } from "next/server";

import { withAuthRoute } from "@/lib/auth";
import { clearSessionCookie, getAuthenticatedSession, revokeSession } from "@/lib/session";

export const POST = withAuthRoute(async function POST(request: Request) {
  const session = await getAuthenticatedSession(request);

  if (session) {
    await revokeSession(session.session.id);
  }

  const response = NextResponse.json(
    {
      ok: true,
      data: {
        message: "Logged out.",
      },
    },
    { status: 200 },
  );

  clearSessionCookie(response, request);
  return response;
});
