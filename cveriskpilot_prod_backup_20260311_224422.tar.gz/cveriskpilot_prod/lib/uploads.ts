export async function enqueueUploadIngestion() {
  // TODO(chunk-6+): replace this stub with real upload intake and parsing orchestration.
  return {
    ok: false,
    reason: "not_implemented",
  } as const;
}
