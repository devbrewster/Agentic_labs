import "server-only";

import { cookies, headers } from "next/headers";
import { redirect } from "next/navigation";

import { getAuthenticatedSession, getSessionCookieName } from "@/lib/session";

function getOriginFromHeaders(headerStore: Headers) {
  const forwardedProto = headerStore.get("x-forwarded-proto");
  const host = headerStore.get("x-forwarded-host") ?? headerStore.get("host");

  if (host) {
    return `${forwardedProto ?? "http"}://${host}`;
  }

  return process.env.APP_BASE_URL ?? "http://localhost:3000";
}

async function buildServerRequest(pathname: string) {
  const headerStore = await headers();
  const cookieStore = await cookies();
  const origin = getOriginFromHeaders(headerStore);
  const requestHeaders = new Headers();

  for (const [key, value] of headerStore.entries()) {
    requestHeaders.set(key, value);
  }

  const sessionCookieName = getSessionCookieName();
  const sessionCookieValue = cookieStore.get(sessionCookieName)?.value;

  if (sessionCookieValue) {
    requestHeaders.set("cookie", `${sessionCookieName}=${sessionCookieValue}`);
  }

  return new Request(new URL(pathname, origin), {
    headers: requestHeaders,
  });
}

export async function getServerAuthenticatedSession(pathname = "/dashboard") {
  const request = await buildServerRequest(pathname);
  return getAuthenticatedSession(request);
}

export async function requireServerAuthenticatedSession(pathname = "/dashboard") {
  const session = await getServerAuthenticatedSession(pathname);

  if (!session) {
    const next = encodeURIComponent(pathname);
    redirect(`/login?next=${next}`);
  }

  return session;
}
