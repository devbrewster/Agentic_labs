import { createHash } from "node:crypto";

import { ChecksumSha256Schema, type ChecksumSha256 } from "@/types/ingestion";

export function toBuffer(input: ArrayBuffer | Uint8Array | Buffer) {
  if (Buffer.isBuffer(input)) {
    return input;
  }

  if (input instanceof Uint8Array) {
    return Buffer.from(input);
  }

  return Buffer.from(input);
}

export function sha256Hex(input: ArrayBuffer | Uint8Array | Buffer): ChecksumSha256 {
  const checksum = createHash("sha256").update(toBuffer(input)).digest("hex");
  return ChecksumSha256Schema.parse(checksum);
}
