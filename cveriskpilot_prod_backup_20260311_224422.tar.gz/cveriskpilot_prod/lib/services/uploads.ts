import { mockUploadJobs, supportedUploadFormats } from "@/lib/mock/uploads";
import type { UploadJob } from "@/types/dashboard";

export function listUploadJobs(): UploadJob[] {
  return mockUploadJobs;
}

export function listSupportedUploadFormats() {
  return supportedUploadFormats;
}

// TODO: Replace this mock service with persisted upload intake and background parsing jobs.
