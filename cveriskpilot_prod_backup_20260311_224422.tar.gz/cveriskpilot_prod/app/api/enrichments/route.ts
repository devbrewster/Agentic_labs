import { NextResponse } from "next/server";

import { invalidateOrganizationWorkloadCache } from "@/lib/cache/workload-cache";
import { handleEnrichmentRouteError } from "@/lib/enrichment/http";
import { getEnrichmentRuntime } from "@/lib/enrichment/runtime";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";
import { CreateEnrichmentRunInputSchema } from "@/types/enrichment";
import { listIntegrationConnectors } from "@/lib/services/enrichments";

export async function GET(request: Request) {
  const auth = await requireCurrentOrganizationAccess(request);

  if (!auth.ok) {
    return auth.response;
  }

  return NextResponse.json({
    ok: true,
    data: {
      connectors: listIntegrationConnectors(),
    },
  });
}

export async function POST(request: Request) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const body = await request.json().catch(() => ({}));
    const input = CreateEnrichmentRunInputSchema.parse(body);

    if (!input.uploadJobId) {
      return NextResponse.json(
        {
          ok: false,
          error: {
            code: "invalid_request",
            message: "uploadJobId is required to trigger enrichment.",
          },
        },
        { status: 400 },
      );
    }

    const { uploadRepository } = await getIngestionRuntime();
    const uploadRecord = await uploadRepository.findByIdForTenant(
      input.uploadJobId,
      auth.organizationId,
    );

    if (!uploadRecord) {
      return NextResponse.json(
        {
          ok: false,
          error: {
            code: "upload_not_found",
            message: "Upload job was not found.",
          },
        },
        { status: 404 },
      );
    }

    const { enrichmentJobRunner } = await getEnrichmentRuntime();
    const result = await enrichmentJobRunner.run({
      uploadJobId: input.uploadJobId,
      providers: input.providers,
      triggeredBy: input.triggeredBy,
      force: input.force,
    });

    invalidateOrganizationWorkloadCache(auth.organizationId);

    return NextResponse.json({
      ok: true,
      data: result,
    });
  } catch (error) {
    return handleEnrichmentRouteError(error, {
      code: "enrichment_run_failed",
      message: "Unable to trigger enrichment run.",
    });
  }
}
