import { UploadsWorkspace } from "@/components/dashboard/UploadsWorkspace";

export default function UploadsPage() {
  return <UploadsWorkspace />;
}
