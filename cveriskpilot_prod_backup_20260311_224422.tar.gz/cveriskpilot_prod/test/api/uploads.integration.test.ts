import { describe, expect, it } from "vitest";

import { GET as getUploadErrors } from "@/app/api/uploads/[id]/errors/route";
import { GET as getUploadFindings } from "@/app/api/uploads/[id]/findings/route";
import { POST as reparseUpload } from "@/app/api/uploads/[id]/reparse/route";
import { GET as getUploadDetail } from "@/app/api/uploads/[id]/route";
import { POST as createUpload } from "@/app/api/uploads/route";
import { createAuthenticatedTestContext, withAuthHeaders } from "@/test/helpers/auth";
import { successfulCsvFixture } from "@/test/fixtures/generic-csv";

async function createUploadThroughRoute(authHeaders: HeadersInit) {
  const formData = new FormData();
  formData.set(
    "file",
    new File([successfulCsvFixture], `integration-${crypto.randomUUID()}.csv`, {
      type: "text/csv",
    }),
  );
  formData.set("selectedSourceType", "generic_csv");

  const response = await createUpload(
    new Request("http://localhost/api/uploads", {
      method: "POST",
      headers: withAuthHeaders(authHeaders),
      body: formData,
    }),
  );

  const json = await response.json();
  return json.data.uploadJob.id as string;
}

describe("upload ingestion routes", () => {
  it("creates an upload job through the route handler", async () => {
    const auth = await createAuthenticatedTestContext("upload-create");
    const uploadJobId = await createUploadThroughRoute(auth.headers);

    expect(uploadJobId).toBeTruthy();
  });

  it("reparses an upload and returns findings, errors, and detail payloads", async () => {
    const auth = await createAuthenticatedTestContext("upload-detail");
    const uploadJobId = await createUploadThroughRoute(auth.headers);

    const reparseResponse = await reparseUpload(
      new Request(`http://localhost/api/uploads/${uploadJobId}/reparse`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({ force: true }),
      }),
      {
        params: Promise.resolve({ id: uploadJobId }),
      },
    );

    const reparseJson = await reparseResponse.json();
    expect(reparseJson.data.uploadJob.status).toBe("enrichment_pending");
    expect(reparseJson.data.forced).toBe(true);
    expect(reparseJson.data.replacedExistingOutcome).toBe(false);

    const detailResponse = await getUploadDetail(
      new Request(`http://localhost/api/uploads/${uploadJobId}`, {
        headers: withAuthHeaders(auth.headers),
      }),
      {
        params: Promise.resolve({ id: uploadJobId }),
      },
    );
    const detailJson = await detailResponse.json();
    expect(detailJson.data.uploadJob.id).toBe(uploadJobId);
    expect(detailJson.data.findings).toHaveLength(2);

    const findingsResponse = await getUploadFindings(
      new Request(`http://localhost/api/uploads/${uploadJobId}/findings`, {
        headers: withAuthHeaders(auth.headers),
      }),
      {
        params: Promise.resolve({ id: uploadJobId }),
      },
    );
    const findingsJson = await findingsResponse.json();
    expect(findingsJson.data.findingCount).toBe(2);

    const errorsResponse = await getUploadErrors(
      new Request(`http://localhost/api/uploads/${uploadJobId}/errors`, {
        headers: withAuthHeaders(auth.headers),
      }),
      {
        params: Promise.resolve({ id: uploadJobId }),
      },
    );
    const errorsJson = await errorsResponse.json();
    expect(errorsJson.data.errorCount).toBe(0);
    expect(errorsJson.data.warningCount).toBe(0);
  });

  it("defaults reparse requests to non-forced behavior", async () => {
    const auth = await createAuthenticatedTestContext("upload-skip");
    const uploadJobId = await createUploadThroughRoute(auth.headers);

    await reparseUpload(
      new Request(`http://localhost/api/uploads/${uploadJobId}/reparse`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({ force: true }),
      }),
      {
        params: Promise.resolve({ id: uploadJobId }),
      },
    );

    const skippedResponse = await reparseUpload(
      new Request(`http://localhost/api/uploads/${uploadJobId}/reparse`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({}),
      }),
      {
        params: Promise.resolve({ id: uploadJobId }),
      },
    );

    const skippedJson = await skippedResponse.json();
    expect(skippedJson.data.skipped).toBe(true);
    expect(skippedJson.data.forced).toBe(false);
    expect(skippedJson.data.replacedExistingOutcome).toBe(false);
    expect(skippedJson.data.message).toBe(
      "Upload job already parsed. Use force to re-run parsing.",
    );
  });

  it("does not expose one organization's upload to another organization", async () => {
    const authA = await createAuthenticatedTestContext("upload-org-a");
    const authB = await createAuthenticatedTestContext("upload-org-b");
    const uploadJobId = await createUploadThroughRoute(authA.headers);

    const response = await getUploadDetail(
      new Request(`http://localhost/api/uploads/${uploadJobId}`, {
        headers: withAuthHeaders(authB.headers),
      }),
      {
        params: Promise.resolve({ id: uploadJobId }),
      },
    );
    const json = await response.json();

    expect(response.status).toBe(404);
    expect(json.ok).toBe(false);
    expect(json.error.code).toBe("upload_not_found");
  });
});
