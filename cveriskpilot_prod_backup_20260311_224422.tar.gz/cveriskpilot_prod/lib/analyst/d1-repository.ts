import type { D1Database } from "@cloudflare/workers-types";

import { D1AppDatabase } from "@/lib/platform/database";
import { SqlAnalystDispositionRepository } from "@/lib/analyst/sql-repository";

export class D1AnalystDispositionRepository extends SqlAnalystDispositionRepository {
  constructor(db: D1Database) {
    super(new D1AppDatabase(db));
  }
}
