import { describe, expect, it, vi } from "vitest";

import { buildAnalysisPromptContext } from "@/lib/analysis/assembler";
import { buildAnalysisPromptEnvelope, generateFindingAnalysis } from "@/lib/analysis/service";
import { mockPriorityFindings } from "@/lib/mock/findings";

describe("analysis prompt scaffolding", () => {
  it("builds deterministic prompt envelope from finding context", () => {
    const context = buildAnalysisPromptContext({
      finding: mockPriorityFindings[0],
      snapshots: [],
      disposition: null,
    });
    const prompt = buildAnalysisPromptEnvelope(context);

    expect(prompt.templateVersion).toBe("p3-7.v1");
    expect(prompt.systemPrompt).toContain("strict JSON only");
    expect(prompt.systemPrompt).toContain("confidence must be a single numeric value");
    expect(prompt.userPrompt).toContain(mockPriorityFindings[0].cveId);
    expect(prompt.userPrompt).toContain("under 1200 characters total");
  });

  it("returns deterministic stub output in stub mode", async () => {
    const context = buildAnalysisPromptContext({
      finding: mockPriorityFindings[1],
      snapshots: [],
      disposition: null,
    });
    const generated = await generateFindingAnalysis(context, "stub");

    expect(generated.provider).toBe("stub");
    expect(generated.traceStatus).toBe("completed");
    expect(generated.fallbackReason).toBeNull();
    expect(generated.output.businessImpact).toContain(mockPriorityFindings[1].cveId);
    expect(generated.output.confidence).toBeGreaterThan(0);
  });

  it("falls back safely in live mode when no Claude key is configured", async () => {
    const previous = process.env.ANTHROPIC_API_KEY;
    delete process.env.ANTHROPIC_API_KEY;

    const context = buildAnalysisPromptContext({
      finding: mockPriorityFindings[0],
      snapshots: [],
      disposition: null,
    });
    const generated = await generateFindingAnalysis(context, "live");

    expect(generated.provider).toBe("stub");
    expect(generated.traceStatus).toBe("fallback");
    expect(generated.fallbackReason).toBe("anthropic_api_key_missing");
    expect(generated.warnings[0]).toContain("ANTHROPIC_API_KEY");

    if (previous) {
      process.env.ANTHROPIC_API_KEY = previous;
    }
  });

  it("accepts Claude JSON wrapped in code fences", async () => {
    const previousKey = process.env.ANTHROPIC_API_KEY;
    const previousModel = process.env.ANTHROPIC_MODEL;
    const originalFetch = global.fetch;

    process.env.ANTHROPIC_API_KEY = "test-key";
    process.env.ANTHROPIC_MODEL = "claude-sonnet-4-6";

    global.fetch = vi.fn(async () =>
      new Response(
        JSON.stringify({
          content: [
            {
              type: "text",
              text: [
                "Here is the analysis payload:",
                "```json",
                JSON.stringify({
                  businessImpact: "Critical email infrastructure exposure.",
                  exploitabilityAssessment: "Attacker interaction is not required.",
                  falsePositiveAssessment: "No evidence of false positive conditions.",
                  recommendedAction: "Patch immediately and isolate the asset.",
                  confidence: 0.88,
                }),
                "```",
              ].join("\n"),
            },
          ],
        }),
        {
          status: 200,
          headers: {
            "content-type": "application/json",
          },
        },
      ),
    ) as typeof fetch;

    const context = buildAnalysisPromptContext({
      finding: mockPriorityFindings[0],
      snapshots: [],
      disposition: null,
    });
    const generated = await generateFindingAnalysis(context, "live");

    expect(generated.provider).toBe("claude");
    expect(generated.traceStatus).toBe("completed");
    expect(generated.fallbackReason).toBeNull();
    expect(generated.output.confidence).toBe(0.88);

    global.fetch = originalFetch;

    if (previousKey) {
      process.env.ANTHROPIC_API_KEY = previousKey;
    } else {
      delete process.env.ANTHROPIC_API_KEY;
    }

    if (previousModel) {
      process.env.ANTHROPIC_MODEL = previousModel;
    } else {
      delete process.env.ANTHROPIC_MODEL;
    }
  });

  it("accepts confidence returned as a percentage string", async () => {
    const previousKey = process.env.ANTHROPIC_API_KEY;
    const previousModel = process.env.ANTHROPIC_MODEL;
    const originalFetch = global.fetch;

    process.env.ANTHROPIC_API_KEY = "test-key";
    process.env.ANTHROPIC_MODEL = "claude-sonnet-4-6";

    global.fetch = vi.fn(async () =>
      new Response(
        JSON.stringify({
          content: [
            {
              type: "text",
              text: JSON.stringify({
                businessImpact: "Internet-facing mail infrastructure is exposed.",
                exploitabilityAssessment: "Exploitability is plausible with low attacker friction.",
                falsePositiveAssessment: "No suppression evidence is present.",
                recommendedAction: "Patch and validate exposure paths.",
                confidence: "88%",
              }),
            },
          ],
        }),
        {
          status: 200,
          headers: {
            "content-type": "application/json",
          },
        },
      ),
    ) as typeof fetch;

    const context = buildAnalysisPromptContext({
      finding: mockPriorityFindings[0],
      snapshots: [],
      disposition: null,
    });
    const generated = await generateFindingAnalysis(context, "live");

    expect(generated.provider).toBe("claude");
    expect(generated.traceStatus).toBe("completed");
    expect(generated.output.confidence).toBe(0.88);

    global.fetch = originalFetch;

    if (previousKey) {
      process.env.ANTHROPIC_API_KEY = previousKey;
    } else {
      delete process.env.ANTHROPIC_API_KEY;
    }

    if (previousModel) {
      process.env.ANTHROPIC_MODEL = previousModel;
    } else {
      delete process.env.ANTHROPIC_MODEL;
    }
  });

  it("accepts loose key-value Claude output when strict JSON is missing", async () => {
    const previousKey = process.env.ANTHROPIC_API_KEY;
    const previousModel = process.env.ANTHROPIC_MODEL;
    const originalFetch = global.fetch;

    process.env.ANTHROPIC_API_KEY = "test-key";
    process.env.ANTHROPIC_MODEL = "claude-sonnet-4-6";

    global.fetch = vi.fn(async () =>
      new Response(
        JSON.stringify({
          content: [
            {
              type: "text",
              text: [
                "business_impact: Critical exposure of production mail infrastructure.",
                "exploitability: Low attacker friction with plausible remote abuse.",
                "false_positive: No suppression evidence is currently available.",
                "recommended_action: Patch immediately and validate exposure paths.",
                "confidence: 0.81",
              ].join("\n"),
            },
          ],
        }),
        {
          status: 200,
          headers: {
            "content-type": "application/json",
          },
        },
      ),
    ) as typeof fetch;

    const context = buildAnalysisPromptContext({
      finding: mockPriorityFindings[0],
      snapshots: [],
      disposition: null,
    });
    const generated = await generateFindingAnalysis(context, "live");

    expect(generated.provider).toBe("claude");
    expect(generated.traceStatus).toBe("completed");
    expect(generated.output.businessImpact).toContain("Critical exposure");
    expect(generated.output.confidence).toBe(0.81);

    global.fetch = originalFetch;

    if (previousKey) {
      process.env.ANTHROPIC_API_KEY = previousKey;
    } else {
      delete process.env.ANTHROPIC_API_KEY;
    }

    if (previousModel) {
      process.env.ANTHROPIC_MODEL = previousModel;
    } else {
      delete process.env.ANTHROPIC_MODEL;
    }
  });

  it("recovers from truncated fenced JSON when confidence is returned as an object", async () => {
    const previousKey = process.env.ANTHROPIC_API_KEY;
    const previousModel = process.env.ANTHROPIC_MODEL;
    const originalFetch = global.fetch;

    process.env.ANTHROPIC_API_KEY = "test-key";
    process.env.ANTHROPIC_MODEL = "claude-sonnet-4-6";

    global.fetch = vi.fn(async () =>
      new Response(
        JSON.stringify({
          content: [
            {
              type: "text",
              text: [
                "```json",
                "{",
                '  "businessImpact": "Production mail infrastructure is exposed to remote code execution.",',
                '  "exploitabilityAssessment": "Public reporting suggests low attacker friction and plausible exploitation.",',
                '  "falsePositiveAssessment": "False positive likelihood is low but version validation is still required.",',
                '  "recommendedAction": "Patch Outlook immediately and validate the installed build version.",',
                '  "confidence": {',
                '    "overall": "medium",',
                '    "rationale": "Enrichment is still pending"',
              ].join("\n"),
            },
          ],
        }),
        {
          status: 200,
          headers: {
            "content-type": "application/json",
          },
        },
      ),
    ) as typeof fetch;

    const context = buildAnalysisPromptContext({
      finding: mockPriorityFindings[0],
      snapshots: [],
      disposition: null,
    });
    const generated = await generateFindingAnalysis(context, "live");

    expect(generated.provider).toBe("claude");
    expect(generated.traceStatus).toBe("completed");
    expect(generated.output.businessImpact).toContain("Production mail infrastructure");
    expect(generated.output.confidence).toBe(0.65);

    global.fetch = originalFetch;

    if (previousKey) {
      process.env.ANTHROPIC_API_KEY = previousKey;
    } else {
      delete process.env.ANTHROPIC_API_KEY;
    }

    if (previousModel) {
      process.env.ANTHROPIC_MODEL = previousModel;
    } else {
      delete process.env.ANTHROPIC_MODEL;
    }
  });
});
