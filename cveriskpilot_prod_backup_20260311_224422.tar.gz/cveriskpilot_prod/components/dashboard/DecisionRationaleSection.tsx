"use client";

import { AnalysisSectionCard } from "@/components/dashboard/AnalysisSectionCard";

type DecisionRationaleSectionProps = {
  value: string;
  onChange: (value: string) => void;
};

export function DecisionRationaleSection({
  value,
  onChange,
}: DecisionRationaleSectionProps) {
  return (
    <AnalysisSectionCard title="Decision Rationale" badge="Draft">
      <textarea
        value={value}
        onChange={(event) => onChange(event.target.value)}
        rows={5}
        className="w-full rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-3 text-[0.82rem] leading-7 text-[var(--text)] outline-none placeholder:text-[#5a7080] focus:border-[var(--accent)]"
        placeholder="Capture why this finding is a true risk, accepted risk, mitigated, false positive, or not applicable."
      />
      <p className="mt-3 text-[0.78rem] leading-7 text-[var(--text-dim)]">
        This rationale will later inform the AI feedback loop and provide audit-ready analyst
        context for future triage decisions.
      </p>
    </AnalysisSectionCard>
  );
}
