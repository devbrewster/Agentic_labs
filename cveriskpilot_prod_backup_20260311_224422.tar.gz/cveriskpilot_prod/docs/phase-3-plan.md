# Phase 3 Plan: Enrichment Pipeline and Decision Intelligence

Last updated: 2026-03-11
Status: completed

## Status Tracker

Overall Phase 3 status: completed

| Chunk | Title | Status |
|---|---|---|
| P3-1 | Enrichment domain model + schema | completed |
| P3-2 | Enrichment service abstraction | completed |
| P3-3 | Enrichment job runner + lifecycle | completed |
| P3-4 | API endpoints for enrichment | completed |
| P3-5 | Dashboard enrichment UI integration | completed |
| P3-6 | Analyst disposition persistence | completed |
| P3-7 | AI prompt strategy scaffolding (Claude-ready) | completed |

## Objective

Phase 3 adds enrichment and decision intelligence on top of stabilized upload parsing.

Starting baseline:

- upload intake/parsing is stable for `generic_csv`
- findings persist to D1 and render in dashboard
- diagnostics and failure paths are verified

Phase 3 outcome target:

- parsed findings are enriched with external context
- enrichment status and errors are observable
- findings display enriched signals in dashboard UI
- analyst decisions can be captured in a structured, auditable way

## Scope for Phase 3

In scope:

- enrichment data model and persistence
- enrichment job orchestration
- external provider client abstraction (NVD, CISA KEV first)
- API and UI surfaces for enrichment state
- analyst disposition capture scaffolding (persisted)

Out of scope for first pass:

- full production-grade provider breadth (Wiz/Snyk/etc.) in one shot
- advanced AI prompt orchestration across all providers at once
- ticketing system write-back

## Recommended Chunk Sequence

### Chunk P3-1 — Enrichment domain model + schema

Build:

- D1 tables for enrichment runs and per-finding enrichment snapshots
- typed models (`types/enrichment.ts`)
- migration SQL updates

Acceptance:

- schema applies locally and preview
- typed contracts cover status, provider, payload, timestamps, errors

### Chunk P3-2 — Enrichment service abstraction

Build:

- `lib/enrichment/` service layer
- provider client interfaces
- stub clients for NVD + CISA KEV with mockable response adapters

Acceptance:

- service can enrich a finding via provider abstraction
- errors are structured and non-fatal where possible

### Chunk P3-3 — Enrichment job runner + lifecycle

Build:

- background-style runner callable via API
- run states: `queued`, `running`, `completed`, `partial`, `failed`
- idempotent rerun behavior by finding checksum/version

Acceptance:

- reruns do not duplicate snapshots
- partial failure keeps successful provider results

### Chunk P3-4 — API endpoints for enrichment

Build:

- `POST /api/enrichments` (trigger)
- `GET /api/enrichments/:id`
- `GET /api/findings/:id/enrichment` (or equivalent batch endpoint)

Acceptance:

- APIs return stable typed payloads
- structured error responses are UI-ready

### Chunk P3-5 — Dashboard enrichment UI integration

Build:

- display enrichment status per finding
- show key enrichment signals in details panel:
  - KEV listed
  - CVSS / vectors
  - exploit availability (if provided)
  - source timestamps

Acceptance:

- enriched findings are visually distinguishable
- non-enriched findings gracefully show pending/none state

### Chunk P3-6 — Analyst disposition persistence

Build:

- persist analyst disposition/rationale/context factors
- add API for create/update/read disposition
- wire details panel controls to persisted state

Acceptance:

- analyst decision survives refresh/session
- decision history fields are queryable

### Chunk P3-7 — AI prompt strategy scaffolding (Claude-ready)

Build:

- prompt templates for business impact/remediation generation
- normalized input payload assembler from finding + enrichment + context
- result schema placeholders (no broad production rollout yet)

Acceptance:

- deterministic prompt payload contract
- clear TODO gates for production key/secrets/rate limits

## Cross-Cutting Requirements

- preserve strict structured JSON errors on all new APIs
- keep storage and orchestration layer separate
- maintain idempotency for rerun workflows
- add tests with fixtures for every new service chunk
- update docs after each chunk:
  - `docs/user-guide.md`
  - `docs/todo-backlog.md`
  - this file

## Blocker Matrix and Playbooks

### Blocker: provider API unavailable/rate limited

Symptoms:

- timeouts or 429/5xx from external sources

Mitigation:

- provider-level retries with capped backoff
- mark enrichment run `partial` instead of full failure
- persist provider error payload for diagnostics

### Blocker: schema drift between local and preview

Symptoms:

- `no such table` or missing column errors

Mitigation:

- rerun migrations:
  - `npm run db:migrate:local`
- if remote testing:
  - `npm run db:migrate:remote`

### Blocker: duplicated enrichment records

Symptoms:

- repeated provider snapshots for same finding/run version

Mitigation:

- enforce unique constraints on enrichment identity keys
- use `ON CONFLICT DO UPDATE` patterns (avoid `INSERT OR REPLACE`)

### Blocker: malformed provider payloads

Symptoms:

- parse/validation failures for provider responses

Mitigation:

- validate with Zod at provider adapter boundary
- store raw response excerpt + parser error in enrichment diagnostics

### Blocker: UI regression from large payloads

Symptoms:

- details panel performance drops

Mitigation:

- store summarized fields for render path
- lazy-load full raw payload in expandable diagnostics area

## Exit Criteria for Phase 3

Phase 3 is complete when:

1. Enrichment model/service/runner are implemented and tested
2. At least two providers (NVD + CISA KEV) are integrated through abstractions
3. Enrichment state is visible in UI for findings
4. Analyst disposition is persisted and retrievable
5. Docs and runbooks are updated with failure playbooks

## Immediate Next Action

Phase 3 is complete. Start Phase 4 planning with a focus on:

- durable persistence for generated narratives and prompt/audit history
- approval workflow for analyst-reviewed AI recommendations
- provider expansion (EPSS/vendor advisories) with deterministic conflict resolution
