"use client";

import { useEffect, useState } from "react";

import { PriorityFindingsWorkspace } from "@/components/dashboard/PriorityFindingsWorkspace";
import { SectionPlaceholder } from "@/components/dashboard/SectionPlaceholder";
import { SummaryCard } from "@/components/dashboard/SummaryCard";
import { createDashboardStatsFromFindings, type DashboardStat } from "@/lib/services/dashboard";

type DashboardOverviewResponse = {
  ok: boolean;
  data?: {
    source: "ingestion";
    stats: DashboardStat[];
    parsedUploadCount: number;
    totalFindingCount: number;
  };
  error?: {
    code: string;
    message: string;
  };
};

export function DashboardOverviewWorkspace() {
  const [stats, setStats] = useState<DashboardStat[]>(createDashboardStatsFromFindings([]));
  const [sourceLabel, setSourceLabel] = useState("Loading real dashboard metrics...");
  const [loadError, setLoadError] = useState<string | null>(null);

  useEffect(() => {
    let cancelled = false;

    async function loadOverview() {
      try {
        const response = await fetch("/api/dashboard/overview", {
          cache: "no-store",
        });
        const payload = (await response.json()) as DashboardOverviewResponse;

        if (!response.ok || !payload.ok || !payload.data) {
          throw new Error(
            payload.error?.message ?? "Unable to load overview metrics.",
          );
        }

        if (cancelled) {
          return;
        }

        setLoadError(null);
        setStats(payload.data.stats);
        setSourceLabel(
          payload.data.totalFindingCount > 0
            ? `Showing ${payload.data.totalFindingCount} ingested findings across ${payload.data.parsedUploadCount} parsed uploads.`
            : payload.data.parsedUploadCount > 0
              ? `Showing 0 normalized findings across ${payload.data.parsedUploadCount} parsed uploads.`
              : "No parsed uploads are available yet.",
        );
      } catch (error) {
        if (!cancelled) {
          setStats(createDashboardStatsFromFindings([]));
          setSourceLabel("Real overview metrics are unavailable.");
          setLoadError(
            error instanceof Error ? error.message : "Unable to load overview metrics.",
          );
        }
      }
    }

    void loadOverview();

    return () => {
      cancelled = true;
    };
  }, []);

  return (
    <div className="space-y-5">
      <section className="grid gap-3 md:grid-cols-2 xl:grid-cols-5">
        {stats.map((stat) => (
          <SummaryCard key={stat.label} stat={stat} />
        ))}
      </section>

      <div className="space-y-5">
        <SectionPlaceholder
          eyebrow="// Dashboard Shell"
          title="Security operations foundation initialized"
          description={`${sourceLabel}${loadError ? ` ${loadError}` : ""}`}
        />

        <PriorityFindingsWorkspace />

        <SectionPlaceholder
          eyebrow="// Future Modules"
          title="Details, uploads, and reports expand from here"
          description="Finding analysis, uploads, action plans, reports, integrations, and settings are available through their dedicated routes and continue to build on the live triage workflow."
          compact
        />
      </div>
    </div>
  );
}
