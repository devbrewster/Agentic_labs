type Props = React.InputHTMLAttributes<HTMLInputElement> & {
  label: string;
};

export default function AuthInput({ label, ...props }: Props) {
  return (
    <label className="block">
      <span className="mb-2 block text-sm text-slate-300">{label}</span>
      <input
        {...props}
        className="w-full rounded-lg border border-slate-700 bg-slate-950 px-3 py-2 text-white outline-none"
      />
    </label>
  );
}
