export const KEV_FEED_URL_DEFAULT =
  "https://www.cisa.gov/sites/default/files/feeds/known_exploited_vulnerabilities.json";
export const KEV_CATALOG_URL = "https://www.cisa.gov/known-exploited-vulnerabilities-catalog";
export const KEV_CACHE_TTL_MINUTES_DEFAULT = 1440;
export const KEV_REQUEST_TIMEOUT_MS_DEFAULT = 15000;
export const KEV_CVE_ID_PATTERN = /^CVE-\d{4}-\d{4,}$/i;
