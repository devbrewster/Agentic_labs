import { NextResponse } from "next/server";

import {
  apiError,
  getUserByEmail,
  readJsonBody,
  withAuthRoute,
} from "@/lib/auth";
import { verifyPassword } from "@/lib/passwords";
import { createSession, setSessionCookie } from "@/lib/session";
import { validateLoginPayload } from "@/lib/validators";

export const POST = withAuthRoute(async function POST(request: Request) {
  const payload = await readJsonBody(request);
  const validation = validateLoginPayload(payload);

  if (!validation.success) {
    return apiError("invalid_input", validation.message, 400, validation.fieldErrors);
  }

  const user = await getUserByEmail(validation.data.email);

  if (!user) {
    return apiError("invalid_credentials", "Invalid email or password.", 401);
  }

  const passwordMatches = await verifyPassword(
    validation.data.password,
    user.password_hash,
  );

  if (!passwordMatches) {
    return apiError("invalid_credentials", "Invalid email or password.", 401);
  }

  if (!user.email_verified) {
    return apiError("not_verified", "Verify your email before logging in.", 403);
  }

  const session = await createSession(user.id, request);
  const response = NextResponse.json(
    {
      ok: true,
      data: {
        active_organization_id: session.active_organization_id,
        session_expires_at: session.expires_at,
      },
    },
    {
      status: 200,
    },
  );

  setSessionCookie(response, session.id, session.expires_at, request);
  return response;
});
