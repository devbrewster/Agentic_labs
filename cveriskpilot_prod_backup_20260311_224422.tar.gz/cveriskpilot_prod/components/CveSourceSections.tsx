import { DataSourceBadge } from "@/components/DataSourceBadge";
import type { VulnerabilityRecord } from "@/lib/nvd/types";
import type { Finding } from "@/types/dashboard";

type CveSourceSectionsProps = {
  record: VulnerabilityRecord | null;
  enrichmentSummary?: Finding["enrichmentSummary"];
};

function ValueLine({ label, value }: { label: string; value: string | undefined }) {
  if (!value) {
    return null;
  }

  return (
    <div className="text-[0.72rem] leading-6 text-[#bcd3df]">
      <span className="font-mono uppercase tracking-[0.08em] text-[#6f8798]">{label}:</span>{" "}
      {value}
    </div>
  );
}

export function CveSourceSections({
  record,
  enrichmentSummary,
}: CveSourceSectionsProps) {
  const providerLabels = enrichmentSummary?.providers ?? [];
  const hasKevSignal =
    enrichmentSummary?.kevListed === true || Boolean(record?.enrichments.kev);
  const hasVendorSignal =
    providerLabels.some((provider) => provider !== "nvd" && provider !== "cisa_kev") ||
    Boolean(record?.enrichments.vendor);
  const hasEpssSignal = Boolean(record?.enrichments.epss);

  return (
    <section className="mt-4 space-y-3">
      <div className="rounded border border-[rgba(0,200,180,0.08)] bg-[#040810] p-3">
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#9ddad3]">
            Original NVD Data
          </div>
          <DataSourceBadge label="Source: NVD" tone="nvd" />
        </div>
        {record ? (
          <div className="space-y-1">
            <ValueLine label="CVE" value={record.cveId} />
            <ValueLine label="Published" value={record.nvd.published} />
            <ValueLine label="Last Modified" value={record.nvd.lastModified} />
            <ValueLine label="Description" value={record.nvd.rawDescription} />
          </div>
        ) : (
          <div className="text-[0.72rem] text-[#6f8798]">
            NVD data not loaded yet.
          </div>
        )}
      </div>

      <div className="rounded border border-[rgba(255,184,77,0.16)] bg-[rgba(255,184,77,0.05)] p-3">
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#ffd28f]">
            CVERiskPilot Analysis
          </div>
          <DataSourceBadge label="Source: CVERiskPilot AI Analysis" tone="analysis" />
        </div>
        {record ? (
          <div className="space-y-1 text-[0.72rem] leading-6 text-[#e6ccab]">
            <ValueLine label="Business Impact" value={record.analysis.businessImpact} />
            <ValueLine
              label="Exploitability"
              value={record.analysis.exploitabilityAssessment}
            />
            <ValueLine
              label="False Positive Assessment"
              value={record.analysis.falsePositiveAssessment}
            />
            <ValueLine label="Recommended Action" value={record.analysis.recommendedAction} />
          </div>
        ) : (
          <div className="text-[0.72rem] text-[#9f8871]">
            AI analysis pending enrichment pipeline.
          </div>
        )}
      </div>

      <div className="rounded border border-[rgba(120,140,255,0.18)] bg-[rgba(120,140,255,0.06)] p-3">
        <div className="mb-2 flex items-center justify-between gap-2">
          <div className="font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#bec8ff]">
            Other Enrichment Sources
          </div>
          <DataSourceBadge label="Source: KEV / Vendor / EPSS" tone="enrichment" />
        </div>
        {record ? (
          <div className="space-y-1 text-[0.72rem] leading-6 text-[#c6d0ff]">
            <ValueLine
              label="KEV"
              value={hasKevSignal ? "Available" : "Not available"}
            />
            <ValueLine
              label="EPSS"
              value={hasEpssSignal ? "Available" : "Not available"}
            />
            <ValueLine
              label="Vendor Advisories"
              value={hasVendorSignal ? "Available" : "Not available"}
            />
            <ValueLine
              label="Providers"
              value={providerLabels.length ? providerLabels.join(", ") : "Not attached"}
            />
          </div>
        ) : (
          <div className="text-[0.72rem] text-[#8f9ad4]">
            Additional sources have not been attached for this finding yet.
          </div>
        )}
      </div>
    </section>
  );
}
