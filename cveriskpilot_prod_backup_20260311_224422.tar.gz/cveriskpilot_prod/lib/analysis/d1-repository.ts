import type { D1Database } from "@cloudflare/workers-types";

import { D1AppDatabase } from "@/lib/platform/database";
import { SqlAnalysisTraceRepository } from "@/lib/analysis/sql-repository";

export class D1AnalysisTraceRepository extends SqlAnalysisTraceRepository {
  constructor(db: D1Database) {
    super(new D1AppDatabase(db));
  }
}
