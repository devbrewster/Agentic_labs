import {
  NormalizedFindingSchema,
  ParseResultSchema,
  type ArtifactFileType,
  type NormalizedFinding,
  type NormalizedSeverity,
  type ParseContext,
  type ParseMetadata,
  type ParseResult,
  type ParserDetectionHint,
  type ParserWarning,
  type RawArtifact,
  type ScannerParser,
} from "@/types/ingestion";

const QUALYS_SCANNER_NAME = "Qualys VMDR";

type QualysCsvRecord = Record<string, string>;

function extractXmlRootTag(sampleText: string | null) {
  if (!sampleText) {
    return null;
  }

  const match = sampleText.match(/<([A-Za-z_][\w:.-]*)[^>]*>/);
  return match?.[1] ?? null;
}

function extractCsvHeaders(sampleText: string | null) {
  if (!sampleText) {
    return [];
  }

  const [firstLine] = sampleText.split(/\r?\n/, 1);
  if (!firstLine) {
    return [];
  }

  return firstLine
    .split(",")
    .map((value) => value.trim().replace(/^"|"$/g, "").toLowerCase())
    .filter(Boolean);
}

function decodeXmlText(value: string | null) {
  if (!value) {
    return null;
  }

  return value
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&#39;/g, "'")
    .trim();
}

function extractTagValue(block: string, tagName: string) {
  const match = block.match(new RegExp(`<${tagName}>([\\s\\S]*?)</${tagName}>`, "i"));
  return decodeXmlText(match?.[1] ?? null);
}

function extractTagValues(block: string, tagName: string) {
  return Array.from(block.matchAll(new RegExp(`<${tagName}>([\\s\\S]*?)</${tagName}>`, "gi")))
    .map((match) => decodeXmlText(match[1] ?? null))
    .filter((value): value is string => Boolean(value));
}

function normalizeSeverity(value: string | undefined | null): NormalizedSeverity {
  const normalized = (value ?? "").trim().toLowerCase();

  if (["5", "critical"].includes(normalized)) {
    return "critical";
  }

  if (["4", "high"].includes(normalized)) {
    return "high";
  }

  if (["3", "medium", "moderate"].includes(normalized)) {
    return "medium";
  }

  if (["2", "low"].includes(normalized)) {
    return "low";
  }

  if (["1", "info", "informational"].includes(normalized)) {
    return "informational";
  }

  return "unknown";
}

function parseNumber(value: string | undefined | null) {
  if (!value) {
    return null;
  }

  const parsed = Number(value.trim());
  return Number.isFinite(parsed) ? parsed : null;
}

function parseCsvContent(content: string): { rows: string[][]; error: string | null } {
  const rows: string[][] = [];
  const currentRow: string[] = [];
  let currentValue = "";
  let inQuotes = false;

  for (let index = 0; index < content.length; index += 1) {
    const char = content[index];
    const nextChar = content[index + 1];

    if (char === '"') {
      if (inQuotes && nextChar === '"') {
        currentValue += '"';
        index += 1;
        continue;
      }

      inQuotes = !inQuotes;
      continue;
    }

    if (char === "," && !inQuotes) {
      currentRow.push(currentValue);
      currentValue = "";
      continue;
    }

    if ((char === "\n" || char === "\r") && !inQuotes) {
      if (char === "\r" && nextChar === "\n") {
        index += 1;
      }

      currentRow.push(currentValue);
      rows.push([...currentRow]);
      currentRow.length = 0;
      currentValue = "";
      continue;
    }

    currentValue += char;
  }

  if (inQuotes) {
    return {
      rows: [],
      error: "CSV parsing failed because a quoted field was not closed.",
    };
  }

  if (currentValue.length > 0 || currentRow.length > 0) {
    currentRow.push(currentValue);
    rows.push([...currentRow]);
  }

  return {
    rows,
    error: null,
  };
}

function trimRow(row: string[]) {
  return row.map((value) => value.trim());
}

function rowToRecord(headers: string[], row: string[]) {
  const record: QualysCsvRecord = {};
  headers.forEach((header, index) => {
    record[header] = row[index]?.trim() ?? "";
  });
  return record;
}

function buildMetadata(input: {
  artifact: RawArtifact;
  parsedAt: string;
  hostCount: number;
  findingCount: number;
}): ParseMetadata {
  return {
    scannerName: QUALYS_SCANNER_NAME,
    scannerVersion: null,
    sourceType: "qualys",
    fileType: input.artifact.fileType,
    hostCount: input.hostCount,
    findingCount: input.findingCount,
    parsedAt: input.parsedAt,
    checksumSha256: input.artifact.checksumSha256,
  };
}

function buildFinding(input: {
  uploadJobId: string;
  artifact: RawArtifact;
  parsedAt: string;
  recordId: string;
  recordIndex: number;
  locationHint: string | null;
  assetIdentifier: string | null;
  hostname: string | null;
  fqdn: string | null;
  ipAddress: string | null;
  qid: string | null;
  cveIds: string[];
  title: string;
  description: string | null;
  severity: string | null;
  cvssScore: number | null;
  remediation: string | null;
  evidence: string | null;
}): NormalizedFinding {
  return NormalizedFindingSchema.parse({
    id: crypto.randomUUID(),
    uploadJobId: input.uploadJobId,
    rawRecordRef: {
      recordId: input.recordId,
      recordIndex: input.recordIndex,
      locationHint: input.locationHint,
      sourceChecksumSha256: input.artifact.checksumSha256,
    },
    assetIdentifier: input.assetIdentifier,
    hostname: input.hostname,
    fqdn: input.fqdn,
    ipAddress: input.ipAddress,
    port: null,
    protocol: null,
    vulnerabilityId: input.qid,
    pluginId: input.qid,
    cveIds: input.cveIds,
    title: input.title,
    description: input.description,
    severity: input.severity,
    normalizedSeverity: normalizeSeverity(input.severity),
    cvssScore: input.cvssScore,
    cvssVector: null,
    remediation: input.remediation,
    evidence: input.evidence,
    status: "open",
    privilegeRequired: "unknown",
    detectedAt: input.parsedAt,
    firstObservedAt: input.parsedAt,
    lastObservedAt: input.parsedAt,
    sourceType: "qualys",
    sourceScanner: QUALYS_SCANNER_NAME,
    tags: ["qualys"],
    createdAt: input.parsedAt,
    updatedAt: input.parsedAt,
  });
}

function parseQualysCsv(input: {
  artifact: RawArtifact;
  content: string;
  context: ParseContext;
}) {
  const { rows, error } = parseCsvContent(input.content);
  const parserWarnings: ParserWarning[] = [];
  const findings: NormalizedFinding[] = [];

  if (error) {
    return {
      findings,
      parserWarnings,
      parserErrors: [
        {
          code: "qualys_csv_unclosed_quote",
          message: error,
          details: null,
          fatal: true,
        },
      ],
      hostCount: 0,
    };
  }

  if (rows.length < 2) {
    return {
      findings,
      parserWarnings,
      parserErrors: [
        {
          code: "qualys_csv_missing_rows",
          message: "Qualys CSV does not contain a header row and at least one data row.",
          details: { rowCount: rows.length },
          fatal: true,
        },
      ],
      hostCount: 0,
    };
  }

  const headers = trimRow(rows[0]);
  const records = rows.slice(1).map((row) => rowToRecord(headers, row));
  const uniqueHosts = new Set<string>();

  records.forEach((record, index) => {
    const hostIp = record["Host IP"] || record["IP"] || null;
    const dns = record["DNS"] || record["FQDN"] || null;
    const hostId = record["Asset ID"] || record["Asset ID/Name"] || null;
    const qid = record["QID"] || null;
    const title = record["Title"] || record["Vulnerability"] || `Qualys QID ${qid ?? "unknown"}`;
    const severity = record["Severity"] || null;
    const cveIds = (record["CVE ID"] || record["CVE"] || "")
      .split(/[\s,;|]+/)
      .map((value) => value.trim().toUpperCase())
      .filter((value, valueIndex, values) => /^CVE-\d{4}-\d{4,}$/i.test(value) && values.indexOf(value) === valueIndex);

    if (!hostIp && !dns && !hostId) {
      parserWarnings.push({
        code: "qualys_csv_missing_host",
        message: `Qualys CSV row ${index + 2} is missing host identity fields.`,
        field: "Host IP",
        row: index + 2,
        level: "warning",
      });
    }

    if (!qid) {
      parserWarnings.push({
        code: "qualys_csv_missing_qid",
        message: `Qualys CSV row ${index + 2} is missing a QID.`,
        field: "QID",
        row: index + 2,
        level: "warning",
      });
    }

    if (hostIp || dns || hostId) {
      uniqueHosts.add(hostIp ?? dns ?? hostId ?? `row-${index}`);
    }

    findings.push(
      buildFinding({
        uploadJobId: input.context.uploadJob.id,
        artifact: input.artifact,
        parsedAt: input.context.now,
        recordId: `${hostIp ?? dns ?? hostId ?? "unknown-host"}:${qid ?? "unknown-qid"}:${index}`,
        recordIndex: index,
        locationHint: hostIp ?? dns ?? hostId,
        assetIdentifier: hostId,
        hostname: dns,
        fqdn: dns,
        ipAddress: hostIp,
        qid,
        cveIds,
        title,
        description: record["Diagnosis"] || record["Description"] || null,
        severity,
        cvssScore: parseNumber(record["CVSS v3.1 Base"] || record["CVSS"] || null),
        remediation: record["Solution"] || null,
        evidence: record["Results"] || null,
      }),
    );
  });

  if (findings.some((finding) => finding.cveIds.length === 0)) {
    parserWarnings.push({
      code: "qualys_missing_cve",
      message: "One or more Qualys findings did not include CVE identifiers.",
      field: "CVE ID",
      row: null,
      level: "warning",
    });
  }

  return {
    findings,
    parserWarnings,
    parserErrors: findings.length
      ? []
      : [
          {
            code: "qualys_csv_no_findings_extracted",
            message: "Qualys CSV was detected but no findings could be normalized.",
            details: null,
            fatal: true,
          },
        ],
    hostCount: uniqueHosts.size,
  };
}

function parseQualysXml(input: {
  artifact: RawArtifact;
  content: string;
  context: ParseContext;
}) {
  const hostBlocks = Array.from(input.content.matchAll(/<HOST>([\s\S]*?)<\/HOST>/gi));
  const parserWarnings: ParserWarning[] = [];
  const findings: NormalizedFinding[] = [];
  const uniqueHosts = new Set<string>();

  if (hostBlocks.length === 0) {
    return {
      findings,
      parserWarnings,
      parserErrors: [
        {
          code: "qualys_xml_missing_hosts",
          message: "Qualys XML did not contain any HOST entries.",
          details: null,
          fatal: true,
        },
      ],
      hostCount: 0,
    };
  }

  hostBlocks.forEach((hostMatch, hostIndex) => {
    const hostBlock = hostMatch[1] ?? "";
    const hostIp = extractTagValue(hostBlock, "IP");
    const dns = extractTagValue(hostBlock, "DNS");
    const hostId = extractTagValue(hostBlock, "ID");
    const detectionBlocks = Array.from(hostBlock.matchAll(/<DETECTION>([\s\S]*?)<\/DETECTION>/gi));

    if (hostIp || dns || hostId) {
      uniqueHosts.add(hostIp ?? dns ?? hostId ?? `host-${hostIndex}`);
    }

    if (detectionBlocks.length === 0) {
      parserWarnings.push({
        code: "qualys_xml_host_without_detections",
        message: `Qualys host '${hostIp ?? dns ?? `index-${hostIndex}`}' did not contain any DETECTION entries.`,
        field: "DETECTION",
        row: hostIndex + 1,
        level: "warning",
      });
    }

    detectionBlocks.forEach((detectionMatch, detectionIndex) => {
      const detectionBlock = detectionMatch[1] ?? "";
      const qid = extractTagValue(detectionBlock, "QID");
      const title =
        extractTagValue(detectionBlock, "TITLE") ??
        `Qualys QID ${qid ?? "unknown"}`;
      const severity = extractTagValue(detectionBlock, "SEVERITY");
      const cveIds = extractTagValues(detectionBlock, "CVE_ID")
        .flatMap((value) => value.split(/[\s,;|]+/))
        .map((value) => value.trim().toUpperCase())
        .filter((value, index, values) => /^CVE-\d{4}-\d{4,}$/i.test(value) && values.indexOf(value) === index);

      findings.push(
        buildFinding({
          uploadJobId: input.context.uploadJob.id,
          artifact: input.artifact,
          parsedAt: input.context.now,
          recordId: `${hostIp ?? dns ?? hostId ?? "unknown-host"}:${qid ?? "unknown-qid"}:${detectionIndex}`,
          recordIndex: detectionIndex,
          locationHint: hostIp ?? dns ?? hostId,
          assetIdentifier: hostId,
          hostname: dns,
          fqdn: dns,
          ipAddress: hostIp,
          qid,
          cveIds,
          title,
          description:
            extractTagValue(detectionBlock, "DIAGNOSIS") ??
            extractTagValue(detectionBlock, "DESCRIPTION"),
          severity,
          cvssScore: parseNumber(extractTagValue(detectionBlock, "CVSS3_BASE")),
          remediation: extractTagValue(detectionBlock, "SOLUTION"),
          evidence: extractTagValue(detectionBlock, "RESULTS"),
        }),
      );
    });
  });

  if (findings.some((finding) => finding.cveIds.length === 0)) {
    parserWarnings.push({
      code: "qualys_missing_cve",
      message: "One or more Qualys findings did not include CVE identifiers.",
      field: "CVE_ID",
      row: null,
      level: "warning",
    });
  }

  return {
    findings,
    parserWarnings,
    parserErrors: findings.length
      ? []
      : [
          {
            code: "qualys_xml_no_findings_extracted",
            message: "Qualys XML was detected but no findings could be normalized.",
            details: null,
            fatal: true,
          },
        ],
    hostCount: uniqueHosts.size,
  };
}

export class QualysParser implements ScannerParser {
  readonly sourceType = "qualys" as const;
  readonly displayName = QUALYS_SCANNER_NAME;
  readonly supportedFileTypes: readonly ArtifactFileType[] = ["xml", "csv"];

  async canParse(input: ParserDetectionHint) {
    if (!this.supportedFileTypes.includes(input.fileType)) {
      return false;
    }

    const rootTag = extractXmlRootTag(input.sampleText)?.toLowerCase();
    const headers = extractCsvHeaders(input.sampleText);

    const xmlSignature =
      rootTag === "host_list_vm_detection_output" || rootTag === "asset_data_report";
    const csvSignature =
      headers.includes("qid") || (headers.includes("severity") && headers.includes("host ip"));

    return /qualys/i.test(input.filename) || xmlSignature || csvSignature;
  }

  async parse(input: {
    artifact: RawArtifact;
    content: string;
    context: ParseContext;
  }): Promise<ParseResult> {
    const parsedAt = input.context.now;
    const result =
      input.artifact.fileType === "csv"
        ? parseQualysCsv(input)
        : parseQualysXml(input);

    return ParseResultSchema.parse({
      findings: result.findings,
      parserWarnings: result.parserWarnings,
      parserErrors: result.parserErrors,
      metadata: buildMetadata({
        artifact: input.artifact,
        parsedAt,
        hostCount: result.hostCount,
        findingCount: result.findings.length,
      }),
    });
  }
}
