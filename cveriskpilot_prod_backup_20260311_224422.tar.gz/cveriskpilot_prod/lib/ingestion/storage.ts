import { GetObjectCommand, PutObjectCommand, S3Client } from "@aws-sdk/client-s3";
import type { D1Database } from "@cloudflare/workers-types";
import { mkdir, writeFile } from "node:fs/promises";
import { readFile } from "node:fs/promises";
import path from "node:path";

import { sha256Hex, toBuffer } from "@/lib/ingestion/checksum";
import { buildRawArtifactRecord, sanitizeFilename } from "@/lib/ingestion/files";
import type { ChecksumSha256, RawArtifact } from "@/types/ingestion";

export type SaveArtifactInput = {
  originalFilename: string;
  mimeType?: string | null;
  body: ArrayBuffer | Uint8Array | Buffer;
  uploadedAt?: string;
};

export type SaveArtifactOutput = {
  artifact: RawArtifact;
  checksumSha256: ChecksumSha256;
};

export type StorageProvider = {
  saveArtifact(input: SaveArtifactInput): Promise<SaveArtifactOutput>;
  readArtifact(storageKey: string): Promise<Buffer>;
};

export type S3StorageClient = {
  send(command: GetObjectCommand | PutObjectCommand): Promise<unknown>;
};

function buildStorageKey(input: {
  originalFilename: string;
  checksumSha256: ChecksumSha256;
  uploadedAt: string;
}) {
  const uploadedDate = input.uploadedAt.slice(0, 10);
  const filename = sanitizeFilename(input.originalFilename);
  return path.posix.join(uploadedDate, input.checksumSha256, crypto.randomUUID(), filename);
}

type LocalFileStorageOptions = {
  rootDirectory?: string;
};

export class LocalFileStorage implements StorageProvider {
  private readonly rootDirectory: string;

  constructor(options: LocalFileStorageOptions = {}) {
    this.rootDirectory =
      options.rootDirectory ?? path.join(process.cwd(), ".data", "uploads");
  }

  async saveArtifact(input: SaveArtifactInput): Promise<SaveArtifactOutput> {
    const uploadedAt = input.uploadedAt ?? new Date().toISOString();
    const bodyBuffer = toBuffer(input.body);
    const checksumSha256 = sha256Hex(bodyBuffer);
    const storageKey = buildStorageKey({
      originalFilename: input.originalFilename,
      checksumSha256,
      uploadedAt,
    });
    const absolutePath = path.join(this.rootDirectory, storageKey);

    await mkdir(path.dirname(absolutePath), { recursive: true });
    await writeFile(absolutePath, bodyBuffer);

    return {
      checksumSha256,
      artifact: buildRawArtifactRecord({
        checksumSha256,
        originalFilename: input.originalFilename,
        mimeType: input.mimeType,
        sizeBytes: bodyBuffer.byteLength,
        storageKey,
        uploadedAt,
      }),
    };
  }

  async readArtifact(storageKey: string) {
    return readFile(path.join(this.rootDirectory, storageKey));
  }
}

type D1ArtifactContentRow = {
  body_text: string;
};

export class D1ArtifactStorage implements StorageProvider {
  constructor(private readonly db: D1Database) {}

  async saveArtifact(input: SaveArtifactInput): Promise<SaveArtifactOutput> {
    const uploadedAt = input.uploadedAt ?? new Date().toISOString();
    const bodyBuffer = toBuffer(input.body);
    const checksumSha256 = sha256Hex(bodyBuffer);
    const storageKey = buildStorageKey({
      originalFilename: input.originalFilename,
      checksumSha256,
      uploadedAt,
    });

    await this.db
      .prepare(
        `INSERT OR REPLACE INTO raw_artifact_contents (
           storage_key,
           checksum_sha256,
           body_text,
           created_at
         ) VALUES (?, ?, ?, ?)`,
      )
      .bind(
        storageKey,
        checksumSha256,
        bodyBuffer.toString("utf8"),
        uploadedAt,
      )
      .run();

    return {
      checksumSha256,
      artifact: buildRawArtifactRecord({
        checksumSha256,
        originalFilename: input.originalFilename,
        mimeType: input.mimeType,
        sizeBytes: bodyBuffer.byteLength,
        storageKey,
        uploadedAt,
      }),
    };
  }

  async readArtifact(storageKey: string) {
    const row = await this.db
      .prepare(
        `SELECT body_text
         FROM raw_artifact_contents
         WHERE storage_key = ?
         LIMIT 1`,
      )
      .bind(storageKey)
      .first<D1ArtifactContentRow>();

    if (!row) {
      throw new Error(`Artifact content not found for storage key '${storageKey}'.`);
    }

    return Buffer.from(row.body_text, "utf8");
  }
}

type S3ArtifactStorageOptions = {
  bucketName: string;
  client?: S3StorageClient;
};

type S3GetObjectBody = {
  transformToByteArray?: () => Promise<Uint8Array>;
};

function isS3BodyWithByteArray(body: unknown): body is S3GetObjectBody {
  return (
    typeof body === "object" &&
    body !== null &&
    "transformToByteArray" in body &&
    typeof (body as S3GetObjectBody).transformToByteArray === "function"
  );
}

export class S3ArtifactStorage implements StorageProvider {
  private readonly client: S3StorageClient;
  private readonly bucketName: string;

  constructor(options: S3ArtifactStorageOptions) {
    this.bucketName = options.bucketName;
    this.client = options.client ?? new S3Client({});
  }

  async saveArtifact(input: SaveArtifactInput): Promise<SaveArtifactOutput> {
    const uploadedAt = input.uploadedAt ?? new Date().toISOString();
    const bodyBuffer = toBuffer(input.body);
    const checksumSha256 = sha256Hex(bodyBuffer);
    const storageKey = buildStorageKey({
      originalFilename: input.originalFilename,
      checksumSha256,
      uploadedAt,
    });

    await this.client.send(
      new PutObjectCommand({
        Bucket: this.bucketName,
        Key: storageKey,
        Body: bodyBuffer,
        ContentType: input.mimeType ?? "application/octet-stream",
      }),
    );

    return {
      checksumSha256,
      artifact: buildRawArtifactRecord({
        checksumSha256,
        originalFilename: input.originalFilename,
        mimeType: input.mimeType,
        sizeBytes: bodyBuffer.byteLength,
        storageKey,
        uploadedAt,
      }),
    };
  }

  async readArtifact(storageKey: string) {
    const response = (await this.client.send(
      new GetObjectCommand({
        Bucket: this.bucketName,
        Key: storageKey,
      }),
    )) as {
      Body?: unknown;
    };

    if (!response.Body) {
      throw new Error(`Artifact content not found for storage key '${storageKey}'.`);
    }

    if (isS3BodyWithByteArray(response.Body)) {
      const transformToByteArray = response.Body.transformToByteArray!;
      const bytes = await transformToByteArray();
      return Buffer.from(bytes);
    }

    if (response.Body instanceof Uint8Array) {
      return Buffer.from(response.Body);
    }

    if (Buffer.isBuffer(response.Body)) {
      return response.Body;
    }

    throw new Error(`Unsupported S3 body type for storage key '${storageKey}'.`);
  }
}
