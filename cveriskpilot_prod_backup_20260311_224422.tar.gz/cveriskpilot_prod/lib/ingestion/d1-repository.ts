import type { D1Database } from "@cloudflare/workers-types";

import { D1AppDatabase } from "@/lib/platform/database";
import {
  SqlNormalizedFindingRepository,
  SqlParseOutcomeRepository,
  SqlRawArtifactRepository,
  SqlUploadJobRepository,
  SqlUploadRepository,
} from "@/lib/ingestion/sql-repository";

export class D1RawArtifactRepository extends SqlRawArtifactRepository {
  constructor(db: D1Database) {
    super(new D1AppDatabase(db));
  }
}

export class D1UploadJobRepository extends SqlUploadJobRepository {
  constructor(db: D1Database) {
    super(new D1AppDatabase(db));
  }
}

export class D1ParseOutcomeRepository extends SqlParseOutcomeRepository {
  constructor(db: D1Database) {
    super(new D1AppDatabase(db));
  }
}

export class D1NormalizedFindingRepository extends SqlNormalizedFindingRepository {
  constructor(db: D1Database) {
    super(new D1AppDatabase(db));
  }
}

export class D1UploadRepository extends SqlUploadRepository {
  constructor(db: D1Database) {
    super(new D1AppDatabase(db));
  }
}
