"use client";

import { useEffect, useMemo, useState } from "react";

import { FindingDetailsPanel } from "@/components/dashboard/FindingDetailsPanel";
import { StatusPill } from "@/components/dashboard/StatusPill";
import { listFindings } from "@/lib/services/findings";
import type { Finding, FindingStatus, Severity } from "@/types/dashboard";

const severityPillTone = {
  critical: "danger",
  high: "warning",
  medium: "accent",
  low: "default",
} as const;

const statusPillTone = {
  new: "danger",
  triaged: "accent",
  in_progress: "warning",
  accepted_risk: "default",
  mitigated: "accent",
  false_positive: "default",
  not_applicable: "default",
} as const;

const enrichmentStatusTone = {
  pending: "default",
  enriched: "accent",
  partial: "warning",
  failed: "danger",
  not_found: "default",
} as const;

const severityOptions: Array<Severity | "all"> = ["all", "critical", "high", "medium", "low"];
const statusOptions: Array<FindingStatus | "all"> = [
  "all",
  "new",
  "triaged",
  "in_progress",
  "accepted_risk",
  "mitigated",
  "false_positive",
  "not_applicable",
];
const environmentOptions: Array<Finding["environment"] | "all"> = [
  "all",
  "production",
  "staging",
  "development",
  "corporate",
];
const sortOptions = ["highest_risk", "newest_discovered", "severity"] as const;
type SortOption = (typeof sortOptions)[number];

function formatStatus(status: string) {
  return status.replaceAll("_", " ");
}

function formatEnrichmentStatus(status: NonNullable<Finding["enrichmentSummary"]>["status"]) {
  return status.replaceAll("_", " ");
}

function severityRank(severity: Severity) {
  switch (severity) {
    case "critical":
      return 4;
    case "high":
      return 3;
    case "medium":
      return 2;
    case "low":
      return 1;
  }
}

type FindingsManagementTableProps = {
  dataSourceLabel?: string;
  findings?: Finding[];
};

export function FindingsManagementTable({
  dataSourceLabel = "Search, filter, and prioritize findings",
  findings,
}: FindingsManagementTableProps) {
  const allFindings = findings ?? listFindings();
  const [selectedSeverity, setSelectedSeverity] = useState<Severity | "all">("all");
  const [selectedStatus, setSelectedStatus] = useState<FindingStatus | "all">("all");
  const [selectedEnvironment, setSelectedEnvironment] =
    useState<Finding["environment"] | "all">("all");
  const [exploitOnly, setExploitOnly] = useState(false);
  const [kevOnly, setKevOnly] = useState(false);
  const [query, setQuery] = useState("");
  const [sortBy, setSortBy] = useState<SortOption>("highest_risk");
  const [selectedId, setSelectedId] = useState<string>(allFindings[0]?.id ?? "");

  useEffect(() => {
    setSelectedId((currentSelectedId) => {
      if (allFindings.some((finding) => finding.id === currentSelectedId)) {
        return currentSelectedId;
      }

      return allFindings[0]?.id ?? "";
    });
  }, [allFindings]);

  const filteredFindings = useMemo(() => {
    const normalized = query.trim().toLowerCase();

    const result = allFindings.filter((finding) => {
      if (selectedSeverity !== "all" && finding.severity !== selectedSeverity) {
        return false;
      }

      if (selectedStatus !== "all" && finding.status !== selectedStatus) {
        return false;
      }

      if (selectedEnvironment !== "all" && finding.environment !== selectedEnvironment) {
        return false;
      }

      if (exploitOnly && !finding.exploitAvailable) {
        return false;
      }

      if (kevOnly && !finding.kevListed) {
        return false;
      }

      if (!normalized) {
        return true;
      }

      const searchable = [
        finding.cveId,
        finding.title,
        finding.assetName,
        finding.product,
      ]
        .join(" ")
        .toLowerCase();

      return searchable.includes(normalized);
    });

    return [...result].sort((left, right) => {
      switch (sortBy) {
        case "highest_risk":
          return right.riskScore - left.riskScore;
        case "newest_discovered":
          return (
            new Date(right.discoveredAt).getTime() - new Date(left.discoveredAt).getTime()
          );
        case "severity":
          return severityRank(right.severity) - severityRank(left.severity);
      }
    });
  }, [
    allFindings,
    selectedSeverity,
    selectedStatus,
    selectedEnvironment,
    exploitOnly,
    kevOnly,
    query,
    sortBy,
  ]);

  const selectedFinding =
    filteredFindings.find((finding) => finding.id === selectedId) ??
    filteredFindings[0] ??
    null;

  return (
    <section className="space-y-5">
      <div className="grid gap-3 md:grid-cols-4">
        <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] px-4 py-4 shadow-[0_12px_26px_rgba(0,0,0,0.18)]">
          <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#5a7080]">
            Filtered Findings
          </div>
          <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-white">
            {filteredFindings.length}
          </div>
        </div>
        <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] px-4 py-4 shadow-[0_12px_26px_rgba(0,0,0,0.18)]">
          <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#5a7080]">
            Exploited
          </div>
          <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-[var(--danger)]">
            {filteredFindings.filter((finding) => finding.exploitAvailable).length}
          </div>
        </div>
        <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] px-4 py-4 shadow-[0_12px_26px_rgba(0,0,0,0.18)]">
          <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#5a7080]">
            KEV Listed
          </div>
          <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-[var(--warning)]">
            {filteredFindings.filter((finding) => finding.kevListed).length}
          </div>
        </div>
        <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] px-4 py-4 shadow-[0_12px_26px_rgba(0,0,0,0.18)]">
          <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#5a7080]">
            Selected Sort
          </div>
          <div className="mt-2 font-mono text-[0.76rem] uppercase tracking-[0.1em] text-[var(--accent)]">
            {sortBy.replaceAll("_", " ")}
          </div>
        </div>
      </div>

      <div className="grid gap-5 2xl:grid-cols-[minmax(0,1.8fr)_360px]">
        <div className="flex min-h-[520px] flex-col overflow-hidden rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] shadow-[0_18px_48px_rgba(0,0,0,0.22)]">
          <div className="flex items-center gap-3 border-b border-[rgba(0,200,180,0.06)] px-4 py-3">
            <div className="font-mono text-[0.75rem] uppercase tracking-[0.12em] text-[var(--accent)]">
              // Findings Management
            </div>
            <div className="ml-auto font-mono text-[0.64rem] text-[#5a7080]">
              {dataSourceLabel}
            </div>
          </div>

          <div className="grid gap-3 border-b border-[rgba(0,200,180,0.06)] px-4 py-3 lg:grid-cols-3 xl:grid-cols-6">
            <select
              value={selectedSeverity}
              onChange={(event) => setSelectedSeverity(event.target.value as Severity | "all")}
              className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[var(--text)] outline-none focus:border-[var(--accent)]"
            >
              {severityOptions.map((option) => (
                <option key={option} value={option}>
                  Severity: {option}
                </option>
              ))}
            </select>

            <select
              value={selectedStatus}
              onChange={(event) =>
                setSelectedStatus(event.target.value as FindingStatus | "all")
              }
              className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[var(--text)] outline-none focus:border-[var(--accent)]"
            >
              {statusOptions.map((option) => (
                <option key={option} value={option}>
                  Status: {formatStatus(option)}
                </option>
              ))}
            </select>

            <select
              value={selectedEnvironment}
              onChange={(event) =>
                setSelectedEnvironment(event.target.value as Finding["environment"] | "all")
              }
              className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[var(--text)] outline-none focus:border-[var(--accent)]"
            >
              {environmentOptions.map((option) => (
                <option key={option} value={option}>
                  Env: {option}
                </option>
              ))}
            </select>

            <select
              value={sortBy}
              onChange={(event) => setSortBy(event.target.value as SortOption)}
              className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[var(--text)] outline-none focus:border-[var(--accent)]"
            >
              {sortOptions.map((option) => (
                <option key={option} value={option}>
                  Sort: {option.replaceAll("_", " ")}
                </option>
              ))}
            </select>

            <label className="flex items-center gap-2 rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[var(--text)]">
              <input
                type="checkbox"
                checked={exploitOnly}
                onChange={(event) => setExploitOnly(event.target.checked)}
                className="accent-[var(--accent)]"
              />
              Exploit Available
            </label>

            <label className="flex items-center gap-2 rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[var(--text)]">
              <input
                type="checkbox"
                checked={kevOnly}
                onChange={(event) => setKevOnly(event.target.checked)}
                className="accent-[var(--accent)]"
              />
              KEV Listed
            </label>
          </div>

          <div className="border-b border-[rgba(0,200,180,0.06)] px-4 py-3">
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search CVE, asset, title, or product..."
              className="w-full rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2 font-mono text-[0.72rem] text-[var(--text)] outline-none placeholder:text-[#3a5060] focus:border-[var(--accent)]"
            />
          </div>

          <div className="min-h-0 overflow-auto">
            <table className="min-w-full divide-y divide-[rgba(0,200,180,0.06)]">
              <thead className="bg-[rgba(255,255,255,0.01)]">
                <tr>
                  {[
                    "CVE",
                    "Title",
                    "Severity",
                    "Exploit",
                    "KEV",
                    "Enrichment",
                    "Asset",
                    "Environment",
                    "Status",
                    "Adjustment",
                    "Risk",
                    "Discovered",
                  ].map((header) => (
                    <th
                      key={header}
                      className="px-4 py-3 text-left font-mono text-[0.58rem] uppercase tracking-[0.16em] text-[#5a7080]"
                    >
                      {header}
                    </th>
                  ))}
                </tr>
              </thead>
              <tbody className="divide-y divide-[rgba(0,200,180,0.06)]">
                {filteredFindings.length === 0 ? (
                  <tr>
                    <td
                      colSpan={12}
                      className="px-4 py-10 text-center font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#5a7080]"
                    >
                      No findings matched the current filters
                    </td>
                  </tr>
                ) : null}
                {filteredFindings.map((finding) => {
                  const isSelected = selectedFinding?.id === finding.id;

                  return (
                    <tr
                      key={finding.id}
                      onClick={() => setSelectedId(finding.id)}
                      className={`cursor-pointer transition ${
                        isSelected
                          ? "bg-[rgba(0,200,180,0.08)]"
                          : "hover:bg-[rgba(0,200,180,0.03)]"
                      }`}
                    >
                      <td className="px-4 py-3 font-mono text-[0.7rem] text-[var(--accent)]">
                        {finding.cveId}
                      </td>
                      <td className="px-4 py-3 text-[0.84rem] text-[var(--text)]">
                        {finding.title}
                      </td>
                      <td className="px-4 py-3">
                        <StatusPill tone={severityPillTone[finding.severity]}>
                          {finding.severity}
                        </StatusPill>
                      </td>
                      <td className="px-4 py-3">
                        {finding.exploitAvailable ? (
                          <StatusPill tone="danger">Yes</StatusPill>
                        ) : (
                          <StatusPill>No</StatusPill>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        {finding.kevListed ? (
                          <StatusPill tone="warning">Listed</StatusPill>
                        ) : (
                          <StatusPill>No</StatusPill>
                        )}
                      </td>
                      <td className="px-4 py-3">
                        <StatusPill
                          tone={
                            enrichmentStatusTone[
                              finding.enrichmentSummary?.status ?? "pending"
                            ]
                          }
                        >
                          {formatEnrichmentStatus(
                            finding.enrichmentSummary?.status ?? "pending",
                          )}
                        </StatusPill>
                      </td>
                      <td className="px-4 py-3 font-mono text-[0.68rem] text-[#5a7080]">
                        {finding.assetName}
                      </td>
                      <td className="px-4 py-3 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[#5a7080]">
                        {finding.environment}
                      </td>
                      <td className="px-4 py-3">
                        <StatusPill tone={statusPillTone[finding.status]}>
                          {formatStatus(finding.status)}
                        </StatusPill>
                      </td>
                      <td className="px-4 py-3 font-mono text-[0.68rem] text-[var(--text-dim)]">
                        {finding.prioritization?.totalAdjustment
                          ? `${finding.prioritization.totalAdjustment > 0 ? "+" : ""}${finding.prioritization.totalAdjustment}`
                          : "0"}
                      </td>
                      <td className="px-4 py-3 font-mono text-[0.78rem] text-[var(--text)]">
                        {finding.riskScore}
                      </td>
                      <td className="px-4 py-3 font-mono text-[0.68rem] text-[#5a7080]">
                        {(
                          finding.enrichmentSummary?.lastObservedAt ?? finding.discoveredAt
                        ).slice(0, 10)}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <FindingDetailsPanel finding={selectedFinding} />
      </div>
    </section>
  );
}
