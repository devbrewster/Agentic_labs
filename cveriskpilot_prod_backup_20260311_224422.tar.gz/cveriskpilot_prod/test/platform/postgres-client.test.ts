import { afterEach, describe, expect, it, vi } from "vitest";

import {
  clearPostgresModuleLoader,
  clearPostgresQueryClient,
  closePostgresQueryClient,
  configurePostgresModuleLoader,
  getOrCreatePostgresQueryClient,
} from "@/lib/platform/postgres";

describe("platform postgres bootstrap", () => {
  afterEach(async () => {
    await closePostgresQueryClient();
    clearPostgresModuleLoader();
    delete process.env.DATABASE_URL;
    delete process.env.POSTGRES_SSL_MODE;
    delete process.env.POSTGRES_POOL_MAX;
    delete process.env.POSTGRES_IDLE_TIMEOUT_MS;
    delete process.env.POSTGRES_CONNECTION_TIMEOUT_MS;
    clearPostgresQueryClient();
  });

  it("returns null when DATABASE_URL is not configured", async () => {
    await expect(getOrCreatePostgresQueryClient()).resolves.toBeNull();
  });

  it("bootstraps a Postgres pool from env using the module loader", async () => {
    process.env.DATABASE_URL = "postgres://example";
    process.env.POSTGRES_SSL_MODE = "disable";

    const end = vi.fn(async () => {});

    class FakePool {
      constructor(public readonly config: Record<string, unknown>) {}

      async query() {
        return {
          rows: [],
          rowCount: 0,
        };
      }

      end = end;
    }

    configurePostgresModuleLoader(async (moduleName: string) => {
      expect(moduleName).toBe("pg");
      return {
        Pool: FakePool,
      };
    });

    const client = await getOrCreatePostgresQueryClient();

    expect(client).not.toBeNull();
    expect((client as InstanceType<typeof FakePool>).config.connectionString).toBe(
      "postgres://example",
    );
    expect((client as InstanceType<typeof FakePool>).config.ssl).toBe(false);
  });
});
