import { apiError, apiSuccess, withAuthRoute } from "@/lib/auth";
import { getOrganizationBillingSnapshot } from "@/lib/billing/service";
import { requireAuthenticatedSession } from "@/lib/session";

export const GET = withAuthRoute(async function GET(request: Request) {
  const auth = await requireAuthenticatedSession(request);

  if (!auth.ok) {
    return auth.response;
  }

  const organizationId = auth.session.user.current_organization_id;

  if (!organizationId) {
    return apiError(
      "invalid_organization",
      "No active organization is available for this account.",
      400,
    );
  }

  const snapshot = await getOrganizationBillingSnapshot(organizationId);
  const organization = auth.session.user.organization_context?.memberships.find(
    (membership) => membership.organization.id === organizationId,
  );

  return apiSuccess({
    organization: organization
      ? {
          id: organization.organization.id,
          name: organization.organization.name,
          role: organization.member.role,
        }
      : {
          id: organizationId,
          name: "Workspace",
          role: "viewer",
        },
    snapshot,
  });
});
