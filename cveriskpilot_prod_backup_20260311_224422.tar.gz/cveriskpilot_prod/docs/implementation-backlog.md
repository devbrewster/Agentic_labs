# CVERiskPilot Implementation Backlog

Last updated: 2026-03-11

## Priority order

1. Dashboard auth and tenant scoping
2. Upload and ingestion hardening
3. Remove remaining mock and fallback behavior from core workflows
4. Stripe billing and paywall enforcement
5. Audit logging, admin tooling, and support/compliance surfaces

## Item 1 - Dashboard auth and tenant scoping

Status: in progress

Scope:
- Require authenticated session on all `/dashboard/*` routes
- Prevent dashboard/report pages from rendering without a valid session
- Ensure executive summary reporting is always scoped to the active organization
- Continue reviewing dashboard-adjacent pages for any unscoped service calls

Completed:
- Added server-component session bridge in `lib/auth/server.ts`
- Added authenticated gate to `app/dashboard/layout.tsx`
- Scoped `app/dashboard/reports/page.tsx` to the active organization before building the executive summary
- Hardened `lib/services/reports.ts` so missing-organization calls return a safe empty ingestion summary instead of reading global findings or falling back to mock report data
- Protected the local `app/api/agent-mesh/route.ts` monitor endpoint behind current-organization access checks
- Added regression coverage for:
  - server-side dashboard auth helper redirect behavior
  - local agent-mesh API auth enforcement

Remaining:
- Audit dashboard child pages for any unscoped data paths
- Review any remaining dashboard-facing services that still allow global fallback reads in app-facing paths

## Item 2 - Upload and ingestion hardening

Status: queued

Scope:
- Tighten file validation and user-facing error states
- Review malware/unsafe artifact handling
- Reduce manual orchestration in parse/enrichment flow
- Continue hardening tenant-aware artifact storage behavior

## Item 3 - Remove remaining mock and fallback behavior

Status: queued

Scope:
- Remove remaining mock fallbacks from dashboard/application routes
- Replace placeholder action plan, integrations, and settings content where possible
- Make empty states explicit instead of silently showing fabricated data

## Item 4 - Stripe billing and paywall enforcement

Status: queued

Scope:
- Checkout session creation
- Stripe webhook ingestion
- Subscription state persistence
- Server-side entitlement checks and usage limits

## Item 5 - Audit logging, admin tooling, and support/compliance surfaces

Status: queued

Scope:
- Audit trail for uploads, enrichments, analyst actions, and billing changes
- Admin cleanup and support tooling
- Compliance/help/reporting surfaces needed for customer operations
