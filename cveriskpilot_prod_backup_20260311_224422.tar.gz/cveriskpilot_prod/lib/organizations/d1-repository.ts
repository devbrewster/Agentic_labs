import type { D1Database } from "@cloudflare/workers-types";

import { D1AppDatabase } from "@/lib/platform/database";
import { SqlOrganizationRepository } from "@/lib/organizations/sql-repository";

export class D1OrganizationRepository extends SqlOrganizationRepository {
  constructor(db: D1Database) {
    super(new D1AppDatabase(db));
  }
}
