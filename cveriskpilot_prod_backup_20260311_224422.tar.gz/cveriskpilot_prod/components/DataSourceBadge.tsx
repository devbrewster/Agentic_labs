type DataSourceBadgeTone = "nvd" | "analysis" | "enrichment";

type DataSourceBadgeProps = {
  label: string;
  tone: DataSourceBadgeTone;
};

const toneClasses: Record<DataSourceBadgeTone, string> = {
  nvd: "border-[rgba(0,200,180,0.35)] bg-[rgba(0,200,180,0.10)] text-[#76f1e4]",
  analysis: "border-[rgba(255,184,77,0.35)] bg-[rgba(255,184,77,0.12)] text-[#ffd28f]",
  enrichment: "border-[rgba(120,140,255,0.35)] bg-[rgba(120,140,255,0.14)] text-[#bec8ff]",
};

export function DataSourceBadge({ label, tone }: DataSourceBadgeProps) {
  return (
    <span
      className={`inline-flex rounded border px-2 py-1 font-mono text-[0.62rem] uppercase tracking-[0.08em] ${toneClasses[tone]}`}
    >
      {label}
    </span>
  );
}
