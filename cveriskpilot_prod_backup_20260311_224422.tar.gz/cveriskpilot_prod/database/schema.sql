PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS organizations (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  slug TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL DEFAULT 'active',
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS organization_members (
  id TEXT PRIMARY KEY,
  organization_id TEXT NOT NULL,
  user_id TEXT NOT NULL,
  role TEXT NOT NULL,
  joined_at TEXT NOT NULL,
  invited_by_user_id TEXT,
  FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS users (
  id TEXT PRIMARY KEY,
  email TEXT NOT NULL UNIQUE,
  password_hash TEXT NOT NULL,
  display_name TEXT NOT NULL,
  email_verified INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sessions (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  user_agent TEXT,
  ip_address TEXT,
  revoked_at TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS session_organization_context (
  session_id TEXT PRIMARY KEY,
  active_organization_id TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE,
  FOREIGN KEY (active_organization_id) REFERENCES organizations(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS email_verification_tokens (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  email TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  used_at TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id TEXT PRIMARY KEY,
  user_id TEXT NOT NULL,
  email TEXT NOT NULL,
  token_hash TEXT NOT NULL UNIQUE,
  expires_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  used_at TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_organizations_slug ON organizations(slug);
CREATE INDEX IF NOT EXISTS idx_organizations_status ON organizations(status);
CREATE INDEX IF NOT EXISTS idx_organization_members_user_id ON organization_members(user_id);
CREATE INDEX IF NOT EXISTS idx_organization_members_organization_id ON organization_members(organization_id);
CREATE UNIQUE INDEX IF NOT EXISTS idx_organization_members_org_user
  ON organization_members(organization_id, user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_user_id ON sessions(user_id);
CREATE INDEX IF NOT EXISTS idx_sessions_expires_at ON sessions(expires_at);
CREATE INDEX IF NOT EXISTS idx_sessions_revoked_at ON sessions(revoked_at);
CREATE INDEX IF NOT EXISTS idx_session_organization_context_active_org
  ON session_organization_context(active_organization_id);
CREATE INDEX IF NOT EXISTS idx_email_verification_tokens_user_id
  ON email_verification_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_email_verification_tokens_expires_at
  ON email_verification_tokens(expires_at);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_user_id
  ON password_reset_tokens(user_id);
CREATE INDEX IF NOT EXISTS idx_password_reset_tokens_expires_at
  ON password_reset_tokens(expires_at);

CREATE TABLE IF NOT EXISTS billing_customers (
  organization_id TEXT PRIMARY KEY,
  stripe_customer_id TEXT NOT NULL UNIQUE,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS subscriptions (
  organization_id TEXT PRIMARY KEY,
  stripe_subscription_id TEXT NOT NULL UNIQUE,
  status TEXT NOT NULL,
  price_id TEXT NOT NULL,
  current_period_start TEXT,
  current_period_end TEXT,
  cancel_at_period_end INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS usage_counters (
  organization_id TEXT NOT NULL,
  period_start TEXT NOT NULL,
  period_end TEXT NOT NULL,
  uploads_used INTEGER NOT NULL DEFAULT 0,
  analyses_used INTEGER NOT NULL DEFAULT 0,
  cve_lookups_used INTEGER NOT NULL DEFAULT 0,
  exports_used INTEGER NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (organization_id, period_start, period_end),
  FOREIGN KEY (organization_id) REFERENCES organizations(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_billing_customers_stripe_customer_id
  ON billing_customers(stripe_customer_id);
CREATE INDEX IF NOT EXISTS idx_subscriptions_status
  ON subscriptions(status);
CREATE INDEX IF NOT EXISTS idx_subscriptions_current_period_end
  ON subscriptions(current_period_end);
CREATE INDEX IF NOT EXISTS idx_usage_counters_period_start
  ON usage_counters(period_start);

CREATE TABLE IF NOT EXISTS raw_artifacts (
  id TEXT PRIMARY KEY,
  tenant_id TEXT,
  storage_key TEXT NOT NULL UNIQUE,
  original_filename TEXT NOT NULL,
  mime_type TEXT NOT NULL,
  file_type TEXT NOT NULL,
  size_bytes INTEGER NOT NULL,
  checksum_sha256 TEXT NOT NULL,
  uploaded_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS raw_artifact_contents (
  storage_key TEXT PRIMARY KEY,
  checksum_sha256 TEXT NOT NULL,
  body_text TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS upload_jobs (
  id TEXT PRIMARY KEY,
  tenant_id TEXT,
  raw_artifact_id TEXT NOT NULL,
  selected_source_type TEXT,
  detected_source_type TEXT,
  status TEXT NOT NULL,
  error_summary TEXT,
  warning_count INTEGER NOT NULL DEFAULT 0,
  finding_count INTEGER NOT NULL DEFAULT 0,
  checksum_sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  parsed_at TEXT,
  FOREIGN KEY (raw_artifact_id) REFERENCES raw_artifacts(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS parse_outcomes (
  upload_job_id TEXT PRIMARY KEY,
  metadata_json TEXT,
  warnings_json TEXT NOT NULL,
  errors_json TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (upload_job_id) REFERENCES upload_jobs(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS normalized_findings (
  id TEXT PRIMARY KEY,
  upload_job_id TEXT NOT NULL,
  raw_record_ref_json TEXT NOT NULL,
  asset_identifier TEXT,
  hostname TEXT,
  fqdn TEXT,
  ip_address TEXT,
  port INTEGER,
  protocol TEXT,
  vulnerability_id TEXT,
  plugin_id TEXT,
  cve_ids_json TEXT NOT NULL,
  title TEXT NOT NULL,
  description TEXT,
  severity TEXT,
  normalized_severity TEXT NOT NULL,
  cvss_score REAL,
  cvss_vector TEXT,
  remediation TEXT,
  evidence TEXT,
  status TEXT,
  privilege_required TEXT,
  detected_at TEXT,
  first_observed_at TEXT,
  last_observed_at TEXT,
  source_type TEXT NOT NULL,
  source_scanner TEXT NOT NULL,
  tags_json TEXT NOT NULL,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (upload_job_id) REFERENCES upload_jobs(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS enrichment_runs (
  id TEXT PRIMARY KEY,
  upload_job_id TEXT,
  triggered_by TEXT NOT NULL,
  status TEXT NOT NULL,
  provider_count INTEGER NOT NULL DEFAULT 0,
  success_count INTEGER NOT NULL DEFAULT 0,
  error_count INTEGER NOT NULL DEFAULT 0,
  error_summary TEXT,
  started_at TEXT,
  completed_at TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (upload_job_id) REFERENCES upload_jobs(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS finding_enrichment_snapshots (
  id TEXT PRIMARY KEY,
  enrichment_run_id TEXT NOT NULL,
  finding_id TEXT NOT NULL,
  provider TEXT NOT NULL,
  status TEXT NOT NULL,
  source_url TEXT,
  source_version TEXT,
  observed_at TEXT,
  error_code TEXT,
  error_message TEXT,
  summary_json TEXT,
  raw_payload_json TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  FOREIGN KEY (enrichment_run_id) REFERENCES enrichment_runs(id) ON DELETE CASCADE,
  FOREIGN KEY (finding_id) REFERENCES normalized_findings(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_raw_artifacts_checksum_sha256
  ON raw_artifacts(checksum_sha256);
CREATE INDEX IF NOT EXISTS idx_raw_artifacts_uploaded_at
  ON raw_artifacts(uploaded_at);
CREATE INDEX IF NOT EXISTS idx_raw_artifact_contents_checksum_sha256
  ON raw_artifact_contents(checksum_sha256);
CREATE INDEX IF NOT EXISTS idx_upload_jobs_checksum_sha256
  ON upload_jobs(checksum_sha256);
CREATE INDEX IF NOT EXISTS idx_upload_jobs_status
  ON upload_jobs(status);
CREATE INDEX IF NOT EXISTS idx_upload_jobs_raw_artifact_id
  ON upload_jobs(raw_artifact_id);
CREATE INDEX IF NOT EXISTS idx_upload_jobs_created_at
  ON upload_jobs(created_at);
CREATE INDEX IF NOT EXISTS idx_normalized_findings_upload_job_id
  ON normalized_findings(upload_job_id);
CREATE INDEX IF NOT EXISTS idx_normalized_findings_normalized_severity
  ON normalized_findings(normalized_severity);
CREATE INDEX IF NOT EXISTS idx_normalized_findings_cve_title
  ON normalized_findings(title);
CREATE INDEX IF NOT EXISTS idx_normalized_findings_hostname
  ON normalized_findings(hostname);
CREATE INDEX IF NOT EXISTS idx_enrichment_runs_upload_job_id
  ON enrichment_runs(upload_job_id);
CREATE INDEX IF NOT EXISTS idx_enrichment_runs_status
  ON enrichment_runs(status);
CREATE INDEX IF NOT EXISTS idx_enrichment_runs_created_at
  ON enrichment_runs(created_at);
CREATE INDEX IF NOT EXISTS idx_finding_enrichment_snapshots_run_id
  ON finding_enrichment_snapshots(enrichment_run_id);
CREATE INDEX IF NOT EXISTS idx_finding_enrichment_snapshots_finding_id
  ON finding_enrichment_snapshots(finding_id);
CREATE INDEX IF NOT EXISTS idx_finding_enrichment_snapshots_provider
  ON finding_enrichment_snapshots(provider);
CREATE UNIQUE INDEX IF NOT EXISTS idx_finding_enrichment_snapshots_run_finding_provider
  ON finding_enrichment_snapshots(enrichment_run_id, finding_id, provider);

CREATE TABLE IF NOT EXISTS analyst_dispositions (
  finding_id TEXT PRIMARY KEY,
  decision TEXT NOT NULL,
  rationale TEXT NOT NULL,
  notes TEXT,
  factors_json TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  updated_at TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS analyst_disposition_events (
  id TEXT PRIMARY KEY,
  finding_id TEXT NOT NULL,
  decision TEXT NOT NULL,
  rationale TEXT NOT NULL,
  notes TEXT,
  factors_json TEXT NOT NULL,
  updated_by TEXT NOT NULL,
  created_at TEXT NOT NULL
);

CREATE INDEX IF NOT EXISTS idx_analyst_dispositions_updated_at
  ON analyst_dispositions(updated_at);
CREATE INDEX IF NOT EXISTS idx_analyst_disposition_events_finding_id
  ON analyst_disposition_events(finding_id);
CREATE INDEX IF NOT EXISTS idx_analyst_disposition_events_created_at
  ON analyst_disposition_events(created_at);

CREATE TABLE IF NOT EXISTS analysis_runs (
  id TEXT PRIMARY KEY,
  finding_id TEXT NOT NULL,
  source TEXT NOT NULL,
  requested_mode TEXT NOT NULL,
  provider TEXT NOT NULL,
  model TEXT NOT NULL,
  template_version TEXT NOT NULL,
  trace_status TEXT NOT NULL,
  fallback_reason TEXT,
  warning_count INTEGER NOT NULL DEFAULT 0,
  generated_at TEXT NOT NULL,
  created_at TEXT NOT NULL,
  prompt_context_json TEXT NOT NULL,
  prompt_envelope_json TEXT NOT NULL,
  output_json TEXT NOT NULL,
  warnings_json TEXT NOT NULL,
  FOREIGN KEY (finding_id) REFERENCES normalized_findings(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_analysis_runs_finding_id
  ON analysis_runs(finding_id);
CREATE INDEX IF NOT EXISTS idx_analysis_runs_created_at
  ON analysis_runs(created_at);
CREATE INDEX IF NOT EXISTS idx_analysis_runs_trace_status
  ON analysis_runs(trace_status);
