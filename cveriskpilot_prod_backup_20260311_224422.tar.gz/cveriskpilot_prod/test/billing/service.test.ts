import { describe, expect, it } from "vitest";

import {
  ensureUsageCounterForOrganization,
  getBillingPlanForSubscription,
  getEntitlementsForPlan,
  getUsageWindow,
} from "@/lib/billing/service";
import type { BillingRepository } from "@/lib/billing/repository";
import type { UsageCounter } from "@/types/billing";

class FakeBillingRepository implements BillingRepository {
  constructor(private counter: UsageCounter | null = null) {}

  async findCustomerByOrganizationId() {
    return null;
  }

  async findSubscriptionByOrganizationId() {
    return null;
  }

  async findUsageCounter() {
    return this.counter;
  }

  async upsertUsageCounter(counter: UsageCounter) {
    this.counter = counter;
  }
}

describe("billing service", () => {
  it("maps active subscriptions to the pro plan", () => {
    expect(
      getBillingPlanForSubscription({
        organizationId: crypto.randomUUID(),
        stripeSubscriptionId: "sub_123",
        status: "active",
        priceId: "price_pro",
        currentPeriodStart: "2026-03-01T00:00:00.000Z",
        currentPeriodEnd: "2026-04-01T00:00:00.000Z",
        cancelAtPeriodEnd: false,
        createdAt: "2026-03-01T00:00:00.000Z",
        updatedAt: "2026-03-01T00:00:00.000Z",
      }),
    ).toBe("pro");
  });

  it("keeps canceled subscriptions on the free plan", () => {
    expect(
      getBillingPlanForSubscription({
        organizationId: crypto.randomUUID(),
        stripeSubscriptionId: "sub_123",
        status: "canceled",
        priceId: "price_pro",
        currentPeriodStart: null,
        currentPeriodEnd: null,
        cancelAtPeriodEnd: true,
        createdAt: "2026-03-01T00:00:00.000Z",
        updatedAt: "2026-03-01T00:00:00.000Z",
      }),
    ).toBe("free");
  });

  it("creates a zeroed usage window when none exists yet", async () => {
    const repository = new FakeBillingRepository();
    const organizationId = crypto.randomUUID();
    const now = new Date("2026-03-11T12:00:00.000Z");
    const usageCounter = await ensureUsageCounterForOrganization(
      organizationId,
      repository,
      now,
    );
    const usageWindow = getUsageWindow(now);

    expect(usageCounter.organizationId).toBe(organizationId);
    expect(usageCounter.periodStart).toBe(usageWindow.periodStart);
    expect(usageCounter.periodEnd).toBe(usageWindow.periodEnd);
    expect(usageCounter.uploadsUsed).toBe(0);
    expect(usageCounter.analysesUsed).toBe(0);
    expect(getEntitlementsForPlan("free").uploadsPerMonth).toBe(3);
    expect(getEntitlementsForPlan("pro").advancedReports).toBe(true);
  });
});
