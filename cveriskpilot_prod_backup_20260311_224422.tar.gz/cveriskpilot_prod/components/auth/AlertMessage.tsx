type Props = { message?: string };

export default function AlertMessage({ message }: Props) {
  if (!message) return null;
  return <div className="rounded border border-amber-500/30 bg-amber-500/10 p-3 text-sm text-amber-200">{message}</div>;
}
