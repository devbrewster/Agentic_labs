import { afterEach, describe, expect, it } from "vitest";

import type { PostgresQueryClient } from "@/lib/platform/database";
import { clearPostgresQueryClient, configurePostgresQueryClient } from "@/lib/platform/postgres";
import { getAnalystRuntime } from "@/lib/analyst/runtime";

describe("analyst runtime", () => {
  afterEach(() => {
    clearPostgresQueryClient();
    delete process.env.DATABASE_URL;
  });

  it("selects the Postgres analyst repository when a Postgres client is configured", async () => {
    process.env.DATABASE_URL = "postgres://example";

    const client: PostgresQueryClient = {
      async query() {
        return {
          rows: [],
          rowCount: 0,
        };
      },
    };

    configurePostgresQueryClient(client);

    const runtime = await getAnalystRuntime();

    expect(runtime.analystDispositionRepository.constructor.name).toBe(
      "PostgresAnalystDispositionRepository",
    );
  });
});
