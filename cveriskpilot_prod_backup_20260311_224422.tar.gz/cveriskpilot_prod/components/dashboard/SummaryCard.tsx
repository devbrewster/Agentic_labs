import { StatusPill } from "@/components/dashboard/StatusPill";
import type { DashboardStat } from "@/lib/services/dashboard";

type SummaryCardProps = {
  stat: DashboardStat;
};

const stripClasses = {
  critical: "bg-[var(--danger)]",
  high: "bg-[#ff8c42]",
  medium: "bg-[var(--warning)]",
  low: "bg-[var(--accent)]",
  accent: "bg-[#6d879b]",
} as const;

const deltaTone = {
  up: "danger",
  down: "accent",
  neutral: "warning",
} as const;

export function SummaryCard({
  stat,
}: SummaryCardProps) {
  return (
    <article className="relative overflow-hidden rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] px-4 py-4 shadow-[0_12px_26px_rgba(0,0,0,0.18)]">
      <div className={`absolute inset-x-0 top-0 h-0.5 ${stripClasses[stat.tone]}`} />

      <div className="flex items-start justify-between gap-3">
        <div>
          <div className="text-[2.1rem] font-black leading-none tracking-[-0.03em] text-white">
            {stat.value}
          </div>
          <div className="mt-1 font-mono text-[0.62rem] uppercase tracking-[0.16em] text-[#5a7080]">
            {stat.label}
          </div>
        </div>

        <StatusPill tone={deltaTone[stat.direction]}>
          {stat.deltaValue === null
            ? "n/a"
            : `${stat.deltaValue > 0 ? "+" : ""}${stat.deltaValue}`}
        </StatusPill>
      </div>

      <div className="mt-3 font-mono text-[0.64rem] text-[var(--text-dim)]">
        {stat.delta}
      </div>
    </article>
  );
}
