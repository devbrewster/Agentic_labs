import { apiError, apiSuccess, readJsonBody, withAuthRoute } from "@/lib/auth";
import { dbRun } from "@/lib/db";
import { requireAuthenticatedSession } from "@/lib/session";
import { validateDisplayNamePayload } from "@/lib/validators";

export const GET = withAuthRoute(async function GET(request: Request) {
  const auth = await requireAuthenticatedSession(request);

  if (!auth.ok) {
    return auth.response;
  }

  return apiSuccess({ user: auth.session.user });
});

export const PATCH = withAuthRoute(async function PATCH(request: Request) {
  const auth = await requireAuthenticatedSession(request);

  if (!auth.ok) {
    return auth.response;
  }

  const payload = await readJsonBody(request);
  const validation = validateDisplayNamePayload(payload);

  if (!validation.success) {
    return apiError("invalid_input", validation.message, 400, validation.fieldErrors);
  }

  await dbRun(
    `UPDATE users
     SET display_name = ?
     WHERE id = ?`,
    validation.data.display_name,
    auth.session.user.id,
  );

  return apiSuccess({
    user: {
      ...auth.session.user,
      display_name: validation.data.display_name,
    },
  });
});
