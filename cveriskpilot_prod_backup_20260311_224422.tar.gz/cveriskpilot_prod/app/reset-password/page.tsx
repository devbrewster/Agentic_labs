"use client";

import Link from "next/link";
import { FormEvent, Suspense, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

function ResetPasswordPageContent() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const token = useMemo(() => searchParams.get("token")?.trim() ?? "", [searchParams]);

  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [validating, setValidating] = useState(true);
  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const authPrimaryButtonClass =
    "mb-6 w-full rounded-[3px] bg-[#00c8b4] px-4 py-3 font-mono text-[0.8rem] font-semibold uppercase tracking-[0.12em] text-[#040810] transition hover:bg-[#00ffe8] hover:shadow-[0_0_24px_rgba(0,200,180,0.4)] disabled:cursor-not-allowed disabled:opacity-50";
  const authTextLinkClass = "font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[#00c8b4] transition hover:text-[#00ffe8]";

  useEffect(() => {
    let cancelled = false;

    async function validateToken() {
      if (!token) {
        setErrorMessage("✗ Reset link is invalid.");
        setValidating(false);
        return;
      }

      try {
        const response = await fetch(`/api/auth/reset?token=${encodeURIComponent(token)}`, {
          method: "GET",
          cache: "no-store",
        });
        const payload = await response.json().catch(() => ({}));

        if (cancelled) {
          return;
        }

        if (!response.ok || !payload.ok) {
          setErrorMessage(
            payload.error?.message ?? "✗ Reset link is invalid or expired.",
          );
          setValidating(false);
          return;
        }

        setErrorMessage("");
        setValidating(false);
      } catch {
        if (!cancelled) {
          setErrorMessage("✗ Unable to validate reset link.");
          setValidating(false);
        }
      }
    }

    void validateToken();

    return () => {
      cancelled = true;
    };
  }, [token]);

  async function handleSubmit(event: FormEvent) {
    event.preventDefault();
    setSuccessMessage("");
    setErrorMessage("");

    if (!token) {
      setErrorMessage("✗ Reset link is invalid.");
      return;
    }

    if (!password || password.length < 8) {
      setErrorMessage("✗ Password must be at least 8 characters.");
      return;
    }

    if (password !== confirmPassword) {
      setErrorMessage("✗ Passwords do not match.");
      return;
    }

    setLoading(true);

    try {
      const response = await fetch("/api/auth/reset", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          token,
          new_password: password,
        }),
      });
      const payload = await response.json().catch(() => ({}));

      if (!response.ok || !payload.ok) {
        setErrorMessage(payload.error?.message ?? "✗ Unable to reset password.");
        return;
      }

      setSuccessMessage("✓ Password reset successful. Redirecting to login...");
      setPassword("");
      setConfirmPassword("");
      window.setTimeout(() => {
        router.push("/login");
      }, 1200);
    } catch {
      setErrorMessage("✗ Network error — please try again.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="relative min-h-screen overflow-hidden bg-[#040810] text-[#c8d8e8]">
      <div className="pointer-events-none fixed inset-0 z-0 bg-[linear-gradient(rgba(0,200,180,0.025)_1px,transparent_1px),linear-gradient(90deg,rgba(0,200,180,0.025)_1px,transparent_1px)] bg-[size:40px_40px]" />
      <div className="pointer-events-none fixed -right-[100px] -top-[100px] z-0 h-[500px] w-[500px] rounded-full bg-[radial-gradient(circle,rgba(0,200,180,0.09)_0%,transparent_70%)] blur-[140px]" />
      <div className="pointer-events-none fixed -bottom-[100px] -left-[100px] z-0 h-[400px] w-[400px] rounded-full bg-[radial-gradient(circle,rgba(255,69,96,0.07)_0%,transparent_70%)] blur-[140px]" />

      <Link
        href="/login"
        className="fixed left-6 top-6 z-20 text-[0.72rem] uppercase tracking-[0.08em] text-[#4a6070] transition hover:text-[#00c8b4]"
      >
        ← Back to Login
      </Link>

      <div className="relative z-10 flex min-h-screen items-center justify-center px-6 py-10">
        <div className="w-full max-w-[420px] rounded-lg border border-[rgba(0,200,180,0.15)] bg-[#070e1a] px-11 py-12 shadow-[0_40px_100px_rgba(0,0,0,0.6),0_0_60px_rgba(0,200,180,0.05)]">
          <div className="mb-1 text-[1.2rem] font-extrabold text-white">
            CVE<span className="text-[#00c8b4]">Risk</span>Pilot
          </div>
          <div className="mb-9 font-mono text-[0.68rem] uppercase tracking-[0.1em] text-[#4a6070]">
            // Password Reset
          </div>

          {successMessage ? (
            <div className="mb-5 rounded-[3px] border border-[#00c8b4] bg-[rgba(0,200,180,0.08)] px-4 py-3 font-mono text-[0.75rem] tracking-[0.05em] text-[#00c8b4]">
              {successMessage}
            </div>
          ) : null}

          {errorMessage ? (
            <div className="mb-5 rounded-[3px] border border-[#ff4560] bg-[rgba(255,69,96,0.08)] px-4 py-3 font-mono text-[0.75rem] tracking-[0.05em] text-[#ff4560]">
              {errorMessage}
            </div>
          ) : null}

          <form onSubmit={handleSubmit}>
            <label className="mb-2 block font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#4a6070]">
              New Password
            </label>
            <div className="relative mb-5">
              <input
                type={showPassword ? "text" : "password"}
                autoComplete="new-password"
                placeholder="Min 8 characters"
                value={password}
                onChange={(event) => setPassword(event.target.value)}
                disabled={validating || Boolean(errorMessage && !successMessage)}
                className="w-full rounded-[3px] border border-[rgba(0,200,180,0.15)] bg-[#040810] px-4 py-[13px] pr-12 font-mono text-[0.88rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] focus:border-[#00c8b4] disabled:opacity-60"
              />
              <button
                type="button"
                onClick={() => setShowPassword((value) => !value)}
                className="absolute right-3 top-1/2 -translate-y-1/2 p-1 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[#4a6070] transition hover:text-[#00c8b4]"
              >
                👁
              </button>
            </div>

            <label className="mb-2 block font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#4a6070]">
              Confirm Password
            </label>
            <input
              type={showPassword ? "text" : "password"}
              autoComplete="new-password"
              placeholder="Repeat new password"
              value={confirmPassword}
              onChange={(event) => setConfirmPassword(event.target.value)}
              disabled={validating || Boolean(errorMessage && !successMessage)}
              className="mb-6 w-full rounded-[3px] border border-[rgba(0,200,180,0.15)] bg-[#040810] px-4 py-[13px] font-mono text-[0.88rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] focus:border-[#00c8b4] disabled:opacity-60"
            />

            <button
              type="submit"
              disabled={loading || validating || !token}
              className={authPrimaryButtonClass}
            >
              {validating ? "Validating..." : loading ? "Resetting..." : "Reset Password →"}
            </button>

            <div className="text-center text-[0.82rem] text-[#4a6070]">
              Remembered your password?{" "}
              <Link href="/login" className={authTextLinkClass}>
                Log in
              </Link>
            </div>
          </form>
        </div>
      </div>
    </main>
  );
}

export default function ResetPasswordPage() {
  return (
    <Suspense
      fallback={
        <main className="flex min-h-screen items-center justify-center bg-[#040810] text-[#c8d8e8]">
          <div className="font-mono text-[0.75rem] uppercase tracking-[0.1em] text-[#00c8b4]">
            Loading reset console...
          </div>
        </main>
      }
    >
      <ResetPasswordPageContent />
    </Suspense>
  );
}
