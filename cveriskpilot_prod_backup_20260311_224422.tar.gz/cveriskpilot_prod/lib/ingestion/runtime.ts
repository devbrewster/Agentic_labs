import { DbSchemaNotInitializedError, getDb } from "@/lib/db";
import { D1UploadRepository } from "@/lib/ingestion/d1-repository";
import { PostgresUploadRepository } from "@/lib/ingestion/postgres-repository";
import { ParseJobRunner } from "@/lib/ingestion/parse-job-runner";
import { DefaultParserRegistry } from "@/lib/ingestion/parser-registry";
import { GenericCsvParser } from "@/lib/ingestion/parsers/generic-csv-parser";
import { NessusParser } from "@/lib/ingestion/parsers/nessus-parser";
import { QualysParser } from "@/lib/ingestion/parsers/qualys-parser";
import { Rapid7Parser } from "@/lib/ingestion/parsers/rapid7-parser";
import { InMemoryUploadRepository, type UploadRepository } from "@/lib/ingestion/repository";
import {
  D1ArtifactStorage,
  LocalFileStorage,
  S3ArtifactStorage,
  type StorageProvider,
} from "@/lib/ingestion/storage";
import { getPlatformProfile } from "@/lib/platform/runtime";
import { getOrCreatePostgresQueryClient } from "@/lib/platform/postgres";
import { UploadService } from "@/lib/ingestion/upload-service";
import type { ParserRegistry } from "@/types/ingestion";

type IngestionRuntime = {
  parseJobRunner: ParseJobRunner;
  parserRegistry: ParserRegistry;
  uploadRepository: UploadRepository;
  uploadService: UploadService;
};

const parserRegistry = createParserRegistry();
const fallbackUploadRepository = new InMemoryUploadRepository();
const fallbackStorageProvider = new LocalFileStorage();

let fallbackRuntime: IngestionRuntime | null = null;

function createParserRegistry() {
  const registry = new DefaultParserRegistry();

  registry.register(new GenericCsvParser());
  registry.register(new NessusParser());
  registry.register(new QualysParser());
  registry.register(new Rapid7Parser());

  return registry;
}

function buildRuntime(
  uploadRepository: UploadRepository,
  storageProvider: StorageProvider,
): IngestionRuntime {
  const uploadService = new UploadService(uploadRepository, storageProvider);
  const parseJobRunner = new ParseJobRunner(
    uploadRepository,
    storageProvider,
    parserRegistry,
  );

  return {
    parseJobRunner,
    parserRegistry,
    uploadRepository,
    uploadService,
  };
}

function getFallbackRuntime() {
  if (!fallbackRuntime) {
    fallbackRuntime = buildRuntime(fallbackUploadRepository, fallbackStorageProvider);
  }

  return fallbackRuntime;
}

function resolveStorageProvider(db?: Awaited<ReturnType<typeof getDb>>): StorageProvider {
  const platform = getPlatformProfile();

  if (platform.artifactStorageDriver === "s3") {
    const bucketName = process.env.UPLOAD_S3_BUCKET?.trim();

    if (!bucketName) {
      throw new Error(
        "UPLOAD_STORAGE_DRIVER is set to `s3` but UPLOAD_S3_BUCKET is not configured.",
      );
    }

    return new S3ArtifactStorage({
      bucketName,
    });
  }

  if (platform.artifactStorageDriver === "local_fs") {
    return new LocalFileStorage();
  }

  if (!db) {
    throw new Error(
      "Artifact storage driver `d1` requires a Cloudflare D1 binding. Configure UPLOAD_STORAGE_DRIVER to `local_fs` or `s3` for Postgres/AWS runtimes.",
    );
  }

  return new D1ArtifactStorage(db);
}

export async function getIngestionRuntime(): Promise<IngestionRuntime> {
  const platform = getPlatformProfile();

  if (platform.databaseDriver === "postgres") {
    const postgresClient = await getOrCreatePostgresQueryClient();

    if (postgresClient) {
      return buildRuntime(
        new PostgresUploadRepository(postgresClient),
        resolveStorageProvider(),
      );
    }
  }

  try {
    const db = await getDb();
    return buildRuntime(new D1UploadRepository(db), resolveStorageProvider(db));
  } catch (error) {
    if (error instanceof DbSchemaNotInitializedError) {
      throw error;
    }

    // Tests and non-Cloudflare execution paths do not have a D1 binding available.
    if (
      error instanceof Error &&
      (/Cloudflare D1 binding/i.test(error.message) ||
        /getCloudflareContext/i.test(error.message) ||
        /Database schema is not initialized/i.test(error.message))
    ) {
      return getFallbackRuntime();
    }

    throw error;
  }
}
