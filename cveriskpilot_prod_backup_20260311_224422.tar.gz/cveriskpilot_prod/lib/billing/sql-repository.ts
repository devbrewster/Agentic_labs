import type { AppDatabase } from "@/lib/platform/database";
import type { BillingRepository } from "@/lib/billing/repository";
import type {
  BillingCustomer,
  BillingSubscription,
  UsageCounter,
} from "@/types/billing";
import { BillingCustomerSchema, BillingSubscriptionSchema, UsageCounterSchema } from "@/types/billing";
import type { OrganizationId } from "@/types/organization";

type BillingCustomerRow = {
  organization_id: string;
  stripe_customer_id: string;
  created_at: string;
  updated_at: string;
};

type BillingSubscriptionRow = {
  organization_id: string;
  stripe_subscription_id: string;
  status: string;
  price_id: string;
  current_period_start: string | null;
  current_period_end: string | null;
  cancel_at_period_end: number | boolean;
  created_at: string;
  updated_at: string;
};

type UsageCounterRow = {
  organization_id: string;
  period_start: string;
  period_end: string;
  uploads_used: number;
  analyses_used: number;
  cve_lookups_used: number;
  exports_used: number;
  updated_at: string;
};

function mapCustomer(row: BillingCustomerRow): BillingCustomer {
  return BillingCustomerSchema.parse({
    organizationId: row.organization_id,
    stripeCustomerId: row.stripe_customer_id,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  });
}

function mapSubscription(row: BillingSubscriptionRow): BillingSubscription {
  return BillingSubscriptionSchema.parse({
    organizationId: row.organization_id,
    stripeSubscriptionId: row.stripe_subscription_id,
    status: row.status,
    priceId: row.price_id,
    currentPeriodStart: row.current_period_start,
    currentPeriodEnd: row.current_period_end,
    cancelAtPeriodEnd: Boolean(row.cancel_at_period_end),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  });
}

function mapUsageCounter(row: UsageCounterRow): UsageCounter {
  return UsageCounterSchema.parse({
    organizationId: row.organization_id,
    periodStart: row.period_start,
    periodEnd: row.period_end,
    uploadsUsed: row.uploads_used,
    analysesUsed: row.analyses_used,
    cveLookupsUsed: row.cve_lookups_used,
    exportsUsed: row.exports_used,
    updatedAt: row.updated_at,
  });
}

export class SqlBillingRepository implements BillingRepository {
  constructor(private readonly db: AppDatabase) {}

  async findCustomerByOrganizationId(organizationId: OrganizationId) {
    const row = await this.db
      .prepare(
        `SELECT
           organization_id,
           stripe_customer_id,
           created_at,
           updated_at
         FROM billing_customers
         WHERE organization_id = ?
         LIMIT 1`,
      )
      .bind(organizationId)
      .first<BillingCustomerRow>();

    return row ? mapCustomer(row) : null;
  }

  async findSubscriptionByOrganizationId(organizationId: OrganizationId) {
    const row = await this.db
      .prepare(
        `SELECT
           organization_id,
           stripe_subscription_id,
           status,
           price_id,
           current_period_start,
           current_period_end,
           cancel_at_period_end,
           created_at,
           updated_at
         FROM subscriptions
         WHERE organization_id = ?
         LIMIT 1`,
      )
      .bind(organizationId)
      .first<BillingSubscriptionRow>();

    return row ? mapSubscription(row) : null;
  }

  async findUsageCounter(
    organizationId: OrganizationId,
    periodStart: string,
    periodEnd: string,
  ) {
    const row = await this.db
      .prepare(
        `SELECT
           organization_id,
           period_start,
           period_end,
           uploads_used,
           analyses_used,
           cve_lookups_used,
           exports_used,
           updated_at
         FROM usage_counters
         WHERE organization_id = ? AND period_start = ? AND period_end = ?
         LIMIT 1`,
      )
      .bind(organizationId, periodStart, periodEnd)
      .first<UsageCounterRow>();

    return row ? mapUsageCounter(row) : null;
  }

  async upsertUsageCounter(counter: UsageCounter) {
    await this.db
      .prepare(
        `INSERT INTO usage_counters (
           organization_id,
           period_start,
           period_end,
           uploads_used,
           analyses_used,
           cve_lookups_used,
           exports_used,
           updated_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(organization_id, period_start, period_end) DO UPDATE SET
           uploads_used = excluded.uploads_used,
           analyses_used = excluded.analyses_used,
           cve_lookups_used = excluded.cve_lookups_used,
           exports_used = excluded.exports_used,
           updated_at = excluded.updated_at`,
      )
      .bind(
        counter.organizationId,
        counter.periodStart,
        counter.periodEnd,
        counter.uploadsUsed,
        counter.analysesUsed,
        counter.cveLookupsUsed,
        counter.exportsUsed,
        counter.updatedAt,
      )
      .run();
  }
}
