# CVERiskPilot Production Roadmap

Last updated: 2026-03-11  
Owner: Product Engineering  
Status: Draft (execution-ready)

## Objective

Ship production billing with a clear `Free` tier and a Stripe-powered paid upgrade path, while keeping current platform stability for ingestion and enrichment flows. Billing is organization-scoped, not user-scoped.

## Product Packaging (Phase 0 Decision)

### Plan model (initial launch)

- Free
- Pro (single monthly price)

### Free tier guardrails (recommended launch defaults)

- Uploads: 3 per calendar month
- AI analyses: 10 per calendar month
- 1 workspace/user scope
- Basic enrichment and dashboard access
- No advanced exports/integrations

### Pro unlocks

- Higher usage limits
- Full AI triage volume
- Advanced enrichment/reporting modules
- Priority processing and premium features

## Implementation Phases

## P4-1: Billing Data Model + Stripe Baseline

### Goals

- Persist customer + subscription state.
- Track usage counters for paywall enforcement.
- Add environment and config contracts.

### Deliverables

- D1 tables:
- `billing_customers` (`organization_id`, `stripe_customer_id`, `created_at`, `updated_at`)
- `subscriptions` (`organization_id`, `stripe_subscription_id`, `status`, `price_id`, `current_period_end`, `cancel_at_period_end`, `created_at`, `updated_at`)
- `usage_counters` (`organization_id`, `period_start`, `period_end`, `uploads_used`, `analyses_used`, `updated_at`)
- Types:
  - Billing/plan enums
  - Entitlement model
  - Usage model
- Env vars:
  - `STRIPE_SECRET_KEY`
  - `STRIPE_WEBHOOK_SECRET`
  - `STRIPE_PRICE_PRO_MONTHLY`
  - `NEXT_PUBLIC_STRIPE_PUBLISHABLE_KEY`
  - `APP_BASE_URL`

### Acceptance criteria

- Schema migrates locally and in preview.
- Billing records can be created/read without UI coupling.

## P4-2: Stripe Checkout + Customer Portal

### Goals

- Enable upgrade flow from dashboard.
- Enable self-service subscription management.

### Deliverables

- API routes:
  - `POST /api/billing/checkout` (creates Stripe Checkout Session)
  - `POST /api/billing/portal` (creates Stripe Billing Portal session)
- UI:
  - Upgrade CTA in dashboard header/nav
  - Billing page with plan status and usage snapshot

### Acceptance criteria

- Free user can open checkout and complete test-mode subscription.
- Pro user can open billing portal from app.

## P4-3: Webhook-Driven Subscription Sync

### Goals

- Make Stripe webhooks the source of truth for subscription state.

### Deliverables

- Route:
  - `POST /api/webhooks/stripe`
- Handle events:
  - `checkout.session.completed`
  - `customer.subscription.updated`
  - `customer.subscription.deleted`
  - `invoice.payment_failed`
- Idempotent event processing + replay safety.
- Structured internal logs for billing events.

### Acceptance criteria

- Subscription status updates correctly from webhook-only flow.
- Duplicate webhook deliveries do not duplicate state.

## P4-4: Entitlements + Paywall Enforcement

### Goals

- Enforce free-tier limits on backend actions.
- Lock premium actions behind upgrade.

### Deliverables

- Entitlement service:
  - `getPlanForUser(userId)`
  - `canUpload(userId)`
  - `canRunAiAnalysis(userId)`
  - `consumeUsage(userId, metric)`
- API enforcement:
  - Upload endpoints enforce upload quota
  - AI analysis endpoints enforce analysis quota
- Standard error codes:
  - `plan_limit_reached`
  - `upgrade_required`
- UI paywall components:
  - Limit-reached modal/banner
  - Upgrade CTA with checkout redirect

### Acceptance criteria

- Limits are enforced server-side (not UI-only).
- Free users see actionable upgrade path when blocked.

## P4-5: Usage Reset + Ops Hardening

### Goals

- Keep usage accounting accurate over time.
- Prepare production support playbooks.

### Deliverables

- Period reset logic:
  - Monthly window reset for free users
  - Subscription-period aware counters for Pro
- Monitoring:
  - webhook failure alerts
  - billing sync drift checks
  - quota enforcement error dashboards
- Admin diagnostics:
  - user plan snapshot endpoint
  - usage counter audit view

### Acceptance criteria

- Usage counters roll over predictably.
- Billing incidents are observable and recoverable.

## P4-6: Production Launch

### Goals

- Safely move from Stripe test mode to live mode.

### Deliverables

- Live Stripe products/prices created and documented.
- Production env vars set in deployment platform.
- Webhook endpoint live and verified (signature validation + retries).
- Rollout strategy:
  - staged release (internal users → small cohort → full release)

### Acceptance criteria

- Real card checkout upgrades account successfully.
- Entitlements and paywall behavior match purchased plan.

## Security and Compliance Requirements

- Never expose `STRIPE_SECRET_KEY` client-side.
- Verify Stripe webhook signatures on every request.
- Log billing outcomes without leaking secrets or full payment payloads.
- Keep AI usage gating on backend APIs to prevent bypass.

## Recommended Build Order (Engineering)

1. P4-1 schema + billing types + env contracts
2. P4-2 checkout/portal APIs + billing UI
3. P4-3 webhook sync + idempotency
4. P4-4 entitlement enforcement + paywall UX
5. P4-5 usage reset + observability
6. P4-6 production rollout

## Risks and Mitigations

- Risk: webhook delivery failures cause plan drift  
Mitigation: idempotent processing + retry-safe storage + reconciliation job

- Risk: client-only gating bypasses quotas  
Mitigation: all usage checks enforced in API layer

- Risk: unclear free-tier limits create support churn  
Mitigation: explicit usage meter and limit messaging in UI

- Risk: launch complexity too high  
Mitigation: launch with only `Free` + single `Pro` monthly price

## Definition of Done (Billing Launch)

- Free-tier limits enforced on upload + AI analysis APIs.
- Stripe checkout and portal flows work end-to-end.
- Webhook sync is idempotent and reliable.
- Users can self-serve upgrade/downgrade/cancel.
- Live deployment checklist completed and verified.
