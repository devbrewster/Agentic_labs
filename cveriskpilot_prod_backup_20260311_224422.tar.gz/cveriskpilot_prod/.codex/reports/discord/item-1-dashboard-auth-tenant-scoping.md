**CVERiskPilot Implementation Item 1**

**Workstream**
- Dashboard auth and tenant scoping

**Status**
- In progress

**Completed in this slice**
- Added a server-component auth/session bridge for dashboard pages.
- `app/dashboard/layout.tsx` now requires an authenticated session before rendering dashboard routes.
- `app/dashboard/reports/page.tsx` now builds the executive summary using the active organization instead of the unscoped report path.
- `lib/services/reports.ts` now returns a safe empty ingestion summary when no organization is provided, instead of reading global findings or returning mock report data.
- `app/api/agent-mesh/route.ts` now requires current-organization access even in local development.
- Added regression coverage for the server auth bridge and protected local agent-mesh API access.

**Why this matters**
- Prevents unauthenticated users from loading dashboard surfaces directly.
- Reduces risk of unscoped reporting paths reading cross-tenant data.

**Next checks**
- Audit remaining dashboard child pages for unscoped service calls.
- Add regression coverage for unauthenticated dashboard redirects.
- Continue item 1 until all dashboard-facing reads are org-scoped by default.
