# CVERiskPilot Admin Runbook

Last updated: 2026-03-11

## Purpose

Operational runbook for admins handling ingestion incidents, especially stale upload artifacts and parser-state cleanup.

## Safety Rules

- Always target a single `checksum_sha256` or exact `storage_key`.
- Never run broad deletes without a backup/export.
- Log every manual cleanup in `docs/upload-stabilization-log.md`.
- Prefer local project Wrangler binary:
  - `./node_modules/.bin/wrangler`

## Environment Selection

Local DB:

```bash
./node_modules/.bin/wrangler d1 execute cveriskpilot-db --local --command "<SQL>"
```

Remote DB:

```bash
./node_modules/.bin/wrangler d1 execute cveriskpilot-db --remote --command "<SQL>"
```

## Incident: `Artifact content not found for storage key ...`

### 1) Inspect targeted records

Replace values:

- `<CHECKSUM>`
- `<STORAGE_KEY>`

```bash
./node_modules/.bin/wrangler d1 execute cveriskpilot-db --local --command "
SELECT id, storage_key, checksum_sha256, uploaded_at
FROM raw_artifacts
WHERE checksum_sha256='<CHECKSUM>' OR storage_key='<STORAGE_KEY>';

SELECT id, raw_artifact_id, status, finding_count, created_at
FROM upload_jobs
WHERE checksum_sha256='<CHECKSUM>';

SELECT storage_key, checksum_sha256, created_at
FROM raw_artifact_contents
WHERE checksum_sha256='<CHECKSUM>' OR storage_key='<STORAGE_KEY>';
"
```

### 2) Clean stale records (targeted)

Use only if `raw_artifacts` exists but `raw_artifact_contents` is missing or corrupt.

```bash
./node_modules/.bin/wrangler d1 execute cveriskpilot-db --local --command "
DELETE FROM raw_artifacts
WHERE checksum_sha256='<CHECKSUM>' OR storage_key='<STORAGE_KEY>';

DELETE FROM raw_artifact_contents
WHERE checksum_sha256='<CHECKSUM>' OR storage_key='<STORAGE_KEY>';
"
```

Note:

- Deleting from `raw_artifacts` cascades to dependent `upload_jobs`, `parse_outcomes`, and `normalized_findings` through FK constraints.

### 3) Verify cleanup

```bash
./node_modules/.bin/wrangler d1 execute cveriskpilot-db --local --command "
SELECT COUNT(*) AS artifacts
FROM raw_artifacts
WHERE checksum_sha256='<CHECKSUM>' OR storage_key='<STORAGE_KEY>';

SELECT COUNT(*) AS jobs
FROM upload_jobs
WHERE checksum_sha256='<CHECKSUM>';

SELECT COUNT(*) AS bodies
FROM raw_artifact_contents
WHERE checksum_sha256='<CHECKSUM>' OR storage_key='<STORAGE_KEY>';
"
```

Expected:

- all three counts are `0`

### 4) Re-upload test file

- Re-upload from `/dashboard/uploads`
- Confirm lifecycle goes to `enrichment_pending` (or `failed` with structured parser errors)
- Check:
  - `GET /api/uploads/:id`
  - `GET /api/uploads/:id/findings`
  - `GET /api/uploads/:id/errors`

## Incident: Schema mismatch (`no such table`)

Local fix:

```bash
npm run db:migrate:local
```

Remote fix:

```bash
npm run db:migrate:remote
```

Then re-test upload flow.

## Quick Health Queries

Recent upload jobs:

```bash
./node_modules/.bin/wrangler d1 execute cveriskpilot-db --local --command "
SELECT id, status, finding_count, warning_count, error_summary, updated_at
FROM upload_jobs
ORDER BY updated_at DESC
LIMIT 20;
"
```

Parse outcomes missing for parsed/enrichment jobs:

```bash
./node_modules/.bin/wrangler d1 execute cveriskpilot-db --local --command "
SELECT uj.id, uj.status, uj.finding_count, uj.updated_at
FROM upload_jobs uj
LEFT JOIN parse_outcomes po ON po.upload_job_id = uj.id
WHERE uj.status IN ('parsed','enrichment_pending') AND po.upload_job_id IS NULL
ORDER BY uj.updated_at DESC;
"
```

Finding row counts by job:

```bash
./node_modules/.bin/wrangler d1 execute cveriskpilot-db --local --command "
SELECT upload_job_id, COUNT(*) AS findings
FROM normalized_findings
GROUP BY upload_job_id
ORDER BY findings DESC, upload_job_id;
"
```

## Audit Logging Requirement

After every manual action, add an entry to:

- `docs/upload-stabilization-log.md`

Include:

- date/time
- local or remote
- checksum/storage key
- commands executed
- before/after counts
- reason for cleanup
