import type { AppDatabase } from "@/lib/platform/database";
import type { AnalystDispositionRepository } from "@/lib/analyst/repository";
import {
  AnalystDispositionEventSchema,
  AnalystDispositionRecordSchema,
  AnalystDispositionResponseSchema,
  type AnalystDispositionEvent,
  type AnalystDispositionRecord,
  type AnalystDispositionResponse,
  type UpsertAnalystDispositionInput,
} from "@/types/analyst";

type AnalystDispositionRow = {
  finding_id: string;
  decision: string;
  rationale: string;
  notes: string | null;
  factors_json: string;
  updated_by: string;
  updated_at: string;
  created_at: string;
};

type AnalystDispositionEventRow = {
  id: string;
  finding_id: string;
  decision: string;
  rationale: string;
  notes: string | null;
  factors_json: string;
  updated_by: string;
  created_at: string;
};

function parseFactors(value: string) {
  return JSON.parse(value) as Record<string, unknown>;
}

function mapDispositionRow(row: AnalystDispositionRow): AnalystDispositionRecord {
  return AnalystDispositionRecordSchema.parse({
    findingId: row.finding_id,
    decision: row.decision,
    rationale: row.rationale,
    notes: row.notes,
    factors: parseFactors(row.factors_json),
    updatedBy: row.updated_by,
    updatedAt: row.updated_at,
    createdAt: row.created_at,
  });
}

function mapEventRow(row: AnalystDispositionEventRow): AnalystDispositionEvent {
  return AnalystDispositionEventSchema.parse({
    id: row.id,
    findingId: row.finding_id,
    decision: row.decision,
    rationale: row.rationale,
    notes: row.notes,
    factors: parseFactors(row.factors_json),
    updatedBy: row.updated_by,
    createdAt: row.created_at,
  });
}

export class SqlAnalystDispositionRepository implements AnalystDispositionRepository {
  constructor(private readonly db: AppDatabase) {}

  async findByFindingId(findingId: string): Promise<AnalystDispositionRecord | null> {
    const row = await this.db
      .prepare(
        `SELECT
           finding_id,
           decision,
           rationale,
           notes,
           factors_json,
           updated_by,
           updated_at,
           created_at
         FROM analyst_dispositions
         WHERE finding_id = ?
         LIMIT 1`,
      )
      .bind(findingId)
      .first<AnalystDispositionRow>();

    return row ? mapDispositionRow(row) : null;
  }

  async listHistoryByFindingId(findingId: string): Promise<AnalystDispositionEvent[]> {
    const rows = await this.db
      .prepare(
        `SELECT
           id,
           finding_id,
           decision,
           rationale,
           notes,
           factors_json,
           updated_by,
           created_at
         FROM analyst_disposition_events
         WHERE finding_id = ?
         ORDER BY created_at DESC`,
      )
      .bind(findingId)
      .all<AnalystDispositionEventRow>();

    return rows.map(mapEventRow);
  }

  async upsertByFindingId(
    findingId: string,
    input: UpsertAnalystDispositionInput,
  ): Promise<AnalystDispositionResponse> {
    const now = new Date().toISOString();
    const existing = await this.findByFindingId(findingId);
    const createdAt = existing?.createdAt ?? now;
    const factorsJson = JSON.stringify(input.factors);

    await this.db
      .prepare(
        `INSERT INTO analyst_dispositions (
           finding_id,
           decision,
           rationale,
           notes,
           factors_json,
           updated_by,
           updated_at,
           created_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(finding_id) DO UPDATE SET
           decision = excluded.decision,
           rationale = excluded.rationale,
           notes = excluded.notes,
           factors_json = excluded.factors_json,
           updated_by = excluded.updated_by,
           updated_at = excluded.updated_at`,
      )
      .bind(
        findingId,
        input.decision,
        input.rationale,
        input.notes,
        factorsJson,
        input.updatedBy,
        now,
        createdAt,
      )
      .run();

    await this.db
      .prepare(
        `INSERT INTO analyst_disposition_events (
           id,
           finding_id,
           decision,
           rationale,
           notes,
           factors_json,
           updated_by,
           created_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        crypto.randomUUID(),
        findingId,
        input.decision,
        input.rationale,
        input.notes,
        factorsJson,
        input.updatedBy,
        now,
      )
      .run();

    const disposition = await this.findByFindingId(findingId);
    const history = await this.listHistoryByFindingId(findingId);

    return AnalystDispositionResponseSchema.parse({
      disposition,
      history,
    });
  }
}
