import { describe, expect, it } from "vitest";

import { GenericCsvParser } from "@/lib/ingestion/parsers/generic-csv-parser";
import {
  malformedCsvFixture,
  successfulCsvFixture,
  warningCsvFixture,
} from "@/test/fixtures/generic-csv";
import type { ParseContext, RawArtifact } from "@/types/ingestion";

function createArtifact(): RawArtifact {
  return {
    id: crypto.randomUUID(),
    storageKey: "test/fixture.csv",
    originalFilename: "fixture.csv",
    mimeType: "text/csv",
    fileType: "csv",
    sizeBytes: 123,
    checksumSha256: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    uploadedAt: "2026-03-10T00:00:00.000Z",
  };
}

function createContext(uploadJobId = crypto.randomUUID()): ParseContext {
  return {
    uploadJob: {
      id: uploadJobId,
      tenantId: null,
      rawArtifactId: crypto.randomUUID(),
      selectedSourceType: "generic_csv",
      detectedSourceType: "generic_csv",
      status: "parsing",
      errorSummary: null,
      warningCount: 0,
      findingCount: 0,
      checksumSha256: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
      createdAt: "2026-03-10T00:00:00.000Z",
      updatedAt: "2026-03-10T00:00:00.000Z",
      parsedAt: null,
    },
    rawArtifact: createArtifact(),
    selectedSourceType: "generic_csv",
    detectedSourceType: "generic_csv",
    checksumSha256: "aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa",
    now: "2026-03-10T00:00:00.000Z",
  };
}

describe("GenericCsvParser", () => {
  it("parses a valid CSV into normalized findings", async () => {
    const parser = new GenericCsvParser();
    const result = await parser.parse({
      artifact: createArtifact(),
      content: successfulCsvFixture,
      context: createContext(),
    });

    expect(result.parserErrors).toHaveLength(0);
    expect(result.findings).toHaveLength(2);
    expect(result.findings[0]?.cveIds).toContain("CVE-2024-21413");
    expect(result.findings[0]?.normalizedSeverity).toBe("critical");
    expect(result.metadata.findingCount).toBe(2);
  });

  it("preserves warnings for unmapped headers and skipped rows", async () => {
    const parser = new GenericCsvParser();
    const result = await parser.parse({
      artifact: createArtifact(),
      content: warningCsvFixture,
      context: createContext(),
    });

    expect(result.findings).toHaveLength(2);
    expect(result.parserWarnings.some((warning) => warning.code === "csv_unmapped_header")).toBe(
      true,
    );
    expect(result.parserWarnings.some((warning) => warning.code === "csv_empty_row")).toBe(true);
  });

  it("returns a fatal parser error for malformed CSV", async () => {
    const parser = new GenericCsvParser();
    const result = await parser.parse({
      artifact: createArtifact(),
      content: malformedCsvFixture,
      context: createContext(),
    });

    expect(result.findings).toHaveLength(0);
    expect(result.parserErrors[0]?.fatal).toBe(true);
    expect(result.parserErrors[0]?.code).toBe("csv_unclosed_quote");
  });
});
