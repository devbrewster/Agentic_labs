import { describe, expect, it } from "vitest";

import { detectSourceType } from "@/lib/ingestion/detection";
import {
  nessusXmlFixture,
  qualysXmlFixture,
  rapid7JsonFixture,
  successfulCsvFixture,
} from "@/test/fixtures/generic-csv";

describe("source detection", () => {
  it("detects generic csv from headers", () => {
    expect(
      detectSourceType({
        filename: "scanner-findings.csv",
        mimeType: "text/csv",
        fileType: "csv",
        leadingBytes: successfulCsvFixture.slice(0, 128),
        sampleText: successfulCsvFixture,
      }),
    ).toBe("generic_csv");
  });

  it("detects nessus from xml root tag", () => {
    expect(
      detectSourceType({
        filename: "enterprise-scan.xml",
        mimeType: "application/xml",
        fileType: "xml",
        leadingBytes: nessusXmlFixture.slice(0, 128),
        sampleText: nessusXmlFixture,
      }),
    ).toBe("nessus");
  });

  it("detects qualys from xml root tag", () => {
    expect(
      detectSourceType({
        filename: "qualys-export.xml",
        mimeType: "application/xml",
        fileType: "xml",
        leadingBytes: qualysXmlFixture.slice(0, 128),
        sampleText: qualysXmlFixture,
      }),
    ).toBe("qualys");
  });

  it("detects rapid7 from json root keys", () => {
    expect(
      detectSourceType({
        filename: "insightvm-export.json",
        mimeType: "application/json",
        fileType: "json",
        leadingBytes: rapid7JsonFixture.slice(0, 128),
        sampleText: rapid7JsonFixture,
      }),
    ).toBe("rapid7");
  });
});
