#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-.}"
REPO_ROOT="$(cd "$REPO_ROOT" && pwd)"

echo "Prompt files in use:"
echo "$REPO_ROOT/.codex/prompts/orchestrator.md"
echo "$REPO_ROOT/.codex/prompts/pm_agent.md"
echo "$REPO_ROOT/.codex/prompts/product-ux.md"
echo "$REPO_ROOT/.codex/prompts/security-platform.md"
echo
echo "Workflow:"
echo "1. Independent assessments"
echo "2. Cross-review"
echo "3. Merge"
echo "4. Final unified assessment"
echo
echo "Automation:"
echo "./scripts/run-agent-mesh.sh"
echo "./scripts/run-agent-mesh.sh --dry-run"
