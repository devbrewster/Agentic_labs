"use client";

import Link from "next/link";
import { FormEvent, KeyboardEvent, useMemo, useState } from "react";

function getPasswordStrength(password: string) {
  let score = 0;

  if (password.length >= 8) score++;
  if (password.length >= 12) score++;
  if (/[A-Z]/.test(password)) score++;
  if (/[0-9]/.test(password)) score++;
  if (/[^A-Za-z0-9]/.test(password)) score++;

  if (!password) {
    return {
      width: "0%",
      color: "transparent",
    };
  }

  const colors = ["#ff4560", "#ff4560", "#ffd060", "#ffd060", "#00c8b4"];
  const widths = ["20%", "40%", "60%", "80%", "100%"];
  const index = Math.min(Math.max(score - 1, 0), 4);

  return {
    width: widths[index],
    color: colors[index],
  };
}

export default function SignupPage() {
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirm, setConfirm] = useState("");

  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);

  const [loading, setLoading] = useState(false);
  const [magicLoading, setMagicLoading] = useState(false);

  const [successMessage, setSuccessMessage] = useState("");
  const [errorMessage, setErrorMessage] = useState("");
  const [previewUrl, setPreviewUrl] = useState("");

  const [nameError, setNameError] = useState(false);
  const [emailError, setEmailError] = useState(false);
  const [passwordError, setPasswordError] = useState(false);
  const [confirmError, setConfirmError] = useState(false);

  const [verifyMode, setVerifyMode] = useState(false);
  const [sentEmail, setSentEmail] = useState("");

  const strength = useMemo(() => getPasswordStrength(password), [password]);
  const authPrimaryButtonClass =
    "mb-5 w-full rounded-[3px] bg-[#00c8b4] px-4 py-3 font-mono text-[0.8rem] font-semibold uppercase tracking-[0.12em] text-[#040810] transition hover:bg-[#00ffe8] hover:shadow-[0_0_24px_rgba(0,200,180,0.4)] disabled:cursor-not-allowed disabled:opacity-50";
  const authSecondaryButtonClass =
    "mb-6 w-full rounded-[3px] border border-[rgba(0,200,180,0.15)] bg-transparent px-4 py-[11px] font-mono text-[0.72rem] uppercase tracking-[0.12em] text-[#5a7080] transition hover:border-[#00c8b4] hover:text-[#00c8b4] disabled:cursor-not-allowed disabled:opacity-50";
  const authTextLinkClass = "font-mono text-[0.72rem] uppercase tracking-[0.08em] text-[#00c8b4] transition hover:text-[#00ffe8]";

  function clearAlerts() {
    setSuccessMessage("");
    setErrorMessage("");
    setPreviewUrl("");
  }

  function clearFieldErrors() {
    setNameError(false);
    setEmailError(false);
    setPasswordError(false);
    setConfirmError(false);
  }

  function validate() {
    clearFieldErrors();

    const trimmedName = name.trim();
    const trimmedEmail = email.trim();
    const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    let valid = true;

    if (!trimmedName) {
      setNameError(true);
      valid = false;
    }

    if (!trimmedEmail || !emailValid.test(trimmedEmail)) {
      setEmailError(true);
      valid = false;
    }

    if (!password || password.length < 8) {
      setPasswordError(true);
      valid = false;
    }

    if (password !== confirm) {
      setConfirmError(true);
      valid = false;
    }

    return valid;
  }

  async function handleSignup(e?: FormEvent) {
    e?.preventDefault();
    clearAlerts();

    const trimmedName = name.trim();
    const trimmedEmail = email.trim();

    const valid = validate();
    if (!valid) return;

    setLoading(true);

    try {
      const res = await fetch("/api/auth/signup", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: trimmedName,
          email: trimmedEmail,
          password,
        }),
      });

      const data = await res.json().catch(() => ({}));

      if (res.ok) {
        setSentEmail(trimmedEmail);
        setVerifyMode(true);
        setPreviewUrl(data.data?.email_preview_url || "");
        setSuccessMessage("✓ Verification email created successfully.");
        return;
      }

      if (data.reason === "email_taken") {
        setErrorMessage("✗ An account with this email already exists.");
      } else if (data.reason === "email_send_failed") {
        setErrorMessage("✗ Unable to send the verification email.");
      } else {
        setErrorMessage("✗ Signup failed. Please try again.");
      }
    } catch {
      setErrorMessage("✗ Network error — please check your connection.");
    } finally {
      setLoading(false);
    }
  }

  async function handleMagic() {
    clearAlerts();

    const entered = window.prompt("Enter your work email for a magic sign-up link:");
    const trimmedEmail = entered?.trim() || "";
    const emailValid = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!trimmedEmail || !emailValid.test(trimmedEmail)) return;

    setMagicLoading(true);

    try {
      const res = await fetch("/api/auth/magic", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          email: trimmedEmail,
        }),
      });

      const data = await res.json().catch(() => ({}));

      if (!res.ok) {
        setErrorMessage(
          data.reason === "todo_not_implemented"
            ? "✗ Magic link signup is not implemented yet."
            : "✗ Unable to send a magic signup link.",
        );
        return;
      }

      setSentEmail(trimmedEmail);
      setVerifyMode(true);
    } catch {
      setErrorMessage("✗ Network error — please check your connection.");
    } finally {
      setMagicLoading(false);
    }
  }

  function handleKeyDown(e: KeyboardEvent<HTMLDivElement>) {
    if (e.key === "Enter" && !verifyMode) {
      void handleSignup();
    }
  }

  return (
    <main
      className="relative min-h-screen overflow-hidden bg-[#040810] text-[#c8d8e8]"
      onKeyDown={handleKeyDown}
    >
      <div className="pointer-events-none fixed inset-0 z-0 bg-[linear-gradient(rgba(0,200,180,0.025)_1px,transparent_1px),linear-gradient(90deg,rgba(0,200,180,0.025)_1px,transparent_1px)] bg-[size:40px_40px]" />
      <div className="pointer-events-none fixed -left-[150px] -top-[150px] z-0 h-[600px] w-[600px] rounded-full bg-[radial-gradient(circle,rgba(0,200,180,0.1)_0%,transparent_70%)] blur-[140px]" />

      <Link
        href="/"
        className="fixed left-6 top-6 z-20 text-[0.72rem] uppercase tracking-[0.08em] text-[#4a6070] transition hover:text-[#00c8b4]"
      >
        ← Back to Home
      </Link>

      <div className="relative z-10 flex min-h-screen items-center justify-center px-6 py-10">
        <div className="w-full max-w-[460px] rounded-lg border border-[rgba(0,200,180,0.15)] bg-[#070e1a] px-11 py-12 shadow-[0_40px_100px_rgba(0,0,0,0.6),0_0_60px_rgba(0,200,180,0.05)]">
          <div className="mb-1 text-[1.2rem] font-extrabold text-white">
            CVE<span className="text-[#00c8b4]">Risk</span>Pilot
          </div>
          <div className="mb-9 font-mono text-[0.68rem] uppercase tracking-[0.1em] text-[#4a6070]">
            // CREATE YOUR FREE ACCOUNT
          </div>

          <div className="mb-5 inline-flex items-center gap-2 rounded-[2px] border border-[rgba(0,200,180,0.15)] px-3 py-1 text-[0.65rem] uppercase tracking-[0.1em] text-[#00c8b4]">
            ✦ FREE TIER — No credit card required
          </div>

          {successMessage ? (
            <div className="mb-5 rounded-[3px] border border-[#00c8b4] bg-[rgba(0,200,180,0.08)] px-4 py-3 font-mono text-[0.75rem] tracking-[0.05em] text-[#00c8b4]">
              {successMessage}
            </div>
          ) : null}

          {errorMessage ? (
            <div className="mb-5 rounded-[3px] border border-[#ff4560] bg-[rgba(255,69,96,0.08)] px-4 py-3 font-mono text-[0.75rem] tracking-[0.05em] text-[#ff4560]">
              {errorMessage}
            </div>
          ) : null}

          {!verifyMode ? (
            <div>
              <form onSubmit={handleSignup}>
                <label className="mb-2 block font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#4a6070]">
                  Display Name
                </label>
                <input
                  type="text"
                  autoComplete="name"
                  placeholder="Jane Smith"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  className={`w-full rounded-[3px] bg-[#040810] px-4 py-[13px] font-mono text-[0.88rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] ${
                    nameError
                      ? "mb-1 border border-[#ff4560]"
                      : "mb-5 border border-[rgba(0,200,180,0.15)] focus:border-[#00c8b4]"
                  }`}
                />
                {nameError ? (
                  <div className="mb-4 mt-0 font-mono text-[0.65rem] tracking-[0.05em] text-[#ff4560]">
                    Please enter your name
                  </div>
                ) : null}

                <label className="mb-2 block font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#4a6070]">
                  Work Email
                </label>
                <input
                  type="email"
                  autoComplete="email"
                  placeholder="you@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className={`w-full rounded-[3px] bg-[#040810] px-4 py-[13px] font-mono text-[0.88rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] ${
                    emailError
                      ? "mb-1 border border-[#ff4560]"
                      : "mb-5 border border-[rgba(0,200,180,0.15)] focus:border-[#00c8b4]"
                  }`}
                />
                {emailError ? (
                  <div className="mb-4 mt-0 font-mono text-[0.65rem] tracking-[0.05em] text-[#ff4560]">
                    Please enter a valid email address
                  </div>
                ) : null}

                <label className="mb-2 block font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#4a6070]">
                  Password
                </label>
                <div className="relative mb-2">
                  <input
                    type={showPassword ? "text" : "password"}
                    autoComplete="new-password"
                    placeholder="Min 8 characters"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    className={`w-full rounded-[3px] bg-[#040810] px-4 py-[13px] pr-12 font-mono text-[0.88rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] ${
                      passwordError
                        ? "border border-[#ff4560]"
                        : "border border-[rgba(0,200,180,0.15)] focus:border-[#00c8b4]"
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[#4a6070] transition hover:text-[#00c8b4]"
                  >
                    {showPassword ? "🙈" : "👁"}
                  </button>
                </div>

                <div className="mb-5 h-[3px] overflow-hidden rounded bg-[rgba(255,255,255,0.05)]">
                  <div
                    className="h-full rounded transition-all duration-300"
                    style={{
                      width: strength.width,
                      background: strength.color,
                    }}
                  />
                </div>

                {passwordError ? (
                  <div className="mb-4 mt-[-8px] font-mono text-[0.65rem] tracking-[0.05em] text-[#ff4560]">
                    Password must be at least 8 characters
                  </div>
                ) : null}

                <label className="mb-2 block font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#4a6070]">
                  Confirm Password
                </label>
                <div className="relative mb-1">
                  <input
                    type={showConfirm ? "text" : "password"}
                    autoComplete="new-password"
                    placeholder="Repeat password"
                    value={confirm}
                    onChange={(e) => setConfirm(e.target.value)}
                    className={`w-full rounded-[3px] bg-[#040810] px-4 py-[13px] pr-12 font-mono text-[0.88rem] text-[#c8d8e8] outline-none transition placeholder:text-[#4a6070] ${
                      confirmError
                        ? "border border-[#ff4560]"
                        : "border border-[rgba(0,200,180,0.15)] focus:border-[#00c8b4]"
                    }`}
                  />
                  <button
                    type="button"
                    onClick={() => setShowConfirm((v) => !v)}
                    className="absolute right-3 top-1/2 -translate-y-1/2 p-1 font-mono text-[0.68rem] uppercase tracking-[0.08em] text-[#4a6070] transition hover:text-[#00c8b4]"
                  >
                    {showConfirm ? "🙈" : "👁"}
                  </button>
                </div>

                {confirmError ? (
                  <div className="mb-4 font-mono text-[0.65rem] tracking-[0.05em] text-[#ff4560]">
                    Passwords do not match
                  </div>
                ) : null}

                <div className="mb-6 text-[0.78rem] leading-6 text-[#4a6070]">
                  By creating an account you agree to our{" "}
                  <Link href="#" className="text-[#00c8b4] no-underline">
                    Terms of Service
                  </Link>{" "}
                  and{" "}
                  <Link href="#" className="text-[#00c8b4] no-underline">
                    Privacy Policy
                  </Link>
                  .
                </div>

                <button
                  type="submit"
                  disabled={loading}
                  className={authPrimaryButtonClass}
                >
                  {loading ? "Creating account..." : "Create Account →"}
                </button>
              </form>

              <div className="mb-5 flex items-center gap-3">
                <div className="h-px flex-1 bg-[rgba(0,200,180,0.15)]" />
                <span className="font-mono text-[0.62rem] tracking-[0.1em] text-[#4a6070]">
                  OR
                </span>
                <div className="h-px flex-1 bg-[rgba(0,200,180,0.15)]" />
              </div>

              <button
                type="button"
                onClick={handleMagic}
                disabled={magicLoading}
                className={authSecondaryButtonClass}
              >
                {magicLoading ? "Sending..." : "✉ Sign up with Magic Link"}
              </button>

              <div className="text-center text-[0.82rem] text-[#4a6070]">
                Already have an account?{" "}
                <Link href="/login" className={authTextLinkClass}>
                  Log in
                </Link>
              </div>
            </div>
          ) : (
            <div className="py-5 text-center">
              <div className="mb-4 text-[2rem]">✉</div>
              <div className="mb-2 text-[1.1rem] font-bold text-white">
                Check your email
              </div>
              <div className="text-[0.85rem] leading-7 text-[#4a6070]">
                We sent a verification link to{" "}
                <strong className="text-[#00c8b4]">{sentEmail}</strong>. Click
                the link to activate your account.
              </div>
              <div className="mt-4 text-[0.75rem] font-mono uppercase tracking-[0.08em] text-[#4a6070]">
                Link expires in 15 minutes
              </div>
              {previewUrl ? (
                <a
                  href={previewUrl}
                  target="_blank"
                  rel="noreferrer"
                  className="mt-6 inline-flex rounded-[3px] border border-[#00c8b4] px-4 py-3 font-mono text-[0.72rem] uppercase tracking-[0.12em] text-[#00c8b4] transition hover:bg-[rgba(0,200,180,0.08)]"
                >
                  Open Email Preview
                </a>
              ) : null}
            </div>
          )}
        </div>
      </div>
    </main>
  );
}
