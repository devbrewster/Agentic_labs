import Link from "next/link";

import { getDashboardHref } from "@/lib/app-routes";

export default function TopBar() {
  return (
    <header className="border-b border-slate-800 bg-slate-950 px-6 py-4 text-white">
      <div className="mx-auto flex max-w-6xl items-center justify-between">
        <Link href="/" prefetch={false} className="text-lg font-bold">
          CVERiskPilot
        </Link>
        <nav className="flex gap-4 text-sm text-slate-300">
          <Link href="/login" prefetch={false}>Login</Link>
          <Link href="/signup" prefetch={false}>Sign Up</Link>
          <Link href={getDashboardHref("overview")} prefetch={false}>Dashboard</Link>
        </nav>
      </div>
    </header>
  );
}
