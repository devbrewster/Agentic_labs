import type { PostgresQueryClient } from "@/lib/platform/database";
import { PostgresAppDatabase } from "@/lib/platform/database";
import { SqlOrganizationRepository } from "@/lib/organizations/sql-repository";

export class PostgresOrganizationRepository extends SqlOrganizationRepository {
  constructor(client: PostgresQueryClient) {
    super(new PostgresAppDatabase(client));
  }
}
