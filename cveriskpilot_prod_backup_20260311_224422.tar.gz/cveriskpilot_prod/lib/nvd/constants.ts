export const NVD_ATTRIBUTION_NOTICE =
  "This product uses the NVD API but is not endorsed or certified by the NVD.";

export const NVD_API_BASE_URL_DEFAULT = "https://services.nvd.nist.gov/rest/json";
export const NVD_CACHE_TTL_MINUTES_DEFAULT = 1440;
export const NVD_RATE_LIMIT_PUBLIC_PER_30S_DEFAULT = 5;
export const NVD_RATE_LIMIT_KEYED_PER_30S_DEFAULT = 50;
export const NVD_REQUEST_TIMEOUT_MS_DEFAULT = 15000;
export const NVD_WINDOW_MS = 30_000;

export const NVD_CVE_ID_PATTERN = /^CVE-\d{4}-\d{4,}$/i;

export const NVD_CLIENT_USER_AGENT = "CVERiskPilot/0.1 (+https://cveriskpilot.com)";
