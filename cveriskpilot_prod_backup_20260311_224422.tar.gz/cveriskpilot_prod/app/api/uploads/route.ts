import { NextResponse } from "next/server";

import { invalidateOrganizationWorkloadCache } from "@/lib/cache/workload-cache";
import { handleIngestionRouteError } from "@/lib/ingestion/http";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";
import { ScannerSourceTypeSchema } from "@/types/ingestion";
import { listSupportedUploadFormats, listUploadJobs } from "@/lib/services/uploads";

export async function GET(request: Request) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const { uploadService } = await getIngestionRuntime();
    const ingestionJobs = await uploadService.listUploadJobs(auth.organizationId);

    return NextResponse.json({
      ok: true,
      data: {
        jobs: listUploadJobs(),
        ingestionJobs,
        supportedFormats: listSupportedUploadFormats(),
      },
    });
  } catch (error) {
    return handleIngestionRouteError(error, {
      code: "upload_list_failed",
      message: "Unable to list upload jobs.",
    });
  }
}

export async function POST(request: Request) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const { uploadService } = await getIngestionRuntime();
    const formData = await request.formData();
    const file = formData.get("file");

    if (!(file instanceof File)) {
      return NextResponse.json(
        {
          ok: false,
          error: {
            code: "invalid_file",
            message: "A file upload is required.",
          },
        },
        { status: 400 },
      );
    }

    const selectedSourceValue = formData.get("selectedSourceType");
    const selectedSourceType =
      typeof selectedSourceValue === "string" && selectedSourceValue.length > 0
        ? ScannerSourceTypeSchema.parse(selectedSourceValue)
        : null;

    const upload = await uploadService.createUploadJob({
      tenantId: auth.organizationId,
      selectedSourceType,
      originalFilename: file.name,
      mimeType: file.type || null,
      sizeBytes: file.size,
      body: await file.arrayBuffer(),
    });

    invalidateOrganizationWorkloadCache(auth.organizationId);

    return NextResponse.json(
      {
        ok: true,
        data: upload,
      },
      { status: upload.deduplicated ? 200 : 201 },
    );
  } catch (error) {
    return handleIngestionRouteError(error, {
      code: "upload_create_failed",
      message: "Unable to create upload job.",
    });
  }
}
