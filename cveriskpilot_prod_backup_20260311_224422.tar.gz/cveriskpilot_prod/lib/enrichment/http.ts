import { NextResponse } from "next/server";

import { DbSchemaNotInitializedError } from "@/lib/db";

export function handleEnrichmentRouteError(
  error: unknown,
  fallback: {
    code: string;
    message: string;
  },
) {
  if (error instanceof Error && error.name === "ZodError") {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "invalid_request",
          message: "Request validation failed.",
          details: error.message,
        },
      },
      { status: 400 },
    );
  }

  if (error instanceof DbSchemaNotInitializedError) {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "enrichment_schema_not_initialized",
          message:
            "Enrichment database schema is not initialized. Run `npm run db:migrate:local` before testing enrichment locally.",
        },
      },
      { status: 500 },
    );
  }

  if (error instanceof Error && /was not found/i.test(error.message)) {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "resource_not_found",
          message: error.message,
        },
      },
      { status: 404 },
    );
  }

  console.error(fallback.message, error);

  return NextResponse.json(
    {
      ok: false,
      error: {
        code: fallback.code,
        message: fallback.message,
      },
    },
    { status: 500 },
  );
}
