import type {
  CurrentOrganizationContext,
  Organization,
  OrganizationId,
  OrganizationMember,
  OrganizationMembershipSummary,
} from "@/types/organization";

export interface OrganizationRepository {
  findOrganizationById(organizationId: OrganizationId): Promise<Organization | null>;
  findMembershipsByUserId(userId: string): Promise<OrganizationMembershipSummary[]>;
  getCurrentContextForUser(userId: string): Promise<CurrentOrganizationContext>;
}

export class InMemoryOrganizationRepository implements OrganizationRepository {
  async findOrganizationById() {
    return null;
  }

  async findMembershipsByUserId() {
    return [];
  }

  async getCurrentContextForUser() {
    return {
      organizationId: null,
      memberships: [],
    };
  }
}

export type OrganizationRowRecord = {
  organization: Organization;
  member: OrganizationMember;
};
