import { NVD_ATTRIBUTION_NOTICE } from "@/lib/nvd/constants";

export function FooterAttribution() {
  return (
    <footer className="border-t border-[rgba(0,200,180,0.12)] bg-[#040810] px-4 py-3 text-center text-[0.68rem] tracking-[0.04em] text-[#6f8798]">
      {NVD_ATTRIBUTION_NOTICE}
    </footer>
  );
}
