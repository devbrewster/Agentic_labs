#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="${1:-.}"
REPO_ROOT="$(cd "$REPO_ROOT" && pwd)"

INDIVIDUAL_DIR="$REPO_ROOT/.codex/reports/individual"
CROSS_DIR="$REPO_ROOT/.codex/reports/cross-review"
BUNDLE_FILE="$REPO_ROOT/.codex/reports/final/unified-source-bundle.md"

FILES=(
  "$INDIVIDUAL_DIR/orchestrator-assessment.md"
  "$INDIVIDUAL_DIR/pm-agent-assessment.md"
  "$INDIVIDUAL_DIR/product-ux-assessment.md"
  "$INDIVIDUAL_DIR/security-platform-assessment.md"
  "$CROSS_DIR/orchestrator-review-of-pm.md"
  "$CROSS_DIR/orchestrator-review-of-product.md"
  "$CROSS_DIR/orchestrator-review-of-security.md"
  "$CROSS_DIR/pm-review-of-orchestrator.md"
  "$CROSS_DIR/pm-review-of-product.md"
  "$CROSS_DIR/pm-review-of-security.md"
  "$CROSS_DIR/product-review-of-orchestrator.md"
  "$CROSS_DIR/product-review-of-pm.md"
  "$CROSS_DIR/product-review-of-security.md"
  "$CROSS_DIR/security-review-of-orchestrator.md"
  "$CROSS_DIR/security-review-of-pm.md"
  "$CROSS_DIR/security-review-of-product.md"
  "$CROSS_DIR/cross-review-matrix.md"
)

{
  echo "# CVERiskPilot Unified Source Bundle"
  echo
  echo "> Auto-assembled source bundle"
  echo "> Generated: $(date '+%Y-%m-%d %H:%M:%S')"
  echo
  echo "## Source Reports Included"
  for file in "${FILES[@]}"; do
    echo "- $(basename "$file")"
  done
  echo
  echo "## Consolidated Input Bundle"
  echo

  for file in "${FILES[@]}"; do
    if [[ -f "$file" ]]; then
      echo "---"
      echo
      echo "## BEGIN: $(basename "$file")"
      echo
      cat "$file"
      echo
      echo "## END: $(basename "$file")"
      echo
    fi
  done
} > "$BUNDLE_FILE"

echo "Merged assessment source bundle into:"
echo "$BUNDLE_FILE"
