import type { PostgresQueryClient } from "@/lib/platform/database";

declare global {
  var __CVERISKPILOT_POSTGRES_CLIENT__: PostgresQueryClient | undefined;
  var __CVERISKPILOT_POSTGRES_POOL__: { end?: () => Promise<void> } | undefined;
  var __CVERISKPILOT_POSTGRES_MODULE_LOADER__:
    | ((moduleName: string) => Promise<unknown>)
    | undefined;
}

export function configurePostgresQueryClient(client: PostgresQueryClient) {
  globalThis.__CVERISKPILOT_POSTGRES_CLIENT__ = client;
}

export function clearPostgresQueryClient() {
  delete globalThis.__CVERISKPILOT_POSTGRES_CLIENT__;
  delete globalThis.__CVERISKPILOT_POSTGRES_POOL__;
}

export function getConfiguredPostgresQueryClient() {
  return globalThis.__CVERISKPILOT_POSTGRES_CLIENT__ ?? null;
}

type NodePostgresPool = PostgresQueryClient & {
  end?: () => Promise<void>;
};

type NodePostgresModule = {
  Pool: new (config: {
    connectionString: string;
    max?: number;
    idleTimeoutMillis?: number;
    connectionTimeoutMillis?: number;
    ssl?: boolean | { rejectUnauthorized: boolean };
  }) => NodePostgresPool;
};

function parseNumberEnv(name: string, fallback: number) {
  const value = process.env[name];

  if (!value) {
    return fallback;
  }

  const parsed = Number.parseInt(value, 10);
  return Number.isFinite(parsed) ? parsed : fallback;
}

function resolveSslConfig() {
  const mode = (process.env.POSTGRES_SSL_MODE ?? "require").trim().toLowerCase();

  if (mode === "disable") {
    return false;
  }

  if (mode === "verify-full") {
    return { rejectUnauthorized: true };
  }

  return { rejectUnauthorized: false };
}

function getModuleLoader() {
  if (globalThis.__CVERISKPILOT_POSTGRES_MODULE_LOADER__) {
    return globalThis.__CVERISKPILOT_POSTGRES_MODULE_LOADER__;
  }

  return (moduleName: string) => {
    const importModule = new Function(
      "moduleName",
      "return import(moduleName);",
    ) as (name: string) => Promise<unknown>;

    return importModule(moduleName);
  };
}

export function configurePostgresModuleLoader(
  loader: (moduleName: string) => Promise<unknown>,
) {
  globalThis.__CVERISKPILOT_POSTGRES_MODULE_LOADER__ = loader;
}

export function clearPostgresModuleLoader() {
  delete globalThis.__CVERISKPILOT_POSTGRES_MODULE_LOADER__;
}

export async function getOrCreatePostgresQueryClient() {
  const existing = getConfiguredPostgresQueryClient();

  if (existing) {
    return existing;
  }

  const connectionString = process.env.DATABASE_URL?.trim();

  if (!connectionString) {
    return null;
  }

  let moduleValue: unknown;

  try {
    moduleValue = await getModuleLoader()("pg");
  } catch (error) {
    throw new Error(
      "DATABASE_URL is configured but the `pg` package is unavailable. Install dependencies for the AWS/Postgres runtime before starting the app.",
      { cause: error },
    );
  }

  const pg = moduleValue as Partial<NodePostgresModule> | undefined;

  if (!pg?.Pool) {
    throw new Error("Failed to load the `pg` Pool constructor for the Postgres runtime.");
  }

  const pool = new pg.Pool({
    connectionString,
    max: parseNumberEnv("POSTGRES_POOL_MAX", 10),
    idleTimeoutMillis: parseNumberEnv("POSTGRES_IDLE_TIMEOUT_MS", 30000),
    connectionTimeoutMillis: parseNumberEnv("POSTGRES_CONNECTION_TIMEOUT_MS", 10000),
    ssl: resolveSslConfig(),
  });

  globalThis.__CVERISKPILOT_POSTGRES_POOL__ = pool;
  globalThis.__CVERISKPILOT_POSTGRES_CLIENT__ = pool;

  return pool;
}

export async function closePostgresQueryClient() {
  const pool = globalThis.__CVERISKPILOT_POSTGRES_POOL__;

  if (pool?.end) {
    await pool.end();
  }

  clearPostgresQueryClient();
}
