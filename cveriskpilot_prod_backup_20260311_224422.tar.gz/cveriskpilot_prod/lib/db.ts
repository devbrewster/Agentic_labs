import type { D1Database } from "@cloudflare/workers-types";
import { getCloudflareContext } from "@opennextjs/cloudflare";
import { D1AppDatabase } from "@/lib/platform/database";

declare global {
  interface CloudflareEnv {
    DB: D1Database;
  }
}

export type DbBindValue = string | number | ArrayBuffer | null;

export class DbSchemaNotInitializedError extends Error {
  constructor(message = "Database schema is not initialized.") {
    super(message);
    this.name = "DbSchemaNotInitializedError";
  }
}

function normalizeDbError(error: unknown): never {
  if (error instanceof Error && /no such table:/i.test(error.message)) {
    throw new DbSchemaNotInitializedError(
      "Database schema is not initialized. Run `npm run db:migrate:local` for local development.",
    );
  }

  throw error;
}

export async function getDb() {
  const { env } = await getCloudflareContext({ async: true });

  if (!env.DB) {
    throw new Error("Cloudflare D1 binding `DB` is not configured.");
  }

  return env.DB;
}

export async function getAppDatabase() {
  const db = await getDb();
  return new D1AppDatabase(db);
}

export async function dbFirst<T>(
  sql: string,
  ...params: DbBindValue[]
): Promise<T | null> {
  try {
    const db = await getAppDatabase();
    return db.prepare(sql).bind(...params).first<T>();
  } catch (error) {
    normalizeDbError(error);
  }
}

export async function dbAll<T>(
  sql: string,
  ...params: DbBindValue[]
): Promise<T[]> {
  try {
    const db = await getAppDatabase();
    return db.prepare(sql).bind(...params).all<T>();
  } catch (error) {
    normalizeDbError(error);
  }
}

export async function dbRun(sql: string, ...params: DbBindValue[]) {
  try {
    const db = await getAppDatabase();
    return db.prepare(sql).bind(...params).run();
  } catch (error) {
    normalizeDbError(error);
  }
}
