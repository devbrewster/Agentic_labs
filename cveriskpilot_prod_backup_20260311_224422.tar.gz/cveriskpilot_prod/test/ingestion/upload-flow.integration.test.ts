import { describe, expect, it } from "vitest";

import { ParseJobRunner } from "@/lib/ingestion/parse-job-runner";
import { DefaultParserRegistry } from "@/lib/ingestion/parser-registry";
import { GenericCsvParser } from "@/lib/ingestion/parsers/generic-csv-parser";
import { InMemoryUploadRepository } from "@/lib/ingestion/repository";
import { createIngestionTestContext } from "@/test/helpers/create-ingestion-test-context";
import { successfulCsvFixture } from "@/test/fixtures/generic-csv";
import type { RawArtifact, UploadJob } from "@/types/ingestion";

describe("upload ingestion flow", () => {
  it("creates queued upload jobs idempotently by checksum", async () => {
    const { uploadService } = await createIngestionTestContext();

    const first = await uploadService.createUploadJob({
      tenantId: null,
      selectedSourceType: "generic_csv",
      originalFilename: "findings.csv",
      mimeType: "text/csv",
      sizeBytes: successfulCsvFixture.length,
      body: Buffer.from(successfulCsvFixture),
    });

    const second = await uploadService.createUploadJob({
      tenantId: null,
      selectedSourceType: "generic_csv",
      originalFilename: "findings.csv",
      mimeType: "text/csv",
      sizeBytes: successfulCsvFixture.length,
      body: Buffer.from(successfulCsvFixture),
    });

    expect(first.deduplicated).toBe(false);
    expect(second.deduplicated).toBe(true);
    expect(second.uploadJob.id).toBe(first.uploadJob.id);
  });

  it("moves lifecycle state to enrichment_pending after a successful parse", async () => {
    const repository = new InMemoryUploadRepository();
    const parserRegistry = new DefaultParserRegistry();
    parserRegistry.register(new GenericCsvParser());

    const rawArtifact: RawArtifact = {
      id: crypto.randomUUID(),
      storageKey: "fixtures/successful.csv",
      originalFilename: "successful.csv",
      mimeType: "text/csv",
      fileType: "csv",
      sizeBytes: successfulCsvFixture.length,
      checksumSha256: "ba2c6f242273ac4849ffcf6995e07d1eec2eb31d7cfe07eba584d34667905136",
      uploadedAt: "2026-03-11T00:00:00.000Z",
    };

    const uploadJob: UploadJob = {
      id: crypto.randomUUID(),
      tenantId: null,
      rawArtifactId: rawArtifact.id,
      selectedSourceType: "generic_csv",
      detectedSourceType: null,
      status: "queued",
      errorSummary: null,
      warningCount: 0,
      findingCount: 0,
      checksumSha256: rawArtifact.checksumSha256,
      createdAt: "2026-03-11T00:00:00.000Z",
      updatedAt: "2026-03-11T00:00:00.000Z",
      parsedAt: null,
    };

    await repository.save({
      uploadJob,
      rawArtifact,
    });

    const parseJobRunner = new ParseJobRunner(
      repository,
      {
        async saveArtifact() {
          throw new Error("saveArtifact is not used in this test.");
        },
        async readArtifact() {
          return Buffer.from(successfulCsvFixture);
        },
      },
      parserRegistry,
    );

    const result = await parseJobRunner.run(uploadJob.id);

    expect(result.skipped).toBe(false);
    expect(result.forced).toBe(false);
    expect(result.replacedExistingOutcome).toBe(false);
    expect(result.uploadJob.status).toBe("enrichment_pending");
    expect(result.outcome?.findings).toHaveLength(2);
  });

  it("skips reparsing an already parsed job when force is false", async () => {
    const { uploadService, parseJobRunner } = await createIngestionTestContext();

    const upload = await uploadService.createUploadJob({
      tenantId: null,
      selectedSourceType: "generic_csv",
      originalFilename: "findings.csv",
      mimeType: "text/csv",
      sizeBytes: successfulCsvFixture.length,
      body: Buffer.from(successfulCsvFixture),
    });

    const initialRun = await parseJobRunner.run(upload.uploadJob.id, { force: true });
    expect(initialRun.uploadJob.status).toBe("enrichment_pending");

    const skippedRun = await parseJobRunner.run(upload.uploadJob.id);

    expect(skippedRun.skipped).toBe(true);
    expect(skippedRun.forced).toBe(false);
    expect(skippedRun.replacedExistingOutcome).toBe(false);
    expect(skippedRun.message).toBe("Upload job already parsed. Use force to re-run parsing.");
    expect(skippedRun.uploadJob.status).toBe("enrichment_pending");
    expect(skippedRun.outcome?.findings).toHaveLength(2);
  });

  it("replaces findings on a forced reparse instead of duplicating them", async () => {
    const { uploadService, parseJobRunner } = await createIngestionTestContext();

    const upload = await uploadService.createUploadJob({
      tenantId: null,
      selectedSourceType: "generic_csv",
      originalFilename: "findings.csv",
      mimeType: "text/csv",
      sizeBytes: successfulCsvFixture.length,
      body: Buffer.from(successfulCsvFixture),
    });

    const firstRun = await parseJobRunner.run(upload.uploadJob.id, { force: true });
    expect(firstRun.outcome?.findings).toHaveLength(2);
    expect(firstRun.replacedExistingOutcome).toBe(false);

    const secondRun = await parseJobRunner.run(upload.uploadJob.id, { force: true });
    const detail = await uploadService.getUploadJobDetail(upload.uploadJob.id);

    expect(secondRun.skipped).toBe(false);
    expect(secondRun.forced).toBe(true);
    expect(secondRun.replacedExistingOutcome).toBe(true);
    expect(secondRun.uploadJob.status).toBe("enrichment_pending");
    expect(detail?.findings).toHaveLength(2);
  });
});
