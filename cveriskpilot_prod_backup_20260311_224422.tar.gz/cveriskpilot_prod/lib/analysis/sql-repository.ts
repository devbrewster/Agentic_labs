import type { AppDatabase } from "@/lib/platform/database";
import type { AnalysisTraceRepository } from "@/lib/analysis/repository";
import {
  AnalysisTraceRecordSchema,
  type AnalysisTraceRecord,
  type CreateAnalysisTraceInput,
} from "@/types/analysis";

type AnalysisTraceRow = {
  id: string;
  finding_id: string;
  source: "ingestion" | "mock";
  requested_mode: "stub" | "live";
  provider: "claude" | "stub";
  model: string;
  template_version: string;
  trace_status: "completed" | "fallback";
  fallback_reason: string | null;
  warning_count: number;
  generated_at: string;
  created_at: string;
  prompt_context_json: string;
  prompt_envelope_json: string;
  output_json: string;
  warnings_json: string;
};

function parseJson<T>(value: string) {
  return JSON.parse(value) as T;
}

function buildTraceRecord(input: CreateAnalysisTraceInput): AnalysisTraceRecord {
  const now = new Date().toISOString();

  return AnalysisTraceRecordSchema.parse({
    id: crypto.randomUUID(),
    findingId: input.findingId,
    source: input.source,
    requestedMode: input.requestedMode,
    provider: input.generated.provider,
    model: input.generated.model,
    templateVersion: input.prompt.templateVersion,
    traceStatus: input.generated.traceStatus,
    fallbackReason: input.generated.fallbackReason,
    warningCount: input.generated.warnings.length,
    generatedAt: input.generated.generatedAt,
    createdAt: now,
    promptContextJson: input.prompt.context,
    promptEnvelopeJson: input.prompt,
    outputJson: input.generated.output,
    warningsJson: input.generated.warnings,
  });
}

function mapRow(row: AnalysisTraceRow): AnalysisTraceRecord {
  return AnalysisTraceRecordSchema.parse({
    id: row.id,
    findingId: row.finding_id,
    source: row.source,
    requestedMode: row.requested_mode,
    provider: row.provider,
    model: row.model,
    templateVersion: row.template_version,
    traceStatus: row.trace_status,
    fallbackReason: row.fallback_reason,
    warningCount: row.warning_count,
    generatedAt: row.generated_at,
    createdAt: row.created_at,
    promptContextJson: parseJson<Record<string, unknown>>(row.prompt_context_json),
    promptEnvelopeJson: parseJson<Record<string, unknown>>(row.prompt_envelope_json),
    outputJson: parseJson<Record<string, unknown>>(row.output_json),
    warningsJson: parseJson<string[]>(row.warnings_json),
  });
}

export class SqlAnalysisTraceRepository implements AnalysisTraceRepository {
  constructor(private readonly db: AppDatabase) {}

  async create(input: CreateAnalysisTraceInput): Promise<AnalysisTraceRecord> {
    const record = buildTraceRecord(input);

    await this.db
      .prepare(
        `INSERT INTO analysis_runs (
           id,
           finding_id,
           source,
           requested_mode,
           provider,
           model,
           template_version,
           trace_status,
           fallback_reason,
           warning_count,
           generated_at,
           created_at,
           prompt_context_json,
           prompt_envelope_json,
           output_json,
           warnings_json
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      )
      .bind(
        record.id,
        record.findingId,
        record.source,
        record.requestedMode,
        record.provider,
        record.model,
        record.templateVersion,
        record.traceStatus,
        record.fallbackReason,
        record.warningCount,
        record.generatedAt,
        record.createdAt,
        JSON.stringify(record.promptContextJson),
        JSON.stringify(record.promptEnvelopeJson),
        JSON.stringify(record.outputJson),
        JSON.stringify(record.warningsJson),
      )
      .run();

    return record;
  }

  async listByFindingId(findingId: string): Promise<AnalysisTraceRecord[]> {
    const rows = await this.db
      .prepare(
        `SELECT
           id,
           finding_id,
           source,
           requested_mode,
           provider,
           model,
           template_version,
           trace_status,
           fallback_reason,
           warning_count,
           generated_at,
           created_at,
           prompt_context_json,
           prompt_envelope_json,
           output_json,
           warnings_json
         FROM analysis_runs
         WHERE finding_id = ?
         ORDER BY created_at DESC`,
      )
      .bind(findingId)
      .all<AnalysisTraceRow>();

    return rows.map(mapRow);
  }
}
