import { describe, expect, it } from "vitest";

import { InMemoryNvdCache } from "@/lib/nvd/cache";
import { NvdClient, type NvdClientOptions } from "@/lib/nvd/client";
import { RollingWindowRateLimiter } from "@/lib/nvd/rateLimiter";

function createOptions(overrides?: Partial<NvdClientOptions>): NvdClientOptions {
  return {
    apiKey: "test-key",
    baseUrl: "https://services.nvd.nist.gov/rest/json",
    requestTimeoutMs: 5000,
    cacheTtlMinutes: 60,
    publicLimitPer30s: 5,
    keyedLimitPer30s: 50,
    ...overrides,
  };
}

describe("NvdClient", () => {
  it("normalizes NVD payload into separated record", async () => {
    const fetcher: typeof fetch = (async () =>
      new Response(
        JSON.stringify({
          vulnerabilities: [
            {
              cve: {
                id: "CVE-2024-9999",
                descriptions: [{ lang: "en", value: "Test vulnerability description." }],
                published: "2026-01-01T00:00:00.000",
                lastModified: "2026-01-02T00:00:00.000",
                metrics: {
                  cvssMetricV31: [{ cvssData: { baseScore: 9.8 } }],
                },
                references: [{ url: "https://example.com/advisory" }],
                weaknesses: [{ description: [{ lang: "en", value: "CWE-79" }] }],
              },
            },
          ],
        }),
        { status: 200 },
      )) as typeof fetch;

    const client = new NvdClient(createOptions(), new InMemoryNvdCache(), fetcher);
    const result = await client.getCveById("CVE-2024-9999");

    expect(result.ok).toBe(true);
    if (!result.ok) return;

    expect(result.data.cveId).toBe("CVE-2024-9999");
    expect(result.data.nvd.source).toBe("NVD");
    expect(result.data.analysis.source).toBe("CVERiskPilot");
    expect(result.data.compliance.modifiedContentSeparated).toBe(true);
    expect(result.data.nvd.weaknesses).toContain("CWE-79");
  });

  it("uses stale cache fallback when upstream fails", async () => {
    const cache = new InMemoryNvdCache();
    const expiresAt = new Date(Date.now() - 60_000).toISOString();

    await cache.set({
      key: "nvd:cve:CVE-2024-1111",
      cveId: "CVE-2024-1111",
      fetchedAt: new Date(Date.now() - 120_000).toISOString(),
      expiresAt,
      rawPayload: { cached: true },
      normalized: {
        cveId: "CVE-2024-1111",
        nvd: { source: "NVD", rawDescription: "cached" },
        analysis: { source: "CVERiskPilot" },
        enrichments: {},
        compliance: {
          attributionRequired: true,
          endorsementProhibited: true,
          modifiedContentSeparated: true,
        },
      },
    });

    const failingFetcher: typeof fetch = (async () => {
      throw new Error("NVD HTTP 503");
    }) as typeof fetch;

    const client = new NvdClient(createOptions(), cache, failingFetcher);
    const result = await client.getCveById("CVE-2024-1111");

    expect(result.ok).toBe(true);
    if (!result.ok) return;
    expect(result.meta.source).toBe("nvd_cache_stale");
    expect(result.meta.stale).toBe(true);
  });
});

describe("RollingWindowRateLimiter", () => {
  it("serializes burst tasks and enforces configured throughput", async () => {
    const limiter = new RollingWindowRateLimiter(1, 30);
    const timeline: number[] = [];

    await Promise.all(
      Array.from({ length: 3 }).map(async () =>
        limiter.schedule(async () => {
          timeline.push(Date.now());
        }),
      ),
    );

    expect(timeline.length).toBe(3);
    expect(timeline[1] - timeline[0]).toBeGreaterThanOrEqual(20);
    expect(timeline[2] - timeline[1]).toBeGreaterThanOrEqual(20);
  });
});
