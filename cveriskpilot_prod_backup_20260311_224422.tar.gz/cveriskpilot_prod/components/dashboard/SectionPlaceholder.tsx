type SectionPlaceholderProps = {
  eyebrow: string;
  title: string;
  description: string;
  compact?: boolean;
};

export function SectionPlaceholder({
  eyebrow,
  title,
  description,
  compact = false,
}: SectionPlaceholderProps) {
  return (
    <section
      className={`rounded-xl border border-[var(--panel-border)] bg-[var(--panel-bg)] shadow-[0_24px_60px_rgba(0,0,0,0.35)] ${
        compact ? "p-5" : "p-6"
      }`}
    >
      <div className="mb-3 font-mono text-[0.66rem] uppercase tracking-[0.18em] text-[var(--accent)]">
        {eyebrow}
      </div>
      <h2 className="text-[1.08rem] font-bold tracking-tight text-white">{title}</h2>
      <p className="mt-3 max-w-2xl text-[0.92rem] leading-7 text-[var(--text-dim)]">
        {description}
      </p>
    </section>
  );
}
