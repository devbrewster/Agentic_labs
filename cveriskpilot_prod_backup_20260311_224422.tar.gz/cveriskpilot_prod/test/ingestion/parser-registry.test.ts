import { describe, expect, it } from "vitest";

import { DefaultParserRegistry } from "@/lib/ingestion/parser-registry";
import { GenericCsvParser } from "@/lib/ingestion/parsers/generic-csv-parser";
import { successfulCsvFixture } from "@/test/fixtures/generic-csv";

describe("DefaultParserRegistry", () => {
  it("returns a parser by explicit source selection", async () => {
    const registry = new DefaultParserRegistry();
    registry.register(new GenericCsvParser());

    const result = await registry.resolve({
      selectedSourceType: "generic_csv",
      detectionHint: {
        filename: "findings.csv",
        mimeType: "text/csv",
        fileType: "csv",
        leadingBytes: successfulCsvFixture.slice(0, 64),
        sampleText: successfulCsvFixture,
      },
    });

    expect(result.error).toBeNull();
    expect(result.parser?.sourceType).toBe("generic_csv");
  });

  it("detects a parser heuristically when no source is selected", async () => {
    const registry = new DefaultParserRegistry();
    registry.register(new GenericCsvParser());

    const result = await registry.resolve({
      selectedSourceType: null,
      detectionHint: {
        filename: "export.csv",
        mimeType: "text/csv",
        fileType: "csv",
        leadingBytes: successfulCsvFixture.slice(0, 64),
        sampleText: successfulCsvFixture,
      },
    });

    expect(result.error).toBeNull();
    expect(result.parser?.sourceType).toBe("generic_csv");
  });
});
