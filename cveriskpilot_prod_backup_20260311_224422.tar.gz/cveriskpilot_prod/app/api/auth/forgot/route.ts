import {
  apiSuccess,
  buildPasswordResetUrl,
  createPasswordResetToken,
  getUserByEmail,
  readJsonBody,
  withAuthRoute,
} from "@/lib/auth";
import { sendPasswordResetEmail } from "@/lib/mailer";
import { validatePasswordResetRequestPayload } from "@/lib/validators";

const GENERIC_MESSAGE = "If that email exists, a password reset link has been sent.";

export const POST = withAuthRoute(async function POST(request: Request) {
  const payload = await readJsonBody(request);
  const validation = validatePasswordResetRequestPayload(payload);

  if (!validation.success) {
    return apiSuccess(
      {
        message: GENERIC_MESSAGE,
      },
      200,
    );
  }

  const user = await getUserByEmail(validation.data.email);

  if (!user) {
    return apiSuccess(
      {
        message: GENERIC_MESSAGE,
      },
      200,
    );
  }

  const resetToken = await createPasswordResetToken(user.id, user.email);
  const mail = await sendPasswordResetEmail({
    to: user.email,
    displayName: user.display_name,
    resetUrl: buildPasswordResetUrl(request, resetToken.token),
  });

  return apiSuccess(
    {
      message: GENERIC_MESSAGE,
      reset_expires_at: resetToken.expiresAt,
      email_preview_url: mail.previewUrl,
    },
    200,
  );
});
