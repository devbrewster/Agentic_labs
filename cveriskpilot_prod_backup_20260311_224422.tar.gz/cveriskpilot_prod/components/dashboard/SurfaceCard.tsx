import type { ReactNode } from "react";

type SurfaceCardProps = {
  eyebrow?: string;
  title: string;
  description?: string;
  meta?: ReactNode;
  children?: ReactNode;
};

export function SurfaceCard({
  eyebrow,
  title,
  description,
  meta,
  children,
}: SurfaceCardProps) {
  return (
    <section className="rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] p-5 shadow-[0_16px_40px_rgba(0,0,0,0.18)]">
      {eyebrow ? (
        <div className="mb-2 font-mono text-[0.64rem] uppercase tracking-[0.14em] text-[var(--accent)]">
          {eyebrow}
        </div>
      ) : null}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-[1.02rem] font-semibold leading-tight text-white">{title}</h2>
          {description ? (
            <p className="mt-3 text-[0.92rem] leading-7 text-[var(--text-dim)]">{description}</p>
          ) : null}
        </div>
        {meta ? <div className="shrink-0">{meta}</div> : null}
      </div>
      {children ? <div className="mt-4">{children}</div> : null}
    </section>
  );
}
