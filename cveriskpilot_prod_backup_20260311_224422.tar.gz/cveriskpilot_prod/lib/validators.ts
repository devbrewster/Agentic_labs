import { getPasswordMinLength, isStrongEnoughPassword } from "@/lib/passwords";
import type {
  DisplayNamePatchPayload,
  LoginPayload,
  MagicLinkPayload,
  PasswordChangePayload,
  PasswordResetPayload,
  PasswordResetRequestPayload,
  SignupPayload,
} from "@/types/auth";

type ValidationSuccess<T> = {
  success: true;
  data: T;
};

type ValidationFailure = {
  success: false;
  code: string;
  message: string;
  fieldErrors?: Record<string, string>;
};

export type ValidationResult<T> = ValidationSuccess<T> | ValidationFailure;

const EMAIL_PATTERN = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

function ok<T>(data: T): ValidationSuccess<T> {
  return { success: true, data };
}

function fail(
  code: string,
  message: string,
  fieldErrors?: Record<string, string>,
): ValidationFailure {
  return { success: false, code, message, fieldErrors };
}

export function normalizeEmail(email: string) {
  return email.trim().toLowerCase();
}

export function isValidEmail(email: string) {
  return EMAIL_PATTERN.test(email);
}

export function validateSignupPayload(payload: unknown): ValidationResult<SignupPayload> {
  const input = (payload ?? {}) as Partial<SignupPayload> & { name?: string };
  const displayName = (input.display_name ?? input.name ?? "").trim();
  const email = normalizeEmail(input.email ?? "");
  const password = input.password ?? "";

  const fieldErrors: Record<string, string> = {};

  if (!displayName) {
    fieldErrors.display_name = "Display name is required.";
  } else if (displayName.length > 80) {
    fieldErrors.display_name = "Display name must be 80 characters or fewer.";
  }

  if (!email || !isValidEmail(email)) {
    fieldErrors.email = "A valid email address is required.";
  }

  if (!password || !isStrongEnoughPassword(password)) {
    fieldErrors.password = `Password must be at least ${getPasswordMinLength()} characters.`;
  }

  if (Object.keys(fieldErrors).length > 0) {
    return fail("invalid_input", "Signup validation failed.", fieldErrors);
  }

  return ok({
    email,
    password,
    display_name: displayName,
  });
}

export function validateLoginPayload(payload: unknown): ValidationResult<LoginPayload> {
  const input = (payload ?? {}) as Partial<LoginPayload>;
  const email = normalizeEmail(input.email ?? "");
  const password = input.password ?? "";

  const fieldErrors: Record<string, string> = {};

  if (!email || !isValidEmail(email)) {
    fieldErrors.email = "A valid email address is required.";
  }

  if (!password) {
    fieldErrors.password = "Password is required.";
  }

  if (Object.keys(fieldErrors).length > 0) {
    return fail("invalid_input", "Login validation failed.", fieldErrors);
  }

  return ok({ email, password });
}

export function validateDisplayNamePayload(
  payload: unknown,
): ValidationResult<DisplayNamePatchPayload> {
  const input = (payload ?? {}) as Partial<DisplayNamePatchPayload>;
  const displayName = (input.display_name ?? "").trim();

  if (!displayName) {
    return fail("invalid_input", "Display name is required.", {
      display_name: "Display name is required.",
    });
  }

  if (displayName.length > 80) {
    return fail("invalid_input", "Display name must be 80 characters or fewer.", {
      display_name: "Display name must be 80 characters or fewer.",
    });
  }

  return ok({ display_name: displayName });
}

export function validatePasswordChangePayload(
  payload: unknown,
): ValidationResult<PasswordChangePayload> {
  const input = (payload ?? {}) as Partial<PasswordChangePayload>;
  const currentPassword = input.current_password ?? "";
  const newPassword = input.new_password ?? "";

  const fieldErrors: Record<string, string> = {};

  if (!currentPassword) {
    fieldErrors.current_password = "Current password is required.";
  }

  if (!newPassword || !isStrongEnoughPassword(newPassword)) {
    fieldErrors.new_password = `New password must be at least ${getPasswordMinLength()} characters.`;
  }

  if (currentPassword && newPassword && currentPassword === newPassword) {
    fieldErrors.new_password = "New password must be different from the current password.";
  }

  if (Object.keys(fieldErrors).length > 0) {
    return fail("invalid_input", "Password validation failed.", fieldErrors);
  }

  return ok({
    current_password: currentPassword,
    new_password: newPassword,
  });
}

export function validateMagicLinkPayload(
  payload: unknown,
): ValidationResult<MagicLinkPayload> {
  const input = (payload ?? {}) as Partial<MagicLinkPayload>;
  const email = normalizeEmail(input.email ?? "");

  if (!email || !isValidEmail(email)) {
    return fail("invalid_input", "A valid email address is required.", {
      email: "A valid email address is required.",
    });
  }

  return ok({ email });
}

export function validatePasswordResetRequestPayload(
  payload: unknown,
): ValidationResult<PasswordResetRequestPayload> {
  const input = (payload ?? {}) as Partial<PasswordResetRequestPayload>;
  const email = normalizeEmail(input.email ?? "");

  if (!email || !isValidEmail(email)) {
    return fail("invalid_input", "A valid email address is required.", {
      email: "A valid email address is required.",
    });
  }

  return ok({ email });
}

export function validatePasswordResetPayload(
  payload: unknown,
): ValidationResult<PasswordResetPayload> {
  const input = (payload ?? {}) as Partial<PasswordResetPayload>;
  const token = (input.token ?? "").trim();
  const newPassword = input.new_password ?? "";

  const fieldErrors: Record<string, string> = {};

  if (!token) {
    fieldErrors.token = "Reset token is required.";
  }

  if (!newPassword || !isStrongEnoughPassword(newPassword)) {
    fieldErrors.new_password = `New password must be at least ${getPasswordMinLength()} characters.`;
  }

  if (Object.keys(fieldErrors).length > 0) {
    return fail("invalid_input", "Password reset validation failed.", fieldErrors);
  }

  return ok({
    token,
    new_password: newPassword,
  });
}
