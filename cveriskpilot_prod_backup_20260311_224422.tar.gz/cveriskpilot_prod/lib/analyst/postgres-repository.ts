import type { PostgresQueryClient } from "@/lib/platform/database";
import { PostgresAppDatabase } from "@/lib/platform/database";
import { SqlAnalystDispositionRepository } from "@/lib/analyst/sql-repository";

export class PostgresAnalystDispositionRepository extends SqlAnalystDispositionRepository {
  constructor(client: PostgresQueryClient) {
    super(new PostgresAppDatabase(client));
  }
}
