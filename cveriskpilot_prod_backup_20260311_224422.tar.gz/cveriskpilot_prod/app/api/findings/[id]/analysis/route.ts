import { NextResponse } from "next/server";

import { buildAnalysisPromptContext } from "@/lib/analysis/assembler";
import { handleAnalysisRouteError } from "@/lib/analysis/http";
import { getAnalysisRuntime } from "@/lib/analysis/runtime";
import { buildAnalysisPromptEnvelope, generateFindingAnalysis } from "@/lib/analysis/service";
import { getAnalystRuntime } from "@/lib/analyst/runtime";
import { getEnrichmentRuntime } from "@/lib/enrichment/runtime";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";
import { getFindingById, mapNormalizedFindingToDashboardFinding } from "@/lib/services/findings";
import {
  GenerateFindingAnalysisRequestSchema,
  type GenerateFindingAnalysisRequest,
} from "@/types/analysis";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

async function resolveFindingContext(findingId: string, organizationId: string) {
  const [{ uploadRepository }, { enrichmentRepository }, { analystDispositionRepository }] =
    await Promise.all([getIngestionRuntime(), getEnrichmentRuntime(), getAnalystRuntime()]);

  const ingestedFinding = await uploadRepository.findFindingByIdForTenant(
    findingId,
    organizationId,
  );

  if (ingestedFinding) {
    const finding = mapNormalizedFindingToDashboardFinding(ingestedFinding);
    const [snapshots, disposition] = await Promise.all([
      enrichmentRepository.listSnapshotsByFindingId(findingId),
      analystDispositionRepository.findByFindingId(findingId),
    ]);

    return {
      finding,
      snapshots,
      disposition,
      source: "ingestion" as const,
    };
  }

  throw new Error(`Finding '${findingId}' was not found.`);
}

export async function GET(request: Request, context: RouteContext) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const { id } = await context.params;
    const resolved = await resolveFindingContext(id, auth.organizationId);
    const { analysisTraceRepository } = await getAnalysisRuntime();
    const promptContext = buildAnalysisPromptContext({
      finding: resolved.finding,
      snapshots: resolved.snapshots,
      disposition: resolved.disposition,
    });
    const prompt = buildAnalysisPromptEnvelope(promptContext);
    const traces = await analysisTraceRepository.listByFindingId(id);

    return NextResponse.json({
      ok: true,
      data: {
        source: resolved.source,
        prompt,
        traces,
      },
    });
  } catch (error) {
    return handleAnalysisRouteError(error, {
      code: "finding_analysis_prompt_failed",
      message: "Unable to prepare analysis prompt payload.",
    });
  }
}

export async function POST(request: Request, context: RouteContext) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const { id } = await context.params;
    const { analysisTraceRepository } = await getAnalysisRuntime();
    const payload = GenerateFindingAnalysisRequestSchema.parse(
      (await request.json().catch(() => ({}))) as GenerateFindingAnalysisRequest,
    );
    const resolved = await resolveFindingContext(id, auth.organizationId);
    const promptContext = buildAnalysisPromptContext({
      finding: resolved.finding,
      snapshots: resolved.snapshots,
      disposition: resolved.disposition,
    });
    const prompt = buildAnalysisPromptEnvelope(promptContext);
    const generated = await generateFindingAnalysis(promptContext, payload.mode);
    const trace = await analysisTraceRepository.create({
      findingId: id,
      source: resolved.source,
      requestedMode: payload.mode,
      generated,
      prompt,
    });
    const traces = await analysisTraceRepository.listByFindingId(id);

    return NextResponse.json({
      ok: true,
      data: {
        source: resolved.source,
        prompt,
        generated,
        trace,
        traces,
      },
      todos: [
        "TODO: add provider-specific rate limits for live Claude generation",
        "TODO: add human approval gate before replacing analyst-authored notes",
      ],
    });
  } catch (error) {
    return handleAnalysisRouteError(error, {
      code: "finding_analysis_generation_failed",
      message: "Unable to generate finding analysis.",
    });
  }
}
