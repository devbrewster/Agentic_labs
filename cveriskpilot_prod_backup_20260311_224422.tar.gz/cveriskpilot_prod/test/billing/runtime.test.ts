import { afterEach, describe, expect, it } from "vitest";

import { clearPostgresQueryClient, configurePostgresQueryClient } from "@/lib/platform/postgres";
import { getBillingRuntime } from "@/lib/billing/runtime";
import type { PostgresQueryClient } from "@/lib/platform/database";

describe("billing runtime", () => {
  afterEach(() => {
    clearPostgresQueryClient();
    delete process.env.DATABASE_URL;
  });

  it("selects the Postgres billing repository when a Postgres client is configured", async () => {
    process.env.DATABASE_URL = "postgres://example";

    const client: PostgresQueryClient = {
      async query() {
        return {
          rows: [],
          rowCount: 0,
        };
      },
    };

    configurePostgresQueryClient(client);

    const runtime = await getBillingRuntime();

    expect(runtime.billingRepository.constructor.name).toBe("PostgresBillingRepository");
  });
});
