import { StatusPill } from "@/components/dashboard/StatusPill";
import { SurfaceCard } from "@/components/dashboard/SurfaceCard";
import { listSettingsSections } from "@/lib/services/platform";

export default function SettingsPage() {
  const settingsSections = listSettingsSections();

  return (
    <div className="space-y-5">
      <SurfaceCard
        eyebrow="// Settings"
        title="Workspace configuration"
        description="Settings centralize workspace policies, AI controls, upload behavior, and analyst workflow options."
        meta={<StatusPill tone="warning">No Persistence Yet</StatusPill>}
      />

      <div className="grid gap-5 xl:grid-cols-2">
        {settingsSections.map((section) => (
          <SurfaceCard
            key={section.title}
            title={section.title}
            description={section.description}
          >
            <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] px-4 py-3 font-mono text-[0.66rem] uppercase tracking-[0.12em] text-[#5a7080]">
              Configuration inputs and policies will appear here as each settings area is activated.
            </div>
          </SurfaceCard>
        ))}
      </div>
    </div>
  );
}
