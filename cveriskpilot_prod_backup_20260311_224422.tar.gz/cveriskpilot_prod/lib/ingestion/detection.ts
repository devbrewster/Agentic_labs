import { ParserDetectionHintSchema, type ParserDetectionHint, type ParserError, type ScannerSourceType } from "@/types/ingestion";

const filenameMatchers: Record<Exclude<ScannerSourceType, "unknown">, RegExp[]> = {
  nessus: [/nessus/i, /\.nessus$/i],
  qualys: [/qualys/i, /qid/i],
  rapid7: [/rapid7/i, /insightvm/i, /nexpose/i],
  generic_csv: [/\.csv$/i, /findings/i, /vuln/i],
};

const jsonRootKeyMatchers: Record<Exclude<ScannerSourceType, "unknown">, string[]> = {
  nessus: ["NessusClientData_v2", "Report", "ReportHost"],
  qualys: ["KnowledgeBase", "VULNS", "HOST_LIST_VM_DETECTION_OUTPUT"],
  rapid7: ["resources", "vulnerabilities", "sites"],
  generic_csv: [],
};

const xmlRootTagMatchers: Record<Exclude<ScannerSourceType, "unknown">, string[]> = {
  nessus: ["NessusClientData_v2"],
  qualys: ["ASSET_DATA_REPORT", "SCAN", "HOST_LIST_VM_DETECTION_OUTPUT"],
  rapid7: ["NexposeReport", "NeXposeSimpleXML"],
  generic_csv: [],
};

const genericCsvHeaderSignals = [
  "cve",
  "title",
  "severity",
  "host",
  "hostname",
  "ip",
  "description",
] as const;

export function normalizeDetectionHint(input: ParserDetectionHint): ParserDetectionHint {
  return ParserDetectionHintSchema.parse({
    ...input,
    filename: input.filename.trim(),
    mimeType: input.mimeType.trim().toLowerCase(),
    sampleText: input.sampleText?.trim() || null,
    leadingBytes: input.leadingBytes?.trim() || null,
  });
}

export function extractCsvHeaders(sampleText: string | null) {
  if (!sampleText) {
    return [];
  }

  const [firstLine] = sampleText.split(/\r?\n/, 1);

  if (!firstLine) {
    return [];
  }

  return firstLine
    .split(",")
    .map((value) => value.trim().replace(/^"|"$/g, "").toLowerCase())
    .filter(Boolean);
}

export function extractJsonRootKeys(sampleText: string | null) {
  if (!sampleText) {
    return [];
  }

  try {
    const parsed = JSON.parse(sampleText);

    if (Array.isArray(parsed)) {
      const firstObject = parsed.find(
        (value): value is Record<string, unknown> =>
          typeof value === "object" && value !== null && !Array.isArray(value),
      );

      return firstObject ? Object.keys(firstObject) : [];
    }

    if (typeof parsed === "object" && parsed !== null) {
      return Object.keys(parsed);
    }

    return [];
  } catch {
    return [];
  }
}

export function extractXmlRootTag(sampleText: string | null) {
  if (!sampleText) {
    return null;
  }

  const match = sampleText.match(/<([A-Za-z_][\w:.-]*)[^>]*>/);
  return match?.[1] ?? null;
}

function matchesFilename(sourceType: Exclude<ScannerSourceType, "unknown">, filename: string) {
  return filenameMatchers[sourceType].some((pattern) => pattern.test(filename));
}

function matchesJsonRootKeys(
  sourceType: Exclude<ScannerSourceType, "unknown">,
  rootKeys: string[],
) {
  const normalizedKeys = rootKeys.map((key) => key.toLowerCase());
  return jsonRootKeyMatchers[sourceType].some((key) =>
    normalizedKeys.includes(key.toLowerCase()),
  );
}

function matchesXmlRootTag(
  sourceType: Exclude<ScannerSourceType, "unknown">,
  rootTag: string | null,
) {
  if (!rootTag) {
    return false;
  }

  return xmlRootTagMatchers[sourceType].some(
    (tag) => tag.toLowerCase() === rootTag.toLowerCase(),
  );
}

function matchesGenericCsv(headers: string[]) {
  const matchedSignals = genericCsvHeaderSignals.filter((header) => headers.includes(header));
  return matchedSignals.length >= 3;
}

export function detectSourceType(input: ParserDetectionHint): ScannerSourceType | null {
  const hint = normalizeDetectionHint(input);
  const headers = extractCsvHeaders(hint.sampleText);
  const jsonRootKeys = extractJsonRootKeys(hint.sampleText);
  const xmlRootTag = extractXmlRootTag(hint.sampleText);

  if (
    hint.fileType === "csv" &&
    (matchesFilename("generic_csv", hint.filename) || matchesGenericCsv(headers))
  ) {
    return "generic_csv";
  }

  for (const sourceType of ["nessus", "qualys", "rapid7"] as const) {
    if (
      matchesFilename(sourceType, hint.filename) ||
      matchesJsonRootKeys(sourceType, jsonRootKeys) ||
      matchesXmlRootTag(sourceType, xmlRootTag)
    ) {
      return sourceType;
    }
  }

  return null;
}

export function createUnknownSourceError(input: ParserDetectionHint): ParserError {
  return {
    code: "source_detection_failed",
    message: "Unable to determine the scanner source for this upload.",
    details: {
      filename: input.filename,
      fileType: input.fileType,
      mimeType: input.mimeType,
      xmlRootTag: extractXmlRootTag(input.sampleText),
      jsonRootKeys: extractJsonRootKeys(input.sampleText),
      csvHeaders: extractCsvHeaders(input.sampleText),
    },
    fatal: true,
  };
}

export function createUnsupportedSelectedSourceError(input: {
  selectedSourceType: ScannerSourceType;
  fileType: ParserDetectionHint["fileType"];
}): ParserError {
  return {
    code: "selected_source_unsupported",
    message: `Selected source '${input.selectedSourceType}' is not registered for parsing.`,
    details: {
      selectedSourceType: input.selectedSourceType,
      fileType: input.fileType,
    },
    fatal: true,
  };
}
