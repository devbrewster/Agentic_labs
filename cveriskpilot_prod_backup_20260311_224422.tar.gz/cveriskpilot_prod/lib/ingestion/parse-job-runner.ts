import { inferFileType, normalizeMimeType } from "@/lib/ingestion/files";
import type { UploadRepository } from "@/lib/ingestion/repository";
import type { StorageProvider } from "@/lib/ingestion/storage";
import type { ParserRegistry } from "@/types/ingestion";
import {
  ParseJobRunOptionsSchema,
  ParseJobRunResultSchema,
  type ParseJobRunResult,
  type ParserDetectionHint,
  type StoredParseOutcome,
  type UploadJob,
} from "@/types/ingestion";

const DETECTION_SAMPLE_BYTES = 8 * 1024;

export class ParseJobRunner {
  constructor(
    private readonly repository: UploadRepository,
    private readonly storageProvider: StorageProvider,
    private readonly parserRegistry: ParserRegistry,
  ) {}

  async run(uploadJobId: string, options?: { force?: boolean }): Promise<ParseJobRunResult> {
    const runOptions = ParseJobRunOptionsSchema.parse(options ?? {});
    const record = await this.repository.findById(uploadJobId);

    if (!record) {
      throw new Error(`Upload job ${uploadJobId} was not found.`);
    }

    const { uploadJob, rawArtifact, outcome } = record;

    const skipMessage = this.getSkipMessage(uploadJob.status, runOptions.force);

    if (skipMessage) {
      return ParseJobRunResultSchema.parse({
        uploadJob,
        outcome,
        skipped: true,
        forced: runOptions.force,
        replacedExistingOutcome: false,
        message: skipMessage,
      });
    }

    const parsingJob = await this.updateJob(uploadJob, {
      status: "parsing",
      detectedSourceType: null,
      warningCount: 0,
      findingCount: 0,
      parsedAt: null,
      updatedAt: new Date().toISOString(),
      errorSummary: null,
    });

    try {
      const artifactBuffer = await this.storageProvider.readArtifact(rawArtifact.storageKey);
      const content = artifactBuffer.toString("utf8");
      const detectionHint = this.buildDetectionHint(rawArtifact.originalFilename, rawArtifact.mimeType, content);
      const resolution = await this.parserRegistry.resolve({
        selectedSourceType: parsingJob.selectedSourceType,
        detectionHint,
      });

      if (!resolution.parser || resolution.error) {
        const failedJob = await this.updateJob(parsingJob, {
          status: "failed",
          detectedSourceType: null,
          errorSummary: resolution.error?.message ?? "No parser available for this upload.",
          updatedAt: new Date().toISOString(),
        });

        const failedOutcome: StoredParseOutcome = {
          uploadJobId: failedJob.id,
          findings: [],
          parserWarnings: [],
          parserErrors: resolution.error ? [resolution.error] : [],
          metadata: null,
          updatedAt: new Date().toISOString(),
        };

        await this.repository.saveParseOutcome(failedOutcome);

        return ParseJobRunResultSchema.parse({
          uploadJob: failedJob,
          outcome: failedOutcome,
          skipped: false,
          forced: runOptions.force,
          replacedExistingOutcome: Boolean(outcome),
          message: failedJob.errorSummary ?? "Parsing failed.",
        });
      }

      const parseResult = await resolution.parser.parse({
        artifact: rawArtifact,
        content,
        context: {
          uploadJob: parsingJob,
          rawArtifact,
          selectedSourceType: parsingJob.selectedSourceType,
          detectedSourceType: resolution.parser.sourceType,
          checksumSha256: parsingJob.checksumSha256,
          now: new Date().toISOString(),
        },
      });

      const hasFatalError = parseResult.parserErrors.some((error) => error.fatal);
      const baseUpdatedAt = new Date().toISOString();

      const parseOutcome: StoredParseOutcome = {
        uploadJobId: parsingJob.id,
        findings: parseResult.findings,
        parserWarnings: parseResult.parserWarnings,
        parserErrors: parseResult.parserErrors,
        metadata: parseResult.metadata,
        updatedAt: baseUpdatedAt,
      };

      await this.repository.saveParseOutcome(parseOutcome);

      if (hasFatalError) {
        const failedJob = await this.updateJob(parsingJob, {
          status: "failed",
          detectedSourceType: parseResult.metadata.sourceType,
          warningCount: parseResult.parserWarnings.length,
          findingCount: 0,
          parsedAt: null,
          errorSummary: parseResult.parserErrors.find((error) => error.fatal)?.message ?? "Parsing failed.",
          updatedAt: baseUpdatedAt,
        });

        return ParseJobRunResultSchema.parse({
          uploadJob: failedJob,
          outcome: parseOutcome,
          skipped: false,
          forced: runOptions.force,
          replacedExistingOutcome: Boolean(outcome),
          message: failedJob.errorSummary ?? "Parsing failed.",
        });
      }

      const parsedJob = await this.updateJob(parsingJob, {
        status: "parsed",
        detectedSourceType: parseResult.metadata.sourceType,
        warningCount: parseResult.parserWarnings.length,
        findingCount: parseResult.findings.length,
        parsedAt: parseResult.metadata.parsedAt,
        updatedAt: baseUpdatedAt,
      });

      const enrichmentPendingJob = await this.updateJob(parsedJob, {
        status: "enrichment_pending",
        updatedAt: new Date().toISOString(),
      });

      return ParseJobRunResultSchema.parse({
        uploadJob: enrichmentPendingJob,
        outcome: parseOutcome,
        skipped: false,
        forced: runOptions.force,
        replacedExistingOutcome: Boolean(outcome),
        message: outcome
          ? "Upload job reparsed and queued for enrichment."
          : "Upload job parsed and queued for enrichment.",
      });
    } catch (error) {
      const failedAt = new Date().toISOString();
      const message = error instanceof Error ? error.message : "Unexpected parse runner failure.";
      const failedJob = await this.updateJob(parsingJob, {
        status: "failed",
        errorSummary: message,
        updatedAt: failedAt,
      });

      const failedOutcome: StoredParseOutcome = {
        uploadJobId: failedJob.id,
        findings: [],
        parserWarnings: [],
        parserErrors: [
          {
            code: "parse_runner_failed",
            message,
            details: null,
            fatal: true,
          },
        ],
        metadata: null,
        updatedAt: failedAt,
      };

      await this.repository.saveParseOutcome(failedOutcome);

      return ParseJobRunResultSchema.parse({
        uploadJob: failedJob,
        outcome: failedOutcome,
        skipped: false,
        forced: runOptions.force,
        replacedExistingOutcome: Boolean(outcome),
        message,
      });
    }
  }

  private getSkipMessage(uploadStatus: UploadJob["status"], force: boolean) {
    if (uploadStatus === "parsing") {
      return force
        ? "Upload job is already parsing. Wait for the current parse to finish before forcing a re-run."
        : "Upload job is already parsing.";
    }

    if (!force && (uploadStatus === "parsed" || uploadStatus === "enrichment_pending")) {
      return "Upload job already parsed. Use force to re-run parsing.";
    }

    return null;
  }

  private async updateJob(
    uploadJob: UploadJob,
    patch: Partial<UploadJob>,
  ): Promise<UploadJob> {
    const nextJob: UploadJob = {
      ...uploadJob,
      ...patch,
    };

    await this.repository.updateUploadJob(nextJob);
    return nextJob;
  }

  private buildDetectionHint(
    originalFilename: string,
    mimeType: string,
    content: string,
  ): ParserDetectionHint {
    const sampleText = content.slice(0, DETECTION_SAMPLE_BYTES);
    const leadingBytes = sampleText.slice(0, 256);

    return {
      filename: originalFilename,
      mimeType: normalizeMimeType(mimeType),
      fileType: inferFileType({
        originalFilename,
        mimeType,
      }),
      sampleText,
      leadingBytes,
    };
  }
}
