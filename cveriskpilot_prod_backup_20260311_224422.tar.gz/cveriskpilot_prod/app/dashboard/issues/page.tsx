import { PendingIssuesReport } from "@/components/dashboard/PendingIssuesReport";
import { IssuesWorkspace } from "@/components/dashboard/IssuesWorkspace";
import { getPendingIssueSummary, listPendingIssues } from "@/lib/services/issues";

export default function IssuesPage() {
  const issues = listPendingIssues();
  const summary = getPendingIssueSummary();

  return (
    <div className="space-y-5">
      <PendingIssuesReport />
      <IssuesWorkspace issues={issues} totalOpenItems={summary.total} />
    </div>
  );
}
