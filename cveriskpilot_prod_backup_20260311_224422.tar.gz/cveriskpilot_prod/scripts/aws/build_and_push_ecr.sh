#!/usr/bin/env bash

set -euo pipefail

if [[ $# -lt 1 ]]; then
  echo "Usage: $0 <ecr-repository-uri> [image-tag]" >&2
  exit 1
fi

REPOSITORY_URI="$1"
IMAGE_TAG="${2:-latest}"
AWS_REGION="${AWS_REGION:-us-east-1}"
DEPLOY_TARGET="${DEPLOY_TARGET:-aws}"
APP_DOMAIN_HOST="${APP_DOMAIN_HOST:-app.cveriskpilot.com}"
DEPLOYMENT_MODE="${NEXT_PUBLIC_APP_DEPLOYMENT_MODE:-subdomain_root}"

ACCOUNT_REGISTRY="${REPOSITORY_URI%/*}"
FULL_IMAGE_URI="${REPOSITORY_URI}:${IMAGE_TAG}"

echo "Building image ${FULL_IMAGE_URI}"
docker build \
  --build-arg DEPLOY_TARGET="${DEPLOY_TARGET}" \
  --build-arg NEXT_PUBLIC_APP_DEPLOYMENT_MODE="${DEPLOYMENT_MODE}" \
  --build-arg NEXT_PUBLIC_APP_DOMAIN_HOST="${APP_DOMAIN_HOST}" \
  -t "${FULL_IMAGE_URI}" .

echo "Logging into ECR ${ACCOUNT_REGISTRY}"
aws ecr get-login-password --region "${AWS_REGION}" | \
  docker login --username AWS --password-stdin "${ACCOUNT_REGISTRY}"

echo "Pushing ${FULL_IMAGE_URI}"
docker push "${FULL_IMAGE_URI}"

echo "Done."
