import { describe, expect, it } from "vitest";

import { PostgresEnrichmentRepository } from "@/lib/enrichment/postgres-repository";
import type { PostgresQueryClient } from "@/lib/platform/database";

describe("PostgresEnrichmentRepository", () => {
  it("maps enrichment runs and snapshots through the shared SQL repository implementation", async () => {
    const runId = crypto.randomUUID();
    const uploadJobId = crypto.randomUUID();
    const findingId = crypto.randomUUID();

    const client: PostgresQueryClient = {
      async query<T>(sql: string, params?: readonly unknown[]) {
        if (sql.includes("FROM enrichment_runs") && sql.includes("WHERE id = $1")) {
          expect(params).toEqual([runId]);

          return {
            rows: [
              {
                id: runId,
                upload_job_id: uploadJobId,
                triggered_by: "system",
                status: "completed",
                provider_count: 2,
                success_count: 2,
                error_count: 0,
                error_summary: null,
                started_at: "2026-03-11T12:00:00.000Z",
                completed_at: "2026-03-11T12:01:00.000Z",
                created_at: "2026-03-11T12:00:00.000Z",
                updated_at: "2026-03-11T12:01:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        if (sql.includes("FROM finding_enrichment_snapshots") && sql.includes("WHERE enrichment_run_id = $1")) {
          expect(params).toEqual([runId]);

          return {
            rows: [
              {
                id: crypto.randomUUID(),
                enrichment_run_id: runId,
                finding_id: findingId,
                provider: "nvd",
                status: "enriched",
                source_url: "https://nvd.nist.gov/vuln/detail/CVE-2026-0001",
                source_version: "2.0",
                observed_at: "2026-03-11T12:01:00.000Z",
                error_code: null,
                error_message: null,
                summary_json: JSON.stringify({ summary: "NVD summary" }),
                raw_payload_json: JSON.stringify({ cve: "CVE-2026-0001" }),
                created_at: "2026-03-11T12:01:00.000Z",
                updated_at: "2026-03-11T12:01:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        if (sql.includes("FROM finding_enrichment_snapshots") && sql.includes("WHERE finding_id = $1")) {
          expect(params).toEqual([findingId]);

          return {
            rows: [
              {
                id: crypto.randomUUID(),
                enrichment_run_id: runId,
                finding_id: findingId,
                provider: "cisa_kev",
                status: "not_found",
                source_url: null,
                source_version: null,
                observed_at: "2026-03-11T12:01:00.000Z",
                error_code: null,
                error_message: null,
                summary_json: null,
                raw_payload_json: null,
                created_at: "2026-03-11T12:01:00.000Z",
                updated_at: "2026-03-11T12:01:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        throw new Error(`Unexpected SQL in test client: ${sql}`);
      },
    };

    const repository = new PostgresEnrichmentRepository(client);
    const run = await repository.findRunById(runId);
    const snapshots = await repository.listSnapshotsByFindingId(findingId);

    expect(run?.run.id).toBe(runId);
    expect(run?.snapshots).toHaveLength(1);
    expect(snapshots).toHaveLength(1);
    expect(snapshots[0]?.provider).toBe("cisa_kev");
  });
});
