## 1. Executive Summary
CVERiskPilot already ships a multi-tenant auth flow with email verification, password reset, upload ingestion, enrichment orchestration, cached workload APIs, and AI assistance hooks, all running inside a Next.js app that can target either Cloudflare Workers or the AWS container defined in the repo. Key proof points include the authenticated upload API backed by the ingestion runtime (`app/api/uploads/route.ts:10`, `lib/ingestion/runtime.ts:1`) and the findings, enrichment, and analysis routes that hydrate dashboards from normalized data and optionally call Claude when an API key exists (`app/api/findings/route.ts:18`, `app/api/enrichments/route.ts:11`, `lib/analysis/service.ts:302`).

Large portions of the UI are still scaffolding: settings advertise "No Persistence Yet," action plans and integration cards are mock data, and the upgrade page simply informs users that billing will unlock "as it becomes available" (`app/dashboard/settings/page.tsx:5`, `lib/services/action-plans.ts:1`, `lib/mock/platform.ts:34`, `app/upgrade/page.tsx:5`). Stripe checkout/portal APIs, paywall enforcement, and automated quota counters have not been implemented beyond the snapshot service (`app/api/billing/route.ts:5`, `lib/billing/service.ts:12`, `docs/production-roadmap.md:1`).

Given the working ingestion + analysis flows but heavy reliance on placeholders for monetization, integrations, admin tooling, and operations (manual D1 scripts remain the recovery plan), the product is best described as **Beta**. It is beyond MVP/Prototype because customers can self-serve uploads, findings, enrichment, password reset, and dashboards, yet it lacks the controls, billing, and automation expected of a production SaaS (`docs/admin-runbook.md:1`, `docs/production-roadmap.md:1`).

**Biggest blockers** preventing a production-ready SaaS launch:
1. **Monetization is read-only.** There is no Stripe checkout/portal, no plan gating, and no usage counters enforced on the API surface, so paid tiers cannot be sold or defended (`app/api/billing/route.ts:5`, `docs/production-roadmap.md:35`).
2. **Ingestion reliability beyond CSV is unverified.** The upload stabilization plan still calls out Generic CSV as the only guaranteed parser, and audit logs/background queues are missing, so scale or compliance requirements fail (`docs/upload-stabilization-plan.md:9`, `docs/todo-backlog.md:11`).
3. **Operations rely on manual SQL cleanup.** The admin runbook instructs engineers to delete D1 rows by checksum when artifacts drift, meaning there is no observable or auditable remediation path (`docs/admin-runbook.md:31`).
4. **Critical UI surfaces remain mock-only.** Action plans, integrations, and settings do not talk to real services, which blocks enterprise hand-offs and makes demos diverge from live data (`lib/services/action-plans.ts:1`, `lib/mock/platform.ts:34`, `app/dashboard/settings/page.tsx:5`).

## 2. Current State Assessment
- **Auth & Identity.** Email/password signup issues verification tokens, seeds a default organization, and sends Ethereal/SMTP emails; password reset and logout-all endpoints revoke sessions server-side, while "magic links" explicitly return `todo_not_implemented` (`app/api/auth/signup/route.ts:1`, `lib/mailer.ts:1`, `app/api/auth/reset/route.ts:1`, `app/api/auth/magic/route.ts:4`).
- **Tenancy & Sessions.** Every workload API calls `requireCurrentOrganizationAccess`, which reads the session cookie, enforces an active organization id, and supports a POST endpoint to switch orgs (`lib/organizations/access.ts:4`, `app/api/auth/organization/route.ts:1`).
- **Upload & Normalization.** Upload routes dedupe by checksum, enforce organization scope, and rely on the ingestion runtime that registers CSV, Nessus, Qualys, and Rapid7 parsers plus S3/local/D1 artifact storage. Integration tests prove reparsing, dedupe, and cross-org isolation work today (`app/api/uploads/route.ts:10`, `lib/ingestion/runtime.ts:1`, `test/api/uploads.integration.test.ts:33`).
- **Findings & Enrichment.** `/api/findings` hydrates dashboards from normalized findings, enrichment snapshots, and analyst dispositions, while `/api/enrichments` lets operators re-run providers on demand; the findings integration test confirms pending/enriched statuses and org filtering (`app/api/findings/route.ts:18`, `app/api/enrichments/route.ts:11`, `test/api/findings.integration.test.ts:47`).
- **AI Assistance.** Analysis routes build deterministic prompt envelopes and record trace history. Live mode falls back to stub output when CLAUDE env vars are missing, and the route still surfaces TODOs for rate limits and human approval gates, so AI governance remains soft (`app/api/findings/[id]/analysis/route.ts:85`, `lib/analysis/service.ts:302`).
- **Dashboards & Reporting.** Overview metrics and the executive summary call cached loaders that translate normalized findings into cards; however, action plan counts still come from mock data, so part of the KPI stack is aspirational (`app/api/dashboard/overview/route.ts:18`, `lib/services/reports.ts:214`, `lib/services/dashboard.ts:55`).
- **Billing & Plans.** The billing API only returns entitlements and usage snapshots with a boolean `upgradeReady` flag; there are no Stripe checkout/webhook routes, and the UI simply links to `/upgrade` for future work (`lib/billing/service.ts:12`, `app/upgrade/page.tsx:5`).
- **Integrations & Action Plans.** The board and connectors pull from hard-coded arrays, so no Jira/ServiceNow or scanner integrations actually exist beyond ingestion uploads (`lib/services/action-plans.ts:1`, `lib/mock/platform.ts:34`).
- **Security Controls.** Middleware adds strict security headers, optional dev basic auth, and host-aware rewrites, but there is no SOC logging, SIEM export, or RBAC beyond owner/reader roles (`middleware.ts:6`).
- **Operations & Observability.** Cache invalidation is in place for dashboards, yet recovery from ingestion drift is manual D1 SQL and the backlog explicitly calls for audit/event logging and telemetry improvements (`lib/cache/workload-cache.ts:1`, `docs/admin-runbook.md:31`, `docs/todo-backlog.md:11`).
- **Deployment Footprint.** The repo can build a Node 20 standalone image for AWS ECS, but production is still Cloudflare-first (`Dockerfile:1`, `wrangler.jsonc:1`, `docs/aws-saas-migration-plan.md:1`).

## 3. SaaS Gap Matrix
| Capability | Status | Evidence | Why it matters | Priority | Recommended next step |
| --- | --- | --- | --- | --- | --- |
| Auth & session hardening | ✅ Core flows live; magic links missing | `app/api/auth/signup/route.ts:1`, `app/api/auth/magic/route.ts:4` | Need predictable identity before monetization | P1 | Either ship magic-link or hide the tab on the login page and finalize MFA strategy |
| Tenant isolation | ✅ Enforced in every workload API + tests | `lib/organizations/access.ts:4`, `test/api/uploads.integration.test.ts:141` | Required for multi-org SaaS trust | P1 | Keep adding org headers in new APIs and add audit logging to prove isolation |
| Upload ingestion | 🟡 Runtime supports CSV/Nessus/Qualys/Rapid7 but stabilization plan still lists CSV as the only guaranteed format | `lib/ingestion/runtime.ts:1`, `docs/upload-stabilization-plan.md:9` | Parser gaps will block enterprise scanners | P0 | Backfill parser fixtures + add automated regression jobs for each supported format |
| Enrichment pipeline | 🟡 Triggerable, but detail panel bugs and provider telemetry are outstanding | `app/api/enrichments/route.ts:11`, `docs/todo-backlog.md:44` | Exec dashboards fall back to mock data when enrichment is stale | P0 | Close the P0 backlog items for enrichment status rendering + add provider metadata caching |
| Analyst workflow & AI | 🟡 Prompt scaffolding and trace history exist, yet live-mode guardrails are TODOs | `app/api/findings/[id]/analysis/route.ts:85` | Without approvals and rate limits, AI output is not enterprise-safe | P1 | Implement the TODOs: provider rate limits, approval gate, and trace retention |
| Billing & monetization | 🔴 Snapshot only; no paywall, checkout, or quotas | `app/api/billing/route.ts:5`, `lib/billing/service.ts:12`, `docs/production-roadmap.md:35` | Cannot convert users or enforce limits | P0 | Implement Stripe checkout/portal/webhooks plus entitlement enforcement before inviting beta cohorts |
| Integration surfaces (Jira, ServiceNow, Wiz, etc.) | 🔴 Entirely mock content | `lib/services/action-plans.ts:1`, `lib/mock/platform.ts:34` | Sales demos diverge from reality; no write-back | P1 | Define real connector APIs, start with Jira ticket export, and remove fake badges |
| Settings & admin tooling | 🔴 UI explicitly says "No Persistence Yet" | `app/dashboard/settings/page.tsx:5` | Enterprises expect workspace controls + RBAC | P1 | Build `/api/settings` CRUD that writes to org tables and expose roles beyond owner/viewer |
| Reporting | 🟡 Executive summary uses ingestion data when present but falls back to mock findings | `lib/services/reports.ts:200` | Board-ready exports need deterministic source-of-truth | P1 | Persist generated reports per org and hook the Action Plans row to real data |
| Security controls | 🟡 Basic headers & session handling exist; no audit log or anomaly monitoring | `middleware.ts:6`, `docs/todo-backlog.md:11` | Compliance teams need audit trail + alerts | P0 | Implement upload audit events + webhook-driven alerts before GA |
| Operational readiness | 🔴 Recovery runbooks rely on manual D1 SQL; no automated health signals | `docs/admin-runbook.md:31` | Manual cleanup does not scale or satisfy SOC2 | P0 | Ship automated cleanup scripts, background jobs, and metrics (queue depth, parser failure rates) |
| Deployment portability | 🟡 AWS migration plan exists and Docker image builds, but production still Cloudflare-first | `Dockerfile:1`, `docs/aws-saas-migration-plan.md:1` | Need reproducible AWS staging before enterprise pilots | P1 | Finish AWS migration chunks 12-15 (Postgres schema, ECS rollout validation) and document Secrets Manager hand-off |

## 4. Missing Screens / Pages / Workflows
- Real workspace settings CRUD (env labels, RBAC, API keys) — UI is a placeholder (`app/dashboard/settings/page.tsx:5`).
- Action plan persistence + ticket export flows; current board is mock-only (`lib/services/action-plans.ts:1`).
- Integration connector configuration wizard (Jira, ServiceNow, Wiz, etc.) — badges are static (`lib/mock/platform.ts:34`).
- Full Stripe checkout / billing portal / webhook screens (guided by `docs/production-roadmap.md:35`).
- Usage quota banners and upgrade CTA that map to real plan enforcement (`lib/billing/service.ts:12`).
- Upload audit log view + admin self-service cleanup UI (`docs/todo-backlog.md:11`).
- Multi-org switcher UI (API exists but no dashboard control) (`lib/organizations/access.ts:4`).
- Background job/queue monitoring screen for ingestion/enrichment health (`docs/admin-runbook.md:31`).
- Report export history (executive summary currently regenerates on every request) (`lib/services/reports.ts:214`).
- AI approval queue / audit panel for generated narratives (`app/api/findings/[id]/analysis/route.ts:124`).

## 5. Production Readiness Scoring
- **Product completeness – 55/100.** Core ingestion/enrichment/analysis flows work, but key UI panels (settings, action plans, integrations) are still mock data (`app/dashboard/settings/page.tsx:5`, `lib/services/action-plans.ts:1`).
- **Architecture maturity – 60/100.** Clean modular services (ingestion runtime, caching, Postgres adapters) exist, yet background jobs, queues, and audit logging are missing (`lib/ingestion/runtime.ts:1`, `docs/todo-backlog.md:11`).
- **Security maturity – 45/100.** Middleware sets strict headers and sessions are server-managed, but there is no RBAC, MFA, or audit log (`middleware.ts:6`, `docs/admin-runbook.md:31`).
- **Tenant isolation readiness – 65/100.** Every API enforces org context and tests cover cross-org access, but there is no UI for managing memberships or roles beyond "owner" (`lib/organizations/access.ts:4`, `test/api/uploads.integration.test.ts:141`).
- **AI maturity – 50/100.** Prompt scaffolding and trace storage are live, yet fallback logic is the safety net and TODOs note missing approval gates and rate limits (`lib/analysis/service.ts:322`, `app/api/findings/[id]/analysis/route.ts:124`).
- **Enterprise readiness – 35/100.** No RBAC UI, no audit exports, no integration connectors, and admin runbooks still rely on SQL scripts (`docs/admin-runbook.md:31`, `lib/mock/platform.ts:34`).
- **Operability – 40/100.** Cache invalidation and health endpoints exist, but ingestion failures require manual SQL cleanup and there is no monitoring/alerting stack (`lib/cache/workload-cache.ts:1`, `docs/admin-runbook.md:31`).
- **Monetization readiness – 25/100.** Billing snapshot service exists, yet there is no checkout, portal, webhook, or quota enforcement (`lib/billing/service.ts:12`, `app/upgrade/page.tsx:5`).
- **Developer experience – 60/100.** Strong test suite (Vitest integration tests for uploads/findings) and clear docs exist, but contributors still have to bounce between D1 + local files and AWS remains theoretical (`test/api/findings.integration.test.ts:47`, `docs/aws-saas-migration-plan.md:1`).

## 6. Recommended Roadmap
### Phase 1 – MVP SaaS blockers
- Close ingestion/enrichment P0s (detail panel accuracy, parser coverage, audit trail) to ensure every dashboard tile reflects real data (`docs/todo-backlog.md:44`, `docs/upload-stabilization-plan.md:9`).
- Build upload audit events, admin UI, and automated cleanup scripts so operations move beyond manual SQL (`docs/todo-backlog.md:11`, `docs/admin-runbook.md:31`).

### Phase 2 – Beta readiness
- Implement Stripe checkout, billing portal, webhooks, and entitlement enforcement as outlined in the production roadmap (`docs/production-roadmap.md:35`).
- Add quota meters + upgrade CTA wiring in account settings and dashboard surfaces (`lib/billing/service.ts:12`).

### Phase 3 – Production readiness
- Finish AWS portability (Postgres schema track, S3 artifact path) and run an ECS staging cutover following the AWS migration plan (`docs/aws-saas-migration-plan.md:1`).
- Ship background jobs / queue telemetry plus ingestion/enrichment monitoring to catch failures before customers do (`docs/todo-backlog.md:11`).

### Phase 4 – Enterprise readiness
- Build workspace settings persistence, RBAC (owner/admin/analyst/viewer), SIEM-friendly audit exports, and SOC2-aligned log retention (`app/dashboard/settings/page.tsx:5`, `docs/admin-runbook.md:31`).
- Replace mock action plans/integration tiles with real data sources and Jira/ServiceNow write-back flows (`lib/services/action-plans.ts:1`, `lib/mock/platform.ts:34`).

### Phase 5 – Premium differentiators
- Layer on premium AI features (approved live Claude mode with rate limits + review queue) and deep scanner connectors once the core SaaS is hardened (`app/api/findings/[id]/analysis/route.ts:124`).
- Productize the agent-mesh workflow monitor for customer-facing automation once it can run outside local dev (`app/api/agent-mesh/route.ts:7`).

## 7. Top 25 Next Tasks
| # | Task | Why now | Dependency | Owner |
| --- | --- | --- | --- | --- |
| 1 | Implement upload audit event table + API | Required for compliance and replaces manual D1 scripts (`docs/todo-backlog.md:11`) | Extend ingestion SQL + DB migrations | Backend |
| 2 | Build admin UI for reviewing upload audit trail and performing targeted cleanup | Operators currently run SQL manually (`docs/admin-runbook.md:31`) | Task #1 | Full-stack |
| 3 | Add parser fixtures + regression tests for Nessus/Qualys/Rapid7 | Plan still treats CSV as the only guaranteed format (`docs/upload-stabilization-plan.md:9`) | Existing parser classes | Backend |
| 4 | Wire ingestion background job/queue runner for Cloudflare Workers & AWS | Today parsing happens inline and can stall requests (`lib/ingestion/runtime.ts:46`) | Parser regression coverage | DevOps |
| 5 | Fix enrichment detail panel + add provider telemetry counters | P0 backlog items call this out (`docs/todo-backlog.md:44`) | Enrichment snapshot API | Frontend |
| 6 | Large-dataset findings integration test (>20 findings) to exercise hydration limits | Prevent regressions in enrichment summary hydration (`docs/todo-backlog.md:44`) | Existing Vitest setup | QA/Backend |
| 7 | Replace mock action plans with persisted records + CRUD APIs | Dashboard counts depend on fake data (`lib/services/action-plans.ts:1`) | New DB tables | Full-stack |
| 8 | Deliver Jira ticket export + ServiceNow stub integration | Customers expect workflow write-back (`lib/mock/platform.ts:34`) | Task #7 | Backend |
| 9 | Settings persistence API + UI for workspace profile, deployment mode, env labels | Settings page is non-functional (`app/dashboard/settings/page.tsx:5`) | New `/api/settings` routes | Full-stack |
| 10 | Implement Stripe Checkout Session creation endpoint | Monetization blocked (`docs/production-roadmap.md:65`) | Stripe account + config | Backend |
| 11 | Implement Stripe Billing Portal endpoint | Needed for self-service cancellations (`docs/production-roadmap.md:65`) | Task #10 | Backend |
| 12 | Add Stripe webhook handler with idempotent event store | Keeps subscriptions in sync (`docs/production-roadmap.md:86`) | Task #10 | Backend |
| 13 | Enforce entitlements (uploads/analyses/exports) at API layer | Prevent abuse once plans exist (`lib/billing/service.ts:12`) | Tasks #10-12 | Backend |
| 14 | Surface usage/quota meters + upgrade CTA banners in dashboard & account pages | Communicates limits to users (`lib/billing/service.ts:12`) | Task #13 | Frontend |
| 15 | Build multi-org switcher UI + invitation management | API exists but no UX (`lib/organizations/access.ts:4`) | None | Frontend |
| 16 | Add RBAC (owner/admin/analyst/viewer) enforcement in APIs + UI | Enterprise requirement | Task #15 | Full-stack |
| 17 | Ship MFA / device management | Complements auth hardening (`app/api/auth/login/route.ts:1`) | Core auth flows | Security |
| 18 | Automate AWS Postgres schema migration + S3 artifact configuration | Required for ECS staging cutover (`docs/aws-saas-migration-plan.md:1`) | Docker image | DevOps |
| 19 | Build ingestion/enrichment monitoring dashboard (queue depth, failure counts) | Need observability beyond manual scripts (`docs/admin-runbook.md:31`) | Background jobs | DevOps |
| 20 | Persist executive summary snapshots + export history | Today reports regenerate on each request (`lib/services/reports.ts:214`) | Storage layer | Backend |
| 21 | Add AI analysis approval queue + reviewer UI | TODO noted in route response (`app/api/findings/[id]/analysis/route.ts:124`) | Existing trace repository | Full-stack |
| 22 | Implement Claude request throttling + provider-level retry policies | Prevent expensive API overruns (`lib/analysis/service.ts:302`) | Task #21 | Backend |
| 23 | Harden `/api/agent-mesh` for staging and add feature flag | Currently dev-only but referenced in docs (`app/api/agent-mesh/route.ts:7`) | Ops secrets | DevOps |
| 24 | Document and script automated upload cleanup (checksum delete wizards) | Reduce reliance on ad-hoc SQL (`docs/admin-runbook.md:31`) | Task #1 | DevTools |
| 25 | Create SOC2-friendly audit export (CSV/JSON) for all org events | Needed for enterprise trust (`docs/todo-backlog.md:11`) | Audit event store | Backend |

## 8. Engineering Backlog
### Epic: Stripe monetization & entitlement enforcement
- **User story.** As a workspace owner, I can upgrade to Pro via Stripe and the app enforces my plan limits automatically.
- **Acceptance criteria.** Checkout + portal endpoints, signed webhooks, subscription state persisted, quota errors returned with upgrade CTAs, and usage meters visible in the account page (`docs/production-roadmap.md:35`, `lib/billing/service.ts:12`).
- **Files/components likely needed.** `app/api/billing/*`, new `/api/billing/checkout|portal|webhooks`, `app/account/page.tsx`, billing store utilities.
- **DB changes.** Add webhook event log + entitlement consumption table.
- **API changes.** New billing endpoints, plan enforcement middleware, error codes `plan_limit_reached` & `upgrade_required`.
- **Priority.** P0.

### Epic: Ingestion observability & audit
- **User story.** As an operator, I can see every upload event, parser status, and enrichment run without running SQL manually.
- **Acceptance criteria.** Append-only `upload_audit_events`, admin UI, alerting on failures, and automated cleanup scripts replace manual D1 commands (`docs/todo-backlog.md:11`, `docs/admin-runbook.md:31`).
- **Files/components likely needed.** `lib/ingestion/repository.ts`, new `app/api/admin/uploads/*`, dashboard admin pages.
- **DB changes.** New audit table + indexes.
- **API changes.** Admin-only audit list/export endpoints.
- **Priority.** P0.

### Epic: Action plan & integration reality check
- **User story.** As an analyst, I see live action plans tied to findings and can push them to Jira/ServiceNow.
- **Acceptance criteria.** Action plans stored per org, linked to findings, connectors for Jira/ServiceNow exist, and "Integration" tiles show real status (`lib/services/action-plans.ts:1`, `lib/mock/platform.ts:34`).
- **Files/components likely needed.** New DB tables, `/api/action-plans`, dashboard components.
- **DB changes.** `action_plans`, `action_plan_activity` tables.
- **API changes.** CRUD + connector webhook endpoints.
- **Priority.** P1.

### Epic: Settings, RBAC, and enterprise controls
- **User story.** As a workspace admin, I can manage organization settings, invite members with roles, and export audit logs.
- **Acceptance criteria.** Settings UI writes to persistent config, invite management + RBAC enforcement exists, audit logs exportable in CSV/JSON (`app/dashboard/settings/page.tsx:5`, `docs/todo-backlog.md:11`).
- **Files/components likely needed.** `app/dashboard/settings`, `/api/settings`, `/api/organizations/members`, audit export job.
- **DB changes.** `organization_settings`, `organization_invitations`, `audit_events` tables.
- **API changes.** Settings CRUD, invite acceptance, audit export.
- **Priority.** P1.

### Epic: AI governance and approval workflow
- **User story.** As a lead analyst, I can review AI-generated narratives before they replace human notes and see provider rate limits enforced.
- **Acceptance criteria.** Analysis POST includes approval flag, review queue UI exists, and Claude rate limits/errors propagate through structured warnings (`app/api/findings/[id]/analysis/route.ts:124`, `lib/analysis/service.ts:322`).
- **Files/components likely needed.** Analysis trace repository, dashboard approval panel.
- **DB changes.** `analysis_review_queue` table.
- **API changes.** `/api/findings/:id/analysis` extended with approval + reviewer endpoints.
- **Priority.** P1.

## 9. Final Verdict
- **Stage:** **Beta** — core ingestion, enrichment, and analysis run in production code, but monetization, integrations, and admin tooling remain placeholders per the production roadmap and upgrade screen (`docs/production-roadmap.md:1`, `app/upgrade/page.tsx:5`).
- **Top 10 missing features:** Stripe checkout & portal (`docs/production-roadmap.md:65`); usage/quota enforcement (`lib/billing/service.ts:12`); action plan persistence (`lib/services/action-plans.ts:1`); integration connectors (`lib/mock/platform.ts:34`); workspace settings CRUD (`app/dashboard/settings/page.tsx:5`); multi-org member management (`lib/organizations/access.ts:4`); upload audit log UI (`docs/todo-backlog.md:11`); automated ingestion cleanup (`docs/admin-runbook.md:31`); executive summary export history (`lib/services/reports.ts:214`); AI approval queue (`app/api/findings/[id]/analysis/route.ts:124`).
- **Top 10 missing security/architecture items:** Audit trail persistence (`docs/todo-backlog.md:11`); RBAC beyond owner/viewer (`lib/organizations/service.ts:1`); MFA/advanced auth (implied by login route only) (`app/api/auth/login/route.ts:1`); automated monitoring for ingestion/enrichment (`docs/admin-runbook.md:31`); Stripe webhook signing & secret storage (`docs/production-roadmap.md:86`); background job queue for parsing/enrichment (`lib/ingestion/runtime.ts:46`); rate limiting + approval for AI output (`app/api/findings/[id]/analysis/route.ts:124`); integration secrets management (connectors mocked) (`lib/mock/platform.ts:34`); AWS Postgres cutover automation (`docs/aws-saas-migration-plan.md:1`); SIEM/SOC2 log exports (`docs/admin-runbook.md:31`).
- **What should be built this week:**
  1. Ship ingestion audit logging + admin cleanup UI to replace manual SQL (`docs/todo-backlog.md:11`, `docs/admin-runbook.md:31`).
  2. Implement Stripe checkout + portal endpoints and start wiring usage enforcement (`docs/production-roadmap.md:65`).
  3. Replace mock action plans with persisted data and hook enrichment detail panel to stored snapshots so dashboards stop lying (`lib/services/action-plans.ts:1`, `docs/todo-backlog.md:44`).
