import { CisaKevEnrichmentProvider } from "@/lib/enrichment/providers/cisa-kev-provider";
import { NvdEnrichmentProvider } from "@/lib/enrichment/providers/nvd-provider";
import { EnrichmentService } from "@/lib/enrichment/service";

export function createDefaultEnrichmentService() {
  return new EnrichmentService([
    new NvdEnrichmentProvider(),
    new CisaKevEnrichmentProvider(),
  ]);
}

