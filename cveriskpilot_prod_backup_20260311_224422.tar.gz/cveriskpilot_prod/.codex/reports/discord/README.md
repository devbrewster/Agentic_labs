# Discord Handoff Reports

These files are Discord-ready status updates derived from the completed individual mesh reports.

Current source basis:
- `.codex/reports/individual/orchestrator-assessment.md`
- `.codex/reports/individual/pm-agent-assessment.md`
- `.codex/reports/individual/product-ux-assessment.md`
- `.codex/reports/individual/security-platform-assessment.md`

Files:
- `executive-update.md`
- `product-ux-update.md`
- `security-platform-update.md`
- `billing-monetization-update.md`
- `recommended-next-actions.md`
- `pending-issues-status.md`

Important:
- These are based on completed individual reports only.
- They should not be treated as a final unified assessment.
- If a final unified report is completed later, regenerate these messages from that source of truth.
- The pending-issues export is generated from `data/pending-issues.json` via:
  - `npm run issues:generate`
