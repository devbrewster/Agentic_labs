import { NextResponse } from "next/server";

import { handleAnalystRouteError } from "@/lib/analyst/http";
import { getAnalystRuntime } from "@/lib/analyst/runtime";
import { invalidateOrganizationWorkloadCache } from "@/lib/cache/workload-cache";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";
import {
  UpsertAnalystDispositionInputSchema,
  type AnalystDispositionResponse,
} from "@/types/analyst";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function GET(request: Request, context: RouteContext) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const { id } = await context.params;
    const { uploadRepository } = await getIngestionRuntime();
    const finding = await uploadRepository.findFindingByIdForTenant(id, auth.organizationId);

    if (!finding) {
      return NextResponse.json(
        {
          ok: false,
          error: {
            code: "finding_not_found",
            message: "Finding was not found.",
          },
        },
        { status: 404 },
      );
    }

    const { analystDispositionRepository } = await getAnalystRuntime();
    const [disposition, history] = await Promise.all([
      analystDispositionRepository.findByFindingId(id),
      analystDispositionRepository.listHistoryByFindingId(id),
    ]);

    return NextResponse.json({
      ok: true,
      data: {
        disposition,
        history,
      } satisfies AnalystDispositionResponse,
    });
  } catch (error) {
    return handleAnalystRouteError(error, {
      code: "finding_disposition_fetch_failed",
      message: "Unable to retrieve analyst disposition.",
    });
  }
}

export async function PATCH(request: Request, context: RouteContext) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const { id } = await context.params;
    const { uploadRepository } = await getIngestionRuntime();
    const finding = await uploadRepository.findFindingByIdForTenant(id, auth.organizationId);

    if (!finding) {
      return NextResponse.json(
        {
          ok: false,
          error: {
            code: "finding_not_found",
            message: "Finding was not found.",
          },
        },
        { status: 404 },
      );
    }

    const payload = UpsertAnalystDispositionInputSchema.parse(await request.json());
    const { analystDispositionRepository } = await getAnalystRuntime();
    const data = await analystDispositionRepository.upsertByFindingId(id, payload);

    invalidateOrganizationWorkloadCache(auth.organizationId);

    return NextResponse.json({
      ok: true,
      data,
    });
  } catch (error) {
    return handleAnalystRouteError(error, {
      code: "finding_disposition_update_failed",
      message: "Unable to persist analyst disposition.",
    });
  }
}
