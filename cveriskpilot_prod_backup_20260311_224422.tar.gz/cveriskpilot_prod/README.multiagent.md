# CVERiskPilot Codex Multi-Agent Workspace

## Prompt source directory
The script auto-loads prompts from:
- agent-prompts/orchestrator.md
- agent-prompts/pm_agent.md
- agent-prompts/product-ux.md
- agent-prompts/security-platform.md

## Flow
1. Independent assessments
2. Cross-review
3. Merge source bundle
4. Final unified assessment

## Commands
./scripts/launch-agent-windows.sh
./scripts/prepare-codex-session.sh
./scripts/merge-agent-assessments.sh
./scripts/launch-agent-tmux.sh
./scripts/run-agent-mesh.sh

## Autonomous Run
Run the full mesh workflow:

```bash
./scripts/run-agent-mesh.sh
```

Preview the workflow without calling Codex:

```bash
./scripts/run-agent-mesh.sh --dry-run
```
