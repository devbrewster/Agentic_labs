# {{AGENT_NAME}} Assessment

## Scope Reviewed
- Product
- Architecture
- Security
- UX
- Platform
- Operations
- SaaS business readiness

## Current State Observed
- 

## Missing for True Production SaaS
### Critical
- 

### High
- 

### Medium
- 

### Low
- 

## Evidence / Code Areas Reviewed
- 

## Risks if Not Addressed
- 

## Recommended Next Steps
1. 
2. 
3. 

## Cross-Review of Other Agents
### Agreements
- 

### Blind Spots Found
- 

### Disagreements / Conflicts
- 

## Final Agent Verdict
- Not production ready / Partially ready / Ready with conditions