import { createDefaultEnrichmentService } from "@/lib/enrichment";
import { integrationCards } from "@/lib/mock/platform";

export function listIntegrationConnectors() {
  return integrationCards;
}

export function getEnrichmentService() {
  return createDefaultEnrichmentService();
}

// TODO: Claude API integration will live here for business-impact and remediation generation.
// TODO: Wiz ingestion and normalization client will live here.
// TODO: Snyk ingestion and normalization client will live here.
