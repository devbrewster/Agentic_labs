#!/usr/bin/env node

import { mkdir, readFile, writeFile } from "node:fs/promises";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const repoRoot = path.resolve(__dirname, "..");

const issuesPath = path.join(repoRoot, "data", "pending-issues.json");
const internalReportPath = path.join(repoRoot, "docs", "issues-status-report.md");
const discordReportPath = path.join(
  repoRoot,
  ".codex",
  "reports",
  "discord",
  "pending-issues-status.md",
);

const issuePriorityOrder = {
  "P0 Now": 0,
  "P1 Next": 1,
  "P2 Later": 2,
};

const issueStatusOrder = {
  in_progress: 0,
  blocked: 1,
  queued: 2,
  monitoring: 3,
  completed: 4,
};

const issueTrackLabels = {
  dashboard_access: "Dashboard Access",
  ingestion: "Ingestion",
  enrichment: "Enrichment",
  billing: "Billing",
  audit: "Audit",
  ui: "UI",
};

function formatIssueStatus(status) {
  return status.replaceAll("_", " ");
}

function sortIssues(issues) {
  return [...issues].sort((left, right) => {
    const priorityDifference =
      issuePriorityOrder[left.priority] - issuePriorityOrder[right.priority];

    if (priorityDifference !== 0) {
      return priorityDifference;
    }

    const statusDifference =
      issueStatusOrder[left.status] - issueStatusOrder[right.status];

    if (statusDifference !== 0) {
      return statusDifference;
    }

    return left.id.localeCompare(right.id);
  });
}

function buildSummary(issues) {
  return {
    total: issues.length,
    byPriority: {
      p0: issues.filter((issue) => issue.priority === "P0 Now").length,
      p1: issues.filter((issue) => issue.priority === "P1 Next").length,
      p2: issues.filter((issue) => issue.priority === "P2 Later").length,
    },
    byStatus: {
      inProgress: issues.filter((issue) => issue.status === "in_progress").length,
      blocked: issues.filter((issue) => issue.status === "blocked").length,
      queued: issues.filter((issue) => issue.status === "queued").length,
      monitoring: issues.filter((issue) => issue.status === "monitoring").length,
    },
  };
}

function buildDiscordReport(issues) {
  return [
    "**CVERiskPilot Pending Issues Status**",
    "",
    "Using the current structured internal issue list.",
    "",
    ...issues.map((issue) =>
      [
        `**${issue.id} · ${issue.priority} · ${formatIssueStatus(issue.status)}**`,
        `${issue.title}`,
        `Track: ${issueTrackLabels[issue.track]}`,
        `Impact: ${issue.impact}`,
        `Next: ${issue.nextAction}`,
      ].join("\n"),
    ),
    "",
  ].join("\n\n");
}

function buildInternalReport(issues, summary) {
  return [
    "# CVERiskPilot Pending Issues Status Report",
    "",
    `Last updated: ${new Date().toISOString().slice(0, 10)}`,
    "",
    "## Summary",
    "",
    `- Total open issues: ${summary.total}`,
    `- P0 Now: ${summary.byPriority.p0}`,
    `- P1 Next: ${summary.byPriority.p1}`,
    `- P2 Later: ${summary.byPriority.p2}`,
    `- In progress: ${summary.byStatus.inProgress}`,
    `- Blocked: ${summary.byStatus.blocked}`,
    `- Queued: ${summary.byStatus.queued}`,
    `- Monitoring: ${summary.byStatus.monitoring}`,
    "",
    "## Structured issue list",
    "",
    ...issues.flatMap((issue) => [
      `### ${issue.id} - ${issue.title}`,
      "",
      `- Priority: ${issue.priority}`,
      `- Status: ${formatIssueStatus(issue.status)}`,
      `- Track: ${issueTrackLabels[issue.track]}`,
      `- Summary: ${issue.summary}`,
      `- Impact: ${issue.impact}`,
      `- Next action: ${issue.nextAction}`,
      "",
    ]),
  ].join("\n");
}

async function main() {
  const raw = await readFile(issuesPath, "utf8");
  const parsed = JSON.parse(raw);
  const issues = sortIssues(parsed);
  const summary = buildSummary(issues);

  await mkdir(path.dirname(internalReportPath), { recursive: true });
  await mkdir(path.dirname(discordReportPath), { recursive: true });

  await writeFile(internalReportPath, buildInternalReport(issues, summary), "utf8");
  await writeFile(discordReportPath, buildDiscordReport(issues), "utf8");

  process.stdout.write(
    `Generated issue reports for ${issues.length} issues.\n- ${internalReportPath}\n- ${discordReportPath}\n`,
  );
}

main().catch((error) => {
  console.error(error);
  process.exitCode = 1;
});
