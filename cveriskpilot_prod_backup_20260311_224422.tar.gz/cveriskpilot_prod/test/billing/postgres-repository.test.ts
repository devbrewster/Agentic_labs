import { describe, expect, it } from "vitest";

import { PostgresBillingRepository } from "@/lib/billing/postgres-repository";
import type { PostgresQueryClient } from "@/lib/platform/database";

describe("PostgresBillingRepository", () => {
  it("maps billing records through the shared SQL repository implementation", async () => {
    const organizationId = crypto.randomUUID();

    const client: PostgresQueryClient = {
      async query<T>(sql: string, params?: readonly unknown[]) {
        if (sql.includes("FROM billing_customers")) {
          expect(sql).toContain("WHERE organization_id = $1");
          expect(params).toEqual([organizationId]);

          return {
            rows: [
              {
                organization_id: organizationId,
                stripe_customer_id: "cus_pg_123",
                created_at: "2026-03-01T00:00:00.000Z",
                updated_at: "2026-03-01T00:00:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        if (sql.includes("FROM subscriptions")) {
          expect(sql).toContain("WHERE organization_id = $1");
          expect(params).toEqual([organizationId]);

          return {
            rows: [
              {
                organization_id: organizationId,
                stripe_subscription_id: "sub_pg_123",
                status: "active",
                price_id: "price_pg_pro",
                current_period_start: "2026-03-01T00:00:00.000Z",
                current_period_end: "2026-04-01T00:00:00.000Z",
                cancel_at_period_end: false,
                created_at: "2026-03-01T00:00:00.000Z",
                updated_at: "2026-03-01T00:00:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        if (sql.includes("FROM usage_counters")) {
          expect(sql).toContain("WHERE organization_id = $1 AND period_start = $2 AND period_end = $3");
          expect(params).toEqual([
            organizationId,
            "2026-03-01T00:00:00.000Z",
            "2026-04-01T00:00:00.000Z",
          ]);

          return {
            rows: [
              {
                organization_id: organizationId,
                period_start: "2026-03-01T00:00:00.000Z",
                period_end: "2026-04-01T00:00:00.000Z",
                uploads_used: 3,
                analyses_used: 8,
                cve_lookups_used: 12,
                exports_used: 1,
                updated_at: "2026-03-11T12:00:00.000Z",
              },
            ] as T[],
            rowCount: 1,
          };
        }

        throw new Error(`Unexpected SQL in test client: ${sql}`);
      },
    };

    const repository = new PostgresBillingRepository(client);
    const [customer, subscription, usage] = await Promise.all([
      repository.findCustomerByOrganizationId(organizationId),
      repository.findSubscriptionByOrganizationId(organizationId),
      repository.findUsageCounter(
        organizationId,
        "2026-03-01T00:00:00.000Z",
        "2026-04-01T00:00:00.000Z",
      ),
    ]);

    expect(customer?.stripeCustomerId).toBe("cus_pg_123");
    expect(subscription?.stripeSubscriptionId).toBe("sub_pg_123");
    expect(usage?.uploadsUsed).toBe(3);
    expect(usage?.analysesUsed).toBe(8);
  });
});
