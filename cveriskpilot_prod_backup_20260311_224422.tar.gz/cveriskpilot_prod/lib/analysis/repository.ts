import {
  AnalysisTraceRecordSchema,
  type AnalysisTraceRecord,
  type CreateAnalysisTraceInput,
} from "@/types/analysis";

function buildTraceRecord(input: CreateAnalysisTraceInput): AnalysisTraceRecord {
  const now = new Date().toISOString();

  return AnalysisTraceRecordSchema.parse({
    id: crypto.randomUUID(),
    findingId: input.findingId,
    source: input.source,
    requestedMode: input.requestedMode,
    provider: input.generated.provider,
    model: input.generated.model,
    templateVersion: input.prompt.templateVersion,
    traceStatus: input.generated.traceStatus,
    fallbackReason: input.generated.fallbackReason,
    warningCount: input.generated.warnings.length,
    generatedAt: input.generated.generatedAt,
    createdAt: now,
    promptContextJson: input.prompt.context,
    promptEnvelopeJson: input.prompt,
    outputJson: input.generated.output,
    warningsJson: input.generated.warnings,
  });
}

export type AnalysisTraceRepository = {
  create(input: CreateAnalysisTraceInput): Promise<AnalysisTraceRecord>;
  listByFindingId(findingId: string): Promise<AnalysisTraceRecord[]>;
};

export class InMemoryAnalysisTraceRepository implements AnalysisTraceRepository {
  private readonly records = new Map<string, AnalysisTraceRecord[]>();

  async create(input: CreateAnalysisTraceInput): Promise<AnalysisTraceRecord> {
    const record = buildTraceRecord(input);
    const existing = this.records.get(record.findingId) ?? [];
    this.records.set(record.findingId, [record, ...existing]);
    return AnalysisTraceRecordSchema.parse(record);
  }

  async listByFindingId(findingId: string): Promise<AnalysisTraceRecord[]> {
    return (this.records.get(findingId) ?? []).map((record) =>
      AnalysisTraceRecordSchema.parse(record),
    );
  }
}
