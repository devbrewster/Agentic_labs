import {
  NVD_API_BASE_URL_DEFAULT,
  NVD_CLIENT_USER_AGENT,
  NVD_CVE_ID_PATTERN,
  NVD_RATE_LIMIT_KEYED_PER_30S_DEFAULT,
  NVD_RATE_LIMIT_PUBLIC_PER_30S_DEFAULT,
  NVD_REQUEST_TIMEOUT_MS_DEFAULT,
  NVD_CACHE_TTL_MINUTES_DEFAULT,
} from "@/lib/nvd/constants";
import { buildNvdCacheKey, InMemoryNvdCache, isCacheEntryFresh, type NvdCacheProvider } from "@/lib/nvd/cache";
import { normalizeNvdCve } from "@/lib/nvd/normalize";
import { RollingWindowRateLimiter } from "@/lib/nvd/rateLimiter";
import type { NvdApiResponse, NvdClientError, NvdClientResult } from "@/lib/nvd/types";

type FetchLike = typeof fetch;

export type NvdClientOptions = {
  apiKey: string | null;
  baseUrl: string;
  requestTimeoutMs: number;
  cacheTtlMinutes: number;
  publicLimitPer30s: number;
  keyedLimitPer30s: number;
};

function toPositiveInt(value: string | undefined, fallback: number) {
  if (!value) {
    return fallback;
  }

  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return fallback;
  }
  return Math.floor(parsed);
}

function sanitizeLogMessage(error: unknown) {
  if (!(error instanceof Error)) {
    return "Unknown NVD error";
  }
  return error.message.replace(/api[-_ ]?key\s*[:=]\s*[^,\s]+/gi, "api_key=[redacted]");
}

function buildClientOptions(): NvdClientOptions {
  return {
    apiKey: process.env.NVD_API_KEY?.trim() || null,
    baseUrl: process.env.NVD_API_BASE_URL?.trim() || NVD_API_BASE_URL_DEFAULT,
    requestTimeoutMs: toPositiveInt(process.env.NVD_REQUEST_TIMEOUT_MS, NVD_REQUEST_TIMEOUT_MS_DEFAULT),
    cacheTtlMinutes: toPositiveInt(process.env.NVD_CACHE_TTL_MINUTES, NVD_CACHE_TTL_MINUTES_DEFAULT),
    publicLimitPer30s: toPositiveInt(
      process.env.NVD_RATE_LIMIT_PUBLIC_PER_30S,
      NVD_RATE_LIMIT_PUBLIC_PER_30S_DEFAULT,
    ),
    keyedLimitPer30s: toPositiveInt(
      process.env.NVD_RATE_LIMIT_KEYED_PER_30S,
      NVD_RATE_LIMIT_KEYED_PER_30S_DEFAULT,
    ),
  };
}

function createClientError(
  input: Omit<NvdClientError, "fromCache"> & { fromCache?: boolean },
): NvdClientError {
  return {
    ...input,
    fromCache: input.fromCache ?? false,
  };
}

export class NvdClient {
  private readonly limiter: RollingWindowRateLimiter;
  private readonly inFlightRequests = new Map<string, Promise<NvdClientResult>>();

  constructor(
    private readonly options: NvdClientOptions,
    private readonly cache: NvdCacheProvider,
    private readonly fetcher: FetchLike = fetch,
  ) {
    const limit = options.apiKey ? options.keyedLimitPer30s : options.publicLimitPer30s;
    this.limiter = new RollingWindowRateLimiter(limit);
  }

  async getCveById(inputCveId: string): Promise<NvdClientResult> {
    const cveId = inputCveId.trim().toUpperCase();

    if (!NVD_CVE_ID_PATTERN.test(cveId)) {
      return {
        ok: false,
        error: createClientError({
          code: "invalid_cve_id",
          message: "CVE ID format is invalid.",
          retriable: false,
        }),
        meta: {
          source: "none",
          fetchedAt: null,
          cacheHit: false,
          stale: false,
        },
      };
    }

    const dedupeKey = `cve:${cveId}`;
    const existing = this.inFlightRequests.get(dedupeKey);
    if (existing) {
      return existing;
    }

    const requestPromise = this.resolveCve(cveId).finally(() => {
      this.inFlightRequests.delete(dedupeKey);
    });
    this.inFlightRequests.set(dedupeKey, requestPromise);
    return requestPromise;
  }

  async searchCves(params: {
    keywordSearch?: string;
    cveId?: string;
    startIndex?: number;
    resultsPerPage?: number;
    lastModStartDate?: string;
    lastModEndDate?: string;
  }): Promise<NvdApiResponse> {
    const url = new URL(`${this.options.baseUrl}/cves/2.0`);

    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== null && value !== "") {
        url.searchParams.set(key, String(value));
      }
    }

    const response = await this.fetchWithRetries(url);
    return (await response.json()) as NvdApiResponse;
  }

  private async resolveCve(cveId: string): Promise<NvdClientResult> {
    const cacheKey = buildNvdCacheKey(cveId);
    const now = new Date().toISOString();
    const cachedEntry = await this.cache.get(cacheKey);

    if (cachedEntry && isCacheEntryFresh(cachedEntry, now)) {
      return {
        ok: true,
        data: cachedEntry.normalized,
        meta: {
          source: "nvd_cache_fresh",
          fetchedAt: cachedEntry.fetchedAt,
          cacheHit: true,
          stale: false,
        },
      };
    }

    try {
      const url = new URL(`${this.options.baseUrl}/cves/2.0`);
      url.searchParams.set("cveId", cveId);

      const response = await this.fetchWithRetries(url);
      const payload = (await response.json()) as NvdApiResponse;
      const normalized = normalizeNvdCve(payload);

      if (!normalized) {
        return {
          ok: false,
          error: createClientError({
            code: "bad_response",
            message: `NVD did not return vulnerability data for ${cveId}.`,
            retriable: false,
          }),
          meta: {
            source: "nvd_live",
            fetchedAt: now,
            cacheHit: false,
            stale: false,
          },
        };
      }

      const fetchedAt = new Date().toISOString();
      const expiresAt = new Date(
        Date.now() + this.options.cacheTtlMinutes * 60 * 1000,
      ).toISOString();

      await this.cache.set({
        key: cacheKey,
        cveId,
        fetchedAt,
        expiresAt,
        rawPayload: payload,
        normalized,
      });

      return {
        ok: true,
        data: normalized,
        meta: {
          source: "nvd_live",
          fetchedAt,
          cacheHit: false,
          stale: false,
        },
      };
    } catch (error) {
      console.error("NVD fetch failure:", sanitizeLogMessage(error));

      if (cachedEntry) {
        return {
          ok: true,
          data: cachedEntry.normalized,
          meta: {
            source: "nvd_cache_stale",
            fetchedAt: cachedEntry.fetchedAt,
            cacheHit: true,
            stale: true,
          },
        };
      }

      const typedError = this.toClientError(error);
      return {
        ok: false,
        error: typedError,
        meta: {
          source: "none",
          fetchedAt: null,
          cacheHit: false,
          stale: false,
        },
      };
    }
  }

  private toClientError(error: unknown): NvdClientError {
    if (error && typeof error === "object" && "code" in error) {
      const code = String((error as { code?: string }).code);
      if (code === "ABORT_ERR") {
        return createClientError({
          code: "request_timeout",
          message: "NVD request timed out.",
          retriable: true,
        });
      }
    }

    if (error instanceof Error && /429/.test(error.message)) {
      return createClientError({
        code: "rate_limited",
        message: "NVD rate limit exceeded.",
        status: 429,
        retriable: true,
      });
    }

    if (error instanceof Error && /5\d\d/.test(error.message)) {
      return createClientError({
        code: "upstream_error",
        message: "NVD upstream service error.",
        retriable: true,
      });
    }

    return createClientError({
      code: "network_error",
      message: error instanceof Error ? error.message : "NVD request failed.",
      retriable: true,
    });
  }

  private async fetchWithRetries(url: URL) {
    const maxAttempts = 3;
    let attempt = 0;

    while (attempt < maxAttempts) {
      attempt += 1;

      try {
        return await this.limiter.schedule(async () => {
          const controller = new AbortController();
          const timer = setTimeout(() => {
            controller.abort();
          }, this.options.requestTimeoutMs);

          try {
            const response = await this.fetcher(url, {
              method: "GET",
              headers: {
                accept: "application/json",
                "content-type": "application/json",
                "user-agent": NVD_CLIENT_USER_AGENT,
                ...(this.options.apiKey ? { apiKey: this.options.apiKey } : {}),
              },
              signal: controller.signal,
            });

            if (response.status === 429 || response.status >= 500) {
              throw new Error(`NVD HTTP ${response.status}`);
            }

            if (!response.ok) {
              throw new Error(`NVD HTTP ${response.status}`);
            }

            return response;
          } finally {
            clearTimeout(timer);
          }
        });
      } catch (error) {
        const shouldRetry =
          error instanceof Error &&
          (/429/.test(error.message) || /5\d\d/.test(error.message) || /timed out/i.test(error.message));

        if (!shouldRetry || attempt >= maxAttempts) {
          throw error;
        }

        const backoffMs = 250 * attempt * attempt;
        await new Promise<void>((resolve) => {
          setTimeout(resolve, backoffMs);
        });
      }
    }

    throw new Error("NVD request failed after retries.");
  }
}

let singletonClient: NvdClient | null = null;

export function getNvdClient() {
  if (!singletonClient) {
    singletonClient = new NvdClient(
      buildClientOptions(),
      new InMemoryNvdCache(),
      fetch,
    );
  }

  return singletonClient;
}

export function __resetNvdClientForTests() {
  singletonClient = null;
}
