export type IssuePriority = "P0 Now" | "P1 Next" | "P2 Later";
export type IssueStatus =
  | "in_progress"
  | "queued"
  | "blocked"
  | "monitoring"
  | "completed";

export type IssueTrack =
  | "dashboard_access"
  | "ingestion"
  | "enrichment"
  | "billing"
  | "audit"
  | "ui";

export type PendingIssue = {
  id: string;
  title: string;
  priority: IssuePriority;
  status: IssueStatus;
  track: IssueTrack;
  summary: string;
  impact: string;
  nextAction: string;
};
