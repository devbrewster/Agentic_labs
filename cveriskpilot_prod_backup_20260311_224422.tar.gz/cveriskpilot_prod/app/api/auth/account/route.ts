import { NextResponse } from "next/server";

import { apiError, deleteUserAccount, withAuthRoute } from "@/lib/auth";
import { clearSessionCookie, requireAuthenticatedSession } from "@/lib/session";

export const DELETE = withAuthRoute(async function DELETE(request: Request) {
  const auth = await requireAuthenticatedSession(request);

  if (!auth.ok) {
    return auth.response;
  }

  try {
    await deleteUserAccount(auth.session.user.id);
  } catch (error) {
    console.error("Account delete failed:", error);
    return apiError("account_delete_failed", "Unable to delete account.", 500);
  }

  const response = NextResponse.json(
    {
      ok: true,
      data: {
        message: "Account deleted.",
      },
    },
    { status: 200 },
  );

  clearSessionCookie(response, request);
  return response;
});
