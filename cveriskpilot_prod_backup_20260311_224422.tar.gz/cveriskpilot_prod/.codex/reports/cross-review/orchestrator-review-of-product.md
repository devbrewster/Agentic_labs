# Cross-Review – Product/UX Assessment

## Agreements
- Multi-user workspace management is still missing from the dashboard: the nav model (`lib/mock/dashboard.ts:1-64`) never surfaces invites or membership CRUD even though the organization service only seeds a default owner on signup (`lib/organizations/service.ts:55-107`).
- The magic-link tab is misleading because the backing API always returns `todo_not_implemented` (`app/api/auth/magic/route.ts:12-16`).
- Workspace settings remains a placeholder; the page literally surfaces a "No Persistence Yet" pill and static cards pulled from mocks (`app/dashboard/settings/page.tsx:10-34`).

## Conflicts & Overstatements
- The report claims the executive summary only falls back to mock content on runtime errors. In practice the page renders a global snapshot because it calls `getExecutiveSummaryReport()` with no tenant context (`app/dashboard/reports/page.tsx:5-33`), and the service itself silently swaps to mock data whenever there are zero normalized findings (`lib/services/reports.ts:134-209`). That means most customers still see demo data even when the API succeeds.
- Billing “account snapshot + quotas” are described as live, but the default runtime downgrades to `InMemoryBillingRepository`, whose methods all return null and discard writes (`lib/billing/runtime.ts:1-54`, `lib/billing/repository.ts:24-47`). Usage counters never persist, so the UI is reading synthetic values rather than actual consumption.
- “Normalized findings + AI enrichment” are positioned as production-ready, yet the generation route explicitly ships TODOs for rate limiting and human approval before replacing analyst notes (`app/api/findings/[id]/analysis/route.ts:86-112`). Calling this workflow finished overstates its readiness for paying customers.

## Blind Spots / Missing Evidence
- The reports server component bypasses any session-scoped guardrail; because it runs on the server without `requireCurrentOrganizationAccess` it can aggregate findings across all tenants via `uploadRepository.normalizedFindings.listAll()` when no org is passed (`app/dashboard/reports/page.tsx:5-20`, `lib/services/reports.ts:169-184`). The assessment never mentions this cross-tenant leakage risk.
- Ingestion durability is still contingent on optional infrastructure. When Cloudflare D1 or Postgres bindings are absent, the runtime silently falls back to `InMemoryUploadRepository` and `LocalFileStorage`, which are process-local and not multi-instance safe (`lib/ingestion/runtime.ts:34-118`). The product write-up treats ingestion as production grade without acknowledging this operational gap.
- The review does not mention that billing usage never increments because the repository implementation is a stub; without actual `upsertUsageCounter` writes, quotas shown on `app/account/page.tsx` are static numbers and cannot enforce plan limits.

## Recommended Changes before Consolidation
1. Reword the executive-summary section to reflect the current behavior (mock fallback when the tenant has no data and server-side rendering without org scoping) and demand a plan to route the dashboard through `/api/reports/executive-summary`'s tenant-aware path.
2. Call out that billing, usage tracking, and upgrade readiness are stubs until a real Stripe-backed repository is wired; otherwise the orchestrator will assume monetization is closer to done than it is.
3. Flag AI analysis workflows as PARTIAL until the TODOs for rate limits and analyst approval are closed; link to `app/api/findings/[id]/analysis/route.ts` so the implementation agent can prioritize the safeguards.
4. Add an explicit note on ingestion storage and multi-tenant isolation so we can track the work to remove in-memory fallbacks prior to any production go-live.
