import { NextResponse } from "next/server";

import { withAuthRoute } from "@/lib/auth";
import {
  clearSessionCookie,
  requireAuthenticatedSession,
  revokeAllSessions,
} from "@/lib/session";

export const POST = withAuthRoute(async function POST(request: Request) {
  const auth = await requireAuthenticatedSession(request);

  if (!auth.ok) {
    return auth.response;
  }

  await revokeAllSessions(auth.session.user.id);

  const response = NextResponse.json(
    {
      ok: true,
      data: {
        message: "All sessions revoked.",
      },
    },
    { status: 200 },
  );

  clearSessionCookie(response, request);
  return response;
});
