import { NextResponse } from "next/server";

import { DbSchemaNotInitializedError } from "@/lib/db";

export function handleAnalystRouteError(
  error: unknown,
  fallback: {
    code: string;
    message: string;
  },
) {
  if (error instanceof Error && error.name === "ZodError") {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "invalid_request",
          message: "Request validation failed.",
          details: error.message,
        },
      },
      { status: 400 },
    );
  }

  if (error instanceof DbSchemaNotInitializedError) {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "analyst_schema_not_initialized",
          message:
            "Analyst disposition schema is not initialized. Run `npm run db:migrate:local` before testing locally.",
        },
      },
      { status: 500 },
    );
  }

  console.error(fallback.message, error);

  return NextResponse.json(
    {
      ok: false,
      error: {
        code: fallback.code,
        message: fallback.message,
      },
    },
    { status: 500 },
  );
}
