import { reportCards, settingsSections } from "@/lib/mock/platform";

export function listReportCards() {
  return reportCards;
}

export function listSettingsSections() {
  return settingsSections;
}
