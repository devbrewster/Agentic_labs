import { describe, expect, it } from "vitest";

import {
  buildDefaultOrganizationName,
  buildUniqueOrganizationSlug,
  resolveActiveOrganizationId,
} from "@/lib/organizations/service";

describe("organization service helpers", () => {
  it("builds a default workspace name from display name", () => {
    expect(buildDefaultOrganizationName("Sec Analyst", "analyst@example.com")).toBe(
      "Sec Analyst Workspace",
    );
  });

  it("builds a unique organization slug with a stable suffix", () => {
    expect(
      buildUniqueOrganizationSlug(
        "Blue Team Ops",
        "ops@example.com",
        "12345678-90ab-cdef-1234-567890abcdef",
      ),
    ).toBe("blue-team-ops-12345678");
  });

  it("prefers the persisted active organization when it still exists", () => {
    const organizationId = crypto.randomUUID();

    expect(
      resolveActiveOrganizationId(
        {
          organizationId,
          memberships: [
            {
              organization: {
                id: organizationId,
                name: "Acme",
                slug: "acme",
                status: "active",
                createdAt: new Date().toISOString(),
                updatedAt: new Date().toISOString(),
              },
              member: {
                id: crypto.randomUUID(),
                organizationId,
                userId: crypto.randomUUID(),
                role: "owner",
                joinedAt: new Date().toISOString(),
                invitedByUserId: null,
              },
            },
          ],
        },
        organizationId,
      ),
    ).toBe(organizationId);
  });
});
