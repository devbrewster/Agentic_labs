import { dbRun } from "@/lib/db";
import { getOrganizationRuntime } from "@/lib/organizations/runtime";
import type { CurrentOrganizationContext, OrganizationId } from "@/types/organization";

function slugify(value: string) {
  return value
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .replace(/-{2,}/g, "-");
}

export function buildDefaultOrganizationName(displayName: string, email: string) {
  const trimmedDisplayName = displayName.trim();

  if (trimmedDisplayName.length > 0) {
    return `${trimmedDisplayName} Workspace`;
  }

  const localPart = email.split("@")[0]?.trim() || "CVERiskPilot";
  return `${localPart} Workspace`;
}

export function buildOrganizationSlugSeed(displayName: string, email: string) {
  const trimmedDisplayName = displayName.trim();

  if (trimmedDisplayName.length > 0) {
    return slugify(trimmedDisplayName);
  }

  return slugify(email.split("@")[0] || "workspace");
}

export function buildUniqueOrganizationSlug(displayName: string, email: string, organizationId: string) {
  const base = buildOrganizationSlugSeed(displayName, email) || "workspace";
  return `${base}-${organizationId.replace(/-/g, "").slice(0, 8)}`;
}

export function resolveActiveOrganizationId(
  context: CurrentOrganizationContext,
  preferredOrganizationId: string | null | undefined,
) {
  if (
    preferredOrganizationId &&
    context.memberships.some(
      (membership) => membership.organization.id === preferredOrganizationId,
    )
  ) {
    return preferredOrganizationId;
  }

  return context.organizationId ?? context.memberships[0]?.organization.id ?? null;
}

export async function createDefaultOrganizationForUser(input: {
  userId: string;
  email: string;
  displayName: string;
  createdAt: string;
}) {
  const organizationId = crypto.randomUUID();
  const membershipId = crypto.randomUUID();
  const organizationName = buildDefaultOrganizationName(input.displayName, input.email);
  const organizationSlug = buildUniqueOrganizationSlug(
    input.displayName,
    input.email,
    organizationId,
  );

  await dbRun(
    `INSERT INTO organizations (
      id,
      name,
      slug,
      status,
      created_at,
      updated_at
    ) VALUES (?, ?, ?, 'active', ?, ?)`,
    organizationId,
    organizationName,
    organizationSlug,
    input.createdAt,
    input.createdAt,
  );

  await dbRun(
    `INSERT INTO organization_members (
      id,
      organization_id,
      user_id,
      role,
      joined_at,
      invited_by_user_id
    ) VALUES (?, ?, ?, 'owner', ?, NULL)`,
    membershipId,
    organizationId,
    input.userId,
    input.createdAt,
  );

  return {
    organizationId,
    membershipId,
    organizationName,
    organizationSlug,
  };
}

export async function getResolvedOrganizationContext(
  userId: string,
  preferredOrganizationId?: string | null,
) {
  const { organizationRepository } = await getOrganizationRuntime();
  const context = await organizationRepository.getCurrentContextForUser(userId);
  const activeOrganizationId = resolveActiveOrganizationId(context, preferredOrganizationId);

  return {
    context,
    activeOrganizationId,
  };
}

export async function ensureUserBelongsToOrganization(
  userId: string,
  organizationId: OrganizationId,
) {
  const { context } = await getResolvedOrganizationContext(userId, organizationId);

  return context.memberships.some(
    (membership) => membership.organization.id === organizationId,
  );
}
