import { describe, expect, it } from "vitest";

import { GET as getFindings } from "@/app/api/findings/route";
import { POST as triggerEnrichment } from "@/app/api/enrichments/route";
import { POST as reparseUpload } from "@/app/api/uploads/[id]/reparse/route";
import { POST as createUpload } from "@/app/api/uploads/route";
import { createAuthenticatedTestContext, withAuthHeaders } from "@/test/helpers/auth";
import { successfulCsvFixture } from "@/test/fixtures/generic-csv";

async function createParsedUpload(authHeaders: HeadersInit) {
  const formData = new FormData();
  formData.set(
    "file",
    new File([successfulCsvFixture], `findings-${crypto.randomUUID()}.csv`, {
      type: "text/csv",
    }),
  );
  formData.set("selectedSourceType", "generic_csv");

  const uploadResponse = await createUpload(
    new Request("http://localhost/api/uploads", {
      method: "POST",
      headers: withAuthHeaders(authHeaders),
      body: formData,
    }),
  );
  const uploadJson = await uploadResponse.json();
  const uploadJobId = uploadJson.data.uploadJob.id as string;

  await reparseUpload(
    new Request(`http://localhost/api/uploads/${uploadJobId}/reparse`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(authHeaders).entries()),
        },
        body: JSON.stringify({ force: true }),
    }),
    {
      params: Promise.resolve({ id: uploadJobId }),
    },
  );

  return uploadJobId;
}

describe("findings route enrichment summary", () => {
  it("returns pending enrichment status before enrichment run", async () => {
    const auth = await createAuthenticatedTestContext("findings-pending");
    await createParsedUpload(auth.headers);

    const response = await getFindings(
      new Request("http://localhost/api/findings", {
        headers: withAuthHeaders(auth.headers),
      }),
    );
    const json = await response.json();
    const enrichmentStatuses = (json.data.findings as Array<{
      enrichmentSummary?: { status?: string };
    }>).map((finding) => finding.enrichmentSummary?.status ?? "missing");

    expect(response.status).toBe(200);
    expect(enrichmentStatuses.some((status) => status === "pending")).toBe(true);
  });

  it("returns non-pending enrichment status after enrichment run", async () => {
    const auth = await createAuthenticatedTestContext("findings-enriched");
    const uploadJobId = await createParsedUpload(auth.headers);

    await triggerEnrichment(
      new Request("http://localhost/api/enrichments", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          ...Object.fromEntries(new Headers(auth.headers).entries()),
        },
        body: JSON.stringify({
          uploadJobId,
          providers: ["nvd", "cisa_kev"],
          triggeredBy: "findings-test",
          force: true,
        }),
      }),
    );

    const response = await getFindings(
      new Request("http://localhost/api/findings", {
        headers: withAuthHeaders(auth.headers),
      }),
    );
    const json = await response.json();
    const enrichmentStatuses = (json.data.findings as Array<{
      enrichmentSummary?: { status?: string };
    }>).map((finding) => finding.enrichmentSummary?.status ?? "missing");

    expect(response.status).toBe(200);
    expect(
      enrichmentStatuses.some(
        (status) => status === "enriched" || status === "partial" || status === "failed",
      ),
    ).toBe(true);
  });

  it("filters findings to the active organization only", async () => {
    const authA = await createAuthenticatedTestContext("findings-org-a");
    const authB = await createAuthenticatedTestContext("findings-org-b");

    await createParsedUpload(authA.headers);

    const response = await getFindings(
      new Request("http://localhost/api/findings", {
        headers: withAuthHeaders(authB.headers),
      }),
    );
    const json = await response.json();

    expect(response.status).toBe(200);
    expect(json.data.source).toBe("ingestion");
    expect(json.data.total).toBe(0);
    expect(json.data.findings).toEqual([]);
  });
});
