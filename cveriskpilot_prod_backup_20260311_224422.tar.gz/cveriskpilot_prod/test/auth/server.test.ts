import { beforeEach, describe, expect, it, vi } from "vitest";

const headersMock = vi.fn();
const cookiesMock = vi.fn();
const redirectMock = vi.fn();
const getAuthenticatedSessionMock = vi.fn();
const getSessionCookieNameMock = vi.fn(() => "cveriskpilot_session");

vi.mock("server-only", () => ({}));

vi.mock("next/headers", () => ({
  headers: headersMock,
  cookies: cookiesMock,
}));

vi.mock("next/navigation", () => ({
  redirect: redirectMock,
}));

vi.mock("@/lib/session", () => ({
  getAuthenticatedSession: getAuthenticatedSessionMock,
  getSessionCookieName: getSessionCookieNameMock,
}));

describe("server auth helpers", () => {
  beforeEach(() => {
    vi.clearAllMocks();

    headersMock.mockResolvedValue(
      new Headers({
        host: "localhost:3000",
        "x-forwarded-proto": "http",
      }),
    );
    cookiesMock.mockResolvedValue({
      get: (name: string) =>
        name === "cveriskpilot_session" ? { value: "session-token" } : undefined,
    });
  });

  it("builds a request and returns the authenticated session", async () => {
    const session = {
      session: {
        id: "session-id",
        user_id: "user-id",
        active_organization_id: "org-id",
        expires_at: new Date().toISOString(),
        created_at: new Date().toISOString(),
        user_agent: null,
        ip_address: null,
        revoked_at: null,
      },
      user: {
        id: "user-id",
        email: "test@example.com",
        display_name: "Test",
        email_verified: true,
        created_at: new Date().toISOString(),
        current_organization_id: "org-id",
      },
    };

    getAuthenticatedSessionMock.mockResolvedValue(session);

    const { getServerAuthenticatedSession } = await import("@/lib/auth/server");
    const result = await getServerAuthenticatedSession("/dashboard/reports");

    expect(result).toBe(session);
    expect(getAuthenticatedSessionMock).toHaveBeenCalledTimes(1);
    const requestArg = getAuthenticatedSessionMock.mock.calls[0]?.[0];
    expect(requestArg).toBeInstanceOf(Request);
    expect(requestArg.url).toBe("http://localhost:3000/dashboard/reports");
    expect(requestArg.headers.get("cookie")).toBe("cveriskpilot_session=session-token");
  });

  it("redirects to login when no session is present", async () => {
    getAuthenticatedSessionMock.mockResolvedValue(null);

    const { requireServerAuthenticatedSession } = await import("@/lib/auth/server");
    await requireServerAuthenticatedSession("/dashboard/issues");

    expect(redirectMock).toHaveBeenCalledWith("/login?next=%2Fdashboard%2Fissues");
  });
});
