export type AgentMeshPhase =
  | "independent"
  | "cross-review"
  | "cross-review-matrix"
  | "final"
  | "unknown";

export type AgentMeshStatusValue =
  | "idle"
  | "running"
  | "completed"
  | "failed"
  | "dry_run_complete"
  | "unknown";

export type AgentMeshStatus = {
  fileName: string;
  agent: string;
  phase: AgentMeshPhase | string;
  status: AgentMeshStatusValue | string;
  startedAt?: string;
  completedAt?: string;
  failedAt?: string;
  output?: string;
  log?: string;
};

export type AgentMeshLogSummary = {
  fileName: string;
  path: string;
  tail: string[];
  updatedAt: string | null;
};

export type AgentMeshReportSummary = {
  path: string;
  exists: boolean;
  sizeBytes: number;
  updatedAt: string | null;
};

export type AgentMeshPhaseState = {
  phase: AgentMeshPhase;
  label: string;
  status: "pending" | "running" | "completed" | "failed";
  totalTasks: number;
  completedTasks: number;
  runningTasks: number;
  failedTasks: number;
};

export type AgentMeshMonitorSnapshot = {
  generatedAt: string;
  currentPhase: AgentMeshPhase | "completed";
  runningCount: number;
  failedCount: number;
  completedCount: number;
  phaseStates: AgentMeshPhaseState[];
  statuses: AgentMeshStatus[];
  logs: AgentMeshLogSummary[];
  reports: {
    individual: AgentMeshReportSummary[];
    crossReview: AgentMeshReportSummary[];
    final: AgentMeshReportSummary[];
  };
};
