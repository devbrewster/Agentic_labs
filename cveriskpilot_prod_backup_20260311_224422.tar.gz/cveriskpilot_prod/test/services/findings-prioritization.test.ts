import { describe, expect, it } from "vitest";

import { applyPrioritizationInfluence } from "@/lib/services/findings";
import { mockPriorityFindings } from "@/lib/mock/findings";
import type { AnalystDispositionRecord } from "@/types/analyst";

function createDisposition(
  overrides?: Partial<AnalystDispositionRecord>,
): AnalystDispositionRecord {
  return {
    findingId: mockPriorityFindings[0].id,
    decision: "true_risk",
    rationale: "Validated by analyst.",
    notes: null,
    factors: {
      internetExposed: true,
      internalOnly: false,
      segmentedNetwork: false,
      compensatingControlPresent: false,
      assetCriticality: "critical",
      authRequired: false,
      reachableFromAttackerPath: true,
    },
    updatedBy: "test",
    updatedAt: "2026-03-11T10:00:00.000Z",
    createdAt: "2026-03-11T10:00:00.000Z",
    ...overrides,
  };
}

describe("findings prioritization influence", () => {
  it("raises effective risk score when analyst confirms true risk with high exposure context", () => {
    const finding = {
      ...mockPriorityFindings[0],
      riskScore: 82,
    };

    const updated = applyPrioritizationInfluence(finding, createDisposition());

    expect(updated.riskScore).toBeGreaterThan(82);
    expect(updated.prioritization?.baseRiskScore).toBe(82);
    expect(updated.prioritization?.reasons.length).toBeGreaterThan(0);
    expect(updated.status).toBe("triaged");
  });

  it("suppresses effective risk score for false positives", () => {
    const finding = {
      ...mockPriorityFindings[1],
      riskScore: 91,
    };

    const updated = applyPrioritizationInfluence(
      finding,
      createDisposition({
        findingId: finding.id,
        decision: "false_positive",
        factors: {
          internetExposed: false,
          internalOnly: true,
          segmentedNetwork: true,
          compensatingControlPresent: true,
          assetCriticality: "low",
          authRequired: true,
          reachableFromAttackerPath: false,
        },
      }),
    );

    expect(updated.riskScore).toBeLessThan(40);
    expect(updated.status).toBe("false_positive");
    expect(updated.prioritization?.totalAdjustment).toBeLessThan(0);
  });
});
