import type { ReactNode } from "react";

import { requireServerAuthenticatedSession } from "@/lib/auth/server";
import { DashboardShell } from "@/components/dashboard/DashboardShell";

export default async function DashboardLayout({
  children,
}: {
  children: ReactNode;
}) {
  await requireServerAuthenticatedSession("/dashboard");

  return (
    <DashboardShell>{children}</DashboardShell>
  );
}
