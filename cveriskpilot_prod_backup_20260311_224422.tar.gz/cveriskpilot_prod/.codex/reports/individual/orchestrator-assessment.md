# Orchestrator Round 1 Assessment

## Summary
- **State**: Core ingestion, enrichment, analyst feedback, and AI trace scaffolding exist, but many SaaS fundamentals remain partial or missing. Key blockers include unauthenticated dashboard routes, mock-only modules (action plans, integrations, settings), manual ingestion/enrichment orchestration, and a nonexistent billing/paywall flow.
- **Risk posture**: Multi-tenant data can leak (reports server component) and unauthenticated users can render dashboard shells. Monetization, compliance, audit logging, and ops tooling are still conceptual.
- **Next steps**: Fix access control, finish ingestion/enrichment automation, implement real billing/paywall, replace mock surfaces with persistent services, and add audit/logging + support/legal foundations.

## Critical Findings
| Area | Status | Priority | Evidence | Why it matters |
| --- | --- | --- | --- | --- |
| Dashboard access control & tenant isolation | **MISSING** | **CRITICAL** | Dashboard layout never checks sessions (`app/dashboard/layout.tsx:5`), middleware only rewrites URLs (`middleware.ts:123`). Reports page calls `getExecutiveSummaryReport()` without scoping (`app/dashboard/reports/page.tsx:13` + `lib/services/reports.ts:197` defaults to `listAll()`), so any request can pull cross-tenant data. | Unauthorized users can render dashboard HTML, and org-sensitive findings bleed across tenants. |
| Billing & paywall | **MISSING** | **CRITICAL** | Only `GET /api/billing` snapshot exists (`app/api/billing/route.ts:1`); billing service just checks env vars (`lib/billing/service.ts:104`) and never consumes usage counters beyond display (`lib/billing/service.ts:83`,`lib/billing/service.ts:119`). `/upgrade` is static marketing copy with no Stripe hooks (`app/upgrade/page.tsx:1`). Roadmap still lists checkout/webhook tasks as future work (`docs/production-roadmap.md:75-118`). | No way to monetize or enforce plan limits; customers stay on a free, honor-system tier. |
| Core workflow completeness | **PARTIAL** | **HIGH** | Upload UI admits findings remain on mock data until “next integration pass” (`components/dashboard/UploadsWorkspace.tsx:368`); API still returns mock jobs (`app/api/uploads/route.ts:24`) via `lib/services/uploads.ts:4`. Enrichment must be triggered manually (`app/api/enrichments/route.ts:26`) and background orchestration is TODO (`lib/uploads.ts:1`). Action plans, integrations, and settings all render static mocks (`lib/services/action-plans.ts:4`, `app/dashboard/integrations/page.tsx:11` + `lib/services/enrichments.ts:4`, `app/dashboard/settings/page.tsx:5`, mock definitions in `lib/mock/platform.ts:34`). | Users cannot complete the promised “ingest → enrich → action plan” loop; most secondary surfaces are demos. |
| Authentication journeys | **PARTIAL** | **HIGH** | Magic link sign-up/login buttons call `/api/auth/magic` but the API returns `todo_not_implemented` (`app/signup/page.tsx:157`, `app/login/page.tsx:102`, `app/api/auth/magic/route.ts:12`). | UX advertises passwordless flows that always error, eroding trust. |
| AI & analysis governance | **PARTIAL** | **HIGH** | Analysis POST response literally returns TODOs for rate limits and human approval (`app/api/findings/[id]/analysis/route.ts:124`). | Generated remediation text can ship without guardrails or audit, risking unsafe advice. |
| Compliance / audit / support | **MISSING** | **HIGH** | Backlog still calls for upload audit events and admin tools (`docs/todo-backlog.md:13-41`). There are no legal/support pages under `app/` (no matches for “privacy” via `rg -n "privacy" app`). | Enterprise customers lack audit trails, DPA/legal references, and support channels. |
| Operational caching & persistence | **PARTIAL** | **MEDIUM** | All workload caches live in a process-local `Map` (`lib/cache/runtime-cache.ts:6`), as do NVD/KEV caches (`lib/nvd/cache.ts:6`, `lib/kev/cache.ts:6`). Fallback ingestion runtime silently downgrades to in-memory storage when D1/PG isn’t reachable (`lib/ingestion/runtime.ts:29-135`). | Multi-instance deployments will have cache incoherence, and local/dev runs never exercise real persistence. |
| Monetization UX (usage, upgrades) | **PARTIAL** | **MEDIUM** | Account page only displays plan info + mock usage (`app/account/page.tsx:141`) and exposes `upgradeReady` boolean but no actions. Usage counters are never incremented outside billing snapshots (only definitions in `lib/billing/service.ts:83-133`). | No actual limit enforcement or upgrade CTA, so paywall can’t launch. |
| Multi-tenant org features | **MISSING** | **MEDIUM** | Schema has only `organizations`/`organization_members` tables (`database/schema.sql:3-21`), no invites or team management UI, and only an API to switch org context (`app/api/auth/organization/route.ts:5`). | Customers can’t invite teammates, manage roles, or administer multiple workspaces. |

## Additional Gap Details
### Access & Security
- Dashboard shell renders for any visitor; auth only exists in API handlers. This breaks the “secure-by-default” contract and exposes metadata even if API calls fail.
- Reports server component calls `getExecutiveSummaryReport()` without org scoping, which in turn queries `uploadRepository.normalizedFindings.listAll()` whenever no org id is provided (`lib/services/reports.ts:229-232`). This is an immediate multi-tenant data leak.
- File uploads accept any file/mime without size limits, malware scanning, or content-type enforcement (`app/api/uploads/route.ts:45-75`).
- AI analysis response flags missing controls (“add provider-specific rate limits”, “add human approval gate”), meaning it knowingly ships without those safeguards.

### Product & Workflow Completeness
- Upload pipeline remains half-mock: the API still returns hardcoded “jobs” and the UI literally warns that dashboard findings are still on mock data. Background ingestion worker is a stub (`lib/uploads.ts:1`).
- Enrichment must be triggered manually (`app/api/enrichments/route.ts:26`) and the GET handler simply echoes static connector cards from mocks; no persistence of connector state happens anywhere (`lib/services/enrichments.ts:4`, `lib/mock/platform.ts:34`).
- Action plans, integrations, and settings pages are pure placeholders with “No Persistence Yet” badges (`app/dashboard/settings/page.tsx:10-26`, `components/dashboard/ActionPlansBoard.tsx:5-30`). Users cannot track remediation, configure integrations, or adjust workspace policies.
- Magic link auth flows are exposed in the UI but always fail because the backend returns 501. That’s a broken onboarding path.

### AI & Automation
- AI triage sequentially runs in the request/response cycle; there’s no job queue or backoff for upload parsing (`lib/ingestion/parse-job-runner.ts`) or analysis. The API even returns TODO items acknowledging missing rate limits and human approval.
- Enrichment service only wires NVD + CISA KEV clients; other “configured” connectors listed on the integrations page are aspirational (mock data in `lib/mock/platform.ts:34`).

### Monetization & Enterprise Readiness
- Billing snapshot shows plan/usage but there’s no Stripe Checkout, Billing Portal, or webhook processing despite being called out as pending in `docs/production-roadmap.md`. `isStripeUpgradeReady` only checks env vars, and no endpoint consumes usage counters, so quotas are unenforced.
- `/upgrade` is static marketing text with no way to pay or request sales. Account page lacks invite/team settings, API tokens, audit exports, incident contacts, or SLAs.
- There are zero legal/support routes; we couldn’t find `privacy`, `terms`, or `support` pages under `app/` (search for “privacy” returns no matches).

### Operational Maturity
- Caching is process-local, so multi-instance deployments will serve stale data and ignore invalidations. NVD/KEV caches also live in-memory, which risks hammering upstream providers when instances recycle.
- Upload audit logging and admin ops remain on the TODO backlog. There’s no observable event stream for uploads, enrichments, or AI actions.
- Fallback runtimes downgrade to in-memory repositories whenever D1/Postgres isn’t reachable, meaning plenty of code paths never exercise real persistence during development/testing.

## Recommendations & Handoffs
1. **Lock down dashboard routes** (add server-side session checks in the layout or middleware) and force tenant scoping inside all server components, starting with reports. (Security/Platform agent should double-check other server imports of `lib/services/...`.)
2. **Finish ingestion automation**: replace the `lib/uploads.ts` stub with a worker or queue, trigger enrichment automatically when parse succeeds, and remove mock job payloads. (Security/Platform agent to verify file validation & storage isolation once done.)
3. **Ship real billing**: implement `/api/billing/checkout`, `/api/billing/portal`, Stripe webhooks, and backend quota enforcement before advertising plans. (Product/UX agent to define upgrade UX; Security agent to review webhook handling.)
4. **Replace mock surfaces with persisted services**: action plans, integrations, and settings should read/write actual tables, not static arrays. (Product agent to specify UX; Platform agent to design schema.)
5. **Add audit/legal/support foundations**: implement upload audit logs (`upload_audit_events`), surface analyst disposition history in a reportable format, and add Privacy/Terms/Support routes. (Security agent to ensure compliance.)
6. **Govern AI outputs**: implement provider-level rate limits, approval workflows, and trace review UI per the TODOs already returned by the API. (Product & Security agents to align on policy.)

## Items Needing Validation by Other Agents
- Confirm no other server components bypass tenant scoping the way `app/dashboard/reports/page.tsx` does (Security/Platform agent).
- Evaluate whether ingesting files to Cloudflare D1 / local FS without tenant_id on `raw_artifacts` introduces data mixing (Security agent).
- Assess UX debt around onboarding (Product agent): magic link, invitations, organization management, upgrade CTA.

**Priority focus for Round 2 cross-review**: fix access control/leak, unblock real billing/paywall, and ensure ingestion/enrichment automation replaces the current mock + manual workflow.
