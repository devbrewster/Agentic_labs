type EnrichmentErrorBannerProps = {
  message: string;
  staleCache?: boolean;
};

export function EnrichmentErrorBanner({
  message,
  staleCache = false,
}: EnrichmentErrorBannerProps) {
  return (
    <div
      className="mt-3 rounded border border-[rgba(255,77,109,0.35)] bg-[rgba(255,77,109,0.10)] px-3 py-2 text-[0.72rem] text-[#ffc0cb]"
      role="alert"
    >
      <div className="font-mono uppercase tracking-[0.08em] text-[#ff94a8]">
        NVD Enrichment Notice
      </div>
      <div className="mt-1 leading-6">{message}</div>
      {staleCache ? (
        <div className="mt-1 text-[#ffd6de]">
          Displaying cached data while live NVD is unavailable.
        </div>
      ) : null}
    </div>
  );
}
