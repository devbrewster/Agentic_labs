# NVD Compliance Guide

Last updated: 2026-03-11

## Purpose

This document defines how CVERiskPilot uses NVD data safely and in compliance-focused form.

## Required Attribution

CVERiskPilot must visibly display:

`This product uses the NVD API but is not endorsed or certified by the NVD.`

Current UI placements:

- global footer attribution component
- About / Data Sources page
- CVE detail context (finding details panel)

## Endorsement Prohibition

UI and docs must never claim:

- endorsed by NVD
- certified by NVD
- official NVD partner
- approved by NVD

## Source Separation Rules

Every CVE view separates data into:

1. Original NVD Data
2. CVERiskPilot Analysis
3. Other Enrichment Sources

NVD source data is shown independently from generated narratives and ranking logic.

## Server-Only Access

NVD API access is server-only:

- key is read from environment variables
- API key is never returned to browser clients
- browser requests use internal route `/api/nvd`

## Rate Limiting Model

The NVD client applies rolling-window throttling with configurable limits:

- public mode default: 5 requests / 30 seconds
- keyed mode default: 50 requests / 30 seconds

Configuration:

- `NVD_RATE_LIMIT_PUBLIC_PER_30S`
- `NVD_RATE_LIMIT_KEYED_PER_30S`

## Caching Model

Current cache provider:

- in-memory server cache abstraction (`lib/nvd/cache.ts`)

Cached fields:

- raw payload
- normalized record
- fetched timestamp
- expiry timestamp

Extensibility:

- cache interface is designed for future D1/KV/Redis/Durable Object backing.

## Resilience and Fallback

When NVD live fetch fails:

1. Serve fresh cache if available.
2. Serve stale cache if available and mark response stale.
3. Return a non-blocking structured error if no cache exists.

The dashboard does not crash if NVD is unavailable.

## Normalization

Normalization entry point:

- `lib/nvd/normalize.ts`

Extracted fields:

- CVE ID
- description
- published / last modified timestamps
- CVSS vectors/scores (v3.1/v3.0/v2 when present)
- weaknesses (CWE summary text)
- references
- configurations

Raw payload is retained in cache/repository layer for diagnostics but not dumped directly in UI responses.

## Developer Extension Guidance

When adding providers (KEV, EPSS, Wiz, Snyk, vendor advisories):

- keep original source data separate from generated analysis
- add explicit `source` metadata
- preserve failure isolation (partial enrichment is acceptable)
- do not block core finding rendering on external provider outages

When adding Claude narratives:

- place all generated text under `analysis`
- do not overwrite `nvd` source fields
- include confidence and provenance metadata for AI outputs
