import { z } from "zod";

import { OrganizationIdSchema } from "@/types/organization";

export const BillingPlanSchema = z.enum(["free", "pro"]);
export type BillingPlan = z.infer<typeof BillingPlanSchema>;

export const BillingProviderSchema = z.enum(["none", "stripe"]);
export type BillingProvider = z.infer<typeof BillingProviderSchema>;

export const BillingSubscriptionStatusSchema = z.enum([
  "inactive",
  "trialing",
  "active",
  "past_due",
  "canceled",
  "unpaid",
]);
export type BillingSubscriptionStatus = z.infer<typeof BillingSubscriptionStatusSchema>;

export const BillingCustomerSchema = z.object({
  organizationId: OrganizationIdSchema,
  stripeCustomerId: z.string().min(1),
  createdAt: z.iso.datetime(),
  updatedAt: z.iso.datetime(),
});
export type BillingCustomer = z.infer<typeof BillingCustomerSchema>;

export const BillingSubscriptionSchema = z.object({
  organizationId: OrganizationIdSchema,
  stripeSubscriptionId: z.string().min(1),
  status: BillingSubscriptionStatusSchema,
  priceId: z.string().min(1),
  currentPeriodStart: z.iso.datetime().nullable(),
  currentPeriodEnd: z.iso.datetime().nullable(),
  cancelAtPeriodEnd: z.boolean(),
  createdAt: z.iso.datetime(),
  updatedAt: z.iso.datetime(),
});
export type BillingSubscription = z.infer<typeof BillingSubscriptionSchema>;

export const UsageCounterSchema = z.object({
  organizationId: OrganizationIdSchema,
  periodStart: z.iso.datetime(),
  periodEnd: z.iso.datetime(),
  uploadsUsed: z.number().int().min(0),
  analysesUsed: z.number().int().min(0),
  cveLookupsUsed: z.number().int().min(0),
  exportsUsed: z.number().int().min(0),
  updatedAt: z.iso.datetime(),
});
export type UsageCounter = z.infer<typeof UsageCounterSchema>;

export const BillingEntitlementsSchema = z.object({
  uploadsPerMonth: z.number().int().min(0),
  analysesPerMonth: z.number().int().min(0),
  cveLookupsPerDay: z.number().int().min(0),
  exportsPerMonth: z.number().int().min(0),
  sharedWorkspaces: z.number().int().min(1),
  advancedReports: z.boolean(),
  premiumIntegrations: z.boolean(),
});
export type BillingEntitlements = z.infer<typeof BillingEntitlementsSchema>;

export const BillingSnapshotSchema = z.object({
  organizationId: OrganizationIdSchema,
  plan: BillingPlanSchema,
  provider: BillingProviderSchema,
  customer: BillingCustomerSchema.nullable(),
  subscription: BillingSubscriptionSchema.nullable(),
  usage: UsageCounterSchema,
  entitlements: BillingEntitlementsSchema,
  upgradeReady: z.boolean(),
});
export type BillingSnapshot = z.infer<typeof BillingSnapshotSchema>;
