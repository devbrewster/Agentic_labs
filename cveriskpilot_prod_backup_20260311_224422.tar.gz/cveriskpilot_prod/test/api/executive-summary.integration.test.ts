import { describe, expect, it } from "vitest";

import { GET as getExecutiveSummary } from "@/app/api/reports/executive-summary/route";
import { PATCH as patchDisposition } from "@/app/api/findings/[id]/disposition/route";
import { POST as postAnalysis } from "@/app/api/findings/[id]/analysis/route";
import { GET as getFindings } from "@/app/api/findings/route";
import { POST as reparseUpload } from "@/app/api/uploads/[id]/reparse/route";
import { POST as createUpload } from "@/app/api/uploads/route";
import { createAuthenticatedTestContext, withAuthHeaders } from "@/test/helpers/auth";
import { successfulCsvFixture } from "@/test/fixtures/generic-csv";

async function createPreparedFinding(authHeaders: HeadersInit) {
  const formData = new FormData();
  formData.set(
    "file",
    new File([successfulCsvFixture], `report-${crypto.randomUUID()}.csv`, {
      type: "text/csv",
    }),
  );
  formData.set("selectedSourceType", "generic_csv");

  const uploadResponse = await createUpload(
    new Request("http://localhost/api/uploads", {
      method: "POST",
      headers: withAuthHeaders(authHeaders),
      body: formData,
    }),
  );
  const uploadJson = await uploadResponse.json();
  const uploadJobId = uploadJson.data.uploadJob.id as string;

  await reparseUpload(
    new Request(`http://localhost/api/uploads/${uploadJobId}/reparse`, {
        method: "POST",
        headers: withAuthHeaders(authHeaders, { "Content-Type": "application/json" }),
        body: JSON.stringify({ force: true }),
      }),
    {
      params: Promise.resolve({ id: uploadJobId }),
    },
  );

  const findingsResponse = await getFindings(
    new Request("http://localhost/api/findings", {
      headers: withAuthHeaders(authHeaders),
    }),
  );
  const findingsJson = await findingsResponse.json();
  const findingId = (findingsJson.data.findings as Array<{ id: string }>)[0]?.id;

  if (!findingId) {
    throw new Error("Expected finding for executive summary test.");
  }

  await patchDisposition(
    new Request(`http://localhost/api/findings/${findingId}/disposition`, {
      method: "PATCH",
      headers: withAuthHeaders(authHeaders, { "Content-Type": "application/json" }),
      body: JSON.stringify({
        decision: "true_risk",
        rationale: "Validated for executive escalation.",
        notes: null,
        factors: {
          internetExposed: true,
          internalOnly: false,
          segmentedNetwork: false,
          compensatingControlPresent: false,
          assetCriticality: "critical",
          authRequired: false,
          reachableFromAttackerPath: true,
        },
        updatedBy: "integration-test",
      }),
    }),
    {
      params: Promise.resolve({ id: findingId }),
    },
  );

  await postAnalysis(
    new Request(`http://localhost/api/findings/${findingId}/analysis`, {
      method: "POST",
      headers: withAuthHeaders(authHeaders, { "Content-Type": "application/json" }),
      body: JSON.stringify({ mode: "stub" }),
    }),
    {
      params: Promise.resolve({ id: findingId }),
    },
  );
}

describe("executive summary route", () => {
  it("returns stakeholder-safe sections with provenance and uncertainty", async () => {
    const auth = await createAuthenticatedTestContext("executive-summary");
    await createPreparedFinding(auth.headers);

    const response = await getExecutiveSummary(
      new Request("http://localhost/api/reports/executive-summary", {
        headers: withAuthHeaders(auth.headers),
      }),
    );
    const json = await response.json();

    expect(response.status).toBe(200);
    expect(json.ok).toBe(true);
    expect(json.data.topFindings.length).toBeGreaterThan(0);
    expect(json.data.topFindings[0].originalSourceData.length).toBeGreaterThan(0);
    expect(json.data.topFindings[0].analysisStatus).toMatch(/present|fallback_only|missing/);
    expect(Array.isArray(json.data.uncertainty.items)).toBe(true);
    expect(json.data.actionPlans.length).toBeGreaterThan(0);
  });
});
