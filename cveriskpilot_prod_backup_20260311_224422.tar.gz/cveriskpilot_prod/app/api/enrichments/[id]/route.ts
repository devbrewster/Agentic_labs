import { NextResponse } from "next/server";

import { handleEnrichmentRouteError } from "@/lib/enrichment/http";
import { getEnrichmentRuntime } from "@/lib/enrichment/runtime";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";

type RouteContext = {
  params: Promise<{
    id: string;
  }>;
};

export async function GET(request: Request, context: RouteContext) {
  try {
    const auth = await requireCurrentOrganizationAccess(request);

    if (!auth.ok) {
      return auth.response;
    }

    const { id } = await context.params;
    const { enrichmentRepository } = await getEnrichmentRuntime();
    const run = await enrichmentRepository.findRunById(id);

    if (!run) {
      return NextResponse.json(
        {
          ok: false,
          error: {
            code: "enrichment_run_not_found",
            message: "Enrichment run was not found.",
          },
        },
        { status: 404 },
      );
    }

    if (!run.run.uploadJobId) {
      return NextResponse.json(
        {
          ok: false,
          error: {
            code: "enrichment_run_not_found",
            message: "Enrichment run was not found.",
          },
        },
        { status: 404 },
      );
    }

    const { uploadRepository } = await getIngestionRuntime();
    const uploadRecord = await uploadRepository.findByIdForTenant(
      run.run.uploadJobId,
      auth.organizationId,
    );

    if (!uploadRecord) {
      return NextResponse.json(
        {
          ok: false,
          error: {
            code: "enrichment_run_not_found",
            message: "Enrichment run was not found.",
          },
        },
        { status: 404 },
      );
    }

    return NextResponse.json({
      ok: true,
      data: run,
    });
  } catch (error) {
    return handleEnrichmentRouteError(error, {
      code: "enrichment_run_detail_failed",
      message: "Unable to retrieve enrichment run details.",
    });
  }
}
