type ClaudeMessageResponse = {
  content?: Array<{
    type?: string;
    text?: string;
  }>;
};

type ClaudeClientConfig = {
  apiKey: string;
  model: string;
  timeoutMs: number;
};

type GenerateClaudeTextInput = {
  systemPrompt: string;
  userPrompt: string;
  maxTokens?: number;
  temperature?: number;
};

function sanitizeClaudeErrorMessage(message: string) {
  return message
    .replace(/sk-ant-[A-Za-z0-9\-_]+/g, "[redacted]")
    .replace(/x-api-key["':=\s]+[A-Za-z0-9\-_]+/gi, "x-api-key=[redacted]");
}

export class ClaudeClient {
  constructor(private readonly config: ClaudeClientConfig) {}

  async generateText(input: GenerateClaudeTextInput): Promise<string> {
    const controller = new AbortController();
    const timeout = setTimeout(() => controller.abort(), this.config.timeoutMs);

    try {
      const response = await fetch("https://api.anthropic.com/v1/messages", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": this.config.apiKey,
          "anthropic-version": "2023-06-01",
        },
        body: JSON.stringify({
          model: this.config.model,
          max_tokens: input.maxTokens ?? 800,
          temperature: input.temperature ?? 0.2,
          system: input.systemPrompt,
          messages: [
            {
              role: "user",
              content: input.userPrompt,
            },
          ],
        }),
        signal: controller.signal,
      });

      if (!response.ok) {
        const text = await response.text();
        throw new Error(
          sanitizeClaudeErrorMessage(
            `Claude API request failed (${response.status}): ${text.slice(0, 240)}`,
          ),
        );
      }

      const data = (await response.json()) as ClaudeMessageResponse;
      const text = data.content?.find((item) => item.type === "text")?.text?.trim();

      if (!text) {
        throw new Error("Claude API returned no text content.");
      }

      return text;
    } finally {
      clearTimeout(timeout);
    }
  }
}

export function getClaudeClient() {
  const apiKey = process.env.ANTHROPIC_API_KEY?.trim();
  if (!apiKey) {
    return null;
  }

  return new ClaudeClient({
    apiKey,
    model: process.env.ANTHROPIC_MODEL?.trim() || "claude-sonnet-4-6",
    timeoutMs: Number(process.env.CLAUDE_REQUEST_TIMEOUT_MS ?? 20000),
  });
}
