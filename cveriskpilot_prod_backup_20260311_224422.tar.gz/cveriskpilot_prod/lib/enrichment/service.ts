import {
  EnrichmentFindingInputSchema,
  EnrichmentRunStatusSchema,
  ProviderEnrichmentResultSchema,
  RunFindingEnrichmentInputSchema,
  RunFindingEnrichmentResultSchema,
  type EnrichmentProvider,
  type RunFindingEnrichmentInput,
  type RunFindingEnrichmentResult,
} from "@/types/enrichment";
import type { EnrichmentProviderClient } from "@/lib/enrichment/providers/base";

export class EnrichmentService {
  private readonly providers = new Map<EnrichmentProvider, EnrichmentProviderClient>();

  constructor(providerClients: readonly EnrichmentProviderClient[]) {
    for (const providerClient of providerClients) {
      if (this.providers.has(providerClient.provider)) {
        throw new Error(`Duplicate enrichment provider registered: ${providerClient.provider}`);
      }

      this.providers.set(providerClient.provider, providerClient);
    }
  }

  listProviders() {
    return Array.from(this.providers.keys());
  }

  async enrichFinding(input: RunFindingEnrichmentInput): Promise<RunFindingEnrichmentResult> {
    const validatedInput = RunFindingEnrichmentInputSchema.parse(input);
    const finding = EnrichmentFindingInputSchema.parse(validatedInput.finding);
    const startedAt = new Date().toISOString();

    const results = await Promise.all(
      validatedInput.providers.map(async (provider) => {
        const providerClient = this.providers.get(provider);

        if (!providerClient) {
          return ProviderEnrichmentResultSchema.parse({
            provider,
            status: "error",
            sourceUrl: null,
            observedAt: startedAt,
            payload: null,
            rawPayload: null,
            errorCode: "provider_not_registered",
            errorMessage: `Provider '${provider}' is not registered.`,
          });
        }

        try {
          return await providerClient.enrichFinding(finding, {
            now: new Date().toISOString(),
          });
        } catch (error) {
          return ProviderEnrichmentResultSchema.parse({
            provider,
            status: "error",
            sourceUrl: null,
            observedAt: new Date().toISOString(),
            payload: null,
            rawPayload: null,
            errorCode: "provider_execution_failed",
            errorMessage: error instanceof Error ? error.message : "Provider execution failed.",
          });
        }
      }),
    );

    const errorCount = results.filter((result) => result.status === "error").length;
    const warningCount = results.filter((result) => result.status === "not_found").length;
    const completedAt = new Date().toISOString();

    const runStatus = (() => {
      if (errorCount === results.length) {
        return EnrichmentRunStatusSchema.parse("failed");
      }

      if (errorCount > 0) {
        return EnrichmentRunStatusSchema.parse("partial");
      }

      return EnrichmentRunStatusSchema.parse("completed");
    })();

    return RunFindingEnrichmentResultSchema.parse({
      findingId: finding.findingId,
      requestedProviders: validatedInput.providers,
      completedProviders: results,
      runStatus,
      errorCount,
      warningCount,
      startedAt,
      completedAt,
    });
  }
}

