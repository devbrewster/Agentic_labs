import { sha256Hex, toBuffer } from "@/lib/ingestion/checksum";
import type { UploadRepository } from "@/lib/ingestion/repository";
import type { StorageProvider } from "@/lib/ingestion/storage";
import {
  CreateUploadJobInputSchema,
  ReparseUploadRequestSchema,
  UploadErrorsResponseSchema,
  UploadFindingsResponseSchema,
  UploadJobDetailSchema,
  UploadJobResponseSchema,
  type ChecksumSha256,
  type CreateUploadJobInput,
  type ParseJobRunResult,
  type UploadJob,
  type UploadJobDetail,
  type UploadErrorsResponse,
  type UploadFindingsResponse,
  type UploadJobResponse,
} from "@/types/ingestion";
import type { ParseJobRunner } from "@/lib/ingestion/parse-job-runner";

type CreateUploadJobRequest = CreateUploadJobInput & {
  body: ArrayBuffer | Uint8Array | Buffer;
};

export class UploadService {
  constructor(
    private readonly repository: UploadRepository,
    private readonly storageProvider: StorageProvider,
  ) {}

  async createUploadJob(input: CreateUploadJobRequest): Promise<UploadJobResponse> {
    const validatedInput = CreateUploadJobInputSchema.parse(input);
    const bodyBuffer = toBuffer(input.body);
    const checksumSha256 = sha256Hex(bodyBuffer);
    const existing = await this.repository.findByChecksumForTenant(
      checksumSha256,
      validatedInput.tenantId,
    );

    if (existing) {
      return UploadJobResponseSchema.parse({
        uploadJob: existing.uploadJob,
        rawArtifact: existing.rawArtifact,
        deduplicated: true,
        message: "Upload already exists for this artifact checksum.",
      });
    }

    const uploadedAt = new Date().toISOString();
    const { artifact } = await this.storageProvider.saveArtifact({
      originalFilename: validatedInput.originalFilename,
      mimeType: validatedInput.mimeType,
      body: bodyBuffer,
      uploadedAt,
    });

    const uploadJob = this.buildQueuedUploadJob({
      rawArtifactId: artifact.id,
      checksumSha256,
      selectedSourceType: validatedInput.selectedSourceType,
      tenantId: validatedInput.tenantId,
      createdAt: uploadedAt,
    });

    await this.repository.save({
      uploadJob,
      rawArtifact: artifact,
    });

    return UploadJobResponseSchema.parse({
      uploadJob,
      rawArtifact: artifact,
      deduplicated: false,
      message: "Upload job created and queued for parsing.",
    });
  }

  async listUploadJobs(tenantId?: string) {
    return tenantId ? this.repository.listByTenant(tenantId) : this.repository.list();
  }

  async getUploadJobDetail(uploadJobId: string, tenantId?: string): Promise<UploadJobDetail | null> {
    const record = tenantId
      ? await this.repository.findByIdForTenant(uploadJobId, tenantId)
      : await this.repository.findById(uploadJobId);

    if (!record) {
      return null;
    }

    return UploadJobDetailSchema.parse({
      uploadJob: record.uploadJob,
      rawArtifact: record.rawArtifact,
      metadata: record.outcome?.metadata ?? null,
      parserWarnings: record.outcome?.parserWarnings ?? [],
      parserErrors: record.outcome?.parserErrors ?? [],
      findings: record.outcome?.findings ?? [],
    });
  }

  async getUploadFindings(uploadJobId: string, tenantId?: string): Promise<UploadFindingsResponse | null> {
    const detail = await this.getUploadJobDetail(uploadJobId, tenantId);

    if (!detail) {
      return null;
    }

    return UploadFindingsResponseSchema.parse({
      uploadJobId: detail.uploadJob.id,
      status: detail.uploadJob.status,
      findingCount: detail.findings.length,
      findings: detail.findings,
    });
  }

  async getUploadErrors(uploadJobId: string, tenantId?: string): Promise<UploadErrorsResponse | null> {
    const detail = await this.getUploadJobDetail(uploadJobId, tenantId);

    if (!detail) {
      return null;
    }

    return UploadErrorsResponseSchema.parse({
      uploadJobId: detail.uploadJob.id,
      status: detail.uploadJob.status,
      warningCount: detail.parserWarnings.length,
      errorCount: detail.parserErrors.length,
      parserWarnings: detail.parserWarnings,
      parserErrors: detail.parserErrors,
    });
  }

  async reparseUpload(
    uploadJobId: string,
    runner: ParseJobRunner,
    tenantId?: string,
    input?: { force?: boolean },
  ): Promise<ParseJobRunResult> {
    const options = ReparseUploadRequestSchema.parse(input ?? {});
    if (tenantId) {
      const record = await this.repository.findByIdForTenant(uploadJobId, tenantId);

      if (!record) {
        throw new Error(`Upload job ${uploadJobId} was not found.`);
      }
    }

    return runner.run(uploadJobId, { force: options.force });
  }

  private buildQueuedUploadJob(input: {
    rawArtifactId: string;
    checksumSha256: ChecksumSha256;
    selectedSourceType: CreateUploadJobInput["selectedSourceType"];
    tenantId: CreateUploadJobInput["tenantId"];
    createdAt: string;
  }): UploadJob {
    return {
      id: crypto.randomUUID(),
      tenantId: input.tenantId,
      rawArtifactId: input.rawArtifactId,
      selectedSourceType: input.selectedSourceType,
      detectedSourceType: null,
      status: "queued",
      errorSummary: null,
      warningCount: 0,
      findingCount: 0,
      checksumSha256: input.checksumSha256,
      createdAt: input.createdAt,
      updatedAt: input.createdAt,
      parsedAt: null,
    };
  }
}
