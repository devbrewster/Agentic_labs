import type {
  EnrichmentFindingInput,
  EnrichmentProvider,
  ProviderEnrichmentResult,
} from "@/types/enrichment";

export type EnrichmentProviderContext = {
  now: string;
  timeoutMs?: number;
};

export type EnrichmentProviderClient = {
  readonly provider: EnrichmentProvider;
  enrichFinding(
    finding: EnrichmentFindingInput,
    context: EnrichmentProviderContext,
  ): Promise<ProviderEnrichmentResult>;
};

export class EnrichmentProviderError extends Error {
  readonly code: string;
  readonly details: Record<string, unknown> | null;

  constructor(
    code: string,
    message: string,
    details: Record<string, unknown> | null = null,
  ) {
    super(message);
    this.name = "EnrichmentProviderError";
    this.code = code;
    this.details = details;
  }
}

