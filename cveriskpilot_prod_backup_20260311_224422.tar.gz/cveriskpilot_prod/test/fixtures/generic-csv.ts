export const successfulCsvFixture = `CVE,Title,Severity,Host,IP,Port,Description,Remediation
CVE-2024-21413,Microsoft Outlook RCE via Hyperlink Preview,Critical,mail-prod-01,10.10.20.15,443,Remote code execution through crafted hyperlink preview handling in Outlook,Patch Outlook immediately and disable hyperlink preview until updated
CVE-2024-27198,JetBrains TeamCity Auth Bypass,High,ci-teamcity-01,10.10.40.22,8111,Authentication bypass on TeamCity administrative endpoints,Upgrade TeamCity to 2023.11.4 or later`;

export const warningCsvFixture = `CVE,Title,Severity,Host,IP,Port,Description,Remediation,Custom Score
CVE-2024-21413,Microsoft Outlook RCE via Hyperlink Preview,Critical,mail-prod-01,10.10.20.15,443,Remote code execution through crafted hyperlink preview handling in Outlook,Patch Outlook immediately and disable hyperlink preview until updated,99

CVE-2024-3400,PAN-OS Command Injection in GlobalProtect,Critical,fw-edge-02,10.10.50.4,443,Unauthenticated command injection on GlobalProtect gateway,Apply PAN-OS hotfix immediately,100`;

export const malformedCsvFixture = `CVE,Title,Severity
"CVE-2024-21413,"Broken Quoted Value",Critical`;

export const rapid7JsonFixture = JSON.stringify({
  resources: [
    {
      id: "asset-001",
      ip: "10.10.60.14",
      host_name: "jenkins-prod-01",
      hostnames: ["jenkins-prod-01.cveriskpilot.local"],
      os: "Ubuntu 22.04",
      services: [
        {
          port: 8080,
          protocol: "tcp",
          name: "http",
          vulnerabilities: ["vuln-001"],
        },
      ],
      vulnerabilities: ["vuln-002"],
    },
  ],
  vulnerabilities: [
    {
      id: "vuln-001",
      title: "Jenkins Arbitrary File Read via CLI",
      severity: "critical",
      cvss_v3_score: 9.8,
      description: "Unauthenticated file read vulnerability on Jenkins CLI endpoint.",
      solution: "Upgrade Jenkins to 2.442 or LTS 2.426.3.",
      cves: ["CVE-2024-23897"],
      proof: "CLI endpoint exposed on production Jenkins node.",
    },
    {
      id: "vuln-002",
      title: "Weak TLS Ciphers Enabled",
      severity: "medium",
      cvss: 5.3,
      description: "Legacy TLS ciphers are enabled on the web service.",
      solution: "Disable deprecated cipher suites and re-scan.",
      cves: [],
      proof: "TLS handshake accepted deprecated ciphers.",
    },
  ],
});

export const nessusXmlFixture = `<?xml version="1.0"?>
<NessusClientData_v2 version="10.8.0">
  <Report name="Example Nessus Scan">
    <ReportHost name="mail-prod-01">
      <HostProperties>
        <tag name="host-ip">10.10.20.15</tag>
        <tag name="host-fqdn">mail-prod-01.cveriskpilot.local</tag>
        <tag name="operating-system">Windows Server 2022</tag>
      </HostProperties>
      <ReportItem
        port="443"
        svc_name="https"
        protocol="tcp"
        severity="4"
        pluginID="100001"
        pluginName="Microsoft Outlook RCE via Hyperlink Preview"
      >
        <description>Remote code execution through crafted hyperlink preview handling in Outlook.</description>
        <solution>Patch Outlook immediately and disable hyperlink preview until updated.</solution>
        <plugin_output>Outlook preview handler version vulnerable on target host.</plugin_output>
        <cvss3_base_score>9.8</cvss3_base_score>
        <cvss3_vector>CVSS:3.1/AV:N/AC:L/PR:N/UI:N/S:U/C:H/I:H/A:H</cvss3_vector>
        <cve>CVE-2024-21413</cve>
      </ReportItem>
      <ReportItem
        port="445"
        svc_name="smb"
        protocol="tcp"
        severity="3"
        pluginID="100002"
        pluginName="SMB Signing Not Required"
      >
        <description>SMB signing is not required on the remote host.</description>
        <solution>Require SMB signing via Group Policy.</solution>
        <plugin_output>Signing: disabled</plugin_output>
      </ReportItem>
    </ReportHost>
  </Report>
</NessusClientData_v2>`;

export const qualysXmlFixture = `<?xml version="1.0"?>
<HOST_LIST_VM_DETECTION_OUTPUT>
  <RESPONSE>
    <DATETIME>2026-03-10T00:00:00Z</DATETIME>
  </RESPONSE>
  <HOST_LIST>
    <HOST>
      <ID>4242</ID>
      <IP>10.10.50.4</IP>
      <DNS>fw-edge-02.cveriskpilot.local</DNS>
      <DETECTION_LIST>
        <DETECTION>
          <QID>376157</QID>
          <TITLE>PAN-OS Command Injection in GlobalProtect</TITLE>
          <SEVERITY>5</SEVERITY>
          <CVE_ID>CVE-2024-3400</CVE_ID>
          <CVSS3_BASE>10.0</CVSS3_BASE>
          <DIAGNOSIS>Unauthenticated command injection on GlobalProtect gateway.</DIAGNOSIS>
          <SOLUTION>Apply PAN-OS hotfix immediately.</SOLUTION>
          <RESULTS>Detected vulnerable PAN-OS build on target firewall.</RESULTS>
        </DETECTION>
        <DETECTION>
          <QID>123456</QID>
          <TITLE>TLS Version Detection</TITLE>
          <SEVERITY>2</SEVERITY>
          <DIAGNOSIS>Legacy TLS versions are enabled.</DIAGNOSIS>
          <SOLUTION>Disable TLS 1.0 and TLS 1.1.</SOLUTION>
        </DETECTION>
      </DETECTION_LIST>
    </HOST>
  </HOST_LIST>
</HOST_LIST_VM_DETECTION_OUTPUT>`;

export const qualysCsvFixture = `Host IP,DNS,QID,Title,Severity,CVE ID,CVSS v3.1 Base,Diagnosis,Solution,Results
10.10.40.22,ci-teamcity-01.cveriskpilot.local,150001,JetBrains TeamCity Auth Bypass,4,CVE-2024-27198,9.8,Authentication bypass on TeamCity administrative endpoints,Upgrade TeamCity to 2023.11.4 or later,Administrative endpoint exposed in current build
10.10.30.8,internal-app-01.cveriskpilot.local,220002,Weak SSH Ciphers,2,,5.3,Weak SSH ciphers are enabled,Disable deprecated SSH ciphers,Deprecated cipher suite detected`;
