"use client";

import { useRef, useState } from "react";

import { StatusPill } from "@/components/dashboard/StatusPill";

type UploadDropzoneProps = {
  errorMessage: string | null;
  isParsing: boolean;
  isUploading: boolean;
  onUpload: (file: File) => Promise<void>;
  selectedFileName: string | null;
  statusMessage: string | null;
};

export function UploadDropzone({
  errorMessage,
  isParsing,
  isUploading,
  onUpload,
  selectedFileName,
  statusMessage,
}: UploadDropzoneProps) {
  const inputRef = useRef<HTMLInputElement>(null);
  const [isDragging, setIsDragging] = useState(false);
  const actionButtonClass =
    "min-h-9 rounded-sm border px-4 py-2 font-mono text-[0.62rem] font-semibold uppercase leading-none tracking-[0.12em] transition";

  function openPicker() {
    inputRef.current?.click();
  }

  async function handleFileSelection(fileList: FileList | null) {
    const file = fileList?.[0];

    if (!file) {
      return;
    }

    await onUpload(file);
  }

  return (
    <section className="rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] p-5 shadow-[0_16px_40px_rgba(0,0,0,0.18)]">
      <div className="mb-3 font-mono text-[0.7rem] uppercase tracking-[0.14em] text-[var(--accent)]">
        // Upload New Report
      </div>
      <div
        className={`rounded border border-dashed px-6 py-10 text-center transition ${
          isDragging
            ? "border-[var(--accent)] bg-[rgba(0,200,180,0.08)]"
            : "border-[rgba(0,200,180,0.12)] bg-[rgba(255,255,255,0.01)]"
        }`}
        onDragOver={(event) => {
          event.preventDefault();
          setIsDragging(true);
        }}
        onDragLeave={() => setIsDragging(false)}
        onDrop={(event) => {
          event.preventDefault();
          setIsDragging(false);
          void handleFileSelection(event.dataTransfer.files);
        }}
      >
        <div className="text-[1.6rem] text-[#5a7080]">↑</div>
        <div className="mt-3 font-mono text-[0.7rem] uppercase tracking-[0.1em] text-[var(--text)]">
          Drag and drop a scan report here
        </div>
        <p className="mx-auto mt-3 max-w-xl text-[0.92rem] leading-7 text-[var(--text-dim)]">
          Upload a scanner export to normalize findings, enrich CVEs, and prepare AI-assisted triage.
        </p>
        <div className="mt-5 flex flex-wrap items-center justify-center gap-3">
          <button
            type="button"
            onClick={openPicker}
            disabled={isUploading || isParsing}
            className={`${actionButtonClass} border-[rgba(0,200,180,0.14)] bg-[var(--accent)] text-[#031017] hover:bg-[var(--accent-strong)]`}
          >
            {isUploading ? "Uploading..." : isParsing ? "Parsing..." : "Choose File"}
          </button>
          <StatusPill tone={isUploading || isParsing ? "warning" : "accent"}>
            {isUploading || isParsing ? "Ingestion Active" : "Live Ingestion"}
          </StatusPill>
        </div>
        <input
          ref={inputRef}
          type="file"
          accept=".json,.csv,.xml,.sarif"
          className="hidden"
          onChange={(event) => {
            void handleFileSelection(event.target.files);
            event.currentTarget.value = "";
          }}
        />
        <div className="mt-4 font-mono text-[0.66rem] leading-5 text-[#5a7080]">
          {selectedFileName
            ? `Selected file: ${selectedFileName}`
            : "Accepted now: JSON, CSV, XML · Future: SARIF"}
        </div>
        {statusMessage ? (
          <div className="mt-4 rounded border border-[rgba(0,200,180,0.16)] bg-[rgba(0,200,180,0.06)] px-3 py-2 text-sm text-[var(--text)]">
            {statusMessage}
          </div>
        ) : null}
        {errorMessage ? (
          <div className="mt-4 rounded border border-[rgba(255,69,96,0.24)] bg-[rgba(255,69,96,0.08)] px-3 py-2 text-sm text-[#ff8a9a]">
            {errorMessage}
          </div>
        ) : null}
      </div>
    </section>
  );
}
