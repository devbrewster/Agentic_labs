"use client";

import { useEffect, useState } from "react";

import { FindingsManagementTable } from "@/components/dashboard/FindingsManagementTable";
import type { Finding } from "@/types/dashboard";

type FindingsApiResponse = {
  ok: boolean;
  data?: {
    findings: Finding[];
    source: "ingestion" | "mock";
    total: number;
  };
  error?: {
    code: string;
    message: string;
  };
};

export function FindingsManagementWorkspace() {
  const [findings, setFindings] = useState<Finding[]>([]);
  const [dataSourceLabel, setDataSourceLabel] = useState("Loading findings dataset...");

  useEffect(() => {
    let cancelled = false;

    async function loadFindings() {
      try {
        const response = await fetch("/api/findings", {
          cache: "no-store",
        });
        const payload = (await response.json()) as FindingsApiResponse;

        if (!response.ok || !payload.ok || !payload.data) {
          throw new Error(payload.error?.message ?? "Unable to load findings.");
        }

        if (cancelled) {
          return;
        }

        setFindings(payload.data.findings);
        setDataSourceLabel(
          payload.data.total > 0
            ? `Showing ${payload.data.total} ingested findings from upload parsing`
            : "No ingested findings are available yet",
        );
      } catch (error) {
        if (!cancelled) {
          setFindings([]);
          setDataSourceLabel(
            error instanceof Error ? error.message : "Unable to load findings dataset",
          );
        }
      }
    }

    void loadFindings();

    return () => {
      cancelled = true;
    };
  }, []);

  return <FindingsManagementTable findings={findings} dataSourceLabel={dataSourceLabel} />;
}
