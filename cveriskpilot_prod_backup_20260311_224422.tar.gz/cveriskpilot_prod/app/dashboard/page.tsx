import { DashboardOverviewWorkspace } from "@/components/dashboard/DashboardOverviewWorkspace";

export default function DashboardOverviewPage() {
  return <DashboardOverviewWorkspace />;
}
