import { getAnalystRuntime } from "@/lib/analyst/runtime";
import { getAnalysisRuntime } from "@/lib/analysis/runtime";
import { getCachedExecutiveSummary } from "@/lib/cache/workload-cache";
import { getEnrichmentRuntime } from "@/lib/enrichment/runtime";
import { getIngestionRuntime } from "@/lib/ingestion/runtime";
import { buildEnrichmentSummary } from "@/lib/services/enrichment-summary";
import {
  applyPrioritizationInfluence,
  listFindings,
  mapNormalizedFindingToDashboardFinding,
  sortFindingsByPriority,
  type FindingIngestionContext,
} from "@/lib/services/findings";
import { toArchitectureSummary } from "@/types/analyst";
import type { Finding } from "@/types/dashboard";

export type ExecutiveSummaryReport = {
  source: "ingestion" | "mock";
  generatedAt: string;
  totals: {
    findings: number;
    criticalOpen: number;
    highOpen: number;
    actionPlans: number;
  };
  posture: {
    originalSourceDataCount: number;
    aiAnalysisCount: number;
    enrichmentCoverageCount: number;
    analystReviewedCount: number;
  };
  uncertainty: {
    count: number;
    items: Array<{
      findingId: string;
      cveId: string;
      title: string;
      message: string;
      severity: Finding["severity"];
    }>;
  };
  topFindings: Array<{
    id: string;
    cveId: string;
    title: string;
    severity: Finding["severity"];
    assetName: string;
    status: Finding["status"];
    baseRiskScore: number;
    adjustedRiskScore: number;
    rationale: string[];
    originalSourceData: string[];
    otherEnrichmentSources: string[];
    analysisStatus: "present" | "fallback_only" | "missing";
  }>;
  actionPlans: Array<{
    findingId: string;
    cveId: string;
    priority: string;
    assignee: string;
    eta: string;
    component: string;
    labels: string[];
  }>;
};

type ReportFindingContext = {
  finding: Finding;
  analysisStatus: "present" | "fallback_only" | "missing";
};

function buildUncertaintyItems(findings: ReportFindingContext[]) {
  const items: ExecutiveSummaryReport["uncertainty"]["items"] = [];

  for (const item of findings) {
    const { finding } = item;

    if (!finding.enrichmentSummary || finding.enrichmentSummary.status === "pending") {
      items.push({
        findingId: finding.id,
        cveId: finding.cveId,
        title: finding.title,
        message: "Enrichment has not completed, so prioritization is based on parsed scanner data only.",
        severity: finding.severity,
      });
      continue;
    }

    if (finding.enrichmentSummary.status === "partial") {
      items.push({
        findingId: finding.id,
        cveId: finding.cveId,
        title: finding.title,
        message: "Enrichment completed with partial provider failures. Review source coverage before escalating to stakeholders.",
        severity: finding.severity,
      });
    }

    if (item.analysisStatus === "fallback_only") {
      items.push({
        findingId: finding.id,
        cveId: finding.cveId,
        title: finding.title,
        message: "AI narrative used deterministic fallback content instead of live Claude output.",
        severity: finding.severity,
      });
    }

    if (!finding.analystDisposition) {
      items.push({
        findingId: finding.id,
        cveId: finding.cveId,
        title: finding.title,
        message: "No analyst disposition is recorded yet, so stakeholder guidance is provisional.",
        severity: finding.severity,
      });
    }
  }

  return items.slice(0, 8);
}

function buildTopFindings(findings: ReportFindingContext[]) {
  return findings.slice(0, 5).map((item) => ({
    id: item.finding.id,
    cveId: item.finding.cveId,
    title: item.finding.title,
    severity: item.finding.severity,
    assetName: item.finding.assetName,
    status: item.finding.status,
    baseRiskScore: item.finding.prioritization?.baseRiskScore ?? item.finding.riskScore,
    adjustedRiskScore: item.finding.riskScore,
    rationale:
      item.finding.prioritization?.reasons.length
        ? item.finding.prioritization.reasons
        : ["Prioritized from base scanner severity and CVSS context."],
    originalSourceData: [
      item.finding.source.name,
      item.finding.ingestionProvenance?.artifactFilename ?? "mock-dataset",
    ],
    otherEnrichmentSources: item.finding.enrichmentSummary?.providers ?? [],
    analysisStatus: item.analysisStatus,
  }));
}

function buildActionPlans(findings: ReportFindingContext[]) {
  return findings
    .filter((item) => item.finding.ticketReadyActionPlan)
    .slice(0, 5)
    .map((item) => ({
      findingId: item.finding.id,
      cveId: item.finding.cveId,
      priority: item.finding.ticketReadyActionPlan?.priority ?? "Pending",
      assignee: item.finding.ticketReadyActionPlan?.assignee ?? "Unassigned",
      eta: item.finding.ticketReadyActionPlan?.eta ?? "TBD",
      component: item.finding.ticketReadyActionPlan?.component ?? item.finding.product,
      labels: item.finding.ticketReadyActionPlan?.labels ?? [],
    }));
}

function buildMockExecutiveSummary(): ExecutiveSummaryReport {
  const findings = sortFindingsByPriority(listFindings()).map((finding) => ({
    finding,
    analysisStatus: "missing" as const,
  }));

  const uncertaintyItems = buildUncertaintyItems(findings);

  return {
    source: "mock",
    generatedAt: new Date().toISOString(),
    totals: {
      findings: findings.length,
      criticalOpen: findings.filter(
        ({ finding }) => finding.severity === "critical" && finding.status !== "mitigated",
      ).length,
      highOpen: findings.filter(
        ({ finding }) => finding.severity === "high" && finding.status !== "mitigated",
      ).length,
      actionPlans: buildActionPlans(findings).length,
    },
    posture: {
      originalSourceDataCount: findings.length,
      aiAnalysisCount: 0,
      enrichmentCoverageCount: findings.filter(({ finding }) => finding.enrichmentSummary).length,
      analystReviewedCount: findings.filter(({ finding }) => Boolean(finding.analystDisposition)).length,
    },
    uncertainty: {
      count: uncertaintyItems.length,
      items: uncertaintyItems,
    },
    topFindings: buildTopFindings(findings),
    actionPlans: buildActionPlans(findings),
  };
}

export async function getExecutiveSummaryReport(
  organizationId?: string,
): Promise<ExecutiveSummaryReport> {
  if (!organizationId) {
    return {
      source: "ingestion",
      generatedAt: new Date().toISOString(),
      totals: {
        findings: 0,
        criticalOpen: 0,
        highOpen: 0,
        actionPlans: 0,
      },
      posture: {
        originalSourceDataCount: 0,
        aiAnalysisCount: 0,
        enrichmentCoverageCount: 0,
        analystReviewedCount: 0,
      },
      uncertainty: {
        count: 0,
        items: [],
      },
      topFindings: [],
      actionPlans: [],
    };
  }

  try {
    return getCachedExecutiveSummary(organizationId, async () =>
      buildExecutiveSummaryReport(organizationId),
    );
  } catch (error) {
    console.error("Falling back to mock executive summary:", error);
    return {
      source: "ingestion",
      generatedAt: new Date().toISOString(),
      totals: {
        findings: 0,
        criticalOpen: 0,
        highOpen: 0,
        actionPlans: 0,
      },
      posture: {
        originalSourceDataCount: 0,
        aiAnalysisCount: 0,
        enrichmentCoverageCount: 0,
        analystReviewedCount: 0,
      },
      uncertainty: {
        count: 0,
        items: [],
      },
      topFindings: [],
      actionPlans: [],
    };
  }
}

async function buildExecutiveSummaryReport(
  organizationId?: string,
): Promise<ExecutiveSummaryReport> {
  try {
    const [
      { uploadRepository },
      { enrichmentRepository },
      { analystDispositionRepository },
      { analysisTraceRepository },
    ] = await Promise.all([
      getIngestionRuntime(),
      getEnrichmentRuntime(),
      getAnalystRuntime(),
      getAnalysisRuntime(),
    ]);
    if (!organizationId) {
      return {
        source: "ingestion",
        generatedAt: new Date().toISOString(),
        totals: {
          findings: 0,
          criticalOpen: 0,
          highOpen: 0,
          actionPlans: 0,
        },
        posture: {
          originalSourceDataCount: 0,
          aiAnalysisCount: 0,
          enrichmentCoverageCount: 0,
          analystReviewedCount: 0,
        },
        uncertainty: {
          count: 0,
          items: [],
        },
        topFindings: [],
        actionPlans: [],
      };
    }

    const normalizedFindings = await uploadRepository.listFindingsByTenant(organizationId);

    if (normalizedFindings.length === 0) {
      return {
        source: "ingestion",
        generatedAt: new Date().toISOString(),
        totals: {
          findings: 0,
          criticalOpen: 0,
          highOpen: 0,
          actionPlans: 0,
        },
        posture: {
          originalSourceDataCount: 0,
          aiAnalysisCount: 0,
          enrichmentCoverageCount: 0,
          analystReviewedCount: 0,
        },
        uncertainty: {
          count: 0,
          items: [],
        },
        topFindings: [],
        actionPlans: [],
      };
    }

    const uniqueUploadJobIds = Array.from(new Set(normalizedFindings.map((finding) => finding.uploadJobId)));
    const uploadContextEntries = await Promise.all(
      uniqueUploadJobIds.map(async (uploadJobId) => {
        const record = await uploadRepository.findByIdForTenant(uploadJobId, organizationId);

        if (!record) {
          return [uploadJobId, undefined] as const;
        }

        const context: FindingIngestionContext = {
          artifactFilename: record.rawArtifact.originalFilename,
          checksumSha256: record.rawArtifact.checksumSha256,
          warningCount: record.outcome?.parserWarnings.length ?? 0,
          errorCount: record.outcome?.parserErrors.length ?? 0,
        };

        return [uploadJobId, context] as const;
      }),
    );
    const uploadContextByJobId = new Map(uploadContextEntries);

    const findings = await Promise.all(
      normalizedFindings.map(async (normalizedFinding) => {
        const mappedFinding = mapNormalizedFindingToDashboardFinding(
          normalizedFinding,
          uploadContextByJobId.get(normalizedFinding.uploadJobId),
        );
        const [snapshots, disposition, traces] = await Promise.all([
          enrichmentRepository.listSnapshotsByFindingId(normalizedFinding.id),
          analystDispositionRepository.findByFindingId(normalizedFinding.id),
          analysisTraceRepository.listByFindingId(normalizedFinding.id),
        ]);

        const enrichmentSummary = buildEnrichmentSummary(snapshots);
        const enrichedFinding: Finding = {
          ...mappedFinding,
          enrichmentSummary,
          analystDisposition: disposition?.decision ?? mappedFinding.analystDisposition,
          analystRationale: disposition?.rationale ?? mappedFinding.analystRationale,
          analystNotes: disposition?.notes ?? mappedFinding.analystNotes,
          decisionRationale: disposition?.rationale ?? mappedFinding.decisionRationale,
          architectureContextSummary: disposition
            ? toArchitectureSummary(disposition.factors)
            : mappedFinding.architectureContextSummary,
        };

        const prioritized = applyPrioritizationInfluence(enrichedFinding, disposition, snapshots);
        const latestTrace = traces[0] ?? null;
        const analysisStatus =
          latestTrace?.traceStatus === "fallback"
            ? "fallback_only"
            : latestTrace
              ? "present"
              : "missing";

        return {
          finding: prioritized,
          analysisStatus,
        } satisfies ReportFindingContext;
      }),
    );

    const sortedFindings = sortFindingsByPriority(findings.map((item) => item.finding)).map((finding) => {
      const context = findings.find((item) => item.finding.id === finding.id);
      return context ?? { finding, analysisStatus: "missing" as const };
    });
    const uncertaintyItems = buildUncertaintyItems(sortedFindings);
    const actionPlans = buildActionPlans(sortedFindings);

    return {
      source: "ingestion",
      generatedAt: new Date().toISOString(),
      totals: {
        findings: sortedFindings.length,
        criticalOpen: sortedFindings.filter(
          ({ finding }) => finding.severity === "critical" && finding.status !== "mitigated",
        ).length,
        highOpen: sortedFindings.filter(
          ({ finding }) => finding.severity === "high" && finding.status !== "mitigated",
        ).length,
        actionPlans: actionPlans.length,
      },
      posture: {
        originalSourceDataCount: sortedFindings.length,
        aiAnalysisCount: sortedFindings.filter(({ analysisStatus }) => analysisStatus !== "missing").length,
        enrichmentCoverageCount: sortedFindings.filter(
          ({ finding }) =>
            Boolean(finding.enrichmentSummary) && finding.enrichmentSummary?.status !== "pending",
        ).length,
        analystReviewedCount: sortedFindings.filter(({ finding }) => Boolean(finding.analystDisposition)).length,
      },
      uncertainty: {
        count: uncertaintyItems.length,
        items: uncertaintyItems,
      },
      topFindings: buildTopFindings(sortedFindings),
      actionPlans,
    };
  } catch (error) {
    throw error;
  }
}
