import { describe, expect, it } from "vitest";

import { QualysParser } from "@/lib/ingestion/parsers/qualys-parser";
import { qualysCsvFixture, qualysXmlFixture } from "@/test/fixtures/generic-csv";
import type { ParseContext, RawArtifact } from "@/types/ingestion";

function createArtifact(fileType: "xml" | "csv", filename: string): RawArtifact {
  return {
    id: crypto.randomUUID(),
    storageKey: `test/${filename}`,
    originalFilename: filename,
    mimeType: fileType === "xml" ? "application/xml" : "text/csv",
    fileType,
    sizeBytes: 1024,
    checksumSha256: "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",
    uploadedAt: "2026-03-10T00:00:00.000Z",
  };
}

function createContext(uploadJobId = crypto.randomUUID()): ParseContext {
  return {
    uploadJob: {
      id: uploadJobId,
      tenantId: null,
      rawArtifactId: crypto.randomUUID(),
      selectedSourceType: "qualys",
      detectedSourceType: "qualys",
      status: "parsing",
      errorSummary: null,
      warningCount: 0,
      findingCount: 0,
      checksumSha256: "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",
      createdAt: "2026-03-10T00:00:00.000Z",
      updatedAt: "2026-03-10T00:00:00.000Z",
      parsedAt: null,
    },
    rawArtifact: createArtifact("xml", "fixture.xml"),
    selectedSourceType: "qualys",
    detectedSourceType: "qualys",
    checksumSha256: "cccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccccc",
    now: "2026-03-10T00:00:00.000Z",
  };
}

describe("QualysParser", () => {
  it("detects and parses Qualys XML into normalized findings", async () => {
    const parser = new QualysParser();
    const canParse = await parser.canParse({
      filename: "qualys-export.xml",
      mimeType: "application/xml",
      fileType: "xml",
      leadingBytes: qualysXmlFixture.slice(0, 128),
      sampleText: qualysXmlFixture.slice(0, 2048),
    });

    expect(canParse).toBe(true);

    const result = await parser.parse({
      artifact: createArtifact("xml", "qualys-export.xml"),
      content: qualysXmlFixture,
      context: createContext(),
    });

    expect(result.parserErrors).toHaveLength(0);
    expect(result.findings).toHaveLength(2);
    expect(result.findings[0]?.cveIds).toContain("CVE-2024-3400");
    expect(result.findings[0]?.normalizedSeverity).toBe("critical");
    expect(result.metadata.hostCount).toBe(1);
    expect(result.metadata.findingCount).toBe(2);
  });

  it("parses Qualys CSV exports into normalized findings", async () => {
    const parser = new QualysParser();
    const result = await parser.parse({
      artifact: createArtifact("csv", "qualys-export.csv"),
      content: qualysCsvFixture,
      context: {
        ...createContext(),
        rawArtifact: createArtifact("csv", "qualys-export.csv"),
      },
    });

    expect(result.parserErrors).toHaveLength(0);
    expect(result.findings).toHaveLength(2);
    expect(result.findings[0]?.title).toContain("TeamCity");
    expect(result.findings[0]?.cvssScore).toBe(9.8);
    expect(
      result.parserWarnings.some((warning) => warning.code === "qualys_missing_cve"),
    ).toBe(true);
  });
});
