import { getDb } from "@/lib/db";
import { D1AnalysisTraceRepository } from "@/lib/analysis/d1-repository";
import { PostgresAnalysisTraceRepository } from "@/lib/analysis/postgres-repository";
import {
  InMemoryAnalysisTraceRepository,
  type AnalysisTraceRepository,
} from "@/lib/analysis/repository";
import { getOrCreatePostgresQueryClient } from "@/lib/platform/postgres";
import { getPlatformProfile } from "@/lib/platform/runtime";

type AnalysisRuntime = {
  analysisTraceRepository: AnalysisTraceRepository;
};

const fallbackAnalysisTraceRepository = new InMemoryAnalysisTraceRepository();

const fallbackRuntime: AnalysisRuntime = {
  analysisTraceRepository: fallbackAnalysisTraceRepository,
};

function isFallbackRuntimeError(error: unknown) {
  if (!(error instanceof Error)) {
    return false;
  }

  return (
    /Cloudflare D1 binding/i.test(error.message) ||
    /getCloudflareContext/i.test(error.message) ||
    /Database schema is not initialized/i.test(error.message)
  );
}

export async function getAnalysisRuntime(): Promise<AnalysisRuntime> {
  const platform = getPlatformProfile();

  if (platform.databaseDriver === "postgres") {
    const postgresClient = await getOrCreatePostgresQueryClient();

    if (postgresClient) {
      return {
        analysisTraceRepository: new PostgresAnalysisTraceRepository(postgresClient),
      };
    }
  }

  try {
    const db = await getDb();
    return {
      analysisTraceRepository: new D1AnalysisTraceRepository(db),
    };
  } catch (error) {
    if (isFallbackRuntimeError(error)) {
      return fallbackRuntime;
    }

    throw error;
  }
}
