"use client";

import type { ArchitectureInfluenceFactors } from "@/types/dashboard";

import { AnalysisSectionCard } from "@/components/dashboard/AnalysisSectionCard";
import { StatusPill } from "@/components/dashboard/StatusPill";

type EnterpriseContextSectionProps = {
  factors: ArchitectureInfluenceFactors;
  onChange: (value: ArchitectureInfluenceFactors) => void;
  summary?: string;
};

const booleanFields: Array<keyof Omit<ArchitectureInfluenceFactors, "assetCriticality">> = [
  "internetExposed",
  "internalOnly",
  "segmentedNetwork",
  "compensatingControlPresent",
  "authRequired",
  "reachableFromAttackerPath",
];

function labelForField(field: string) {
  return field.replace(/[A-Z]/g, (match) => ` ${match.toLowerCase()}`);
}

function computeInfluenceSummary(factors: ArchitectureInfluenceFactors) {
  const notes = [];

  if (factors.internetExposed && factors.reachableFromAttackerPath) {
    notes.push("Internet exposure and attacker-path reachability increase likely business impact.");
  }

  if (factors.compensatingControlPresent || factors.segmentedNetwork) {
    notes.push("Segmentation and compensating controls can reduce effective blast radius.");
  }

  if (factors.assetCriticality === "critical" || factors.assetCriticality === "high") {
    notes.push("High asset criticality should bias future triage toward stronger remediation urgency.");
  }

  if (factors.authRequired && !factors.internetExposed) {
    notes.push("Authentication requirements and internal-only access may reduce exploitability assumptions.");
  }

  return notes.join(" ");
}

export function EnterpriseContextSection({
  factors,
  onChange,
  summary,
}: EnterpriseContextSectionProps) {
  return (
    <AnalysisSectionCard title="Enterprise Architecture Context" badge="Context Model">
      <div className="grid gap-2 sm:grid-cols-2">
        {booleanFields.map((field) => (
          <label
            key={field}
            className="flex items-center gap-2 rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2 font-mono text-[0.64rem] uppercase tracking-[0.08em] text-[var(--text)]"
          >
            <input
              type="checkbox"
              checked={factors[field]}
              onChange={(event) =>
                onChange({
                  ...factors,
                  [field]: event.target.checked,
                })
              }
              className="accent-[var(--accent)]"
            />
            {labelForField(field)}
          </label>
        ))}
      </div>

      <div className="mt-3">
        <div className="mb-2 font-mono text-[0.62rem] uppercase tracking-[0.12em] text-[#5a7080]">
          Asset criticality
        </div>
        <div className="flex flex-wrap gap-2">
          {(["critical", "high", "medium", "low"] as const).map((level) => (
            <button
              key={level}
              type="button"
              onClick={() => onChange({ ...factors, assetCriticality: level })}
              className={`rounded border px-3 py-1.5 font-mono text-[0.62rem] uppercase tracking-[0.08em] transition ${
                factors.assetCriticality === level
                  ? "border-[rgba(0,200,180,0.16)] bg-[rgba(0,200,180,0.12)] text-[var(--accent)]"
                  : "border-[rgba(0,200,180,0.06)] text-[#5a7080] hover:border-[rgba(0,200,180,0.12)] hover:text-[var(--text)]"
              }`}
            >
              {level}
            </button>
          ))}
        </div>
      </div>

      {summary ? (
        <div className="mt-4 rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-3 text-[0.8rem] leading-7 text-[var(--text-dim)]">
          {summary}
        </div>
      ) : null}

      <div className="mt-4 flex flex-wrap gap-2">
        <StatusPill tone="accent">Future AI Influence</StatusPill>
      </div>
      <p className="mt-3 text-[0.78rem] leading-7 text-[var(--text-dim)]">
        {computeInfluenceSummary(factors)}
      </p>
    </AnalysisSectionCard>
  );
}
