import type { AppDatabase } from "@/lib/platform/database";
import type { OrganizationRepository } from "@/lib/organizations/repository";
import type {
  CurrentOrganizationContext,
  Organization,
  OrganizationId,
  OrganizationMembershipSummary,
} from "@/types/organization";
import { OrganizationMemberSchema, OrganizationSchema } from "@/types/organization";

type MembershipRow = {
  organization_id: string;
  organization_name: string;
  organization_slug: string;
  organization_status: string;
  organization_created_at: string;
  organization_updated_at: string;
  member_id: string;
  user_id: string;
  role: string;
  joined_at: string;
  invited_by_user_id: string | null;
};

type OrganizationRow = {
  id: string;
  name: string;
  slug: string;
  status: string;
  created_at: string;
  updated_at: string;
};

function mapOrganization(row: OrganizationRow): Organization {
  return OrganizationSchema.parse({
    id: row.id,
    name: row.name,
    slug: row.slug,
    status: row.status,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  });
}

function mapMembershipSummary(row: MembershipRow): OrganizationMembershipSummary {
  return {
    organization: OrganizationSchema.parse({
      id: row.organization_id,
      name: row.organization_name,
      slug: row.organization_slug,
      status: row.organization_status,
      createdAt: row.organization_created_at,
      updatedAt: row.organization_updated_at,
    }),
    member: OrganizationMemberSchema.parse({
      id: row.member_id,
      organizationId: row.organization_id,
      userId: row.user_id,
      role: row.role,
      joinedAt: row.joined_at,
      invitedByUserId: row.invited_by_user_id,
    }),
  };
}

export class SqlOrganizationRepository implements OrganizationRepository {
  constructor(private readonly db: AppDatabase) {}

  async findOrganizationById(organizationId: OrganizationId) {
    const row = await this.db
      .prepare(
        `SELECT id, name, slug, status, created_at, updated_at
         FROM organizations
         WHERE id = ?
         LIMIT 1`,
      )
      .bind(organizationId)
      .first<OrganizationRow>();

    return row ? mapOrganization(row) : null;
  }

  async findMembershipsByUserId(userId: string) {
    const rows = await this.db
      .prepare(
        `SELECT
           org.id AS organization_id,
           org.name AS organization_name,
           org.slug AS organization_slug,
           org.status AS organization_status,
           org.created_at AS organization_created_at,
           org.updated_at AS organization_updated_at,
           om.id AS member_id,
           om.user_id,
           om.role,
           om.joined_at,
           om.invited_by_user_id
         FROM organization_members om
         INNER JOIN organizations org ON org.id = om.organization_id
         WHERE om.user_id = ?
         ORDER BY org.created_at ASC`,
      )
      .bind(userId)
      .all<MembershipRow>();

    return rows.map(mapMembershipSummary);
  }

  async getCurrentContextForUser(userId: string): Promise<CurrentOrganizationContext> {
    const memberships = await this.findMembershipsByUserId(userId);

    return {
      organizationId: memberships[0]?.organization.id ?? null,
      memberships,
    };
  }
}
