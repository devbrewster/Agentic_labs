"use client";

import { useMemo, useState } from "react";

import { StatusPill } from "@/components/dashboard/StatusPill";
import { SurfaceCard } from "@/components/dashboard/SurfaceCard";
import type { PendingIssue, IssuePriority, IssueStatus, IssueTrack } from "@/types/issues";

type IssuesWorkspaceProps = {
  issues: PendingIssue[];
  totalOpenItems: number;
};

const priorityOptions: Array<IssuePriority | "all"> = ["all", "P0 Now", "P1 Next", "P2 Later"];
const statusOptions: Array<IssueStatus | "all"> = [
  "all",
  "in_progress",
  "blocked",
  "queued",
  "monitoring",
  "completed",
];
const trackOptions: Array<IssueTrack | "all"> = [
  "all",
  "dashboard_access",
  "enrichment",
  "ingestion",
  "billing",
  "audit",
  "ui",
];

const priorityTone: Record<IssuePriority, "danger" | "warning" | "default"> = {
  "P0 Now": "danger",
  "P1 Next": "warning",
  "P2 Later": "default",
};

const statusTone: Record<IssueStatus, "accent" | "danger" | "warning" | "default" | "success"> = {
  in_progress: "accent",
  blocked: "danger",
  queued: "warning",
  monitoring: "default",
  completed: "success",
};

function formatIssueStatus(status: IssueStatus) {
  return status.replaceAll("_", " ");
}

function formatIssueTrack(track: IssueTrack) {
  switch (track) {
    case "dashboard_access":
      return "Dashboard Access";
    case "ingestion":
      return "Ingestion";
    case "enrichment":
      return "Enrichment";
    case "billing":
      return "Billing";
    case "audit":
      return "Audit";
    case "ui":
      return "UI";
  }
}

export function IssuesWorkspace({ issues, totalOpenItems }: IssuesWorkspaceProps) {
  const [query, setQuery] = useState("");
  const [priority, setPriority] = useState<IssuePriority | "all">("all");
  const [status, setStatus] = useState<IssueStatus | "all">("all");
  const [track, setTrack] = useState<IssueTrack | "all">("all");

  const filteredIssues = useMemo(() => {
    const normalizedQuery = query.trim().toLowerCase();

    return issues.filter((issue) => {
      if (priority !== "all" && issue.priority !== priority) {
        return false;
      }

      if (status !== "all" && issue.status !== status) {
        return false;
      }

      if (track !== "all" && issue.track !== track) {
        return false;
      }

      if (!normalizedQuery) {
        return true;
      }

      const searchable = [
        issue.id,
        issue.title,
        issue.summary,
        issue.impact,
        issue.nextAction,
      ].join(" ").toLowerCase();

      return searchable.includes(normalizedQuery);
    });
  }, [issues, priority, query, status, track]);

  return (
    <div className="space-y-5">
      <SurfaceCard
        eyebrow="// Issues"
        title="Pending issue monitor"
        description="This view tracks the live implementation backlog with priority, status, impact, and next action so operators and Discord agents share one current source of truth."
        meta={<StatusPill tone="warning">{totalOpenItems} Open Items</StatusPill>}
      >
        <div className="grid gap-3 lg:grid-cols-[1.2fr_repeat(3,minmax(0,0.8fr))]">
          <label className="space-y-2">
            <span className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#5a7080]">
              Search
            </span>
            <input
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Search issue, impact, or next action..."
              className="w-full rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2.5 text-[0.84rem] text-white outline-none transition focus:border-[rgba(0,200,180,0.18)]"
            />
          </label>

          <label className="space-y-2">
            <span className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#5a7080]">
              Priority
            </span>
            <select
              value={priority}
              onChange={(event) => setPriority(event.target.value as IssuePriority | "all")}
              className="w-full rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2.5 text-[0.84rem] text-white outline-none transition focus:border-[rgba(0,200,180,0.18)]"
            >
              {priorityOptions.map((option) => (
                <option key={option} value={option}>
                  {option === "all" ? "All priorities" : option}
                </option>
              ))}
            </select>
          </label>

          <label className="space-y-2">
            <span className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#5a7080]">
              Status
            </span>
            <select
              value={status}
              onChange={(event) => setStatus(event.target.value as IssueStatus | "all")}
              className="w-full rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2.5 text-[0.84rem] text-white outline-none transition focus:border-[rgba(0,200,180,0.18)]"
            >
              {statusOptions.map((option) => (
                <option key={option} value={option}>
                  {option === "all" ? "All statuses" : formatIssueStatus(option)}
                </option>
              ))}
            </select>
          </label>

          <label className="space-y-2">
            <span className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#5a7080]">
              Track
            </span>
            <select
              value={track}
              onChange={(event) => setTrack(event.target.value as IssueTrack | "all")}
              className="w-full rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2.5 text-[0.84rem] text-white outline-none transition focus:border-[rgba(0,200,180,0.18)]"
            >
              {trackOptions.map((option) => (
                <option key={option} value={option}>
                  {option === "all" ? "All tracks" : formatIssueTrack(option)}
                </option>
              ))}
            </select>
          </label>
        </div>
      </SurfaceCard>

      <SurfaceCard
        eyebrow="// Filtered List"
        title="Structured issue list"
        description={`Showing ${filteredIssues.length} issue${filteredIssues.length === 1 ? "" : "s"} after local filtering.`}
      >
        <div className="space-y-3">
          {filteredIssues.map((issue) => (
            <div
              key={issue.id}
              className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4"
            >
              <div className="flex flex-wrap items-center gap-2">
                <div className="font-mono text-[0.68rem] tracking-[0.08em] text-[var(--accent)]">
                  {issue.id}
                </div>
                <StatusPill tone={priorityTone[issue.priority]}>{issue.priority}</StatusPill>
                <StatusPill tone={statusTone[issue.status]}>{formatIssueStatus(issue.status)}</StatusPill>
                <StatusPill>{formatIssueTrack(issue.track)}</StatusPill>
              </div>
              <div className="mt-3 text-[0.95rem] font-semibold text-white">{issue.title}</div>
              <div className="mt-2 text-[0.82rem] leading-7 text-[var(--text-dim)]">
                {issue.summary}
              </div>
              <div className="mt-2 text-[0.8rem] leading-7 text-[var(--text)]">
                <span className="font-semibold text-white">Impact:</span> {issue.impact}
              </div>
              <div className="mt-1 text-[0.8rem] leading-7 text-[var(--text)]">
                <span className="font-semibold text-white">Next action:</span> {issue.nextAction}
              </div>
            </div>
          ))}
          {filteredIssues.length === 0 ? (
            <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4 text-[0.84rem] text-[var(--text-dim)]">
              No issues match the current filters.
            </div>
          ) : null}
        </div>
      </SurfaceCard>
    </div>
  );
}
