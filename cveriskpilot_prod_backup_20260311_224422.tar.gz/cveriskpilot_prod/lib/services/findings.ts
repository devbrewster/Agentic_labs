import {
  findingsFilterTabs,
  mockPriorityFindings,
  type FindingsFilterTab,
} from "@/lib/mock/findings";
import type { AnalystDispositionRecord } from "@/types/analyst";
import type { NormalizedFinding } from "@/types/ingestion";
import type { FindingEnrichmentSnapshot } from "@/types/enrichment";
import type { Finding } from "@/types/dashboard";
import { buildEnrichmentSummary } from "@/lib/services/enrichment-summary";

export type { FindingsFilterTab } from "@/lib/mock/findings";

export function listFindings(): Finding[] {
  return mockPriorityFindings;
}

export function listFindingsFilterTabs(): readonly FindingsFilterTab[] {
  return findingsFilterTabs;
}

export function getFindingById(findingId: string): Finding | null {
  return mockPriorityFindings.find((finding) => finding.id === findingId) ?? null;
}

export type FindingIngestionContext = {
  artifactFilename: string;
  checksumSha256: string;
  errorCount: number;
  warningCount: number;
};

function clampRiskScore(value: number) {
  return Math.max(0, Math.min(100, Math.round(value)));
}

function normalizeFindingStatus(status: NormalizedFinding["status"]): Finding["status"] {
  switch (status) {
    case "triaged":
    case "in_progress":
    case "accepted_risk":
    case "false_positive":
    case "not_applicable":
      return status;
    case "resolved":
      return "mitigated";
    default:
      return "new";
  }
}

function resolveEnvironment(finding: NormalizedFinding): Finding["environment"] {
  const assetValue = `${finding.hostname ?? ""} ${finding.fqdn ?? ""}`.toLowerCase();

  if (assetValue.includes("stage") || assetValue.includes("staging")) {
    return "staging";
  }

  if (assetValue.includes("dev") || assetValue.includes("test")) {
    return "development";
  }

  return "production";
}

function buildRiskScore(finding: NormalizedFinding) {
  const cvssBase = Math.round((finding.cvssScore ?? 0) * 10);

  switch (finding.normalizedSeverity) {
    case "critical":
      return Math.max(cvssBase, 90);
    case "high":
      return Math.max(cvssBase, 75);
    case "medium":
      return Math.max(cvssBase, 55);
    case "low":
      return Math.max(cvssBase, 30);
    default:
      return Math.max(cvssBase, 20);
  }
}

function buildDispositionAdjustment(
  disposition: AnalystDispositionRecord | null,
  reasons: string[],
) {
  switch (disposition?.decision) {
    case "true_risk":
      reasons.push("Analyst confirmed this finding as a true risk.");
      return 6;
    case "accepted_risk":
      reasons.push("Accepted risk lowers remediation priority while keeping visibility.");
      return -18;
    case "mitigated":
      reasons.push("Mitigated finding is deprioritized after analyst validation.");
      return -40;
    case "false_positive":
      reasons.push("False positive strongly suppresses prioritization.");
      return -60;
    case "not_applicable":
      reasons.push("Not applicable finding is suppressed for active triage.");
      return -55;
    default:
      return 0;
  }
}

function buildContextAdjustment(
  disposition: AnalystDispositionRecord | null,
  enrichmentSummary: Finding["enrichmentSummary"] | undefined,
  reasons: string[],
) {
  const factors = disposition?.factors;
  let adjustment = 0;

  if (factors?.internetExposed) {
    adjustment += 8;
    reasons.push("Internet exposure increases business urgency.");
  }

  if (factors?.reachableFromAttackerPath) {
    adjustment += 8;
    reasons.push("Reachable attacker path raises exploitation likelihood.");
  }

  if (factors?.assetCriticality === "critical") {
    adjustment += 8;
    reasons.push("Critical asset context elevates the finding.");
  } else if (factors?.assetCriticality === "high") {
    adjustment += 4;
    reasons.push("High asset criticality increases priority.");
  } else if (factors?.assetCriticality === "low") {
    adjustment -= 4;
    reasons.push("Low asset criticality reduces priority.");
  }

  if (factors?.compensatingControlPresent) {
    adjustment -= 10;
    reasons.push("Compensating controls reduce immediate remediation urgency.");
  }

  if (factors?.segmentedNetwork) {
    adjustment -= 5;
    reasons.push("Segmented network limits blast radius.");
  }

  if (factors?.authRequired) {
    adjustment -= 3;
    reasons.push("Authentication requirement reduces opportunistic exploitability.");
  }

  if (factors?.internalOnly) {
    adjustment -= 4;
    reasons.push("Internal-only exposure reduces stakeholder urgency.");
  }

  if (enrichmentSummary?.kevListed) {
    adjustment += 6;
    reasons.push("KEV listing increases urgency for remediation planning.");
  }

  if (enrichmentSummary?.exploitAvailable) {
    adjustment += 5;
    reasons.push("Exploit availability elevates prioritization.");
  }

  return adjustment;
}

function applyDispositionStatus(
  finding: Finding,
  disposition: AnalystDispositionRecord | null,
): Finding["status"] {
  switch (disposition?.decision) {
    case "accepted_risk":
    case "mitigated":
    case "false_positive":
    case "not_applicable":
      return disposition.decision;
    case "true_risk":
      return finding.status === "new" ? "triaged" : finding.status;
    default:
      return finding.status;
  }
}

export function mapNormalizedFindingToDashboardFinding(
  finding: NormalizedFinding,
  context?: FindingIngestionContext,
): Finding {
  const assetName =
    finding.hostname ??
    finding.fqdn ??
    finding.assetIdentifier ??
    finding.ipAddress ??
    "unknown-asset";

  const cveId = finding.cveIds[0] ?? finding.vulnerabilityId ?? finding.pluginId ?? finding.id;
  const discoveredAt =
    finding.detectedAt ?? finding.firstObservedAt ?? finding.createdAt;

  return {
    id: finding.id,
    cveId,
    title: finding.title,
    description: finding.description ?? "Imported from parsed scan artifact.",
    severity:
      finding.normalizedSeverity === "informational" || finding.normalizedSeverity === "unknown"
        ? "low"
        : finding.normalizedSeverity,
    cvssScore: finding.cvssScore ?? 0,
    riskScore: buildRiskScore(finding),
    exploitAvailable: false,
    kevListed: false,
    assetId: finding.assetIdentifier ?? assetName,
    assetName,
    product: finding.sourceScanner,
    version: "n/a",
    environment: resolveEnvironment(finding),
    internetExposed: false,
    privilegeRequired:
      finding.privilegeRequired === "low" || finding.privilegeRequired === "high"
        ? finding.privilegeRequired
        : "none",
    status: normalizeFindingStatus(finding.status),
    discoveredAt,
    source: {
      id: `${finding.uploadJobId}:${finding.sourceType}`,
      name: finding.sourceScanner,
      kind: "scanner",
      importedAt: finding.createdAt,
    },
    tags: finding.tags,
    businessImpact: finding.description ?? undefined,
    technicalImpact: finding.evidence ?? undefined,
    remediationSummary: finding.remediation ?? undefined,
    analystNotes: undefined,
    decisionRationale: undefined,
    businessImpactSource: "analyst",
    aiConfidence: undefined,
    lastEnrichedAt: finding.updatedAt,
    analystDisposition: undefined,
    analystRationale: undefined,
    architectureContextSummary: `Imported from ${finding.sourceScanner} via upload job ${finding.uploadJobId}.`,
    ticketReadyActionPlan: {
      priority:
        finding.normalizedSeverity === "critical"
          ? "P0 - Critical"
          : finding.normalizedSeverity === "high"
            ? "P1 - High"
            : "P2 - Normal",
      assignee: "Unassigned",
      eta: "TBD",
      component: assetName,
      labels: finding.tags,
    },
    ingestionProvenance: context
      ? {
          uploadJobId: finding.uploadJobId,
          artifactFilename: context.artifactFilename,
          sourceScanner: finding.sourceScanner,
          checksumSha256: context.checksumSha256,
          warningCount: context.warningCount,
          errorCount: context.errorCount,
        }
      : undefined,
  };
}

export function applyPrioritizationInfluence(
  finding: Finding,
  disposition: AnalystDispositionRecord | null,
  snapshots: FindingEnrichmentSnapshot[] = [],
): Finding {
  const enrichmentSummary =
    finding.enrichmentSummary ?? (snapshots.length > 0 ? buildEnrichmentSummary(snapshots) : undefined);
  const reasons: string[] = [];
  const baseRiskScore = finding.prioritization?.baseRiskScore ?? finding.riskScore;
  const dispositionAdjustment = buildDispositionAdjustment(disposition, reasons);
  const contextAdjustment = buildContextAdjustment(disposition, enrichmentSummary, reasons);
  const totalAdjustment = dispositionAdjustment + contextAdjustment;
  const adjustedRiskScore = clampRiskScore(baseRiskScore + totalAdjustment);

  return {
    ...finding,
    riskScore: adjustedRiskScore,
    status: applyDispositionStatus(finding, disposition),
    enrichmentSummary,
    prioritization: {
      baseRiskScore,
      adjustedRiskScore,
      dispositionAdjustment,
      contextAdjustment,
      totalAdjustment,
      reasons,
      lastUpdatedAt: disposition?.updatedAt ?? finding.prioritization?.lastUpdatedAt,
    },
  };
}

export function sortFindingsByPriority(findings: Finding[]) {
  return [...findings].sort((left, right) => {
    if (right.riskScore !== left.riskScore) {
      return right.riskScore - left.riskScore;
    }

    return new Date(right.discoveredAt).getTime() - new Date(left.discoveredAt).getTime();
  });
}
