import { StatusPill } from "@/components/dashboard/StatusPill";
import { SurfaceCard } from "@/components/dashboard/SurfaceCard";
import {
  formatIssueStatus,
  formatIssueTrack,
  getPendingIssueSummary,
  listPendingIssues,
} from "@/lib/services/issues";
import type { IssuePriority, IssueStatus } from "@/types/issues";

const priorityTone: Record<IssuePriority, "danger" | "warning" | "default"> = {
  "P0 Now": "danger",
  "P1 Next": "warning",
  "P2 Later": "default",
};

const statusTone: Record<IssueStatus, "accent" | "danger" | "warning" | "default" | "success"> = {
  in_progress: "accent",
  blocked: "danger",
  queued: "warning",
  monitoring: "default",
  completed: "success",
};

export function PendingIssuesReport() {
  const summary = getPendingIssueSummary();
  const issues = listPendingIssues();

  return (
    <SurfaceCard
      eyebrow="// Pending Issues"
      title="Current blocking and queued work"
      description="This report tracks the active implementation issues that still affect trust, SaaS readiness, or operator workflow. Use it as the internal source for Discord updates and execution planning."
      meta={<StatusPill tone="warning">{summary.total} Open Items</StatusPill>}
    >
      <div className="grid gap-4 md:grid-cols-4">
        <div className="rounded border border-[rgba(255,77,109,0.18)] bg-[rgba(255,77,109,0.08)] p-4">
          <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#ff9cab]">
            P0 Now
          </div>
          <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-[var(--danger)]">
            {summary.byPriority.p0}
          </div>
        </div>
        <div className="rounded border border-[rgba(255,208,96,0.18)] bg-[rgba(255,208,96,0.08)] p-4">
          <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#f3c46d]">
            P1 Next
          </div>
          <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-[var(--warning)]">
            {summary.byPriority.p1}
          </div>
        </div>
        <div className="rounded border border-[rgba(0,200,180,0.12)] bg-[rgba(0,200,180,0.08)] p-4">
          <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[var(--accent)]">
            In Progress
          </div>
          <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-white">
            {summary.byStatus.inProgress}
          </div>
        </div>
        <div className="rounded border border-[rgba(255,255,255,0.06)] bg-[#040810] p-4">
          <div className="font-mono text-[0.58rem] uppercase tracking-[0.14em] text-[#5a7080]">
            Blocked
          </div>
          <div className="mt-2 text-[1.8rem] font-black tracking-[-0.03em] text-white">
            {summary.byStatus.blocked}
          </div>
        </div>
      </div>

      <div className="mt-4 space-y-3">
        {issues.map((issue) => (
          <div
            key={issue.id}
            className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] p-4"
          >
            <div className="flex flex-wrap items-center gap-2">
              <div className="font-mono text-[0.68rem] tracking-[0.08em] text-[var(--accent)]">
                {issue.id}
              </div>
              <StatusPill tone={priorityTone[issue.priority]}>{issue.priority}</StatusPill>
              <StatusPill tone={statusTone[issue.status]}>{formatIssueStatus(issue.status)}</StatusPill>
              <StatusPill>{formatIssueTrack(issue.track)}</StatusPill>
            </div>
            <div className="mt-3 text-[0.95rem] font-semibold text-white">
              {issue.title}
            </div>
            <div className="mt-2 text-[0.82rem] leading-7 text-[var(--text-dim)]">
              {issue.summary}
            </div>
            <div className="mt-2 text-[0.8rem] leading-7 text-[var(--text)]">
              <span className="font-semibold text-white">Impact:</span> {issue.impact}
            </div>
            <div className="mt-1 text-[0.8rem] leading-7 text-[var(--text)]">
              <span className="font-semibold text-white">Next action:</span> {issue.nextAction}
            </div>
          </div>
        ))}
      </div>
    </SurfaceCard>
  );
}
