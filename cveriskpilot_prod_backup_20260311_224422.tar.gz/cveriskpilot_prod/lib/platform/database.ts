import type { D1Database } from "@cloudflare/workers-types";

import type { DbBindValue } from "@/lib/db";

export type AppDatabaseDriver = "cloudflare_d1" | "postgres";

export type AppDatabaseRunResult = {
  rowsAffected: number;
};

export interface AppDatabaseStatement {
  bind(...params: DbBindValue[]): AppDatabaseStatement;
  first<T>(): Promise<T | null>;
  all<T>(): Promise<T[]>;
  run(): Promise<AppDatabaseRunResult>;
}

export interface AppDatabase {
  readonly driver: AppDatabaseDriver;
  prepare(sql: string): AppDatabaseStatement;
}

export interface PostgresQueryClient {
  query<T = Record<string, unknown>>(
    sql: string,
    params?: readonly DbBindValue[],
  ): Promise<{
    rows: T[];
    rowCount?: number | null;
  }>;
}

export function rewriteSqlPlaceholdersForPostgres(sql: string) {
  let index = 0;

  return sql.replace(/\?/g, () => {
    index += 1;
    return `$${index}`;
  });
}

class D1AppDatabaseStatement implements AppDatabaseStatement {
  private params: DbBindValue[] = [];

  constructor(
    private readonly db: D1Database,
    private readonly sql: string,
  ) {}

  bind(...params: DbBindValue[]) {
    this.params = params;
    return this;
  }

  async first<T>() {
    const row = await this.db.prepare(this.sql).bind(...this.params).first<T>();
    return row ?? null;
  }

  async all<T>() {
    const result = await this.db.prepare(this.sql).bind(...this.params).all<T>();
    return result.results ?? [];
  }

  async run() {
    const result = await this.db.prepare(this.sql).bind(...this.params).run();
    return {
      rowsAffected: result.meta?.changes ?? 0,
    };
  }
}

export class D1AppDatabase implements AppDatabase {
  readonly driver = "cloudflare_d1" as const;

  constructor(private readonly db: D1Database) {}

  prepare(sql: string) {
    return new D1AppDatabaseStatement(this.db, sql);
  }
}

class PostgresAppDatabaseStatement implements AppDatabaseStatement {
  private params: DbBindValue[] = [];

  constructor(
    private readonly client: PostgresQueryClient,
    private readonly sql: string,
  ) {}

  bind(...params: DbBindValue[]) {
    this.params = params;
    return this;
  }

  async first<T>() {
    const result = await this.client.query<T>(
      rewriteSqlPlaceholdersForPostgres(this.sql),
      this.params,
    );
    return result.rows[0] ?? null;
  }

  async all<T>() {
    const result = await this.client.query<T>(
      rewriteSqlPlaceholdersForPostgres(this.sql),
      this.params,
    );
    return result.rows;
  }

  async run() {
    const result = await this.client.query(
      rewriteSqlPlaceholdersForPostgres(this.sql),
      this.params,
    );
    return {
      rowsAffected: result.rowCount ?? 0,
    };
  }
}

export class PostgresAppDatabase implements AppDatabase {
  readonly driver = "postgres" as const;

  constructor(private readonly client: PostgresQueryClient) {}

  prepare(sql: string) {
    return new PostgresAppDatabaseStatement(this.client, sql);
  }
}
