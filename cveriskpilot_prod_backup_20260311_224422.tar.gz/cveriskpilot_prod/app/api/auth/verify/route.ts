import { NextResponse } from "next/server";

import { consumeEmailVerificationToken, getAppBaseUrl, withAuthRoute } from "@/lib/auth";

function buildRedirect(request: Request, status: "success" | "invalid" | "expired") {
  const url = new URL("/login", getAppBaseUrl(request));
  url.searchParams.set("verified", status);
  return NextResponse.redirect(url);
}

export const GET = withAuthRoute(async function GET(request: Request) {
  const token = new URL(request.url).searchParams.get("token")?.trim();

  if (!token) {
    return buildRedirect(request, "invalid");
  }

  const result = await consumeEmailVerificationToken(token);

  if (!result.ok) {
    return buildRedirect(
      request,
      result.reason === "token_expired" ? "expired" : "invalid",
    );
  }

  return buildRedirect(request, "success");
});
