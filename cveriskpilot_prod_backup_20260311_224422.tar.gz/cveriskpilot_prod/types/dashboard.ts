export type Severity = "critical" | "high" | "medium" | "low";

export type FindingStatus =
  | "new"
  | "triaged"
  | "in_progress"
  | "accepted_risk"
  | "mitigated"
  | "false_positive"
  | "not_applicable";

export type AnalystDecision =
  | "true_risk"
  | "accepted_risk"
  | "mitigated"
  | "false_positive"
  | "not_applicable";

export type VulnerabilitySource = {
  id: string;
  name: string;
  kind: "scanner" | "enrichment" | "manual";
  importedAt: string;
};

export type Asset = {
  id: string;
  name: string;
  environment: "production" | "staging" | "development" | "corporate";
  internetExposed: boolean;
  businessCriticality: "critical" | "high" | "medium" | "low";
  owner?: string;
  tags: string[];
};

export type Enrichment = {
  kevListed: boolean;
  exploitAvailable: boolean;
  epssScore?: number;
  references: string[];
  sources: string[];
};

export type BusinessImpactAssessment = {
  summary: string;
  technicalImpact: string;
  businessImpact: string;
  decisionRationale?: string;
  generatedBy: "ai" | "analyst";
};

export type RemediationPlan = {
  summary: string;
  steps: string[];
  eta: string;
  owner?: string;
  ticketTemplate?: string;
};

export type ActionPlanStatus = "open" | "in_progress" | "completed";

export type ActionPlan = {
  id: string;
  findingId: string;
  relatedCve: string;
  title: string;
  priority: string;
  assignee: string;
  component: string;
  eta: string;
  labels: string[];
  status: ActionPlanStatus;
  createdAt: string;
  updatedAt: string;
  summary: string;
  notes?: string;
  integrationTargets?: Array<"jira" | "servicenow">;
};

export type AnalystDisposition = {
  decision: AnalystDecision;
  analystNotes: string;
  decisionRationale: string;
  updatedAt: string;
  updatedBy: string;
};

export type ArchitectureContext = {
  id: string;
  summary: string;
  criticalSystems: string[];
  trustBoundaries: string[];
  internetFacingAssets: string[];
};

export type ArchitectureInfluenceFactors = {
  internetExposed: boolean;
  internalOnly: boolean;
  segmentedNetwork: boolean;
  compensatingControlPresent: boolean;
  assetCriticality: Asset["businessCriticality"];
  authRequired: boolean;
  reachableFromAttackerPath: boolean;
};

export type UploadJob = {
  id: string;
  filename: string;
  sourceType: string;
  status:
    | "queued"
    | "processing"
    | "parsing"
    | "parsed"
    | "enrichment_pending"
    | "completed"
    | "failed";
  uploadedAt: string;
  findingsDetected?: number;
  uploadedBy: string;
  notes?: string;
  warningCount?: number;
  errorCount?: number;
};

export type Finding = {
  id: string;
  cveId: string;
  title: string;
  description: string;
  severity: Severity;
  cvssScore: number;
  riskScore: number;
  exploitAvailable: boolean;
  kevListed: boolean;
  assetId: string;
  assetName: string;
  product: string;
  version: string;
  environment: Asset["environment"];
  internetExposed: boolean;
  privilegeRequired: "none" | "low" | "high";
  status: FindingStatus;
  discoveredAt: string;
  source: VulnerabilitySource;
  tags: string[];
  businessImpact?: string;
  technicalImpact?: string;
  remediationSummary?: string;
  analystNotes?: string;
  decisionRationale?: string;
  businessImpactSource?: "ai" | "analyst";
  aiConfidence?: number;
  lastEnrichedAt?: string;
  analystDisposition?: AnalystDecision;
  analystRationale?: string;
  architectureContextSummary?: string;
  ticketReadyActionPlan?: {
    priority: string;
    assignee: string;
    eta: string;
    component: string;
    labels: string[];
  };
  ingestionProvenance?: {
    uploadJobId: string;
    artifactFilename: string;
    sourceScanner: string;
    checksumSha256: string;
    warningCount: number;
    errorCount: number;
  };
  enrichmentSummary?: {
    status: "pending" | "enriched" | "partial" | "failed" | "not_found";
    providers: string[];
    lastObservedAt?: string;
    kevListed?: boolean;
    exploitAvailable?: boolean;
    cvssScore?: number;
    cvssVector?: string;
  };
  prioritization?: {
    baseRiskScore: number;
    adjustedRiskScore: number;
    dispositionAdjustment: number;
    contextAdjustment: number;
    totalAdjustment: number;
    reasons: string[];
    lastUpdatedAt?: string;
  };
};
