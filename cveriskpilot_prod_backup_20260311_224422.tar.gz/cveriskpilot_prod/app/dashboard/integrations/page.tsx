import { StatusPill } from "@/components/dashboard/StatusPill";
import { SurfaceCard } from "@/components/dashboard/SurfaceCard";
import { listIntegrationConnectors } from "@/lib/services/enrichments";

const statusTone = {
  "Not Connected": "default",
  Configured: "accent",
  "Coming Soon": "warning",
} as const;

export default function IntegrationsPage() {
  const integrationCards = listIntegrationConnectors();

  return (
    <div className="space-y-5">
      <SurfaceCard
        eyebrow="// Integrations"
        title="Connector catalog"
        description="Connector states show which enrichment, workflow, and AI integrations are configured, available, or still pending activation."
      />

      <div className="grid gap-5 md:grid-cols-2 xl:grid-cols-3">
        {integrationCards.map((integration) => (
          <SurfaceCard
            key={integration.name}
            title={integration.name}
            description={`Category: ${integration.category}. Configuration, sync health, and credential state will appear here as each connector is activated.`}
            meta={<StatusPill tone={statusTone[integration.status]}>{integration.status}</StatusPill>}
          />
        ))}
      </div>
    </div>
  );
}
