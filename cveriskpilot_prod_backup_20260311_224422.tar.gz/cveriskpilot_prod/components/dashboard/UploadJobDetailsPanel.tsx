"use client";

import { StatusPill } from "@/components/dashboard/StatusPill";
import type { UploadJob } from "@/types/dashboard";

type UploadJobDetail = {
  findings: Array<{
    id: string;
    title: string;
    normalizedSeverity: string;
  }>;
  metadata: {
    checksumSha256: string;
    fileType: string;
    findingCount: number;
    hostCount: number;
    parsedAt: string;
    scannerName: string;
    scannerVersion: string | null;
    sourceType: string;
  } | null;
  parserErrors: Array<{
    code: string;
    details?: Record<string, unknown> | null;
    fatal: boolean;
    message: string;
  }>;
  parserWarnings: Array<{
    code: string;
    field: string | null;
    level: string;
    message: string;
    row: number | null;
  }>;
  rawArtifact: {
    checksumSha256: string;
    fileType: string;
    mimeType: string;
    originalFilename: string;
    uploadedAt: string;
  };
  uploadJob: {
    id: string;
    status: string;
    selectedSourceType: string | null;
    updatedAt: string;
  };
};

type UploadJobDetailsPanelProps = {
  detail: UploadJobDetail | null;
  isLoading: boolean;
  selectedJob: UploadJob | null;
};

export function UploadJobDetailsPanel({
  detail,
  isLoading,
  selectedJob,
}: UploadJobDetailsPanelProps) {
  const findingsPreviewCount = detail ? Math.min(detail.findings.length, 5) : 0;

  return (
    <section className="rounded border border-[rgba(0,200,180,0.06)] bg-[var(--bg-elevated)] p-5 shadow-[0_16px_40px_rgba(0,0,0,0.18)]">
      <div className="mb-3 font-mono text-[0.72rem] uppercase tracking-[0.14em] text-[var(--accent)]">
        // Upload Diagnostics
      </div>

      {!selectedJob ? (
        <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] p-4">
          <div className="font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#5a7080]">
            No upload selected
          </div>
          <p className="mt-3 text-sm leading-7 text-[var(--text-dim)]">
            Select an upload job from the recent jobs table to inspect parser warnings,
            errors, metadata, and the first parsed findings.
          </p>
        </div>
      ) : null}

      {selectedJob && isLoading ? (
        <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] p-4">
          <div className="font-mono text-[0.68rem] uppercase tracking-[0.12em] text-[#5a7080]">
            Loading upload diagnostics...
          </div>
        </div>
      ) : null}

      {selectedJob && detail ? (
        <div className="space-y-4">
          <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] p-4">
            <div className="group relative max-w-full">
              <div
                className="max-w-full overflow-hidden text-ellipsis whitespace-nowrap font-mono text-[0.74rem] text-[var(--text)]"
              >
                {detail.rawArtifact.originalFilename}
              </div>
              <div className="pointer-events-none absolute left-0 top-full z-20 mt-2 hidden max-w-[32rem] rounded border border-[rgba(0,200,180,0.2)] bg-[#040810] px-2 py-1 font-mono text-[0.62rem] leading-5 text-[var(--text)] shadow-[0_8px_24px_rgba(0,0,0,0.35)] group-hover:block">
                {detail.rawArtifact.originalFilename}
              </div>
            </div>
            <div className="mt-3 flex flex-wrap gap-2">
              <StatusPill tone={detail.parserErrors.length > 0 ? "danger" : "accent"}>
                {detail.uploadJob.status}
              </StatusPill>
              <StatusPill tone={detail.parserWarnings.length > 0 ? "warning" : "default"}>
                warnings {detail.parserWarnings.length}
              </StatusPill>
              <StatusPill tone={detail.parserErrors.length > 0 ? "danger" : "default"}>
                errors {detail.parserErrors.length}
              </StatusPill>
            </div>
            <div className="mt-4 space-y-2 font-mono text-[0.66rem] leading-6 text-[#5a7080]">
              <div>
                checksum: {detail.rawArtifact.checksumSha256.slice(0, 16)}...
              </div>
              <div>
                selected source: {detail.uploadJob.selectedSourceType ?? "auto-detect"}
              </div>
              <div>
                uploaded: {detail.rawArtifact.uploadedAt.slice(0, 19).replace("T", " ")}
              </div>
            </div>
          </div>

          <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] p-4">
            <div className="font-mono text-[0.64rem] uppercase tracking-[0.12em] text-[var(--accent)]">
              Parse Metadata
            </div>
            {detail.metadata ? (
              <div className="mt-3 space-y-2 font-mono text-[0.66rem] leading-6 text-[#5a7080]">
                <div>scanner: {detail.metadata.scannerName}</div>
                <div>source type: {detail.metadata.sourceType}</div>
                <div>file type: {detail.metadata.fileType}</div>
                <div>hosts: {detail.metadata.hostCount}</div>
                <div>findings: {detail.metadata.findingCount}</div>
                <div>
                  parsed at: {detail.metadata.parsedAt.slice(0, 19).replace("T", " ")}
                </div>
              </div>
            ) : (
              <p className="mt-3 text-sm leading-7 text-[var(--text-dim)]">
                No parse metadata is available yet for this upload job.
              </p>
            )}
          </div>

          <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] p-4">
            <div className="font-mono text-[0.64rem] uppercase tracking-[0.12em] text-[var(--accent)]">
              Parser Warnings
            </div>
            {detail.parserWarnings.length > 0 ? (
              <div className="mt-3 space-y-3">
                {detail.parserWarnings.map((warning, index) => (
                  <div
                    key={`${warning.code}-${warning.row ?? "none"}-${index}`}
                    className="rounded border border-[rgba(255,208,96,0.16)] bg-[rgba(255,208,96,0.06)] p-3"
                  >
                    <div className="font-mono text-[0.65rem] uppercase tracking-[0.1em] text-[var(--warning)]">
                      {warning.code}
                    </div>
                    <p className="mt-2 text-sm leading-7 text-[var(--text)]">
                      {warning.message}
                    </p>
                    <div className="mt-2 font-mono text-[0.62rem] text-[#8ba1b0]">
                      level: {warning.level}
                      {" · "}
                      {warning.field ? `field: ${warning.field}` : "field: n/a"}
                      {" · "}
                      {warning.row ? `row: ${warning.row}` : "row: n/a"}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-3 text-sm leading-7 text-[var(--text-dim)]">
                No parser warnings were recorded for this upload.
              </p>
            )}
          </div>

          <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] p-4">
            <div className="font-mono text-[0.64rem] uppercase tracking-[0.12em] text-[var(--accent)]">
              Parser Errors
            </div>
            {detail.parserErrors.length > 0 ? (
              <div className="mt-3 space-y-3">
                {detail.parserErrors.map((error, index) => (
                  <div
                    key={`${error.code}-${index}`}
                    className="rounded border border-[rgba(255,69,96,0.18)] bg-[rgba(255,69,96,0.08)] p-3"
                  >
                    <div className="font-mono text-[0.65rem] uppercase tracking-[0.1em] text-[var(--danger)]">
                      {error.code}
                    </div>
                    <p className="mt-2 text-sm leading-7 text-[var(--text)]">
                      {error.message}
                    </p>
                    <div className="mt-2 font-mono text-[0.62rem] text-[#ff98a7]">
                      fatal: {error.fatal ? "yes" : "no"}
                    </div>
                    {error.details ? (
                      <pre className="mt-2 overflow-x-auto rounded border border-[rgba(255,69,96,0.18)] bg-[#040810] p-2 font-mono text-[0.6rem] leading-5 text-[#ffb8c2]">
                        {JSON.stringify(error.details, null, 2)}
                      </pre>
                    ) : null}
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-3 text-sm leading-7 text-[var(--text-dim)]">
                No parser errors were recorded for this upload.
              </p>
            )}
          </div>

          <div className="rounded border border-[rgba(0,200,180,0.06)] bg-[rgba(255,255,255,0.01)] p-4">
            <div className="font-mono text-[0.64rem] uppercase tracking-[0.12em] text-[var(--accent)]">
              Parsed Findings Preview
            </div>
            <div className="mt-2 font-mono text-[0.62rem] uppercase tracking-[0.08em] text-[#5a7080]">
              showing {findingsPreviewCount} of {detail.findings.length}
            </div>
            {detail.findings.length > 0 ? (
              <div className="mt-3 space-y-2">
                {detail.findings.slice(0, 5).map((finding) => (
                  <div
                    key={finding.id}
                    className="rounded border border-[rgba(0,200,180,0.06)] bg-[#040810] px-3 py-2"
                  >
                    <div className="font-mono text-[0.65rem] text-[var(--accent)]">
                      {finding.normalizedSeverity}
                    </div>
                    <div className="mt-1 text-sm text-[var(--text)]">{finding.title}</div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="mt-3 text-sm leading-7 text-[var(--text-dim)]">
                No normalized findings were stored for this upload.
              </p>
            )}
          </div>
        </div>
      ) : null}
    </section>
  );
}
