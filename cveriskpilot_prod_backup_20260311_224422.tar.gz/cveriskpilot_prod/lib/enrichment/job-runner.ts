import type { UploadRepository } from "@/lib/ingestion/repository";
import type { EnrichmentRepository } from "@/lib/enrichment/repository";
import { EnrichmentService } from "@/lib/enrichment/service";
import {
  FindingEnrichmentSnapshotSchema,
  RunEnrichmentJobInputSchema,
  RunEnrichmentJobResultSchema,
  type EnrichmentRun,
  type FindingEnrichmentSnapshot,
  type RunEnrichmentJobInput,
  type RunEnrichmentJobResult,
} from "@/types/enrichment";
import type { NormalizedFinding } from "@/types/ingestion";

function toSortedUnique(values: string[]) {
  return Array.from(new Set(values)).sort();
}

function buildDesiredFingerprint(
  uploadChecksumSha256: string,
  providers: string[],
  findings: NormalizedFinding[],
) {
  const providerKey = toSortedUnique(providers).join(",");
  const findingKey = findings.map((finding) => finding.id).sort().join("|");

  return `${uploadChecksumSha256}::${providerKey}::${findingKey}`;
}

function buildExistingFingerprint(
  uploadChecksumSha256: string,
  snapshots: FindingEnrichmentSnapshot[],
) {
  const providerKey = toSortedUnique(snapshots.map((snapshot) => snapshot.provider)).join(",");
  const findingKey = toSortedUnique(snapshots.map((snapshot) => snapshot.findingId)).join("|");

  return `${uploadChecksumSha256}::${providerKey}::${findingKey}`;
}

function normalizeProviderSet(values: string[]) {
  return Array.from(new Set(values)).sort();
}

function hasEquivalentCoverage(
  findings: NormalizedFinding[],
  providers: string[],
  snapshots: FindingEnrichmentSnapshot[],
) {
  if (findings.length === 0) {
    return snapshots.length === 0;
  }

  const expectedProviders = normalizeProviderSet(providers);
  const snapshotProviders = normalizeProviderSet(snapshots.map((snapshot) => snapshot.provider));
  const expectedProviderKey = expectedProviders.join(",");
  const snapshotProviderKey = snapshotProviders.join(",");

  if (expectedProviderKey !== snapshotProviderKey) {
    return false;
  }

  if (snapshots.length !== findings.length * expectedProviders.length) {
    return false;
  }

  const expectedKeys = new Set<string>();
  const actualKeys = new Set<string>();

  for (const finding of findings) {
    for (const provider of expectedProviders) {
      expectedKeys.add(`${finding.id}::${provider}`);
    }
  }

  for (const snapshot of snapshots) {
    actualKeys.add(`${snapshot.findingId}::${snapshot.provider}`);
  }

  if (expectedKeys.size !== actualKeys.size) {
    return false;
  }

  for (const expectedKey of expectedKeys) {
    if (!actualKeys.has(expectedKey)) {
      return false;
    }
  }

  return true;
}

function createBaseRun(input: {
  uploadJobId: string;
  triggeredBy: string;
  now: string;
}): EnrichmentRun {
  return {
    id: crypto.randomUUID(),
    uploadJobId: input.uploadJobId,
    triggeredBy: input.triggeredBy,
    status: "queued",
    providerCount: 0,
    successCount: 0,
    errorCount: 0,
    errorSummary: null,
    startedAt: null,
    completedAt: null,
    createdAt: input.now,
    updatedAt: input.now,
  };
}

export class EnrichmentJobRunner {
  constructor(
    private readonly uploadRepository: UploadRepository,
    private readonly enrichmentRepository: EnrichmentRepository,
    private readonly enrichmentService: EnrichmentService,
  ) {}

  async run(input: RunEnrichmentJobInput): Promise<RunEnrichmentJobResult> {
    const validatedInput = RunEnrichmentJobInputSchema.parse(input);
    const uploadRecord = await this.uploadRepository.findById(validatedInput.uploadJobId);

    if (!uploadRecord) {
      throw new Error(`Upload job ${validatedInput.uploadJobId} was not found.`);
    }

    const findings = await this.uploadRepository.normalizedFindings.findByUploadJobId(
      validatedInput.uploadJobId,
    );
    const latestRun = await this.enrichmentRepository.findLatestRunByUploadJobId(
      validatedInput.uploadJobId,
    );
    const desiredFingerprint = buildDesiredFingerprint(
      uploadRecord.uploadJob.checksumSha256,
      validatedInput.providers,
      findings,
    );

    if (
      !validatedInput.force &&
      latestRun &&
      (latestRun.run.status === "completed" || latestRun.run.status === "partial")
    ) {
      const existingFingerprint = buildExistingFingerprint(
        uploadRecord.uploadJob.checksumSha256,
        latestRun.snapshots,
      );
      const parsedAt = uploadRecord.uploadJob.parsedAt;
      const runIsCurrentForParsedUpload =
        parsedAt === null || latestRun.run.createdAt >= parsedAt;
      const equivalentCoverage = hasEquivalentCoverage(
        findings,
        validatedInput.providers,
        latestRun.snapshots,
      );

      if (desiredFingerprint === existingFingerprint && runIsCurrentForParsedUpload && equivalentCoverage) {
        return RunEnrichmentJobResultSchema.parse({
          run: latestRun.run,
          snapshots: latestRun.snapshots,
          skipped: true,
          forced: false,
          replacedExisting: false,
          message: "Equivalent enrichment run already exists for this upload.",
        });
      }
    }

    const now = new Date().toISOString();
    const runModel = createBaseRun({
      uploadJobId: validatedInput.uploadJobId,
      triggeredBy: validatedInput.triggeredBy,
      now,
    });
    await this.enrichmentRepository.createRun(runModel);

    const runningRun: EnrichmentRun = {
      ...runModel,
      status: "running",
      startedAt: now,
      updatedAt: now,
    };
    await this.enrichmentRepository.updateRun(runningRun);

    try {
      const results = await Promise.all(
        findings.map((finding) =>
          this.enrichmentService.enrichFinding({
            triggeredBy: validatedInput.triggeredBy,
            providers: validatedInput.providers,
            finding: {
              findingId: finding.id,
              cveIds: finding.cveIds,
              title: finding.title,
              description: finding.description,
              normalizedSeverity: finding.normalizedSeverity,
              cvssScore: finding.cvssScore,
              sourceUpdatedAt: finding.updatedAt,
            },
          }),
        ),
      );

      const snapshots = results.flatMap((result) =>
        result.completedProviders.map((providerResult) =>
          FindingEnrichmentSnapshotSchema.parse({
            id: crypto.randomUUID(),
            enrichmentRunId: runModel.id,
            findingId: result.findingId,
            provider: providerResult.provider,
            status: providerResult.status,
            sourceUrl: providerResult.sourceUrl,
            sourceVersion: providerResult.payload?.sourceVersion ?? null,
            observedAt: providerResult.observedAt,
            errorCode: providerResult.errorCode,
            errorMessage: providerResult.errorMessage,
            summaryJson: providerResult.payload,
            rawPayloadJson: {
              findingUpdatedAt: result.completedAt,
              payload: providerResult.rawPayload,
            },
            createdAt: new Date().toISOString(),
            updatedAt: new Date().toISOString(),
          }),
        ),
      );

      await this.enrichmentRepository.replaceSnapshotsForRun(runModel.id, snapshots);

      const providerCount = snapshots.length;
      const errorCount = snapshots.filter((snapshot) => snapshot.status === "error").length;
      const successCount = providerCount - errorCount;
      const completedAt = new Date().toISOString();
      const status =
        providerCount === 0
          ? "completed"
          : errorCount === providerCount
            ? "failed"
            : errorCount > 0
              ? "partial"
              : "completed";

      const updatedRun: EnrichmentRun = {
        ...runningRun,
        status,
        providerCount,
        successCount,
        errorCount,
        errorSummary:
          snapshots.find((snapshot) => snapshot.status === "error")?.errorMessage ?? null,
        completedAt,
        updatedAt: completedAt,
      };
      await this.enrichmentRepository.updateRun(updatedRun);

      return RunEnrichmentJobResultSchema.parse({
        run: updatedRun,
        snapshots,
        skipped: false,
        forced: validatedInput.force,
        replacedExisting: Boolean(latestRun),
        message:
          status === "failed"
            ? "Enrichment run failed."
            : status === "partial"
              ? "Enrichment run completed with partial provider errors."
              : "Enrichment run completed successfully.",
      });
    } catch (error) {
      const failedAt = new Date().toISOString();
      const message = error instanceof Error ? error.message : "Enrichment run failed.";
      const failedRun: EnrichmentRun = {
        ...runningRun,
        status: "failed",
        errorCount: 1,
        errorSummary: message,
        completedAt: failedAt,
        updatedAt: failedAt,
      };
      await this.enrichmentRepository.updateRun(failedRun);

      return RunEnrichmentJobResultSchema.parse({
        run: failedRun,
        snapshots: [],
        skipped: false,
        forced: validatedInput.force,
        replacedExisting: Boolean(latestRun),
        message,
      });
    }
  }
}
