import { AgentMeshMonitor } from "@/components/agent-mesh/AgentMeshMonitor";

export default function AgentMeshMonitorPage() {
  return <AgentMeshMonitor />;
}
