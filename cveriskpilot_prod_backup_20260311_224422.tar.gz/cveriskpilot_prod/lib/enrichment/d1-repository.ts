import type { D1Database } from "@cloudflare/workers-types";

import { D1AppDatabase } from "@/lib/platform/database";
import { SqlEnrichmentRepository } from "@/lib/enrichment/sql-repository";

export class D1EnrichmentRepository extends SqlEnrichmentRepository {
  constructor(db: D1Database) {
    super(new D1AppDatabase(db));
  }
}
