import {
  KEV_CACHE_TTL_MINUTES_DEFAULT,
  KEV_CATALOG_URL,
  KEV_CVE_ID_PATTERN,
  KEV_FEED_URL_DEFAULT,
  KEV_REQUEST_TIMEOUT_MS_DEFAULT,
} from "@/lib/kev/constants";
import {
  buildKevCacheKey,
  InMemoryKevCache,
  isKevCacheEntryFresh,
  type KevCacheProvider,
} from "@/lib/kev/cache";
import type {
  KevCatalogIndex,
  KevCatalogResponse,
  KevClientError,
  KevClientResult,
  KevMatchRecord,
} from "@/lib/kev/types";

type FetchLike = typeof fetch;
type LoadCatalogResult =
  | {
      ok: true;
      catalog: KevCatalogIndex;
      meta: {
        source: "kev_live" | "kev_cache_fresh" | "kev_cache_stale";
        fetchedAt: string;
        cacheHit: boolean;
        stale: boolean;
      };
    }
  | {
      ok: false;
      error: KevClientError;
      meta: {
        source: "none";
        fetchedAt: null;
        cacheHit: false;
        stale: false;
      };
      sourceVersion: null;
    };

export type KevClientOptions = {
  feedUrl: string;
  requestTimeoutMs: number;
  cacheTtlMinutes: number;
};

function toPositiveInt(value: string | undefined, fallback: number) {
  if (!value) {
    return fallback;
  }

  const parsed = Number(value);
  if (!Number.isFinite(parsed) || parsed <= 0) {
    return fallback;
  }

  return Math.floor(parsed);
}

function createClientError(
  input: Omit<KevClientError, "fromCache"> & { fromCache?: boolean },
): KevClientError {
  return {
    ...input,
    fromCache: input.fromCache ?? false,
  };
}

function toNullableString(value: unknown) {
  if (typeof value !== "string") {
    return null;
  }

  const trimmed = value.trim();
  return trimmed.length > 0 ? trimmed : null;
}

function normalizeKevRecord(input: Record<string, unknown>): KevMatchRecord | null {
  const cveId = toNullableString(input.cveID)?.toUpperCase() ?? null;

  if (!cveId || !KEV_CVE_ID_PATTERN.test(cveId)) {
    return null;
  }

  return {
    cveId,
    vendorProject: toNullableString(input.vendorProject),
    product: toNullableString(input.product),
    vulnerabilityName: toNullableString(input.vulnerabilityName),
    shortDescription: toNullableString(input.shortDescription),
    dateAdded: toNullableString(input.dateAdded),
    dueDate: toNullableString(input.dueDate),
    requiredAction: toNullableString(input.requiredAction),
    knownRansomwareCampaignUse: toNullableString(input.knownRansomwareCampaignUse),
    notes: toNullableString(input.notes),
  };
}

function buildCatalogIndex(payload: KevCatalogResponse, fetchedAt: string): KevCatalogIndex | null {
  const vulnerabilities = Array.isArray(payload.vulnerabilities) ? payload.vulnerabilities : null;

  if (!vulnerabilities) {
    return null;
  }

  const entriesByCve: Record<string, KevMatchRecord> = {};

  for (const vulnerability of vulnerabilities) {
    if (!vulnerability || typeof vulnerability !== "object") {
      continue;
    }

    const record = normalizeKevRecord(vulnerability as Record<string, unknown>);
    if (!record) {
      continue;
    }

    entriesByCve[record.cveId] = record;
  }

  return {
    sourceVersion: toNullableString(payload.catalogVersion) ?? toNullableString(payload.dateReleased),
    fetchedAt,
    entriesByCve,
  };
}

async function sleep(ms: number) {
  await new Promise((resolve) => setTimeout(resolve, ms));
}

function buildClientOptions(): KevClientOptions {
  return {
    feedUrl: process.env.KEV_FEED_URL?.trim() || KEV_FEED_URL_DEFAULT,
    requestTimeoutMs: toPositiveInt(
      process.env.KEV_REQUEST_TIMEOUT_MS,
      KEV_REQUEST_TIMEOUT_MS_DEFAULT,
    ),
    cacheTtlMinutes: toPositiveInt(
      process.env.KEV_CACHE_TTL_MINUTES,
      KEV_CACHE_TTL_MINUTES_DEFAULT,
    ),
  };
}

export class KevClient {
  private readonly inFlightRequest = new Map<string, Promise<LoadCatalogResult>>();

  constructor(
    private readonly options: KevClientOptions,
    private readonly cache: KevCacheProvider,
    private readonly fetcher: FetchLike = fetch,
  ) {}

  async getCveById(inputCveId: string): Promise<KevClientResult> {
    const cveId = inputCveId.trim().toUpperCase();

    if (!KEV_CVE_ID_PATTERN.test(cveId)) {
      return {
        ok: false,
        error: createClientError({
          code: "invalid_cve_id",
          message: "CVE ID format is invalid.",
          retriable: false,
        }),
        meta: {
          source: "none",
          fetchedAt: null,
          cacheHit: false,
          stale: false,
        },
        sourceVersion: null,
      };
    }

    const dedupeKey = buildKevCacheKey();
    const existing = this.inFlightRequest.get(dedupeKey);
    if (existing) {
      return existing.then((result) => this.mapResultForCve(result, cveId));
    }

    const requestPromise = this.loadCatalog().finally(() => {
      this.inFlightRequest.delete(dedupeKey);
    });
    this.inFlightRequest.set(dedupeKey, requestPromise);

    const result = await requestPromise;
    return this.mapResultForCve(result, cveId);
  }

  private mapResultForCve(result: LoadCatalogResult, cveId: string): KevClientResult {
    if (!result.ok) {
      return result;
    }

    return {
      ok: true,
      data: result.catalog.entriesByCve[cveId] ?? null,
      meta: result.meta,
      sourceVersion: result.catalog.sourceVersion,
    };
  }

  private async loadCatalog(): Promise<LoadCatalogResult> {
    const cacheKey = buildKevCacheKey();
    const now = new Date().toISOString();
    const cachedEntry = await this.cache.get(cacheKey);

    if (cachedEntry && isKevCacheEntryFresh(cachedEntry, now)) {
      return {
        ok: true,
        catalog: cachedEntry.catalog,
        meta: {
          source: "kev_cache_fresh",
          fetchedAt: cachedEntry.fetchedAt,
          cacheHit: true,
          stale: false,
        },
      };
    }

    try {
      const payload = await this.fetchCatalogWithRetries();
      const fetchedAt = new Date().toISOString();
      const catalog = buildCatalogIndex(payload, fetchedAt);

      if (!catalog) {
        return {
          ok: false,
          error: createClientError({
            code: "bad_response",
            message: "KEV feed did not return a valid vulnerabilities catalog.",
            retriable: false,
          }),
          meta: {
            source: "none",
            fetchedAt: null,
            cacheHit: false,
            stale: false,
          },
          sourceVersion: null,
        };
      }

      const expiresAt = new Date(
        Date.now() + this.options.cacheTtlMinutes * 60 * 1000,
      ).toISOString();

      await this.cache.set({
        key: cacheKey,
        fetchedAt,
        expiresAt,
        rawPayload: payload,
        catalog,
      });

      return {
        ok: true,
        catalog,
        meta: {
          source: "kev_live",
          fetchedAt,
          cacheHit: false,
          stale: false,
        },
      };
    } catch (error) {
      const message = error instanceof Error ? error.message : "Unknown KEV error";
      console.error("KEV fetch failure:", message);

      if (cachedEntry) {
        return {
          ok: true,
          catalog: cachedEntry.catalog,
          meta: {
            source: "kev_cache_stale",
            fetchedAt: cachedEntry.fetchedAt,
            cacheHit: true,
            stale: true,
          },
        };
      }

      return {
        ok: false,
        error: this.toClientError(error),
        meta: {
          source: "none",
          fetchedAt: null,
          cacheHit: false,
          stale: false,
        },
        sourceVersion: null,
      };
    }
  }

  private async fetchCatalogWithRetries(): Promise<KevCatalogResponse> {
    const url = new URL(this.options.feedUrl);

    for (let attempt = 0; attempt < 3; attempt += 1) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), this.options.requestTimeoutMs);

      try {
        const response = await this.fetcher(url, {
          headers: {
            Accept: "application/json",
          },
          signal: controller.signal,
        });

        if (!response.ok) {
          const isRetriable = response.status === 429 || response.status >= 500;
          if (isRetriable && attempt < 2) {
            await sleep(250 * (attempt + 1));
            continue;
          }

          throw new Error(`KEV HTTP ${response.status}`);
        }

        return (await response.json()) as KevCatalogResponse;
      } catch (error) {
        const isAbort =
          error instanceof Error &&
          ((error as Error & { code?: string }).code === "ABORT_ERR" || error.name === "AbortError");
        if (isAbort) {
          if (attempt < 2) {
            await sleep(250 * (attempt + 1));
            continue;
          }
        }

        if (attempt < 2 && error instanceof Error && /KEV HTTP (429|5\d\d)/.test(error.message)) {
          await sleep(250 * (attempt + 1));
          continue;
        }

        throw error;
      } finally {
        clearTimeout(timeout);
      }
    }

    throw new Error("KEV retry budget exhausted.");
  }

  private toClientError(error: unknown): KevClientError {
    if (error && typeof error === "object" && "code" in error) {
      const code = String((error as { code?: string }).code);
      if (code === "ABORT_ERR") {
        return createClientError({
          code: "request_timeout",
          message: "KEV request timed out.",
          retriable: true,
        });
      }
    }

    if (error instanceof Error && error.name === "AbortError") {
      return createClientError({
        code: "request_timeout",
        message: "KEV request timed out.",
        retriable: true,
      });
    }

    if (error instanceof Error && /5\d\d|429/.test(error.message)) {
      return createClientError({
        code: "upstream_error",
        message: "KEV upstream service error.",
        retriable: true,
      });
    }

    return createClientError({
      code: "upstream_error",
      message: error instanceof Error ? error.message : "KEV request failed.",
      retriable: true,
    });
  }
}

let singletonClient: KevClient | null = null;

export function createKevClient(fetcher?: FetchLike) {
  return new KevClient(buildClientOptions(), new InMemoryKevCache(), fetcher);
}

export function getKevClient() {
  if (!singletonClient) {
    singletonClient = createKevClient();
  }

  return singletonClient;
}

export { KEV_CATALOG_URL };
