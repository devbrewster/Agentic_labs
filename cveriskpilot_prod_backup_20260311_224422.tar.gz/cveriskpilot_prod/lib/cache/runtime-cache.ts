type CacheEntry<T> = {
  expiresAt: number;
  value: T;
};

const runtimeCache = new Map<string, CacheEntry<unknown>>();

export async function getOrSetRuntimeCache<T>(
  key: string,
  ttlMs: number,
  loader: () => Promise<T>,
): Promise<T> {
  const now = Date.now();
  const existing = runtimeCache.get(key) as CacheEntry<T> | undefined;

  if (existing && existing.expiresAt > now) {
    return existing.value;
  }

  const value = await loader();
  runtimeCache.set(key, {
    value,
    expiresAt: now + ttlMs,
  });

  return value;
}

export function invalidateRuntimeCache(key: string) {
  runtimeCache.delete(key);
}

export function invalidateRuntimeCachePrefix(prefix: string) {
  for (const key of runtimeCache.keys()) {
    if (key.startsWith(prefix)) {
      runtimeCache.delete(key);
    }
  }
}

export function clearRuntimeCache() {
  runtimeCache.clear();
}
