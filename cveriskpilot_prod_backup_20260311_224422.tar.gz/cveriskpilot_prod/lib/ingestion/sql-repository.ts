import type { AppDatabase } from "@/lib/platform/database";
import {
  NormalizedFindingSchema,
  ParseMetadataSchema,
  ParserErrorSchema,
  ParserWarningSchema,
  RawArtifactSchema,
  StoredParseOutcomeSchema,
  UploadJobSchema,
  type ChecksumSha256,
  type NormalizedFinding,
  type ParseMetadata,
  type ParserError,
  type ParserWarning,
  type RawArtifact,
  type StoredParseOutcome,
  type UploadJob,
} from "@/types/ingestion";
import type {
  NormalizedFindingRepository,
  ParseOutcomeRepository,
  RawArtifactRepository,
  UploadJobRepository,
  UploadRecord,
  UploadRecordWithOutcome,
  UploadRepository,
} from "@/lib/ingestion/repository";

type RawArtifactRow = {
  id: string;
  tenant_id: string | null;
  storage_key: string;
  original_filename: string;
  mime_type: string;
  file_type: string;
  size_bytes: number;
  checksum_sha256: string;
  uploaded_at: string;
};

type UploadJobRow = {
  id: string;
  tenant_id: string | null;
  raw_artifact_id: string;
  selected_source_type: string | null;
  detected_source_type: string | null;
  status: string;
  error_summary: string | null;
  warning_count: number;
  finding_count: number;
  checksum_sha256: string;
  created_at: string;
  updated_at: string;
  parsed_at: string | null;
};

type ParseOutcomeRow = {
  upload_job_id: string;
  metadata_json: string | null;
  warnings_json: string;
  errors_json: string;
  updated_at: string;
};

type NormalizedFindingRow = {
  id: string;
  upload_job_id: string;
  raw_record_ref_json: string;
  asset_identifier: string | null;
  hostname: string | null;
  fqdn: string | null;
  ip_address: string | null;
  port: number | null;
  protocol: string | null;
  vulnerability_id: string | null;
  plugin_id: string | null;
  cve_ids_json: string;
  title: string;
  description: string | null;
  severity: string | null;
  normalized_severity: string;
  cvss_score: number | null;
  cvss_vector: string | null;
  remediation: string | null;
  evidence: string | null;
  status: string | null;
  privilege_required: string | null;
  detected_at: string | null;
  first_observed_at: string | null;
  last_observed_at: string | null;
  source_type: string;
  source_scanner: string;
  tags_json: string;
  created_at: string;
  updated_at: string;
};

type UploadJoinRow = RawArtifactRow & UploadJobRow;

function parseJsonField<T>(value: string | null, fallback: T): T {
  if (!value) {
    return fallback;
  }

  return JSON.parse(value) as T;
}

function buildTenantWhereClause(tenantId: string | null) {
  if (tenantId === null) {
    return {
      clause: "tenant_id IS NULL",
      params: [] as (string | number | null)[],
    };
  }

  return {
    clause: "tenant_id = ?",
    params: [tenantId] as (string | number | null)[],
  };
}

function mapRawArtifactRow(row: RawArtifactRow): RawArtifact {
  return RawArtifactSchema.parse({
    id: row.id,
    storageKey: row.storage_key,
    originalFilename: row.original_filename,
    mimeType: row.mime_type,
    fileType: row.file_type,
    sizeBytes: row.size_bytes,
    checksumSha256: row.checksum_sha256,
    uploadedAt: row.uploaded_at,
  });
}

function mapUploadJobRow(row: UploadJobRow): UploadJob {
  return UploadJobSchema.parse({
    id: row.id,
    tenantId: row.tenant_id,
    rawArtifactId: row.raw_artifact_id,
    selectedSourceType: row.selected_source_type,
    detectedSourceType: row.detected_source_type,
    status: row.status,
    errorSummary: row.error_summary,
    warningCount: row.warning_count,
    findingCount: row.finding_count,
    checksumSha256: row.checksum_sha256,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    parsedAt: row.parsed_at,
  });
}

function mapParseOutcomeRow(row: ParseOutcomeRow): StoredParseOutcome {
  const metadata = row.metadata_json
    ? ParseMetadataSchema.parse(parseJsonField<ParseMetadata | null>(row.metadata_json, null))
    : null;

  return StoredParseOutcomeSchema.parse({
    uploadJobId: row.upload_job_id,
    findings: [],
    parserWarnings: ParserWarningSchema.array().parse(
      parseJsonField<ParserWarning[]>(row.warnings_json, []),
    ),
    parserErrors: ParserErrorSchema.array().parse(
      parseJsonField<ParserError[]>(row.errors_json, []),
    ),
    metadata,
    updatedAt: row.updated_at,
  });
}

function mapNormalizedFindingRow(row: NormalizedFindingRow): NormalizedFinding {
  return NormalizedFindingSchema.parse({
    id: row.id,
    uploadJobId: row.upload_job_id,
    rawRecordRef: parseJsonField(row.raw_record_ref_json, null),
    assetIdentifier: row.asset_identifier,
    hostname: row.hostname,
    fqdn: row.fqdn,
    ipAddress: row.ip_address,
    port: row.port,
    protocol: row.protocol,
    vulnerabilityId: row.vulnerability_id,
    pluginId: row.plugin_id,
    cveIds: parseJsonField<string[]>(row.cve_ids_json, []),
    title: row.title,
    description: row.description,
    severity: row.severity,
    normalizedSeverity: row.normalized_severity,
    cvssScore: row.cvss_score,
    cvssVector: row.cvss_vector,
    remediation: row.remediation,
    evidence: row.evidence,
    status: row.status,
    privilegeRequired: row.privilege_required,
    detectedAt: row.detected_at,
    firstObservedAt: row.first_observed_at,
    lastObservedAt: row.last_observed_at,
    sourceType: row.source_type,
    sourceScanner: row.source_scanner,
    tags: parseJsonField<string[]>(row.tags_json, []),
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  });
}

function mapJoinedUploadRow(row: UploadJoinRow): UploadRecord {
  return {
    uploadJob: mapUploadJobRow(row),
    rawArtifact: mapRawArtifactRow({
      id: row.raw_artifact_id,
      tenant_id: row.tenant_id,
      storage_key: row.storage_key,
      original_filename: row.original_filename,
      mime_type: row.mime_type,
      file_type: row.file_type,
      size_bytes: row.size_bytes,
      checksum_sha256: row.checksum_sha256,
      uploaded_at: row.uploaded_at,
    }),
  };
}

export class SqlRawArtifactRepository implements RawArtifactRepository {
  constructor(private readonly db: AppDatabase) {}

  async findById(rawArtifactId: string) {
    const row = await this.db
      .prepare(
        `SELECT
           id,
           tenant_id,
           storage_key,
           original_filename,
           mime_type,
           file_type,
           size_bytes,
           checksum_sha256,
           uploaded_at
         FROM raw_artifacts
         WHERE id = ?
         LIMIT 1`,
      )
      .bind(rawArtifactId)
      .first<RawArtifactRow>();

    return row ? mapRawArtifactRow(row) : null;
  }

  async findByChecksum(checksumSha256: ChecksumSha256) {
    const row = await this.db
      .prepare(
        `SELECT
           id,
           tenant_id,
           storage_key,
           original_filename,
           mime_type,
           file_type,
           size_bytes,
           checksum_sha256,
           uploaded_at
         FROM raw_artifacts
         WHERE checksum_sha256 = ?
         ORDER BY uploaded_at DESC
         LIMIT 1`,
      )
      .bind(checksumSha256)
      .first<RawArtifactRow>();

    return row ? mapRawArtifactRow(row) : null;
  }

  async save(rawArtifact: RawArtifact) {
    await this.db
      .prepare(
        `INSERT INTO raw_artifacts (
           id,
           tenant_id,
           storage_key,
           original_filename,
           mime_type,
           file_type,
           size_bytes,
           checksum_sha256,
           uploaded_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           tenant_id = excluded.tenant_id,
           storage_key = excluded.storage_key,
           original_filename = excluded.original_filename,
           mime_type = excluded.mime_type,
           file_type = excluded.file_type,
           size_bytes = excluded.size_bytes,
           checksum_sha256 = excluded.checksum_sha256,
           uploaded_at = excluded.uploaded_at`,
      )
      .bind(
        rawArtifact.id,
        null,
        rawArtifact.storageKey,
        rawArtifact.originalFilename,
        rawArtifact.mimeType,
        rawArtifact.fileType,
        rawArtifact.sizeBytes,
        rawArtifact.checksumSha256,
        rawArtifact.uploadedAt,
      )
      .run();
  }
}

export class SqlUploadJobRepository implements UploadJobRepository {
  constructor(private readonly db: AppDatabase) {}

  async findById(uploadJobId: string) {
    const row = await this.db
      .prepare(
        `SELECT
           id,
           tenant_id,
           raw_artifact_id,
           selected_source_type,
           detected_source_type,
           status,
           error_summary,
           warning_count,
           finding_count,
           checksum_sha256,
           created_at,
           updated_at,
           parsed_at
         FROM upload_jobs
         WHERE id = ?
         LIMIT 1`,
      )
      .bind(uploadJobId)
      .first<UploadJobRow>();

    return row ? mapUploadJobRow(row) : null;
  }

  async findByChecksum(checksumSha256: ChecksumSha256) {
    const row = await this.db
      .prepare(
        `SELECT
           id,
           tenant_id,
           raw_artifact_id,
           selected_source_type,
           detected_source_type,
           status,
           error_summary,
           warning_count,
           finding_count,
           checksum_sha256,
           created_at,
           updated_at,
           parsed_at
         FROM upload_jobs
         WHERE checksum_sha256 = ?
         ORDER BY created_at DESC
         LIMIT 1`,
      )
      .bind(checksumSha256)
      .first<UploadJobRow>();

    return row ? mapUploadJobRow(row) : null;
  }

  async findByChecksumForTenant(checksumSha256: ChecksumSha256, tenantId: string | null) {
    const tenantFilter = buildTenantWhereClause(tenantId);
    const row = await this.db
      .prepare(
        `SELECT
           id,
           tenant_id,
           raw_artifact_id,
           selected_source_type,
           detected_source_type,
           status,
           error_summary,
           warning_count,
           finding_count,
           checksum_sha256,
           created_at,
           updated_at,
           parsed_at
         FROM upload_jobs
         WHERE checksum_sha256 = ? AND ${tenantFilter.clause}
         ORDER BY created_at DESC
         LIMIT 1`,
      )
      .bind(checksumSha256, ...tenantFilter.params)
      .first<UploadJobRow>();

    return row ? mapUploadJobRow(row) : null;
  }

  async save(uploadJob: UploadJob) {
    await this.db
      .prepare(
        `INSERT INTO upload_jobs (
           id,
           tenant_id,
           raw_artifact_id,
           selected_source_type,
           detected_source_type,
           status,
           error_summary,
           warning_count,
           finding_count,
           checksum_sha256,
           created_at,
           updated_at,
           parsed_at
         ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
         ON CONFLICT(id) DO UPDATE SET
           tenant_id = excluded.tenant_id,
           raw_artifact_id = excluded.raw_artifact_id,
           selected_source_type = excluded.selected_source_type,
           detected_source_type = excluded.detected_source_type,
           status = excluded.status,
           error_summary = excluded.error_summary,
           warning_count = excluded.warning_count,
           finding_count = excluded.finding_count,
           checksum_sha256 = excluded.checksum_sha256,
           created_at = excluded.created_at,
           updated_at = excluded.updated_at,
           parsed_at = excluded.parsed_at`,
      )
      .bind(
        uploadJob.id,
        uploadJob.tenantId,
        uploadJob.rawArtifactId,
        uploadJob.selectedSourceType,
        uploadJob.detectedSourceType,
        uploadJob.status,
        uploadJob.errorSummary,
        uploadJob.warningCount,
        uploadJob.findingCount,
        uploadJob.checksumSha256,
        uploadJob.createdAt,
        uploadJob.updatedAt,
        uploadJob.parsedAt,
      )
      .run();
  }

  async update(uploadJob: UploadJob) {
    await this.save(uploadJob);
  }

  async list() {
    const rows = await this.db
      .prepare(
        `SELECT
           id,
           tenant_id,
           raw_artifact_id,
           selected_source_type,
           detected_source_type,
           status,
           error_summary,
           warning_count,
           finding_count,
           checksum_sha256,
           created_at,
           updated_at,
           parsed_at
         FROM upload_jobs
         ORDER BY created_at DESC`,
      )
      .all<UploadJobRow>();

    return rows.map(mapUploadJobRow);
  }

  async listByTenant(tenantId: string) {
    const rows = await this.db
      .prepare(
        `SELECT
           id,
           tenant_id,
           raw_artifact_id,
           selected_source_type,
           detected_source_type,
           status,
           error_summary,
           warning_count,
           finding_count,
           checksum_sha256,
           created_at,
           updated_at,
           parsed_at
         FROM upload_jobs
         WHERE tenant_id = ?
         ORDER BY created_at DESC`,
      )
      .bind(tenantId)
      .all<UploadJobRow>();

    return rows.map(mapUploadJobRow);
  }
}

export class SqlParseOutcomeRepository implements ParseOutcomeRepository {
  constructor(private readonly db: AppDatabase) {}

  async findByUploadJobId(uploadJobId: string) {
    const row = await this.db
      .prepare(
        `SELECT
           upload_job_id,
           metadata_json,
           warnings_json,
           errors_json,
           updated_at
         FROM parse_outcomes
         WHERE upload_job_id = ?
         LIMIT 1`,
      )
      .bind(uploadJobId)
      .first<ParseOutcomeRow>();

    return row ? mapParseOutcomeRow(row) : null;
  }

  async listByUploadJobIds(uploadJobIds: string[]) {
    if (uploadJobIds.length === 0) {
      return [];
    }

    const placeholders = uploadJobIds.map(() => "?").join(", ");
    const rows = await this.db
      .prepare(
        `SELECT
           upload_job_id,
           metadata_json,
           warnings_json,
           errors_json,
           updated_at
         FROM parse_outcomes
         WHERE upload_job_id IN (${placeholders})`,
      )
      .bind(...uploadJobIds)
      .all<ParseOutcomeRow>();

    return rows.map(mapParseOutcomeRow);
  }

  async save(outcome: StoredParseOutcome) {
    await this.db
      .prepare(
        `INSERT INTO parse_outcomes (
           upload_job_id,
           metadata_json,
           warnings_json,
           errors_json,
           updated_at
         ) VALUES (?, ?, ?, ?, ?)
         ON CONFLICT(upload_job_id) DO UPDATE SET
           metadata_json = excluded.metadata_json,
           warnings_json = excluded.warnings_json,
           errors_json = excluded.errors_json,
           updated_at = excluded.updated_at`,
      )
      .bind(
        outcome.uploadJobId,
        outcome.metadata ? JSON.stringify(outcome.metadata) : null,
        JSON.stringify(outcome.parserWarnings),
        JSON.stringify(outcome.parserErrors),
        outcome.updatedAt,
      )
      .run();
  }
}

export class SqlNormalizedFindingRepository implements NormalizedFindingRepository {
  constructor(private readonly db: AppDatabase) {}

  async findByUploadJobId(uploadJobId: string) {
    const rows = await this.db
      .prepare(
        `SELECT
           id,
           upload_job_id,
           raw_record_ref_json,
           asset_identifier,
           hostname,
           fqdn,
           ip_address,
           port,
           protocol,
           vulnerability_id,
           plugin_id,
           cve_ids_json,
           title,
           description,
           severity,
           normalized_severity,
           cvss_score,
           cvss_vector,
           remediation,
           evidence,
           status,
           privilege_required,
           detected_at,
           first_observed_at,
           last_observed_at,
           source_type,
           source_scanner,
           tags_json,
           created_at,
           updated_at
         FROM normalized_findings
         WHERE upload_job_id = ?
         ORDER BY created_at ASC`,
      )
      .bind(uploadJobId)
      .all<NormalizedFindingRow>();

    return rows.map(mapNormalizedFindingRow);
  }

  async listAll() {
    const rows = await this.db
      .prepare(
        `SELECT
           id,
           upload_job_id,
           raw_record_ref_json,
           asset_identifier,
           hostname,
           fqdn,
           ip_address,
           port,
           protocol,
           vulnerability_id,
           plugin_id,
           cve_ids_json,
           title,
           description,
           severity,
           normalized_severity,
           cvss_score,
           cvss_vector,
           remediation,
           evidence,
           status,
           privilege_required,
           detected_at,
           first_observed_at,
           last_observed_at,
           source_type,
           source_scanner,
           tags_json,
           created_at,
           updated_at
         FROM normalized_findings
         ORDER BY created_at DESC`,
      )
      .all<NormalizedFindingRow>();

    return rows.map(mapNormalizedFindingRow);
  }

  async listAllByTenant(tenantId: string) {
    const rows = await this.db
      .prepare(
        `SELECT
           nf.id,
           nf.upload_job_id,
           nf.raw_record_ref_json,
           nf.asset_identifier,
           nf.hostname,
           nf.fqdn,
           nf.ip_address,
           nf.port,
           nf.protocol,
           nf.vulnerability_id,
           nf.plugin_id,
           nf.cve_ids_json,
           nf.title,
           nf.description,
           nf.severity,
           nf.normalized_severity,
           nf.cvss_score,
           nf.cvss_vector,
           nf.remediation,
           nf.evidence,
           nf.status,
           nf.privilege_required,
           nf.detected_at,
           nf.first_observed_at,
           nf.last_observed_at,
           nf.source_type,
           nf.source_scanner,
           nf.tags_json,
           nf.created_at,
           nf.updated_at
         FROM normalized_findings nf
         INNER JOIN upload_jobs uj ON uj.id = nf.upload_job_id
         WHERE uj.tenant_id = ?
         ORDER BY nf.created_at DESC`,
      )
      .bind(tenantId)
      .all<NormalizedFindingRow>();

    return rows.map(mapNormalizedFindingRow);
  }

  async replaceForUploadJob(uploadJobId: string, findings: NormalizedFinding[]) {
    await this.db
      .prepare(`DELETE FROM normalized_findings WHERE upload_job_id = ?`)
      .bind(uploadJobId)
      .run();

    for (const finding of findings) {
      await this.db
        .prepare(
          `INSERT INTO normalized_findings (
             id,
             upload_job_id,
             raw_record_ref_json,
             asset_identifier,
             hostname,
             fqdn,
             ip_address,
             port,
             protocol,
             vulnerability_id,
             plugin_id,
             cve_ids_json,
             title,
             description,
             severity,
             normalized_severity,
             cvss_score,
             cvss_vector,
             remediation,
             evidence,
             status,
             privilege_required,
             detected_at,
             first_observed_at,
             last_observed_at,
             source_type,
             source_scanner,
             tags_json,
             created_at,
             updated_at
           ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        )
        .bind(
          finding.id,
          finding.uploadJobId,
          JSON.stringify(finding.rawRecordRef),
          finding.assetIdentifier,
          finding.hostname,
          finding.fqdn,
          finding.ipAddress,
          finding.port,
          finding.protocol,
          finding.vulnerabilityId,
          finding.pluginId,
          JSON.stringify(finding.cveIds),
          finding.title,
          finding.description,
          finding.severity,
          finding.normalizedSeverity,
          finding.cvssScore,
          finding.cvssVector,
          finding.remediation,
          finding.evidence,
          finding.status,
          finding.privilegeRequired,
          finding.detectedAt,
          finding.firstObservedAt,
          finding.lastObservedAt,
          finding.sourceType,
          finding.sourceScanner,
          JSON.stringify(finding.tags),
          finding.createdAt,
          finding.updatedAt,
        )
        .run();
    }
  }
}

export class SqlUploadRepository implements UploadRepository {
  readonly rawArtifacts: RawArtifactRepository;
  readonly uploadJobs: UploadJobRepository;
  readonly parseOutcomes: ParseOutcomeRepository;
  readonly normalizedFindings: NormalizedFindingRepository;

  constructor(private readonly db: AppDatabase) {
    this.rawArtifacts = new SqlRawArtifactRepository(db);
    this.uploadJobs = new SqlUploadJobRepository(db);
    this.parseOutcomes = new SqlParseOutcomeRepository(db);
    this.normalizedFindings = new SqlNormalizedFindingRepository(db);
  }

  async findByChecksum(checksumSha256: ChecksumSha256): Promise<UploadRecord | null> {
    const row = await this.db
      .prepare(
        `SELECT
           uj.id,
           uj.tenant_id,
           uj.raw_artifact_id,
           uj.selected_source_type,
           uj.detected_source_type,
           uj.status,
           uj.error_summary,
           uj.warning_count,
           uj.finding_count,
           uj.checksum_sha256,
           uj.created_at,
           uj.updated_at,
           uj.parsed_at,
           ra.storage_key,
           ra.original_filename,
           ra.mime_type,
           ra.file_type,
           ra.size_bytes,
           ra.uploaded_at
         FROM upload_jobs uj
         INNER JOIN raw_artifacts ra ON ra.id = uj.raw_artifact_id
         WHERE uj.checksum_sha256 = ?
         ORDER BY uj.created_at DESC
         LIMIT 1`,
      )
      .bind(checksumSha256)
      .first<UploadJoinRow>();

    return row ? mapJoinedUploadRow(row) : null;
  }

  async findByChecksumForTenant(
    checksumSha256: ChecksumSha256,
    tenantId: string | null,
  ): Promise<UploadRecord | null> {
    const tenantFilter = buildTenantWhereClause(tenantId);
    const row = await this.db
      .prepare(
        `SELECT
           uj.id,
           uj.tenant_id,
           uj.raw_artifact_id,
           uj.selected_source_type,
           uj.detected_source_type,
           uj.status,
           uj.error_summary,
           uj.warning_count,
           uj.finding_count,
           uj.checksum_sha256,
           uj.created_at,
           uj.updated_at,
           uj.parsed_at,
           ra.storage_key,
           ra.original_filename,
           ra.mime_type,
           ra.file_type,
           ra.size_bytes,
           ra.uploaded_at
         FROM upload_jobs uj
         INNER JOIN raw_artifacts ra ON ra.id = uj.raw_artifact_id
         WHERE uj.checksum_sha256 = ? AND uj.${tenantFilter.clause}
         ORDER BY uj.created_at DESC
         LIMIT 1`,
      )
      .bind(checksumSha256, ...tenantFilter.params)
      .first<UploadJoinRow>();

    return row ? mapJoinedUploadRow(row) : null;
  }

  async findById(uploadJobId: string): Promise<UploadRecordWithOutcome | null> {
    const row = await this.db
      .prepare(
        `SELECT
           uj.id,
           uj.tenant_id,
           uj.raw_artifact_id,
           uj.selected_source_type,
           uj.detected_source_type,
           uj.status,
           uj.error_summary,
           uj.warning_count,
           uj.finding_count,
           uj.checksum_sha256,
           uj.created_at,
           uj.updated_at,
           uj.parsed_at,
           ra.storage_key,
           ra.original_filename,
           ra.mime_type,
           ra.file_type,
           ra.size_bytes,
           ra.uploaded_at
         FROM upload_jobs uj
         INNER JOIN raw_artifacts ra ON ra.id = uj.raw_artifact_id
         WHERE uj.id = ?
         LIMIT 1`,
      )
      .bind(uploadJobId)
      .first<UploadJoinRow>();

    if (!row) {
      return null;
    }

    const outcome = await this.parseOutcomes.findByUploadJobId(uploadJobId);
    const findings = await this.normalizedFindings.findByUploadJobId(uploadJobId);

    return {
      ...mapJoinedUploadRow(row),
      outcome: outcome
        ? {
            ...outcome,
            findings,
          }
        : null,
    };
  }

  async findByIdForTenant(uploadJobId: string, tenantId: string): Promise<UploadRecordWithOutcome | null> {
    const row = await this.db
      .prepare(
        `SELECT
           uj.id,
           uj.tenant_id,
           uj.raw_artifact_id,
           uj.selected_source_type,
           uj.detected_source_type,
           uj.status,
           uj.error_summary,
           uj.warning_count,
           uj.finding_count,
           uj.checksum_sha256,
           uj.created_at,
           uj.updated_at,
           uj.parsed_at,
           ra.storage_key,
           ra.original_filename,
           ra.mime_type,
           ra.file_type,
           ra.size_bytes,
           ra.uploaded_at
         FROM upload_jobs uj
         INNER JOIN raw_artifacts ra ON ra.id = uj.raw_artifact_id
         WHERE uj.id = ? AND uj.tenant_id = ?
         LIMIT 1`,
      )
      .bind(uploadJobId, tenantId)
      .first<UploadJoinRow>();

    if (!row) {
      return null;
    }

    const outcome = await this.parseOutcomes.findByUploadJobId(uploadJobId);
    const findings = await this.normalizedFindings.findByUploadJobId(uploadJobId);

    return {
      ...mapJoinedUploadRow(row),
      outcome: outcome
        ? {
            ...outcome,
            findings,
          }
        : null,
    };
  }

  async save(input: { uploadJob: UploadJob; rawArtifact: RawArtifact }) {
    await this.rawArtifacts.save(input.rawArtifact);
    await this.uploadJobs.save(input.uploadJob);
  }

  async updateUploadJob(uploadJob: UploadJob) {
    await this.uploadJobs.update(uploadJob);
  }

  async saveParseOutcome(outcome: StoredParseOutcome) {
    await this.parseOutcomes.save(outcome);
    await this.normalizedFindings.replaceForUploadJob(outcome.uploadJobId, outcome.findings);
  }

  async list() {
    const rows = await this.db
      .prepare(
        `SELECT
           uj.id,
           uj.tenant_id,
           uj.raw_artifact_id,
           uj.selected_source_type,
           uj.detected_source_type,
           uj.status,
           uj.error_summary,
           uj.warning_count,
           uj.finding_count,
           uj.checksum_sha256,
           uj.created_at,
           uj.updated_at,
           uj.parsed_at,
           ra.storage_key,
           ra.original_filename,
           ra.mime_type,
           ra.file_type,
           ra.size_bytes,
           ra.uploaded_at
         FROM upload_jobs uj
         INNER JOIN raw_artifacts ra ON ra.id = uj.raw_artifact_id
         ORDER BY uj.created_at DESC`,
      )
      .all<UploadJoinRow>();

    return rows.map(mapJoinedUploadRow);
  }

  async listByTenant(tenantId: string) {
    const rows = await this.db
      .prepare(
        `SELECT
           uj.id,
           uj.tenant_id,
           uj.raw_artifact_id,
           uj.selected_source_type,
           uj.detected_source_type,
           uj.status,
           uj.error_summary,
           uj.warning_count,
           uj.finding_count,
           uj.checksum_sha256,
           uj.created_at,
           uj.updated_at,
           uj.parsed_at,
           ra.storage_key,
           ra.original_filename,
           ra.mime_type,
           ra.file_type,
           ra.size_bytes,
           ra.uploaded_at
         FROM upload_jobs uj
         INNER JOIN raw_artifacts ra ON ra.id = uj.raw_artifact_id
         WHERE uj.tenant_id = ?
         ORDER BY uj.created_at DESC`,
      )
      .bind(tenantId)
      .all<UploadJoinRow>();

    return rows.map(mapJoinedUploadRow);
  }

  async listFindingsByTenant(tenantId: string) {
    return this.normalizedFindings.listAllByTenant(tenantId);
  }

  async findFindingByIdForTenant(findingId: string, tenantId: string) {
    const row = await this.db
      .prepare(
        `SELECT
           nf.id,
           nf.upload_job_id,
           nf.raw_record_ref_json,
           nf.asset_identifier,
           nf.hostname,
           nf.fqdn,
           nf.ip_address,
           nf.port,
           nf.protocol,
           nf.vulnerability_id,
           nf.plugin_id,
           nf.cve_ids_json,
           nf.title,
           nf.description,
           nf.severity,
           nf.normalized_severity,
           nf.cvss_score,
           nf.cvss_vector,
           nf.remediation,
           nf.evidence,
           nf.status,
           nf.privilege_required,
           nf.detected_at,
           nf.first_observed_at,
           nf.last_observed_at,
           nf.source_type,
           nf.source_scanner,
           nf.tags_json,
           nf.created_at,
           nf.updated_at
         FROM normalized_findings nf
         INNER JOIN upload_jobs uj ON uj.id = nf.upload_job_id
         WHERE nf.id = ? AND uj.tenant_id = ?
         LIMIT 1`,
      )
      .bind(findingId, tenantId)
      .first<NormalizedFindingRow>();

    return row ? mapNormalizedFindingRow(row) : null;
  }
}
