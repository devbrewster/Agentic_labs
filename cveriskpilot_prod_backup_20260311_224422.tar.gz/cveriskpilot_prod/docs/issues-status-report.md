# CVERiskPilot Pending Issues Status Report

Last updated: 2026-03-12

## Summary

- Total open issues: 6
- P0 Now: 2
- P1 Next: 3
- P2 Later: 1
- In progress: 1
- Blocked: 1
- Queued: 3
- Monitoring: 1

## Structured issue list

### ISSUE-001 - Complete dashboard auth and tenant scoping

- Priority: P0 Now
- Status: in progress
- Track: Dashboard Access
- Summary: Dashboard layout is now gated and reports are org-scoped, but the remaining dashboard-facing services still need an audit for unscoped fallback reads.
- Impact: This is the primary barrier to trusting dashboard and report isolation across organizations.
- Next action: Audit all dashboard child routes and add redirect coverage for unauthenticated access.

### ISSUE-002 - Fix selected-finding enrichment signals after completed provider runs

- Priority: P0 Now
- Status: blocked
- Track: Enrichment
- Summary: Persisted KEV/NVD/provider snapshots still do not render reliably in the selected finding view under all list hydration conditions.
- Impact: Users can see stale pending signals even when enrichment has already completed, which undermines confidence in the source data.
- Next action: Trace the source-of-truth path between findings list, enrichment detail API, and the detail rail, then add a large-list regression test.

### ISSUE-003 - Harden upload validation and ingestion orchestration

- Priority: P1 Next
- Status: queued
- Track: Ingestion
- Summary: Core uploads work, but the platform still needs stricter validation, safer artifact handling, and less manual orchestration in parse/enrichment execution.
- Impact: Upload reliability and enterprise trust remain limited until ingestion is safer and more deterministic.
- Next action: Add stricter upload validation, audit events, and continue moving parse/enrichment work off fragile request-path assumptions.

### ISSUE-004 - Implement Stripe checkout, webhook ingestion, and server-side entitlements

- Priority: P1 Next
- Status: queued
- Track: Billing
- Summary: Stripe CLI is available locally, but the application still lacks checkout, webhook handling, subscription state updates, and paywall enforcement.
- Impact: The product cannot move from beta workflow validation to monetized SaaS operation without this layer.
- Next action: Build checkout + webhook routes, then wire org-scoped usage enforcement before exposing paid plans.

### ISSUE-005 - Add compliance-grade upload audit events and retrieval surfaces

- Priority: P1 Next
- Status: queued
- Track: Audit
- Summary: Audit event persistence and retrieval APIs are still backlog items, and there is no internal dashboard view for upload/compliance tracking yet.
- Impact: Support, compliance, and incident-review workflows are weaker without append-only audit history.
- Next action: Implement upload audit event persistence, retrieval APIs, and an internal operator view.

### ISSUE-006 - Clean up remaining UI polish and placeholder copy drift

- Priority: P2 Later
- Status: monitoring
- Track: UI
- Summary: Most production-facing scaffold copy is gone, but some typography and low-risk cosmetic issues still remain in backlog.
- Impact: This does not block core behavior, but it still affects perceived quality.
- Next action: Address only after access control, enrichment truthfulness, ingestion hardening, and billing are stable.
