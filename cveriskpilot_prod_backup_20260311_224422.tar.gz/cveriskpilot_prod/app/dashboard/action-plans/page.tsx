import { ActionPlansBoard } from "@/components/dashboard/ActionPlansBoard";

export default function ActionPlansPage() {
  return <ActionPlansBoard />;
}
