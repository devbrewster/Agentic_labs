import type { FindingEnrichmentSnapshot } from "@/types/enrichment";
import type { Finding } from "@/types/dashboard";

type SnapshotPayload = {
  kevListed?: boolean | null;
  exploitAvailable?: boolean | null;
  cvssScore?: number | null;
  cvssVector?: string | null;
};

function asPayload(summaryJson: FindingEnrichmentSnapshot["summaryJson"]): SnapshotPayload {
  if (!summaryJson || typeof summaryJson !== "object") {
    return {};
  }

  return summaryJson as unknown as SnapshotPayload;
}

export function buildEnrichmentSummary(
  snapshots: FindingEnrichmentSnapshot[],
): NonNullable<Finding["enrichmentSummary"]> {
  if (snapshots.length === 0) {
    return {
      status: "pending",
      providers: [],
    };
  }

  const providers = Array.from(new Set(snapshots.map((snapshot) => snapshot.provider))).sort();
  const hasError = snapshots.some((snapshot) => snapshot.status === "error");
  const hasEnriched = snapshots.some((snapshot) => snapshot.status === "enriched");
  const hasNotFound = snapshots.some((snapshot) => snapshot.status === "not_found");

  const status: NonNullable<Finding["enrichmentSummary"]>["status"] = (() => {
    if (hasEnriched && hasError) {
      return "partial";
    }
    if (hasError && !hasEnriched && !hasNotFound) {
      return "failed";
    }
    if (hasEnriched) {
      return "enriched";
    }
    if (hasNotFound) {
      return "not_found";
    }
    return "pending";
  })();

  const observedAtValues = snapshots
    .map((snapshot) => snapshot.observedAt ?? snapshot.createdAt)
    .filter(Boolean)
    .sort();
  const lastObservedAt = observedAtValues[observedAtValues.length - 1];

  const payloads = snapshots.map((snapshot) => asPayload(snapshot.summaryJson));
  const kevListed = payloads.find((payload) => payload.kevListed === true)?.kevListed;
  const exploitAvailable = payloads.find((payload) => payload.exploitAvailable === true)?.exploitAvailable;
  const cvssScore = payloads.find((payload) => typeof payload.cvssScore === "number")?.cvssScore ?? undefined;
  const cvssVector = payloads.find((payload) => typeof payload.cvssVector === "string")?.cvssVector ?? undefined;

  return {
    status,
    providers,
    lastObservedAt,
    kevListed: kevListed ?? undefined,
    exploitAvailable: exploitAvailable ?? undefined,
    cvssScore,
    cvssVector,
  };
}
