import type { VulnerabilityRecord } from "@/lib/nvd/types";

export type NvdCacheEntry = {
  key: string;
  cveId: string;
  fetchedAt: string;
  expiresAt: string;
  rawPayload: unknown;
  normalized: VulnerabilityRecord;
};

export type NvdCacheProvider = {
  get(key: string): Promise<NvdCacheEntry | null>;
  set(entry: NvdCacheEntry): Promise<void>;
};

export class InMemoryNvdCache implements NvdCacheProvider {
  private readonly map = new Map<string, NvdCacheEntry>();

  async get(key: string): Promise<NvdCacheEntry | null> {
    return this.map.get(key) ?? null;
  }

  async set(entry: NvdCacheEntry) {
    this.map.set(entry.key, entry);
  }
}

export function buildNvdCacheKey(cveId: string) {
  return `nvd:cve:${cveId.toUpperCase()}`;
}

export function isCacheEntryFresh(entry: NvdCacheEntry, nowIso: string) {
  return entry.expiresAt > nowIso;
}
