const nodemailer = require("nodemailer");

import { verificationWindowMinutes } from "@/lib/auth";

type MailTransportBundle = {
  transport: {
    sendMail: (options: Record<string, unknown>) => Promise<Record<string, unknown>>;
  };
};

type VerificationMailArgs = {
  to: string;
  displayName: string;
  verificationUrl: string;
};

type PasswordResetMailArgs = {
  to: string;
  displayName: string;
  resetUrl: string;
};

let transportPromise: Promise<MailTransportBundle> | null = null;

function getMailFrom() {
  return process.env.MAIL_FROM?.trim() || "CVERiskPilot <no-reply@cveriskpilot.local>";
}

function getConfiguredTransport() {
  const host = process.env.SMTP_HOST?.trim();
  const port = Number(process.env.SMTP_PORT || "587");
  const user = process.env.SMTP_USER?.trim();
  const pass = process.env.SMTP_PASS?.trim();
  const secure = process.env.SMTP_SECURE === "true" || port === 465;

  if (!host) {
    return null;
  }

  return {
    transport: nodemailer.createTransport({
      host,
      port,
      secure,
      auth: user && pass ? { user, pass } : undefined,
    }),
  } satisfies MailTransportBundle;
}

async function getTransportBundle() {
  if (transportPromise) {
    return transportPromise;
  }

  transportPromise = (async () => {
    const configured = getConfiguredTransport();

    if (configured) {
      return configured;
    }

    if (process.env.NODE_ENV === "production") {
      throw new Error("SMTP configuration is required in production.");
    }

    const testAccount = await nodemailer.createTestAccount();

    return {
      transport: nodemailer.createTransport({
        host: testAccount.smtp.host,
        port: testAccount.smtp.port,
        secure: testAccount.smtp.secure,
        auth: {
          user: testAccount.user,
          pass: testAccount.pass,
        },
      }),
    } satisfies MailTransportBundle;
  })();

  return transportPromise;
}

export async function sendVerificationEmail({
  to,
  displayName,
  verificationUrl,
}: VerificationMailArgs) {
  const { transport } = await getTransportBundle();
  const expiresInMinutes = verificationWindowMinutes();

  const info = await transport.sendMail({
    from: getMailFrom(),
    to,
    subject: "Verify your CVERiskPilot account",
    text: [
      `Hello ${displayName},`,
      "",
      "Verify your CVERiskPilot account by opening the link below:",
      verificationUrl,
      "",
      `This link expires in ${expiresInMinutes} minutes.`,
    ].join("\n"),
    html: `
      <div style="font-family:Arial,sans-serif;line-height:1.6;color:#d7e4f2;background:#040810;padding:24px">
        <div style="max-width:560px;margin:0 auto;background:#070e1a;border:1px solid rgba(0,200,180,.2);padding:32px;border-radius:8px">
          <h1 style="margin:0 0 12px;color:#ffffff;font-size:24px">Verify your CVERiskPilot account</h1>
          <p style="margin:0 0 16px;color:#c8d8e8">Hello ${displayName},</p>
          <p style="margin:0 0 24px;color:#8ca2b4">Confirm your email address to activate your account and sign in.</p>
          <p style="margin:0 0 24px">
            <a href="${verificationUrl}" style="display:inline-block;background:#00c8b4;color:#040810;text-decoration:none;font-weight:700;padding:12px 20px;border-radius:4px">Verify Email</a>
          </p>
          <p style="margin:0 0 8px;color:#8ca2b4">If the button does not work, use this link:</p>
          <p style="margin:0 0 16px;word-break:break-all"><a href="${verificationUrl}" style="color:#00c8b4">${verificationUrl}</a></p>
          <p style="margin:0;color:#8ca2b4">This link expires in ${expiresInMinutes} minutes.</p>
        </div>
      </div>
    `,
  });

  return {
    messageId:
      typeof info.messageId === "string" ? info.messageId : undefined,
    previewUrl: nodemailer.getTestMessageUrl(info) ?? undefined,
  };
}

export async function sendPasswordResetEmail({
  to,
  displayName,
  resetUrl,
}: PasswordResetMailArgs) {
  const { transport } = await getTransportBundle();
  const expiresInMinutes = verificationWindowMinutes();

  const info = await transport.sendMail({
    from: getMailFrom(),
    to,
    subject: "Reset your CVERiskPilot password",
    text: [
      `Hello ${displayName},`,
      "",
      "Reset your CVERiskPilot password by opening the link below:",
      resetUrl,
      "",
      `This link expires in ${expiresInMinutes} minutes.`,
      "If you did not request this reset, you can ignore this email.",
    ].join("\n"),
    html: `
      <div style="font-family:Arial,sans-serif;line-height:1.6;color:#d7e4f2;background:#040810;padding:24px">
        <div style="max-width:560px;margin:0 auto;background:#070e1a;border:1px solid rgba(0,200,180,.2);padding:32px;border-radius:8px">
          <h1 style="margin:0 0 12px;color:#ffffff;font-size:24px">Reset your password</h1>
          <p style="margin:0 0 16px;color:#c8d8e8">Hello ${displayName},</p>
          <p style="margin:0 0 24px;color:#8ca2b4">Use the link below to set a new password for your CVERiskPilot account.</p>
          <p style="margin:0 0 24px">
            <a href="${resetUrl}" style="display:inline-block;background:#00c8b4;color:#040810;text-decoration:none;font-weight:700;padding:12px 20px;border-radius:4px">Reset Password</a>
          </p>
          <p style="margin:0 0 8px;color:#8ca2b4">If the button does not work, use this link:</p>
          <p style="margin:0 0 16px;word-break:break-all"><a href="${resetUrl}" style="color:#00c8b4">${resetUrl}</a></p>
          <p style="margin:0 0 8px;color:#8ca2b4">This link expires in ${expiresInMinutes} minutes.</p>
          <p style="margin:0;color:#8ca2b4">If you did not request this reset, you can ignore this email.</p>
        </div>
      </div>
    `,
  });

  return {
    messageId:
      typeof info.messageId === "string" ? info.messageId : undefined,
    previewUrl: nodemailer.getTestMessageUrl(info) ?? undefined,
  };
}
