import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

import { GET as getNvdRoute } from "@/app/api/nvd/route";
import { __resetNvdClientForTests } from "@/lib/nvd/client";

const originalFetch = globalThis.fetch;
const originalEnv = {
  NVD_API_KEY: process.env.NVD_API_KEY,
  NVD_CACHE_TTL_MINUTES: process.env.NVD_CACHE_TTL_MINUTES,
  NVD_REQUEST_TIMEOUT_MS: process.env.NVD_REQUEST_TIMEOUT_MS,
};

describe("NVD API fallback and safety", () => {
  beforeEach(() => {
    __resetNvdClientForTests();
    process.env.NVD_API_KEY = "secret-test-key";
    process.env.NVD_CACHE_TTL_MINUTES = "60";
    process.env.NVD_REQUEST_TIMEOUT_MS = "5000";
  });

  afterEach(() => {
    globalThis.fetch = originalFetch;
    process.env.NVD_API_KEY = originalEnv.NVD_API_KEY;
    process.env.NVD_CACHE_TTL_MINUTES = originalEnv.NVD_CACHE_TTL_MINUTES;
    process.env.NVD_REQUEST_TIMEOUT_MS = originalEnv.NVD_REQUEST_TIMEOUT_MS;
    __resetNvdClientForTests();
  });

  it("does not leak API key in response payload", async () => {
    globalThis.fetch = vi.fn(async () =>
      new Response(
        JSON.stringify({
          vulnerabilities: [
            {
              cve: {
                id: "CVE-2024-4242",
                descriptions: [{ lang: "en", value: "Leak test description." }],
              },
            },
          ],
        }),
        { status: 200 },
      )) as typeof fetch;

    const response = await getNvdRoute(
      new Request("http://localhost/api/nvd?cve=CVE-2024-4242"),
    );
    const body = await response.text();

    expect(response.status).toBe(200);
    expect(body).not.toContain("secret-test-key");
    expect(body).not.toContain("apiKey");
  });

  it("returns graceful error payload when upstream fails without cache", async () => {
    globalThis.fetch = vi.fn(async () => {
      throw new Error("upstream unavailable");
    }) as typeof fetch;

    const response = await getNvdRoute(
      new Request("http://localhost/api/nvd?cve=CVE-2024-5252"),
    );
    const json = (await response.json()) as {
      ok: boolean;
      error: { code: string; message: string };
    };

    expect(response.status).toBe(503);
    expect(json.ok).toBe(false);
    expect(json.error.code).toBe("network_error");
  });

});
