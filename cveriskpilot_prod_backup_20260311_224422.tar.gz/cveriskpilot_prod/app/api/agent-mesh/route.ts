import { NextResponse } from "next/server";

import { getAgentMeshMonitorSnapshot } from "@/lib/agent-mesh/monitor";
import { requireCurrentOrganizationAccess } from "@/lib/organizations/access";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  if (process.env.NODE_ENV === "production") {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "not_available",
          message: "Agent mesh monitor is only available in local development.",
        },
      },
      { status: 404 },
    );
  }

  const auth = await requireCurrentOrganizationAccess(request);

  if (!auth.ok) {
    return auth.response;
  }

  try {
    const snapshot = await getAgentMeshMonitorSnapshot();

    return NextResponse.json({
      ok: true,
      data: snapshot,
    });
  } catch (error) {
    return NextResponse.json(
      {
        ok: false,
        error: {
          code: "agent_mesh_monitor_failed",
          message:
            error instanceof Error
              ? error.message
              : "Unable to read local agent mesh state.",
        },
      },
      { status: 500 },
    );
  }
}
