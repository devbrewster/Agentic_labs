import {
  apiError,
  createOpaqueToken,
  getNow,
  getUserById,
  hydrateUserOrganizationContext,
  sanitizeUser,
  toIso,
} from "@/lib/auth";
import { dbFirst, dbRun } from "@/lib/db";
import {
  ensureUserBelongsToOrganization,
  getResolvedOrganizationContext,
} from "@/lib/organizations/service";
import type { SafeUser, SessionRecord } from "@/types/auth";

const SESSION_COOKIE_NAME = "cveriskpilot_session";
const SESSION_TTL_MS = 30 * 24 * 60 * 60 * 1000;

type SessionWithUser = {
  session: SessionRecord;
  user: SafeUser;
};

function getSessionCookieSecureFlag(request?: Request) {
  if (process.env.NODE_ENV === "production") {
    return true;
  }

  if (process.env.APP_BASE_URL?.startsWith("https://")) {
    return true;
  }

  return request ? new URL(request.url).protocol === "https:" : false;
}

function getCookieValue(cookieHeader: string | null, name: string) {
  if (!cookieHeader) {
    return null;
  }

  const match = cookieHeader
    .split(";")
    .map((part) => part.trim())
    .find((part) => part.startsWith(`${name}=`));

  return match ? match.slice(name.length + 1) : null;
}

function getClientIpAddress(request: Request) {
  const cfIp = request.headers.get("cf-connecting-ip");
  if (cfIp) {
    return cfIp;
  }

  const forwardedFor = request.headers.get("x-forwarded-for");
  if (forwardedFor) {
    return forwardedFor.split(",")[0]?.trim() ?? null;
  }

  return null;
}

export function getSessionCookieName() {
  return SESSION_COOKIE_NAME;
}

export function setSessionCookie(
  response: {
    cookies: {
      set: (options: {
        name: string;
        value: string;
        httpOnly: boolean;
        sameSite: "lax";
        secure: boolean;
        path: string;
        expires: Date;
      }) => void;
    };
  },
  sessionId: string,
  expiresAt: string,
  request?: Request,
) {
  response.cookies.set({
    name: SESSION_COOKIE_NAME,
    value: sessionId,
    httpOnly: true,
    sameSite: "lax",
    secure: getSessionCookieSecureFlag(request),
    path: "/",
    expires: new Date(expiresAt),
  });
}

export function clearSessionCookie(
  response: {
    cookies: {
      set: (options: {
        name: string;
        value: string;
        httpOnly: boolean;
        sameSite: "lax";
        secure: boolean;
        path: string;
        expires: Date;
      }) => void;
    };
  },
  request?: Request,
) {
  response.cookies.set({
    name: SESSION_COOKIE_NAME,
    value: "",
    httpOnly: true,
    sameSite: "lax",
    secure: getSessionCookieSecureFlag(request),
    path: "/",
    expires: new Date(0),
  });
}

export async function createSession(userId: string, request: Request) {
  const now = getNow();
  const expiresAt = new Date(now.getTime() + SESSION_TTL_MS);
  const sessionId = createOpaqueToken(32);
  const { activeOrganizationId } = await getResolvedOrganizationContext(userId);

  await dbRun(
    `INSERT INTO sessions (
      id,
      user_id,
      expires_at,
      created_at,
      user_agent,
      ip_address,
      revoked_at
    ) VALUES (?, ?, ?, ?, ?, ?, NULL)`,
    sessionId,
    userId,
    toIso(expiresAt),
    toIso(now),
    request.headers.get("user-agent"),
    getClientIpAddress(request),
  );

  await dbRun(
    `INSERT INTO session_organization_context (
      session_id,
      active_organization_id,
      created_at,
      updated_at
    ) VALUES (?, ?, ?, ?)`,
    sessionId,
    activeOrganizationId,
    toIso(now),
    toIso(now),
  );

  return {
    id: sessionId,
    active_organization_id: activeOrganizationId,
    expires_at: toIso(expiresAt),
    created_at: toIso(now),
  };
}

export async function revokeSession(sessionId: string) {
  await dbRun(
    `UPDATE sessions
     SET revoked_at = COALESCE(revoked_at, ?)
     WHERE id = ?`,
    toIso(getNow()),
    sessionId,
  );
}

export async function revokeAllSessions(userId: string) {
  await dbRun(
    `UPDATE sessions
     SET revoked_at = COALESCE(revoked_at, ?)
     WHERE user_id = ? AND revoked_at IS NULL`,
    toIso(getNow()),
    userId,
  );
}

export async function setActiveOrganizationForSession(
  sessionId: string,
  userId: string,
  organizationId: string,
) {
  const belongsToOrganization = await ensureUserBelongsToOrganization(
    userId,
    organizationId,
  );

  if (!belongsToOrganization) {
    return false;
  }

  await dbRun(
    `INSERT INTO session_organization_context (
       session_id,
       active_organization_id,
       created_at,
       updated_at
     ) VALUES (?, ?, ?, ?)
     ON CONFLICT(session_id) DO UPDATE SET
       active_organization_id = excluded.active_organization_id,
       updated_at = excluded.updated_at`,
    sessionId,
    organizationId,
    toIso(getNow()),
    toIso(getNow()),
  );

  return true;
}

export async function getAuthenticatedSession(request: Request): Promise<SessionWithUser | null> {
  const sessionId = getCookieValue(request.headers.get("cookie"), SESSION_COOKIE_NAME);

  if (!sessionId) {
    return null;
  }

  const session = await dbFirst<SessionRecord>(
    `SELECT
       s.id,
       s.user_id,
       soc.active_organization_id,
       s.expires_at,
       s.created_at,
       s.user_agent,
       s.ip_address,
       s.revoked_at
     FROM sessions s
     LEFT JOIN session_organization_context soc ON soc.session_id = s.id
     WHERE id = ?
     LIMIT 1`,
    sessionId,
  );

  if (!session || session.revoked_at) {
    return null;
  }

  if (new Date(session.expires_at).getTime() <= Date.now()) {
    return null;
  }

  const user = await getUserById(session.user_id);

  if (!user) {
    return null;
  }

  const hydratedUser = await hydrateUserOrganizationContext(sanitizeUser(user));
  const activeOrganizationId =
    hydratedUser.current_organization_id ?? session.active_organization_id ?? null;

  if (activeOrganizationId !== session.active_organization_id) {
    await dbRun(
      `INSERT INTO session_organization_context (
         session_id,
         active_organization_id,
         created_at,
         updated_at
       ) VALUES (?, ?, ?, ?)
       ON CONFLICT(session_id) DO UPDATE SET
         active_organization_id = excluded.active_organization_id,
         updated_at = excluded.updated_at`,
      session.id,
      activeOrganizationId,
      toIso(getNow()),
      toIso(getNow()),
    );
  }

  return {
    session: {
      ...session,
      active_organization_id: activeOrganizationId,
    },
    user: hydratedUser,
  };
}

export async function requireAuthenticatedSession(request: Request) {
  const session = await getAuthenticatedSession(request);

  if (!session) {
    return {
      ok: false as const,
      response: apiError("not_authenticated", "Authentication is required.", 401),
    };
  }

  return {
    ok: true as const,
    session,
  };
}
