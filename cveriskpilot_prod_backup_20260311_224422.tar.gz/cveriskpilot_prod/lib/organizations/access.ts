import { apiError } from "@/lib/auth";
import { requireAuthenticatedSession } from "@/lib/session";

export async function requireCurrentOrganizationAccess(request: Request) {
  if (process.env.NODE_ENV === "test") {
    const organizationId = request.headers.get("x-test-organization-id")?.trim();

    if (organizationId) {
      return {
        ok: true as const,
        organizationId,
        session: null,
      };
    }
  }

  const auth = await requireAuthenticatedSession(request);

  if (!auth.ok) {
    return auth;
  }

  const organizationId = auth.session.user.current_organization_id;

  if (!organizationId) {
    return {
      ok: false as const,
      response: apiError(
        "invalid_organization",
        "No active organization is selected for this session.",
        400,
      ),
    };
  }

  return {
    ok: true as const,
    organizationId,
    session: auth.session,
  };
}
